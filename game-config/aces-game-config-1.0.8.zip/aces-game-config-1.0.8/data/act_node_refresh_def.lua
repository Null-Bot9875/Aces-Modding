local act_node_refresh_def = {}
local ConfigRowRuntime = require("common/config/ConfigRowRuntime")

--config
local config_num = 330
local config_schema =
{
    ["groupId"] = { type = "int" },
    ["nodeId"] = { type = "int" },
    ["weight"] = { type = "int" },
    ["limitBaseId"] = { type = "list", item = { type = "int" } },
    ["nodeLimit"] = { type = "int" },
}
local config_runtime_schema = config_schema
local config_source =
{
    [1] = {groupId=2100,nodeId=5102,weight=1,limitBaseId={},nodeLimit=1},
    [2] = {groupId=2101,nodeId=5103,weight=1,limitBaseId={},nodeLimit=1},
    [3] = {groupId=2102,nodeId=5104,weight=1,limitBaseId={},nodeLimit=1},
    [4] = {groupId=2103,nodeId=5105,weight=1,limitBaseId={},nodeLimit=1},
    [5] = {groupId=2104,nodeId=5111,weight=1,limitBaseId={},nodeLimit=1},
    [6] = {groupId=2105,nodeId=5106,weight=1,limitBaseId={},nodeLimit=1},
    [7] = {groupId=2111,nodeId=5115,weight=1,limitBaseId={},nodeLimit=1},
    [8] = {groupId=2114,nodeId=5114,weight=1,limitBaseId={},nodeLimit=1},
    [9] = {groupId=2115,nodeId=5107,weight=1,limitBaseId={},nodeLimit=1},
    [10] = {groupId=2376,nodeId=5006,weight=1,limitBaseId={},nodeLimit=0},
    [11] = {groupId=2375,nodeId=5005,weight=1,limitBaseId={},nodeLimit=0},
    [12] = {groupId=2374,nodeId=5004,weight=1,limitBaseId={},nodeLimit=0},
    [13] = {groupId=2373,nodeId=5003,weight=1,limitBaseId={},nodeLimit=0},
    [14] = {groupId=2372,nodeId=5002,weight=1,limitBaseId={},nodeLimit=0},
    [15] = {groupId=2371,nodeId=5001,weight=1,limitBaseId={},nodeLimit=0},
    [16] = {groupId=2008,nodeId=5101,weight=1,limitBaseId={},nodeLimit=1},
    [17] = {groupId=2007,nodeId=4095,weight=1,limitBaseId={},nodeLimit=0},
    [18] = {groupId=2006,nodeId=4021,weight=6,limitBaseId={},nodeLimit=0},
    [19] = {groupId=2004,nodeId=4440,weight=1,limitBaseId={},nodeLimit=0},
    [20] = {groupId=2003,nodeId=2011,weight=6,limitBaseId={},nodeLimit=0},
    [21] = {groupId=2002,nodeId=3200,weight=6,limitBaseId={},nodeLimit=0},
    [22] = {groupId=2001,nodeId=4315,weight=6,limitBaseId={},nodeLimit=0},
    [23] = {groupId=1465,nodeId=4270,weight=6,limitBaseId={},nodeLimit=0},
    [24] = {groupId=1454,nodeId=4193,weight=6,limitBaseId={},nodeLimit=0},
    [25] = {groupId=1453,nodeId=4257,weight=1,limitBaseId={},nodeLimit=1},
    [26] = {groupId=1453,nodeId=4258,weight=1,limitBaseId={},nodeLimit=1},
    [27] = {groupId=1451,nodeId=3218,weight=6,limitBaseId={},nodeLimit=1},
    [28] = {groupId=1451,nodeId=4190,weight=6,limitBaseId={},nodeLimit=1},
    [29] = {groupId=1451,nodeId=4206,weight=3,limitBaseId={},nodeLimit=1},
    [30] = {groupId=1451,nodeId=4207,weight=6,limitBaseId={},nodeLimit=1},
    [31] = {groupId=1451,nodeId=4208,weight=3,limitBaseId={},nodeLimit=1},
    [32] = {groupId=1451,nodeId=4209,weight=3,limitBaseId={},nodeLimit=1},
    [33] = {groupId=1451,nodeId=4249,weight=8,limitBaseId={},nodeLimit=1},
    [34] = {groupId=1451,nodeId=4250,weight=8,limitBaseId={},nodeLimit=1},
    [35] = {groupId=1451,nodeId=4251,weight=8,limitBaseId={},nodeLimit=1},
    [36] = {groupId=1451,nodeId=4252,weight=3,limitBaseId={},nodeLimit=1},
    [37] = {groupId=1451,nodeId=4253,weight=3,limitBaseId={},nodeLimit=1},
    [38] = {groupId=1451,nodeId=4339,weight=1,limitBaseId={},nodeLimit=1},
    [39] = {groupId=1451,nodeId=4340,weight=1,limitBaseId={},nodeLimit=1},
    [40] = {groupId=1451,nodeId=1463,weight=1,limitBaseId={},nodeLimit=1},
    [41] = {groupId=1451,nodeId=1464,weight=1,limitBaseId={},nodeLimit=1},
    [42] = {groupId=1451,nodeId=1472,weight=1,limitBaseId={},nodeLimit=1},
    [43] = {groupId=1451,nodeId=1473,weight=1,limitBaseId={},nodeLimit=1},
    [44] = {groupId=1451,nodeId=1412,weight=1,limitBaseId={},nodeLimit=1},
    [45] = {groupId=1451,nodeId=1474,weight=1,limitBaseId={},nodeLimit=1},
    [46] = {groupId=1451,nodeId=1475,weight=1,limitBaseId={},nodeLimit=1},
    [47] = {groupId=1451,nodeId=1476,weight=1,limitBaseId={},nodeLimit=1},
    [48] = {groupId=1444,nodeId=1400,weight=6,limitBaseId={},nodeLimit=0},
    [49] = {groupId=1443,nodeId=4339,weight=1,limitBaseId={},nodeLimit=1},
    [50] = {groupId=1443,nodeId=4340,weight=0,limitBaseId={1},nodeLimit=1},
    [51] = {groupId=1441,nodeId=3218,weight=1,limitBaseId={},nodeLimit=1},
    [52] = {groupId=1441,nodeId=4190,weight=1,limitBaseId={},nodeLimit=1},
    [53] = {groupId=1441,nodeId=4206,weight=1,limitBaseId={},nodeLimit=1},
    [54] = {groupId=1441,nodeId=4207,weight=1,limitBaseId={},nodeLimit=1},
    [55] = {groupId=1441,nodeId=4208,weight=1,limitBaseId={},nodeLimit=1},
    [56] = {groupId=1441,nodeId=4209,weight=1,limitBaseId={},nodeLimit=1},
    [57] = {groupId=1441,nodeId=4249,weight=1,limitBaseId={},nodeLimit=1},
    [58] = {groupId=1441,nodeId=4250,weight=1,limitBaseId={},nodeLimit=1},
    [59] = {groupId=1441,nodeId=4251,weight=1,limitBaseId={},nodeLimit=1},
    [60] = {groupId=1441,nodeId=4252,weight=1,limitBaseId={},nodeLimit=1},
    [61] = {groupId=1441,nodeId=4253,weight=1,limitBaseId={},nodeLimit=1},
    [62] = {groupId=1441,nodeId=1463,weight=1,limitBaseId={},nodeLimit=1},
    [63] = {groupId=1441,nodeId=1464,weight=1,limitBaseId={},nodeLimit=1},
    [64] = {groupId=1441,nodeId=1472,weight=100,limitBaseId={},nodeLimit=1},
    [65] = {groupId=1441,nodeId=1473,weight=100,limitBaseId={},nodeLimit=1},
    [66] = {groupId=1441,nodeId=1412,weight=100,limitBaseId={},nodeLimit=1},
    [67] = {groupId=1441,nodeId=1474,weight=100,limitBaseId={},nodeLimit=1},
    [68] = {groupId=1434,nodeId=4181,weight=6,limitBaseId={},nodeLimit=0},
    [69] = {groupId=1433,nodeId=4255,weight=1,limitBaseId={},nodeLimit=1},
    [70] = {groupId=1432,nodeId=1432,weight=2,limitBaseId={},nodeLimit=2},
    [71] = {groupId=1432,nodeId=1433,weight=1,limitBaseId={},nodeLimit=2},
    [72] = {groupId=1432,nodeId=1434,weight=1,limitBaseId={},nodeLimit=2},
    [73] = {groupId=1432,nodeId=4003,weight=1,limitBaseId={},nodeLimit=2},
    [74] = {groupId=1432,nodeId=4021,weight=1,limitBaseId={},nodeLimit=2},
    [75] = {groupId=1432,nodeId=4105,weight=1,limitBaseId={},nodeLimit=2},
    [76] = {groupId=1432,nodeId=4106,weight=1,limitBaseId={},nodeLimit=2},
    [77] = {groupId=1432,nodeId=4107,weight=1,limitBaseId={},nodeLimit=2},
    [78] = {groupId=1432,nodeId=4108,weight=1,limitBaseId={},nodeLimit=2},
    [79] = {groupId=1432,nodeId=4226,weight=1,limitBaseId={},nodeLimit=2},
    [80] = {groupId=1432,nodeId=4227,weight=1,limitBaseId={},nodeLimit=2},
    [81] = {groupId=1432,nodeId=4229,weight=1,limitBaseId={},nodeLimit=2},
    [82] = {groupId=1432,nodeId=4230,weight=1,limitBaseId={},nodeLimit=2},
    [83] = {groupId=1432,nodeId=4231,weight=1,limitBaseId={},nodeLimit=2},
    [84] = {groupId=1432,nodeId=4232,weight=2,limitBaseId={},nodeLimit=2},
    [85] = {groupId=1432,nodeId=4235,weight=2,limitBaseId={},nodeLimit=2},
    [86] = {groupId=1432,nodeId=4239,weight=1,limitBaseId={},nodeLimit=-1},
    [87] = {groupId=1432,nodeId=4240,weight=1,limitBaseId={},nodeLimit=2},
    [88] = {groupId=1432,nodeId=4241,weight=1,limitBaseId={},nodeLimit=2},
    [89] = {groupId=1432,nodeId=4316,weight=1,limitBaseId={},nodeLimit=2},
    [90] = {groupId=1432,nodeId=4317,weight=1,limitBaseId={},nodeLimit=2},
    [91] = {groupId=1432,nodeId=4318,weight=1,limitBaseId={},nodeLimit=2},
    [92] = {groupId=1431,nodeId=1403,weight=8,limitBaseId={},nodeLimit=1},
    [93] = {groupId=1431,nodeId=1405,weight=8,limitBaseId={},nodeLimit=1},
    [94] = {groupId=1431,nodeId=1408,weight=3,limitBaseId={},nodeLimit=1},
    [95] = {groupId=1431,nodeId=1411,weight=3,limitBaseId={},nodeLimit=1},
    [96] = {groupId=1431,nodeId=1413,weight=6,limitBaseId={},nodeLimit=1},
    [97] = {groupId=1431,nodeId=1414,weight=5,limitBaseId={},nodeLimit=1},
    [98] = {groupId=1431,nodeId=1417,weight=6,limitBaseId={},nodeLimit=1},
    [99] = {groupId=1431,nodeId=1418,weight=6,limitBaseId={},nodeLimit=1},
    [100] = {groupId=1431,nodeId=3211,weight=8,limitBaseId={},nodeLimit=1},
    [101] = {groupId=1423,nodeId=4254,weight=1,limitBaseId={},nodeLimit=1},
    [102] = {groupId=1422,nodeId=4317,weight=1,limitBaseId={},nodeLimit=2},
    [103] = {groupId=1422,nodeId=1432,weight=2,limitBaseId={},nodeLimit=2},
    [104] = {groupId=1422,nodeId=1433,weight=1,limitBaseId={},nodeLimit=2},
    [105] = {groupId=1422,nodeId=1434,weight=1,limitBaseId={},nodeLimit=2},
    [106] = {groupId=1422,nodeId=4003,weight=1,limitBaseId={},nodeLimit=2},
    [107] = {groupId=1422,nodeId=4006,weight=1,limitBaseId={},nodeLimit=2},
    [108] = {groupId=1422,nodeId=4007,weight=1,limitBaseId={},nodeLimit=2},
    [109] = {groupId=1422,nodeId=4021,weight=1,limitBaseId={},nodeLimit=2},
    [110] = {groupId=1422,nodeId=4105,weight=1,limitBaseId={},nodeLimit=2},
    [111] = {groupId=1422,nodeId=4106,weight=1,limitBaseId={},nodeLimit=2},
    [112] = {groupId=1422,nodeId=4107,weight=1,limitBaseId={},nodeLimit=2},
    [113] = {groupId=1422,nodeId=4108,weight=1,limitBaseId={},nodeLimit=2},
    [114] = {groupId=1422,nodeId=4109,weight=2,limitBaseId={},nodeLimit=2},
    [115] = {groupId=1422,nodeId=4226,weight=1,limitBaseId={},nodeLimit=2},
    [116] = {groupId=1422,nodeId=4227,weight=1,limitBaseId={},nodeLimit=2},
    [117] = {groupId=1422,nodeId=4229,weight=1,limitBaseId={},nodeLimit=2},
    [118] = {groupId=1422,nodeId=4230,weight=1,limitBaseId={},nodeLimit=2},
    [119] = {groupId=1422,nodeId=4231,weight=1,limitBaseId={},nodeLimit=2},
    [120] = {groupId=1422,nodeId=4235,weight=2,limitBaseId={},nodeLimit=2},
    [121] = {groupId=1422,nodeId=4239,weight=1,limitBaseId={},nodeLimit=-1},
    [122] = {groupId=1422,nodeId=4240,weight=1,limitBaseId={},nodeLimit=2},
    [123] = {groupId=1422,nodeId=4241,weight=1,limitBaseId={},nodeLimit=2},
    [124] = {groupId=1422,nodeId=4320,weight=1,limitBaseId={},nodeLimit=2},
    [125] = {groupId=1421,nodeId=1403,weight=1,limitBaseId={},nodeLimit=1},
    [126] = {groupId=1421,nodeId=1405,weight=1,limitBaseId={},nodeLimit=1},
    [127] = {groupId=1421,nodeId=1408,weight=1,limitBaseId={},nodeLimit=1},
    [128] = {groupId=1421,nodeId=1411,weight=1,limitBaseId={},nodeLimit=1},
    [129] = {groupId=1421,nodeId=1413,weight=1,limitBaseId={},nodeLimit=1},
    [130] = {groupId=1421,nodeId=1414,weight=1,limitBaseId={},nodeLimit=1},
    [131] = {groupId=1421,nodeId=1417,weight=1,limitBaseId={},nodeLimit=1},
    [132] = {groupId=1421,nodeId=1418,weight=1,limitBaseId={},nodeLimit=1},
    [133] = {groupId=1421,nodeId=3211,weight=1,limitBaseId={},nodeLimit=1},
    [134] = {groupId=1414,nodeId=4179,weight=6,limitBaseId={},nodeLimit=0},
    [135] = {groupId=1413,nodeId=4256,weight=1,limitBaseId={},nodeLimit=1},
    [136] = {groupId=1413,nodeId=4184,weight=30,limitBaseId={},nodeLimit=1},
    [137] = {groupId=1413,nodeId=1416,weight=30,limitBaseId={},nodeLimit=1},
    [138] = {groupId=1412,nodeId=1432,weight=2,limitBaseId={},nodeLimit=2},
    [139] = {groupId=1412,nodeId=1433,weight=1,limitBaseId={},nodeLimit=2},
    [140] = {groupId=1412,nodeId=1434,weight=1,limitBaseId={},nodeLimit=2},
    [141] = {groupId=1412,nodeId=4003,weight=1,limitBaseId={},nodeLimit=2},
    [142] = {groupId=1412,nodeId=4006,weight=100,limitBaseId={},nodeLimit=2},
    [143] = {groupId=1412,nodeId=4007,weight=1,limitBaseId={},nodeLimit=2},
    [144] = {groupId=1412,nodeId=4021,weight=1,limitBaseId={},nodeLimit=2},
    [145] = {groupId=1412,nodeId=4105,weight=1,limitBaseId={},nodeLimit=2},
    [146] = {groupId=1412,nodeId=4106,weight=1,limitBaseId={},nodeLimit=2},
    [147] = {groupId=1412,nodeId=4107,weight=1,limitBaseId={},nodeLimit=2},
    [148] = {groupId=1412,nodeId=4109,weight=2,limitBaseId={},nodeLimit=2},
    [149] = {groupId=1412,nodeId=4226,weight=1,limitBaseId={},nodeLimit=2},
    [150] = {groupId=1412,nodeId=4227,weight=1,limitBaseId={},nodeLimit=2},
    [151] = {groupId=1412,nodeId=4229,weight=1,limitBaseId={},nodeLimit=2},
    [152] = {groupId=1412,nodeId=4230,weight=1,limitBaseId={},nodeLimit=2},
    [153] = {groupId=1412,nodeId=4231,weight=1,limitBaseId={},nodeLimit=2},
    [154] = {groupId=1412,nodeId=4235,weight=2,limitBaseId={},nodeLimit=2},
    [155] = {groupId=1412,nodeId=4239,weight=1,limitBaseId={},nodeLimit=-1},
    [156] = {groupId=1412,nodeId=4240,weight=1,limitBaseId={},nodeLimit=2},
    [157] = {groupId=1412,nodeId=4241,weight=1,limitBaseId={},nodeLimit=2},
    [158] = {groupId=1412,nodeId=4320,weight=1,limitBaseId={},nodeLimit=2},
    [159] = {groupId=1411,nodeId=1407,weight=6,limitBaseId={},nodeLimit=1},
    [160] = {groupId=1411,nodeId=3210,weight=6,limitBaseId={},nodeLimit=1},
    [161] = {groupId=1411,nodeId=4168,weight=6,limitBaseId={},nodeLimit=1},
    [162] = {groupId=1411,nodeId=4171,weight=6,limitBaseId={},nodeLimit=1},
    [163] = {groupId=1411,nodeId=4175,weight=6,limitBaseId={},nodeLimit=1},
    [164] = {groupId=1411,nodeId=4177,weight=5,limitBaseId={},nodeLimit=1},
    [165] = {groupId=1405,nodeId=4501,weight=1,limitBaseId={},nodeLimit=1},
    [166] = {groupId=1405,nodeId=4502,weight=1,limitBaseId={},nodeLimit=1},
    [167] = {groupId=1405,nodeId=4503,weight=1,limitBaseId={},nodeLimit=1},
    [168] = {groupId=1404,nodeId=1415,weight=6,limitBaseId={},nodeLimit=0},
    [169] = {groupId=1402,nodeId=1432,weight=2,limitBaseId={},nodeLimit=2},
    [170] = {groupId=1402,nodeId=1433,weight=1,limitBaseId={},nodeLimit=2},
    [171] = {groupId=1402,nodeId=1434,weight=1,limitBaseId={},nodeLimit=2},
    [172] = {groupId=1402,nodeId=4003,weight=1,limitBaseId={},nodeLimit=2},
    [173] = {groupId=1402,nodeId=4007,weight=1,limitBaseId={},nodeLimit=2},
    [174] = {groupId=1402,nodeId=4021,weight=1,limitBaseId={},nodeLimit=2},
    [175] = {groupId=1402,nodeId=4105,weight=1,limitBaseId={},nodeLimit=2},
    [176] = {groupId=1402,nodeId=4106,weight=1,limitBaseId={},nodeLimit=2},
    [177] = {groupId=1402,nodeId=4107,weight=1,limitBaseId={},nodeLimit=2},
    [178] = {groupId=1402,nodeId=4226,weight=1,limitBaseId={},nodeLimit=2},
    [179] = {groupId=1402,nodeId=4227,weight=1,limitBaseId={},nodeLimit=2},
    [180] = {groupId=1402,nodeId=4229,weight=1,limitBaseId={},nodeLimit=2},
    [181] = {groupId=1402,nodeId=4230,weight=1,limitBaseId={},nodeLimit=2},
    [182] = {groupId=1402,nodeId=4231,weight=1,limitBaseId={},nodeLimit=2},
    [183] = {groupId=1402,nodeId=4239,weight=1,limitBaseId={},nodeLimit=-1},
    [184] = {groupId=1402,nodeId=4240,weight=1,limitBaseId={},nodeLimit=2},
    [185] = {groupId=1402,nodeId=4241,weight=1,limitBaseId={},nodeLimit=2},
    [186] = {groupId=1402,nodeId=4316,weight=1,limitBaseId={},nodeLimit=2},
    [187] = {groupId=1402,nodeId=4318,weight=1,limitBaseId={},nodeLimit=2},
    [188] = {groupId=1402,nodeId=4109,weight=2,limitBaseId={},nodeLimit=2},
    [189] = {groupId=1401,nodeId=1404,weight=5,limitBaseId={},nodeLimit=1},
    [190] = {groupId=1401,nodeId=1406,weight=6,limitBaseId={},nodeLimit=1},
    [191] = {groupId=1401,nodeId=1409,weight=12,limitBaseId={},nodeLimit=1},
    [192] = {groupId=1401,nodeId=1410,weight=12,limitBaseId={},nodeLimit=1},
    [193] = {groupId=1401,nodeId=4173,weight=12,limitBaseId={},nodeLimit=1},
    [194] = {groupId=1401,nodeId=4176,weight=12,limitBaseId={},nodeLimit=1},
    [195] = {groupId=1401,nodeId=5101,weight=120000,limitBaseId={},nodeLimit=-1},
    [196] = {groupId=1401,nodeId=4210,weight=12,limitBaseId={},nodeLimit=1},
    [197] = {groupId=1150,nodeId=4325,weight=6,limitBaseId={501},nodeLimit=0},
    [198] = {groupId=1150,nodeId=4328,weight=6,limitBaseId={503},nodeLimit=0},
    [199] = {groupId=1150,nodeId=4331,weight=6,limitBaseId={504},nodeLimit=0},
    [200] = {groupId=1147,nodeId=4304,weight=6,limitBaseId={},nodeLimit=0},
    [201] = {groupId=1146,nodeId=4303,weight=6,limitBaseId={},nodeLimit=0},
    [202] = {groupId=1031,nodeId=4257,weight=30,limitBaseId={},nodeLimit=1},
    [203] = {groupId=1031,nodeId=4258,weight=30,limitBaseId={},nodeLimit=1},
    [204] = {groupId=1024,nodeId=4246,weight=6,limitBaseId={},nodeLimit=0},
    [205] = {groupId=404,nodeId=4319,weight=1,limitBaseId={},nodeLimit=1},
    [206] = {groupId=404,nodeId=4319,weight=1,limitBaseId={},nodeLimit=1},
    [207] = {groupId=204,nodeId=4106,weight=6,limitBaseId={},nodeLimit=1},
    [208] = {groupId=204,nodeId=4108,weight=6,limitBaseId={},nodeLimit=1},
    [209] = {groupId=204,nodeId=4003,weight=6,limitBaseId={},nodeLimit=1},
    [210] = {groupId=203,nodeId=4226,weight=6,limitBaseId={},nodeLimit=1},
    [211] = {groupId=203,nodeId=4231,weight=6,limitBaseId={},nodeLimit=1},
    [212] = {groupId=203,nodeId=4227,weight=6,limitBaseId={},nodeLimit=1},
    [213] = {groupId=203,nodeId=1434,weight=6,limitBaseId={},nodeLimit=1},
    [214] = {groupId=203,nodeId=1416,weight=6,limitBaseId={},nodeLimit=1},
    [215] = {groupId=202,nodeId=1432,weight=6,limitBaseId={},nodeLimit=1},
    [216] = {groupId=202,nodeId=4239,weight=1,limitBaseId={},nodeLimit=0},
    [217] = {groupId=162,nodeId=1322,weight=1,limitBaseId={},nodeLimit=0},
    [218] = {groupId=161,nodeId=1321,weight=1,limitBaseId={},nodeLimit=0},
    [219] = {groupId=160,nodeId=1320,weight=1,limitBaseId={},nodeLimit=0},
    [220] = {groupId=143,nodeId=4105,weight=1,limitBaseId={},nodeLimit=1},
    [221] = {groupId=143,nodeId=4106,weight=1,limitBaseId={},nodeLimit=1},
    [222] = {groupId=143,nodeId=4107,weight=1,limitBaseId={},nodeLimit=1},
    [223] = {groupId=143,nodeId=4108,weight=1,limitBaseId={},nodeLimit=1},
    [224] = {groupId=143,nodeId=4109,weight=1,limitBaseId={},nodeLimit=1},
    [225] = {groupId=143,nodeId=4003,weight=1,limitBaseId={},nodeLimit=1},
    [226] = {groupId=143,nodeId=4006,weight=1,limitBaseId={},nodeLimit=1},
    [227] = {groupId=143,nodeId=4007,weight=1,limitBaseId={},nodeLimit=1},
    [228] = {groupId=143,nodeId=1432,weight=1,limitBaseId={},nodeLimit=1},
    [229] = {groupId=143,nodeId=1433,weight=1,limitBaseId={},nodeLimit=1},
    [230] = {groupId=143,nodeId=1434,weight=1,limitBaseId={},nodeLimit=1},
    [231] = {groupId=143,nodeId=4021,weight=1,limitBaseId={},nodeLimit=1},
    [232] = {groupId=143,nodeId=4226,weight=1,limitBaseId={},nodeLimit=1},
    [233] = {groupId=143,nodeId=4227,weight=1,limitBaseId={},nodeLimit=1},
    [234] = {groupId=143,nodeId=4229,weight=1,limitBaseId={},nodeLimit=1},
    [235] = {groupId=143,nodeId=4230,weight=1,limitBaseId={},nodeLimit=1},
    [236] = {groupId=143,nodeId=4231,weight=1,limitBaseId={},nodeLimit=1},
    [237] = {groupId=143,nodeId=4232,weight=1,limitBaseId={},nodeLimit=1},
    [238] = {groupId=143,nodeId=4239,weight=1,limitBaseId={},nodeLimit=0},
    [239] = {groupId=143,nodeId=4240,weight=1,limitBaseId={},nodeLimit=1},
    [240] = {groupId=143,nodeId=4241,weight=1,limitBaseId={},nodeLimit=1},
    [241] = {groupId=143,nodeId=4316,weight=1,limitBaseId={},nodeLimit=1},
    [242] = {groupId=143,nodeId=4317,weight=1,limitBaseId={},nodeLimit=1},
    [243] = {groupId=143,nodeId=4318,weight=1,limitBaseId={},nodeLimit=1},
    [244] = {groupId=143,nodeId=4255,weight=3,limitBaseId={},nodeLimit=1},
    [245] = {groupId=143,nodeId=4235,weight=1,limitBaseId={},nodeLimit=1},
    [246] = {groupId=142,nodeId=4105,weight=1,limitBaseId={},nodeLimit=1},
    [247] = {groupId=142,nodeId=4106,weight=1,limitBaseId={},nodeLimit=1},
    [248] = {groupId=142,nodeId=4107,weight=1,limitBaseId={},nodeLimit=1},
    [249] = {groupId=142,nodeId=4108,weight=1,limitBaseId={},nodeLimit=1},
    [250] = {groupId=142,nodeId=4109,weight=1,limitBaseId={},nodeLimit=1},
    [251] = {groupId=142,nodeId=4003,weight=1,limitBaseId={},nodeLimit=1},
    [252] = {groupId=142,nodeId=4006,weight=1,limitBaseId={},nodeLimit=1},
    [253] = {groupId=142,nodeId=4007,weight=1,limitBaseId={},nodeLimit=1},
    [254] = {groupId=142,nodeId=1432,weight=1,limitBaseId={},nodeLimit=1},
    [255] = {groupId=142,nodeId=1433,weight=1,limitBaseId={},nodeLimit=1},
    [256] = {groupId=142,nodeId=1434,weight=1,limitBaseId={},nodeLimit=1},
    [257] = {groupId=142,nodeId=4021,weight=1,limitBaseId={},nodeLimit=1},
    [258] = {groupId=142,nodeId=4226,weight=1,limitBaseId={},nodeLimit=1},
    [259] = {groupId=142,nodeId=4227,weight=1,limitBaseId={},nodeLimit=1},
    [260] = {groupId=142,nodeId=4229,weight=1,limitBaseId={},nodeLimit=1},
    [261] = {groupId=142,nodeId=4230,weight=1,limitBaseId={},nodeLimit=1},
    [262] = {groupId=142,nodeId=4231,weight=1,limitBaseId={},nodeLimit=1},
    [263] = {groupId=142,nodeId=4232,weight=1,limitBaseId={},nodeLimit=1},
    [264] = {groupId=142,nodeId=4239,weight=1,limitBaseId={},nodeLimit=0},
    [265] = {groupId=142,nodeId=4240,weight=1,limitBaseId={},nodeLimit=1},
    [266] = {groupId=142,nodeId=4241,weight=1,limitBaseId={},nodeLimit=1},
    [267] = {groupId=142,nodeId=4319,weight=1,limitBaseId={},nodeLimit=1},
    [268] = {groupId=142,nodeId=4320,weight=1,limitBaseId={},nodeLimit=1},
    [269] = {groupId=142,nodeId=4254,weight=8,limitBaseId={},nodeLimit=1},
    [270] = {groupId=142,nodeId=4235,weight=1,limitBaseId={},nodeLimit=1},
    [271] = {groupId=141,nodeId=4105,weight=1,limitBaseId={},nodeLimit=1},
    [272] = {groupId=141,nodeId=4106,weight=1,limitBaseId={},nodeLimit=1},
    [273] = {groupId=141,nodeId=4107,weight=1,limitBaseId={},nodeLimit=1},
    [274] = {groupId=141,nodeId=4108,weight=1,limitBaseId={},nodeLimit=1},
    [275] = {groupId=141,nodeId=4109,weight=1,limitBaseId={},nodeLimit=1},
    [276] = {groupId=141,nodeId=4003,weight=1,limitBaseId={},nodeLimit=1},
    [277] = {groupId=141,nodeId=4006,weight=1,limitBaseId={},nodeLimit=1},
    [278] = {groupId=141,nodeId=4007,weight=1,limitBaseId={},nodeLimit=1},
    [279] = {groupId=141,nodeId=1432,weight=1,limitBaseId={},nodeLimit=1},
    [280] = {groupId=141,nodeId=1433,weight=1,limitBaseId={},nodeLimit=1},
    [281] = {groupId=141,nodeId=1434,weight=1,limitBaseId={},nodeLimit=1},
    [282] = {groupId=141,nodeId=4021,weight=1,limitBaseId={},nodeLimit=1},
    [283] = {groupId=141,nodeId=4226,weight=1,limitBaseId={},nodeLimit=1},
    [284] = {groupId=141,nodeId=4227,weight=1,limitBaseId={},nodeLimit=1},
    [285] = {groupId=141,nodeId=4229,weight=1,limitBaseId={},nodeLimit=1},
    [286] = {groupId=141,nodeId=4230,weight=1,limitBaseId={},nodeLimit=1},
    [287] = {groupId=141,nodeId=4231,weight=1,limitBaseId={},nodeLimit=1},
    [288] = {groupId=141,nodeId=4232,weight=1,limitBaseId={},nodeLimit=1},
    [289] = {groupId=141,nodeId=4239,weight=1,limitBaseId={},nodeLimit=0},
    [290] = {groupId=141,nodeId=4240,weight=1,limitBaseId={},nodeLimit=1},
    [291] = {groupId=141,nodeId=4241,weight=1,limitBaseId={},nodeLimit=1},
    [292] = {groupId=141,nodeId=4319,weight=1,limitBaseId={},nodeLimit=1},
    [293] = {groupId=141,nodeId=4320,weight=1,limitBaseId={},nodeLimit=1},
    [294] = {groupId=141,nodeId=4256,weight=5,limitBaseId={},nodeLimit=1},
    [295] = {groupId=141,nodeId=4235,weight=1,limitBaseId={},nodeLimit=1},
    [296] = {groupId=140,nodeId=4105,weight=1,limitBaseId={},nodeLimit=1},
    [297] = {groupId=140,nodeId=4106,weight=1,limitBaseId={},nodeLimit=1},
    [298] = {groupId=140,nodeId=4107,weight=1,limitBaseId={},nodeLimit=1},
    [299] = {groupId=140,nodeId=4108,weight=1,limitBaseId={},nodeLimit=1},
    [300] = {groupId=140,nodeId=4109,weight=1,limitBaseId={},nodeLimit=1},
    [301] = {groupId=140,nodeId=4003,weight=1,limitBaseId={},nodeLimit=1},
    [302] = {groupId=140,nodeId=4006,weight=1,limitBaseId={},nodeLimit=1},
    [303] = {groupId=140,nodeId=4007,weight=1,limitBaseId={},nodeLimit=1},
    [304] = {groupId=140,nodeId=1432,weight=1,limitBaseId={},nodeLimit=1},
    [305] = {groupId=140,nodeId=1433,weight=1,limitBaseId={},nodeLimit=1},
    [306] = {groupId=140,nodeId=1434,weight=1,limitBaseId={},nodeLimit=1},
    [307] = {groupId=140,nodeId=4021,weight=1,limitBaseId={},nodeLimit=1},
    [308] = {groupId=140,nodeId=4226,weight=1,limitBaseId={},nodeLimit=1},
    [309] = {groupId=140,nodeId=4227,weight=1,limitBaseId={},nodeLimit=1},
    [310] = {groupId=140,nodeId=4229,weight=1,limitBaseId={},nodeLimit=1},
    [311] = {groupId=140,nodeId=4230,weight=1,limitBaseId={},nodeLimit=1},
    [312] = {groupId=140,nodeId=4231,weight=1,limitBaseId={},nodeLimit=1},
    [313] = {groupId=140,nodeId=4232,weight=1,limitBaseId={},nodeLimit=1},
    [314] = {groupId=140,nodeId=4239,weight=1,limitBaseId={},nodeLimit=0},
    [315] = {groupId=140,nodeId=4240,weight=1,limitBaseId={},nodeLimit=1},
    [316] = {groupId=140,nodeId=4241,weight=1,limitBaseId={},nodeLimit=1},
    [317] = {groupId=140,nodeId=4316,weight=1,limitBaseId={},nodeLimit=1},
    [318] = {groupId=140,nodeId=4317,weight=1,limitBaseId={},nodeLimit=1},
    [319] = {groupId=140,nodeId=4318,weight=1,limitBaseId={},nodeLimit=1},
    [320] = {groupId=132,nodeId=4095,weight=6,limitBaseId={},nodeLimit=0},
    [321] = {groupId=34,nodeId=4021,weight=6,limitBaseId={},nodeLimit=0},
    [322] = {groupId=34,nodeId=4022,weight=6,limitBaseId={},nodeLimit=0},
    [323] = {groupId=34,nodeId=4023,weight=6,limitBaseId={},nodeLimit=0},
    [324] = {groupId=32,nodeId=4095,weight=6,limitBaseId={},nodeLimit=0},
    [325] = {groupId=1401,nodeId=1466,weight=100,limitBaseId={},nodeLimit=1},
    [326] = {groupId=1401,nodeId=1467,weight=12,limitBaseId={},nodeLimit=1},
    [327] = {groupId=1401,nodeId=1468,weight=12,limitBaseId={},nodeLimit=1},
    [328] = {groupId=1401,nodeId=1469,weight=12,limitBaseId={},nodeLimit=1},
    [329] = {groupId=1424,nodeId=1477,weight=1,limitBaseId={},nodeLimit=1},
    [330] = {groupId=2007,nodeId=40951,weight=1,limitBaseId={},nodeLimit=0},
}
local config = {}
local config_loaded = {}
local config_languages = {}

local function config_load(index)
    if index == nil then return nil end
    if config_loaded[index] then return config[index] end
    local source = config_source[index]
    if source == nil then return nil end
    local rowLanguage = config_languages[index] or nil
    local data = ConfigRowRuntime.Build(source,config_runtime_schema,"act_node_refresh_def",rowLanguage)
    config[index] = data
    config_loaded[index] = true
    return data
end

function act_node_refresh_def.config_index(index)
    return config_load(index)
end

function act_node_refresh_def.config_set(index,data)
    config[index] = data
    config_loaded[index] = true
end

function act_node_refresh_def.config_num()
    return config_num
end

local config_groupId =
{
    [2100]={1},[2101]={2},[2102]={3},[2103]={4},[2104]={5},[2105]={6},[2111]={7},[2114]={8},[2115]={9},[2376]={10},[2375]={11},[2374]={12},[2373]={13},[2372]={14},[2371]={15},[2008]={16},[2007]={17,330},[2006]={18},[2004]={19},[2003]={20},[2002]={21},[2001]={22},[1465]={23},[1454]={24},[1453]={25,26},[1451]={27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47},[1444]={48},[1443]={49,50},[1441]={51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67},[1434]={68},[1433]={69},[1432]={70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91},[1431]={92,93,94,95,96,97,98,99,100},[1423]={101},[1422]={102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124},[1421]={125,126,127,128,129,130,131,132,133},[1414]={134},[1413]={135,136,137},[1412]={138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158},[1411]={159,160,161,162,163,164},[1405]={165,166,167},[1404]={168},[1402]={169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188},[1401]={189,190,191,192,193,194,195,196,325,326,327,328},[1150]={197,198,199},[1147]={200},[1146]={201},[1031]={202,203},[1024]={204},[404]={205,206},[204]={207,208,209},[203]={210,211,212,213,214},[202]={215,216},[162]={217},[161]={218},[160]={219},[143]={220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245},[142]={246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270},[141]={271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295},[140]={296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319},[132]={320},[34]={321,322,323},[32]={324},[1424]={329}
}

local config_groupId_data = {}
function act_node_refresh_def.config_groupId(key)
    if config_groupId_data[key] then
        return config_groupId_data[key]
    end
    local indexs = config_groupId[key]
    local datas = {}
    if indexs == nil then return datas end
    for _,index in ipairs(indexs) do
        table.insert(datas,act_node_refresh_def.config_index(index))
    end
    config_groupId_data[key] = datas
    return datas
end

local configSheets =
{
    ["config"] =
    {
        schema = config_schema,
        indexes =
        {
            { indexKey = "groupId", fields = {"groupId"}, fieldTypes = {"int"}, group = true },
        },
    },
}

local configSheetRuntimes =
{
    ["config"] =
    {
        getRows = function() return config_source end,
        getLanguages = function() return config_languages end,
        getSchema = function() return config_runtime_schema end,
        publish = function(rows,indexes,schema,languages)
            config_source = rows
            config_runtime_schema = schema or config_schema
            config_languages = languages or {}
            config = {}
            config_loaded = {}
            config_num = #rows
            config_groupId = indexes["groupId"] or {}
            config_groupId_data = {}
        end,
    },
}

local function BuildIndexKey(row,fields)
    if #fields == 1 then return row[fields[1]] end
    local values = {}
    for index,fieldName in ipairs(fields) do
        values[index] = tostring(row[fieldName])
    end
    return table.concat(values,"_")
end

local function BuildIndexKeyFromValue(value,fields)
    if #fields == 1 then return value end
    if type(value) ~= "table" or #value ~= #fields then return nil end
    local values = {}
    for index = 1,#fields do values[index] = tostring(value[index]) end
    return table.concat(values,"_")
end

local function ValidateRowsTable(rows)
    if type(rows) ~= "table" then return false,"配置行集合需要 table" end
    local count = 0
    for key in pairs(rows) do
        if type(key) ~= "number" or key < 1 or key % 1 ~= 0 then
            return false,string.format("配置行集合包含无效数组键[%s]",tostring(key))
        end
        count = count + 1
    end
    for index = 1,count do
        if rows[index] == nil then return false,string.format("配置行集合存在空洞[%s]",index) end
    end
    return true
end

local function GetIndexRule(info,installKey)
    local indexKey = nil
    if type(installKey) == "string" then
        indexKey = installKey
    elseif type(installKey) == "table" then
        local valid,err = ValidateRowsTable(installKey)
        if not valid then return nil,err end
        local fields = {}
        for index,fieldName in ipairs(installKey) do
            if type(fieldName) ~= "string" then return nil,string.format("installKey第%s项需要 string",index) end
            fields[index] = fieldName
        end
        indexKey = table.concat(fields,",")
    else
        return nil,string.format("installKey需要 string 或有序字段数组，实际为 %s",type(installKey))
    end
    for _,rule in ipairs(info.indexes) do
        if rule.indexKey == indexKey then return rule end
    end
    return nil,string.format("installKey未匹配现有查询索引[%s]",tostring(indexKey))
end

function act_node_refresh_def.GetSheetInfo(sheetName)
    return configSheets[sheetName]
end

function act_node_refresh_def.CaptureState(sheetName)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    return { rows = runtime.getRows(), languages = runtime.getLanguages(), schema = runtime.getSchema() }
end

function act_node_refresh_def.RestoreState(sheetName,state)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    if type(state) ~= "table" or type(state.rows) ~= "table" or type(state.languages) ~= "table" or type(state.schema) ~= "table" then
        return false,"配置快照无效"
    end
    local indexes,indexErr = act_node_refresh_def.BuildIndexes(sheetName,state.rows,true,state.schema)
    if indexes == nil then return false,indexErr end
    runtime.publish(state.rows,indexes,state.schema,state.languages)
    return true
end

function act_node_refresh_def.ValidateRow(sheetName,row,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return false,schemaErr end
    return ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
end

function act_node_refresh_def.BuildIndexes(sheetName,rows,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    local rowsValid,rowsErr = ValidateRowsTable(rows)
    if not rowsValid then return nil,rowsErr end
    local indexes = {}
    for _,rule in ipairs(info.indexes) do indexes[rule.indexKey] = {} end
    for index,row in ipairs(rows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",index,err) end
        for _,rule in ipairs(info.indexes) do
            local key = BuildIndexKey(row,rule.fields)
            local target = indexes[rule.indexKey]
            if rule.group then
                target[key] = target[key] or {}
                table.insert(target[key],index)
            else
                target[key] = index
            end
        end
    end
    return indexes
end

local function RemoveRowOwners(info,owners,row,rowIndex)
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local key = BuildIndexKey(row,rule.fields)
            local keyOwners = owners[rule.indexKey][key]
            if keyOwners ~= nil then
                for ownerIndex = #keyOwners,1,-1 do
                    if keyOwners[ownerIndex] == rowIndex then table.remove(keyOwners,ownerIndex) end
                end
                if #keyOwners == 0 then owners[rule.indexKey][key] = nil end
            end
        end
    end
end

local function ResolveNewRowConflicts(info,groupRule,rows,languages,newRowIndexes)
    local owners = {}
    local active = {}
    local isNew = {}
    local conflicts = {}
    for _,rowIndex in ipairs(newRowIndexes) do isNew[rowIndex] = true end
    for _,rule in ipairs(info.indexes) do if not rule.group then owners[rule.indexKey] = {} end end
    for rowIndex,row in ipairs(rows) do
        active[rowIndex] = true
        if not isNew[rowIndex] then
            for _,rule in ipairs(info.indexes) do
                if not rule.group then
                    local key = BuildIndexKey(row,rule.fields)
                    local keyOwners = owners[rule.indexKey][key] or {}
                    table.insert(keyOwners,rowIndex)
                    owners[rule.indexKey][key] = keyOwners
                end
            end
        end
    end
    for _,rowIndex in ipairs(newRowIndexes) do
        local row = rows[rowIndex]
        local removeIndexes = {}
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                local keyOwners = owners[rule.indexKey][key]
                if keyOwners ~= nil then
                    for _,oldIndex in ipairs(keyOwners) do
                        if active[oldIndex] then
                            removeIndexes[oldIndex] = true
                            table.insert(conflicts,{
                                indexKey = rule.indexKey,
                                key = key,
                                oldIndex = oldIndex,
                                newIndex = rowIndex,
                                oldGroupKey = BuildIndexKey(rows[oldIndex],groupRule.fields),
                                newGroupKey = BuildIndexKey(row,groupRule.fields),
                            })
                        end
                    end
                end
            end
        end
        for oldIndex in pairs(removeIndexes) do
            active[oldIndex] = false
            RemoveRowOwners(info,owners,rows[oldIndex],oldIndex)
        end
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                owners[rule.indexKey][key] = {rowIndex}
            end
        end
    end
    local result = {}
    local resultLanguages = {}
    for rowIndex,row in ipairs(rows) do
        if active[rowIndex] then
            table.insert(result,row)
            table.insert(resultLanguages,languages[rowIndex] or false)
        end
    end
    return result,resultLanguages,conflicts
end

local function CollectAppendConflicts(info,currentCount,rows)
    local conflicts = {}
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local latest = {}
            for rowIndex,row in ipairs(rows) do
                local key = BuildIndexKey(row,rule.fields)
                local oldIndex = latest[key]
                if rowIndex > currentCount and oldIndex ~= nil then
                    table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=oldIndex,newIndex=rowIndex})
                end
                latest[key] = rowIndex
            end
        end
    end
    return conflicts
end

function act_node_refresh_def.ApplyBatch(sheetName,batch,allowUnknown,schemaOverride,rowLanguage)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local runtime = configSheetRuntimes[sheetName]
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    if type(batch) ~= "table" then return nil,"配置批次需要 table" end
    for key in pairs(batch) do
        if key ~= "installKey" and key ~= "installValue" and key ~= "operation" and key ~= "rows" then
            return nil,string.format("配置批次包含未知字段[%s]",tostring(key))
        end
    end
    local newRows = batch.rows
    local rowsValid,rowsErr = ValidateRowsTable(newRows)
    if not rowsValid then return nil,rowsErr end
    for rowIndex,row in ipairs(newRows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",rowIndex,err) end
    end
    local warnings = {}
    if #newRows == 0 and batch.installKey == nil then
        return { operation = "append", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} }
    end
    local currentRows = runtime.getRows()
    local currentLanguages = runtime.getLanguages()
    local candidateRows = {}
    local candidateLanguages = {}
    local newRowIndexes = {}
    if batch.installKey == nil then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"无 installKey 批次不能声明 installValue/operation" end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
        end
        local indexes,indexErr = act_node_refresh_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        local conflicts = CollectAppendConflicts(info,#currentRows,candidateRows)
        if #conflicts > 0 then table.insert(warnings,string.format("无 installKey 追加产生 %s 个普通查询键冲突；后写结果生效",#conflicts)) end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "append", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    local rule,ruleErr = GetIndexRule(info,batch.installKey)
    if rule == nil then return nil,ruleErr end
    if not rule.group then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"普通 upsert 不能声明 installValue/operation" end
        if #newRows == 0 then return { operation = "upsert", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} } end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        local conflicts = {}
        for _,newRow in ipairs(newRows) do
            local key = BuildIndexKey(newRow,rule.fields)
            local matched = {}
            for rowIndex,oldRow in ipairs(candidateRows) do
                if BuildIndexKey(oldRow,rule.fields) == key then table.insert(matched,rowIndex) end
            end
            if #matched > 1 then return nil,string.format("安装身份歧义[index:%s][key:%s][rows:%s]",rule.indexKey,tostring(key),table.concat(matched,",")) end
            if #matched == 1 then
                table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=matched[1],newIndex=matched[1]})
                candidateRows[matched[1]] = newRow
                candidateLanguages[matched[1]] = rowLanguage or false
            else
                table.insert(candidateRows,newRow)
                table.insert(candidateLanguages,rowLanguage or false)
            end
        end
        local indexes,indexErr = act_node_refresh_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "upsert", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    if batch.installValue == nil then return nil,"组批次缺少 installValue" end
    local groupKey = BuildIndexKeyFromValue(batch.installValue,rule.fields)
    if groupKey == nil then return nil,"installValue 与组查询字段不匹配" end
    local operation = batch.operation or "replace"
    if operation ~= "replace" and operation ~= "append" then return nil,string.format("无效组操作[%s]",tostring(operation)) end
    for rowIndex,row in ipairs(newRows) do
        local rowGroupKey = BuildIndexKey(row,rule.fields)
        if rowGroupKey ~= groupKey then return nil,string.format("组键不一致[目标:%s][第%s行:%s]",tostring(groupKey),rowIndex,tostring(rowGroupKey)) end
    end
    if operation == "append" and #newRows == 0 then return { operation = operation, groupKey = groupKey, rows = runtime.getRows(), warnings = {"空组 append 未修改配置"}, conflicts = {} } end
    local firstGroupIndex = nil
    local oldGroupCount = 0
    if operation == "replace" then
        for rowIndex,row in ipairs(currentRows) do
            if BuildIndexKey(row,rule.fields) == groupKey then
                oldGroupCount = oldGroupCount + 1
                if firstGroupIndex == nil then firstGroupIndex = #candidateRows + 1 end
            else
                table.insert(candidateRows,row)
                table.insert(candidateLanguages,currentLanguages[rowIndex] or false)
            end
        end
        local insertIndex = firstGroupIndex or (#candidateRows + 1)
        for offset,row in ipairs(newRows) do
            table.insert(candidateRows,insertIndex + offset - 1,row)
            table.insert(candidateLanguages,insertIndex + offset - 1,rowLanguage or false)
        end
        for offset = 1,#newRows do table.insert(newRowIndexes,insertIndex + offset - 1) end
    else
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
            table.insert(newRowIndexes,#candidateRows)
        end
    end
    if operation == "replace" and oldGroupCount == 0 and #newRows == 0 then table.insert(warnings,"清空不存在的组未修改配置") end
    local resultRows,resultLanguages,conflicts = ResolveNewRowConflicts(info,rule,candidateRows,candidateLanguages,newRowIndexes)
    local indexes,indexErr = act_node_refresh_def.BuildIndexes(sheetName,resultRows,allowUnknown,schemaOverride)
    if indexes == nil then return nil,indexErr end
    runtime.publish(resultRows,indexes,schema,resultLanguages)
    return { operation = operation, groupKey = groupKey, rows = resultRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
end

local sheetFunc = 
{
    ["config"] = 
    {
        ["index"] = "config_index",
        ["@num"] = "config_num",
        ["@set"] = "config_set",
        ["groupId"] = "config_groupId",
    },
}

function act_node_refresh_def.Get(sheetName,keyIndex,key)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return nil,1 end
    local funName = funcIndexs[keyIndex]
    if not funName then return nil,2 end
    return act_node_refresh_def[funName](key),nil
end

function act_node_refresh_def.Set(sheetName,index,data)
    if index == nil then return false end
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return false end
    local funName = funcIndexs["@set"]
    act_node_refresh_def[funName](index,data)
    return true
end

function act_node_refresh_def.GetNum(sheetName)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return 0 end
    local funName = funcIndexs["@num"]
    return act_node_refresh_def[funName]()
end

return act_node_refresh_def