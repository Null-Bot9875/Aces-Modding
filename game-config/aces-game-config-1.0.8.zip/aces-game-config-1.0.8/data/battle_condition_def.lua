local battle_condition_def = {}
local ConfigRowRuntime = require("common/config/ConfigRowRuntime")

--config
local config_num = 347
local config_schema =
{
    ["id"] = { type = "int" },
    ["desc"] = { type = "string" },
    ["target"] = { type = "int" },
    ["type"] = { type = "int" },
    ["minValue"] = { type = "int" },
    ["maxValue"] = { type = "int" },
    ["args"] = { type = "lua" },
}
local config_runtime_schema = config_schema
local config_source =
{
    [1] = {id=1001,desc="机体的技能",target=1,type=4,minValue=1,maxValue=1,args={cardTag={{104}}}},
    [2] = {id=1002,desc="无人机带有集群指示物",target=1,type=9,minValue=1,maxValue=-1,args={token=202}},
    [3] = {id=1003,desc="无人机带有联觉指示物",target=1,type=9,minValue=1,maxValue=-1,args={token=104}},
    [4] = {id=1004,desc="场上有1联觉指示物",target=1,type=9,minValue=1,maxValue=1,args={token=104}},
    [5] = {id=1005,desc="无人机带有2子弹指示物",target=1,type=9,minValue=2,maxValue=2,args={token=203}},
    [6] = {id=1006,desc="无人机带有4子弹指示物",target=1,type=9,minValue=4,maxValue=4,args={token=203}},
    [7] = {id=1007,desc="无人机牌",target=1,type=5,minValue=0,maxValue=1,args={cardTag={{4}}}},
    [8] = {id=1008,desc="场上存在[RN-001a 试作型九头蛇]无人机",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardTag={{1001}}}},
    [9] = {id=1009,desc="猎户座量表达到4",target=1,type=13,minValue=4,maxValue=-1,args={gauge="cardCount",cardTag={{414}}}},
    [10] = {id=1010,desc="臂装无人机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{413}}}},
    [11] = {id=1011,desc="小臂装",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{416}}}},
    [12] = {id=1012,desc="选择目标己方技能设备槽",target=1,type=10,minValue=1,maxValue=1,args={slotType={4}}},
    [13] = {id=1013,desc="自身武器设备",target=1,type=4,minValue=1,maxValue=1,args={cardTag={{104}}}},
    [14] = {id=1014,desc="猎户座武装",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{414}}}},
    [15] = {id=1015,desc="自身终结技设备",target=1,type=4,minValue=1,maxValue=1,args={cardTag={{109}}}},
    [16] = {id=1016,desc="血量<=5",target=1,type=1,minValue=1,maxValue=5,args={}},
    [17] = {id=1017,desc="血量>=6",target=1,type=1,minValue=6,maxValue=-1,args={}},
    [18] = {id=1018,desc="猎弓无人机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{417}}}},
    [19] = {id=1019,desc="薮猫",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{418}}}},
    [20] = {id=1020,desc="战术牌",target=1,type=5,minValue=0,maxValue=1,args={cardTag={{3}}}},
    [21] = {id=1021,desc="白矮星无人机",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{419}}}},
    [22] = {id=1022,desc="血量<=0",target=1,type=1,minValue=-1,maxValue=0,args={}},
    [23] = {id=1023,desc="集群衍生物无人机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{1001}}}},
    [24] = {id=501,desc="无人机",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{4}}}},
    [25] = {id=502,desc="量表达到4",target=1,type=13,minValue=4,maxValue=-1,args={gauge="cardCount",cardTag={{4}}}},
    [26] = {id=503,desc="量表达到5",target=1,type=13,minValue=5,maxValue=-1,args={gauge="tokenCount", token=202}},
    [27] = {id=504,desc="当前攻击力大于3",target=1,type=11,minValue=3,maxValue=-1,args={valueKey="attk"}},
    [28] = {id=505,desc="当前攻击力大等于7",target=1,type=11,minValue=7,maxValue=-1,args={valueKey="attk"}},
    [29] = {id=601,desc="特里格拉夫专属卡牌",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{501}}}},
    [30] = {id=602,desc="特里格拉夫",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{502}}}},
    [31] = {id=603,desc="不是特里格拉夫",target=1,type=5,minValue=1,maxValue=-1,args={noTag={502}}},
    [32] = {id=60,desc="主将卡",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{6}}}},
    [33] = {id=61,desc="僚机卡",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{7}}}},
    [34] = {id=2000,desc="场上存在[薮猫]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={9201}}},
    [35] = {id=2001,desc="所有薮猫",target=1,type=5,minValue=1,maxValue=-1,args={cardId={9201}}},
    [36] = {id=2002,desc="场上存在[猎户座]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={9213}}},
    [37] = {id=2003,desc="艺术追求者",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{423}}}},
    [38] = {id=2004,desc="联觉无人机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{411}}}},
    [39] = {id=2005,desc="所有十字星",target=1,type=5,minValue=1,maxValue=-1,args={cardId={9233}}},
    [40] = {id=2006,desc="场上存在[十字星]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={9233}}},
    [41] = {id=2007,desc="集群无人机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{410}}}},
    [42] = {id=2008,desc="翼装盾墙",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{503}}}},
    [43] = {id=2009,desc="十字星",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{424}}}},
    [44] = {id=2010,desc="白矮星：无人机有3台以上",target=1,type=11,minValue=3,maxValue=-1,args={valueKey="droneCount",noTag={6,7}}},
    [45] = {id=2011,desc="持有背刺的无人机",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="attkBack"}},
    [46] = {id=2012,desc="持有圣盾的无人机",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="attkShield"}},
    [47] = {id=2013,desc="持有连击的无人机",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="attkTwice"}},
    [48] = {id=2014,desc="所有武库核心",target=1,type=5,minValue=1,maxValue=-1,args={cardId={9443}}},
    [49] = {id=2015,desc="不是主将",target=1,type=5,minValue=1,maxValue=-1,args={noTag={6}}},
    [50] = {id=2016,desc="不是主将或僚机",target=1,type=5,minValue=0,maxValue=-1,args={noTag={6,7}}},
    [51] = {id=2017,desc="战术牌",target=1,type=5,minValue=0,maxValue=1,args={cardTag={{3}}}},
    [52] = {id=2018,desc="射线牌",target=1,type=5,minValue=0,maxValue=1,args={cardTag={{451}}}},
    [53] = {id=2019,desc="牌组卡牌为空",target=1,type=11,minValue=0,maxValue=0,args={valueKey="cardCount",area={1}}},
    [54] = {id=2020,desc="所有薮猫",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{418}}}},
    [55] = {id=2021,desc="所有黑洞",target=1,type=5,minValue=1,maxValue=-1,args={cardId={9801}}},
    [56] = {id=2022,desc="所有导弹巢",target=1,type=5,minValue=1,maxValue=-1,args={cardId={9810}}},
    [57] = {id=2023,desc="主将卡",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{6}}}},
    [58] = {id=2024,desc="此机体回路在2以上",target=1,type=11,minValue=2,maxValue=-1,args={valueKey="dirCount"}},
    [59] = {id=2025,desc="此机体回路在3以上",target=1,type=11,minValue=3,maxValue=-1,args={valueKey="dirCount"}},
    [60] = {id=2026,desc="此机体回路在4以上",target=1,type=11,minValue=4,maxValue=-1,args={valueKey="dirCount"}},
    [61] = {id=2027,desc="废弃区数量大等于5",target=1,type=11,minValue=5,maxValue=-1,args={valueKey="cardCount",area={4}}},
    [62] = {id=2028,desc="废弃区数量大等于2",target=1,type=11,minValue=2,maxValue=-1,args={valueKey="cardCount",area={4}}},
    [63] = {id=2029,desc="废弃区数量大等于4",target=1,type=11,minValue=4,maxValue=-1,args={valueKey="cardCount",area={4}}},
    [64] = {id=2030,desc="废弃区数量大等于6",target=1,type=11,minValue=6,maxValue=-1,args={valueKey="cardCount",area={4}}},
    [65] = {id=2031,desc="原型无人机",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2302}}},
    [66] = {id=2032,desc="僚机白矮星",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2204}}},
    [67] = {id=2033,desc="僚机十字星",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2208}}},
    [68] = {id=2034,desc="僚机猎户座",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2212}}},
    [69] = {id=2035,desc="僚机薮猫",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2216}}},
    [70] = {id=2036,desc="僚机特里格拉夫",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2220}}},
    [71] = {id=2037,desc="薮猫主将",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2323}}},
    [72] = {id=2038,desc="立体防御无人机",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2403}}},
    [73] = {id=2039,desc="南十字",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2442}}},
    [74] = {id=2040,desc="废弃区数量大等于3",target=1,type=11,minValue=3,maxValue=-1,args={valueKey="cardCount",area={4}}},
    [75] = {id=2041,desc="血量<=100",target=1,type=1,minValue=1,maxValue=100,args={}},
    [76] = {id=2042,desc="血量<=80",target=1,type=1,minValue=1,maxValue=80,args={}},
    [77] = {id=2043,desc="无人机在前排",target=1,type=5,minValue=0,maxValue=-1,args={positionList={row=1}}},
    [78] = {id=2044,desc="僚机白矮星",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2224}}},
    [79] = {id=2045,desc="僚机十字星",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2225}}},
    [80] = {id=2046,desc="僚机猎户座",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2226}}},
    [81] = {id=2047,desc="僚机薮猫",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2227}}},
    [82] = {id=2048,desc="僚机特里格拉夫",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2228}}},
    [83] = {id=2049,desc="手牌为0",target=1,type=11,minValue=0,maxValue=0,args={valueKey="cardCount",area={2}}},
    [84] = {id=2050,desc="此机体回路在5以上",target=1,type=11,minValue=5,maxValue=-1,args={valueKey="dirCount"}},
    [85] = {id=2051,desc="血量<=60",target=1,type=1,minValue=1,maxValue=60,args={}},
    [86] = {id=2052,desc="机体牌",target=1,type=5,minValue=0,maxValue=1,args={cardTag={{4}}}},
    [87] = {id=2053,desc="场上存在僚机[白矮星]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={2204}}},
    [88] = {id=2054,desc="场上存在僚机[十字星]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={2208}}},
    [89] = {id=2055,desc="场上存在僚机[猎户座]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={2212}}},
    [90] = {id=2056,desc="场上存在僚机[薮猫]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={2216}}},
    [91] = {id=2057,desc="场上存在僚机[特里格拉夫]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={2220}}},
    [92] = {id=2058,desc="场上存在投影僚机[白矮星]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={2224}}},
    [93] = {id=2059,desc="场上存在投影僚机[十字星]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={2225}}},
    [94] = {id=2060,desc="场上存在投影僚机[猎户座]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={2226}}},
    [95] = {id=2061,desc="场上存在投影僚机[薮猫]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={2227}}},
    [96] = {id=2062,desc="场上存在投影僚机[特里格拉夫]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={2228}}},
    [97] = {id=2063,desc="约翰驱逐舰",target=1,type=5,minValue=1,maxValue=-1,args={cardId={7009}}},
    [98] = {id=2064,desc="无人机牌",target=1,type=5,minValue=0,maxValue=1,args={cardTag={{4}}}},
    [99] = {id=2065,desc="弃牌堆数量大等于5",target=1,type=11,minValue=5,maxValue=-1,args={valueKey="cardCount",area={3}}},
    [100] = {id=2066,desc="火炮",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{600}}}},
    [101] = {id=2067,desc="突击火炮",target=1,type=5,minValue=1,maxValue=-1,args={cardId={7505}}},
    [102] = {id=2068,desc="远射火炮",target=1,type=5,minValue=1,maxValue=-1,args={cardId={7504}}},
    [103] = {id=2069,desc="拒马",target=1,type=5,minValue=0,maxValue=1,args={cardId={7506}}},
    [104] = {id=2070,desc="不存在突击火炮",target=1,type=11,minValue=0,maxValue=0,args={valueKey="droneCount",cardId={7505}}},
    [105] = {id=2071,desc="不存在远射火炮",target=1,type=11,minValue=0,maxValue=0,args={valueKey="droneCount",cardId={7504}}},
    [106] = {id=2072,desc="轰炸",target=1,type=5,minValue=0,maxValue=1,args={cardId={7514}}},
    [107] = {id=2073,desc="贯射",target=1,type=5,minValue=0,maxValue=1,args={cardId={7515}}},
    [108] = {id=2074,desc="攻击力3或3以下的无人机",target=1,type=11,minValue=0,maxValue=3,args={valueKey="attk",noTag={6,7}}},
    [109] = {id=2075,desc="数据演算无人机",target=1,type=5,minValue=0,maxValue=-1,args={cardId={7573}}},
    [110] = {id=2076,desc="己方场上有1台或更多无人机",target=1,type=13,minValue=1,maxValue=-1,args={gauge="cardCount",cardTag={{4}},noTag={7}}},
    [111] = {id=2077,desc="当手牌中有2张或更多剑匠牌时才能打出此牌。",target=1,type=11,minValue=2,maxValue=-1,args={valueKey="cardCount",area={2},cardTag={{430}}}},
    [112] = {id=2078,desc="剑匠牌",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{430}}}},
    [113] = {id=2079,desc="不是紧急维修",target=1,type=5,minValue=0,maxValue=-1,args={noTag={7599}}},
    [114] = {id=2080,desc="紧急维修",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{7599}}}},
    [115] = {id=2081,desc="此机体回路在5以上",target=1,type=11,minValue=5,maxValue=-1,args={valueKey="dirCount"}},
    [116] = {id=2082,desc="武装",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{610}}}},
    [117] = {id=2083,desc="场上存在三个以上武装",target=1,type=11,minValue=3,maxValue=-1,args={valueKey="droneCount",cardTag={{610}}}},
    [118] = {id=2084,desc="场上存在两个以上武装",target=1,type=11,minValue=2,maxValue=-1,args={valueKey="droneCount",cardTag={{610}}}},
    [119] = {id=2085,desc="突击火炮",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={7505}}},
    [120] = {id=2086,desc="远射火炮",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={7504}}},
    [121] = {id=2087,desc="战术牌",target=1,type=5,minValue=0,maxValue=1,args={cardTag={{3}}}},
    [122] = {id=2088,desc="攻击力1或1以下的无人机",target=1,type=11,minValue=0,maxValue=1,args={valueKey="attk",noTag={6,7}}},
    [123] = {id=2089,desc="堆叠内的战术牌",target=1,type=8,minValue=0,maxValue=1,args={stack={1}}},
    [124] = {id=2090,desc="若此时敌方在本回合已经使用过2张或更多牌",target=2,type=11,minValue=2,maxValue=-1,args={valueKey="roundRecord"}},
    [125] = {id=2091,desc="仅无人机",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{4}},noTag={6,7}}},
    [126] = {id=2092,desc="场上不存在病毒炸弹",target=2,type=11,minValue=0,maxValue=0,args={valueKey="droneCount",cardId={7519}}},
    [127] = {id=2093,desc="血量<=42",target=1,type=1,minValue=1,maxValue=42,args={}},
    [128] = {id=2094,desc="场上不存在无人机",target=1,type=11,minValue=1,maxValue=1,args={valueKey="droneCount"}},
    [129] = {id=2095,desc="敌方场上存在三台及以上无人机",target=2,type=11,minValue=4,maxValue=-1,args={valueKey="droneCount"}},
    [130] = {id=2096,desc="废弃区数量大等于10",target=1,type=11,minValue=10,maxValue=-1,args={valueKey="cardCount",area={4}}},
    [131] = {id=2097,desc="智械无人机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{611}}}},
    [132] = {id=2098,desc="海盗无人机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{612}}}},
    [133] = {id=2099,desc="海盗老兵",target=1,type=5,minValue=0,maxValue=1,args={cardId={8536}}},
    [134] = {id=2100,desc="海盗统帅",target=1,type=5,minValue=0,maxValue=1,args={cardId={8540}}},
    [135] = {id=2101,desc="商会无人机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{614}}}},
    [136] = {id=2102,desc="星骸无人机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{615}}}},
    [137] = {id=2103,desc="满血无人机",target=1,type=1,minValue=-1,maxValue=0,args={hpDiff=1,noTag={6,7}}},
    [138] = {id=2104,desc="所有海盗牌",target=1,type=5,minValue=-1,maxValue=-1,args={cardTag={{612}}}},
    [139] = {id=2105,desc="卡组数量大等于16",target=1,type=11,minValue=16,maxValue=-1,args={valueKey="cardCount",area={1}}},
    [140] = {id=2106,desc="攻击力0的无人机",target=1,type=11,minValue=0,maxValue=0,args={valueKey="attk",noTag={6,7}}},
    [141] = {id=2107,desc="血量1及以下的机体",target=1,type=11,minValue=0,maxValue=1,args={valueKey="hp"}},
    [142] = {id=2108,desc=">0",target=1,type=11,minValue=1,maxValue=-1,args={}},
    [143] = {id=2109,desc=">1",target=1,type=11,minValue=2,maxValue=-1,args={}},
    [144] = {id=2110,desc=">2",target=1,type=11,minValue=3,maxValue=-1,args={}},
    [145] = {id=2111,desc=">3",target=1,type=11,minValue=4,maxValue=-1,args={}},
    [146] = {id=2112,desc=">4",target=1,type=11,minValue=5,maxValue=-1,args={}},
    [147] = {id=2113,desc=">5",target=1,type=11,minValue=6,maxValue=-1,args={}},
    [148] = {id=2114,desc=">6",target=1,type=11,minValue=7,maxValue=-1,args={}},
    [149] = {id=2115,desc=">7",target=1,type=11,minValue=8,maxValue=-1,args={}},
    [150] = {id=2116,desc="满血敌方主将",target=2,type=1,minValue=-1,maxValue=0,args={hpDiff=1}},
    [151] = {id=2117,desc="牌库空",target=2,type=11,minValue=0,maxValue=0,args={valueKey="cardCount",area={1}}},
    [152] = {id=2118,desc="弃牌堆空",target=2,type=11,minValue=0,maxValue=0,args={valueKey="cardCount",area={3}}},
    [153] = {id=2119,desc="牌库小于1张",target=1,type=11,minValue=0,maxValue=1,args={valueKey="cardCount",area={1}}},
    [154] = {id=2120,desc="玩家血量小等于30",target=1,type=1,minValue=0,maxValue=30,args={}},
    [155] = {id=2121,desc="剑势牌",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{616}}}},
    [156] = {id=2122,desc="弃牌堆大等于5张",target=1,type=11,minValue=5,maxValue=-1,args={valueKey="cardCount",area={3}}},
    [157] = {id=2123,desc="弃牌堆小于5张",target=1,type=11,minValue=0,maxValue=4,args={valueKey="cardCount",area={3}}},
    [158] = {id=2124,desc="突击牌",target=1,type=5,minValue=0,maxValue=1,args={cardTag={{618}}}},
    [159] = {id=2125,desc="不包含此卡己方在本回合已经使用过1张或更多机体牌",target=1,type=11,minValue=2,maxValue=-1,args={valueKey="roundRecord",cardTag={{4}}}},
    [160] = {id=2126,desc="血量>=114514",target=1,type=1,minValue=114514,maxValue=-1,args={}},
    [161] = {id=2127,desc="血量<=30",target=1,type=1,minValue=1,maxValue=30,args={}},
    [162] = {id=2128,desc="费用大于2的手牌",target=1,type=11,minValue=2,maxValue=-1,args={valueKey="cost"}},
    [163] = {id=2129,desc="费用大于3的手牌",target=1,type=11,minValue=3,maxValue=-1,args={valueKey="cost"}},
    [164] = {id=2130,desc="掠影无人机",target=1,type=5,minValue=0,maxValue=1,args={cardId={2779}}},
    [165] = {id=2131,desc="场上存在三台及以上无人机",target=1,type=11,minValue=4,maxValue=-1,args={valueKey="droneCount"}},
    [166] = {id=2132,desc="血量<=15",target=1,type=1,minValue=1,maxValue=15,args={}},
    [167] = {id=2133,desc="手牌大等于1张",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="cardCount",area={2}}},
    [168] = {id=2134,desc="能量大等于1",target=1,type=2,minValue=1,maxValue=-1,args={}},
    [169] = {id=2135,desc="血量<=10",target=1,type=1,minValue=1,maxValue=10,args={}},
    [170] = {id=2136,desc="能量0",target=1,type=2,minValue=0,maxValue=0,args={}},
    [171] = {id=2137,desc="当前攻击力小等于10",target=1,type=11,minValue=0,maxValue=10,args={valueKey="attk"}},
    [172] = {id=2138,desc="主将持有延缓",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="attkDelay"}},
    [173] = {id=2139,desc="旋臂",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{621}}}},
    [174] = {id=2140,desc="旋臂（每个static对应）",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{621}}}},
    [175] = {id=2141,desc="拒马",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{622}}}},
    [176] = {id=2142,desc="所有猎户座",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{10037}}}},
    [177] = {id=2143,desc="所有白矮星",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{10041}}}},
    [178] = {id=2144,desc="所有追猎者",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{10045}}}},
    [179] = {id=2145,desc="所有薮猫",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{10050}}}},
    [180] = {id=2146,desc="不存在坚盾",target=1,type=11,minValue=0,maxValue=0,args={valueKey="droneCount",cardId={10018}}},
    [181] = {id=2147,desc="敌方废弃区数量大等于5",target=2,type=11,minValue=5,maxValue=-1,args={valueKey="cardCount",area={4}}},
    [182] = {id=2148,desc="所有乌羽",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10109}}},
    [183] = {id=2149,desc="导弹",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{201}}}},
    [184] = {id=2150,desc="血量<=20",target=1,type=1,minValue=1,maxValue=20,args={}},
    [185] = {id=2151,desc="所有圣域降临",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10151}}},
    [186] = {id=2152,desc="机体数量大等于1",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="cardCount",area={14}}},
    [187] = {id=2153,desc="机体数量大等于2",target=1,type=11,minValue=2,maxValue=-1,args={valueKey="cardCount",area={14}}},
    [188] = {id=2154,desc="机体数量大等于3",target=1,type=11,minValue=3,maxValue=-1,args={valueKey="cardCount",area={14}}},
    [189] = {id=2155,desc="机体数量大等于4",target=1,type=11,minValue=4,maxValue=-1,args={valueKey="cardCount",area={14}}},
    [190] = {id=2156,desc="机体数量大等于5",target=1,type=11,minValue=5,maxValue=-1,args={valueKey="cardCount",area={14}}},
    [191] = {id=2157,desc="机体数量大等于6",target=1,type=11,minValue=6,maxValue=-1,args={valueKey="cardCount",area={14}}},
    [192] = {id=2158,desc="机体数量大等于7",target=1,type=11,minValue=7,maxValue=-1,args={valueKey="cardCount",area={14}}},
    [193] = {id=2159,desc="机体数量大等于8",target=1,type=11,minValue=8,maxValue=-1,args={valueKey="cardCount",area={14}}},
    [194] = {id=2160,desc="机体数量大等于9",target=1,type=11,minValue=9,maxValue=-1,args={valueKey="cardCount",area={14}}},
    [195] = {id=2161,desc="特里格拉夫",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{10180}}}},
    [196] = {id=2162,desc="伊米尔改",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{10184}}}},
    [197] = {id=2163,desc="所有炮击",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2012}}},
    [198] = {id=2164,desc="所有标准无人机",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2025}}},
    [199] = {id=2165,desc="废弃区数量大等于5",target=1,type=11,minValue=5,maxValue=-1,args={valueKey="cardCount",area={4}}},
    [200] = {id=2166,desc="血量<=50",target=1,type=1,minValue=1,maxValue=50,args={base=1}},
    [201] = {id=2167,desc="不是兵装",target=1,type=5,minValue=0,maxValue=-1,args={noTag={623}}},
    [202] = {id=2168,desc="兵装",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{623}}}},
    [203] = {id=2169,desc="聚能浮游炮1",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10121}}},
    [204] = {id=2170,desc="聚能浮游炮2",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10122}}},
    [205] = {id=2171,desc="改修装置",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10123}}},
    [206] = {id=2172,desc="无人机派出",target=1,type=5,minValue=0,maxValue=-1,args={cardId={2301}}},
    [207] = {id=2173,desc="血量<=50",target=1,type=1,minValue=1,maxValue=50,args={base=1}},
    [208] = {id=2174,desc="血量<=60",target=1,type=1,minValue=1,maxValue=60,args={base=1}},
    [209] = {id=2175,desc="疾驰协议",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10340}}},
    [210] = {id=2176,desc="疾驰牌",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{624}}}},
    [211] = {id=2177,desc="当前攻击力小等于2",target=1,type=11,minValue=0,maxValue=2,args={valueKey="attk"}},
    [212] = {id=2178,desc="血量<=2",target=1,type=1,minValue=1,maxValue=2,args={}},
    [213] = {id=2179,desc="支援牌",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{625}}}},
    [214] = {id=2180,desc="持有覆膜",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="attkShield"}},
    [215] = {id=2181,desc="介错人",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10406}}},
    [216] = {id=2182,desc="手牌大等于6张",target=1,type=11,minValue=6,maxValue=-1,args={valueKey="cardCount",area={2}}},
    [217] = {id=2183,desc=">=10",target=1,type=11,minValue=10,maxValue=-1,args={}},
    [218] = {id=2184,desc="费用大于2的战术牌",target=1,type=11,minValue=2,maxValue=-1,args={valueKey="cost"}},
    [219] = {id=2185,desc="费用为1的牌",target=1,type=11,minValue=1,maxValue=1,args={valueKey="cost"}},
    [220] = {id=2186,desc="费用为2的牌",target=1,type=11,minValue=2,maxValue=2,args={valueKey="cost"}},
    [221] = {id=2187,desc="防御协议",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10416}}},
    [222] = {id=2188,desc="指令牌",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{626}}}},
    [223] = {id=2189,desc="不是指令牌",target=1,type=5,minValue=0,maxValue=-1,args={noTag={626}}},
    [224] = {id=2190,desc="指令牌大等于2张",target=1,type=11,minValue=2,maxValue=-1,args={valueKey="cardCount",area={2},cardTag={{626}}}},
    [225] = {id=2191,desc="坚守指令",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10454,10453}}},
    [226] = {id=2192,desc="血量>=4",target=1,type=1,minValue=4,maxValue=-1,args={valueKey="hp"}},
    [227] = {id=2193,desc="血量>=3",target=1,type=1,minValue=3,maxValue=-1,args={valueKey="hp"}},
    [228] = {id=2194,desc="能量大等于1",target=1,type=2,minValue=1,maxValue=-1,args={}},
    [229] = {id=2195,desc="能量大等于2",target=1,type=2,minValue=2,maxValue=-1,args={}},
    [230] = {id=2196,desc="能量大等于3",target=1,type=2,minValue=3,maxValue=-1,args={}},
    [231] = {id=2197,desc="能量大等于4",target=1,type=2,minValue=4,maxValue=-1,args={}},
    [232] = {id=2198,desc="能量大等于5",target=1,type=2,minValue=5,maxValue=-1,args={}},
    [233] = {id=2199,desc="能量大等于6",target=1,type=2,minValue=6,maxValue=-1,args={}},
    [234] = {id=2200,desc="能量大等于7",target=1,type=2,minValue=7,maxValue=-1,args={}},
    [235] = {id=2201,desc="能量大等于8",target=1,type=2,minValue=8,maxValue=-1,args={}},
    [236] = {id=2202,desc="能量大等于9",target=1,type=2,minValue=9,maxValue=-1,args={}},
    [237] = {id=2203,desc="能量大等于10",target=1,type=2,minValue=10,maxValue=-1,args={}},
    [238] = {id=2204,desc="恒星贯射",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{633}}}},
    [239] = {id=2205,desc=">8",target=1,type=11,minValue=9,maxValue=-1,args={}},
    [240] = {id=2206,desc=">9",target=1,type=11,minValue=10,maxValue=-1,args={}},
    [241] = {id=2207,desc=">10",target=1,type=11,minValue=11,maxValue=-1,args={}},
    [242] = {id=2208,desc=">11",target=1,type=11,minValue=12,maxValue=-1,args={}},
    [243] = {id=2209,desc=">12",target=1,type=11,minValue=13,maxValue=-1,args={}},
    [244] = {id=2210,desc=">13",target=1,type=11,minValue=14,maxValue=-1,args={}},
    [245] = {id=2211,desc=">14",target=1,type=11,minValue=15,maxValue=-1,args={}},
    [246] = {id=2212,desc=">15",target=1,type=11,minValue=16,maxValue=-1,args={}},
    [247] = {id=2213,desc=">16",target=1,type=11,minValue=17,maxValue=-1,args={}},
    [248] = {id=2214,desc=">17",target=1,type=11,minValue=18,maxValue=-1,args={}},
    [249] = {id=2215,desc=">18",target=1,type=11,minValue=19,maxValue=-1,args={}},
    [250] = {id=2216,desc="不是特里格拉夫的僚机",target=1,type=5,minValue=1,maxValue=-1,args={noTag={10180},cardTag={{7}}}},
    [251] = {id=2217,desc="赝波",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{10510}}}},
    [252] = {id=2218,desc="矩阵无人机L",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10540}}},
    [253] = {id=2219,desc="矩阵无人机D",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10541}}},
    [254] = {id=2220,desc="矩阵无人机",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10541,10540}}},
    [255] = {id=2221,desc="是矩阵无人机L",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10540}}},
    [256] = {id=2222,desc="是矩阵无人机D",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10541}}},
    [257] = {id=2223,desc="矩阵无人机>=4",target=1,type=11,minValue=4,maxValue=-1,args={valueKey="cardCount",area={14},cardTag={{6311}}}},
    [258] = {id=2224,desc="矩阵无人机L>=1",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="cardCount",area={14},cardId={10540}}},
    [259] = {id=2225,desc="矩阵无人机D>=1",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="cardCount",area={14},cardId={10541}}},
    [260] = {id=2226,desc="矩阵无人机",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10560,10561}}},
    [261] = {id=2227,desc="电磁",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{628}}}},
    [262] = {id=2228,desc="电磁掠影",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10598}}},
    [263] = {id=2229,desc="当前攻击力=0",target=1,type=11,minValue=0,maxValue=0,args={valueKey="attk"}},
    [264] = {id=2230,desc="血量<=20",target=1,type=1,minValue=0,maxValue=20,args={base=1}},
    [265] = {id=2231,desc="血量<=40",target=1,type=1,minValue=0,maxValue=40,args={base=1}},
    [266] = {id=2232,desc="手牌>=7",target=1,type=11,minValue=7,maxValue=-1,args={valueKey="cardCount",area={2}}},
    [267] = {id=2233,desc="手牌>=5",target=1,type=11,minValue=5,maxValue=-1,args={valueKey="cardCount",area={2}}},
    [268] = {id=2234,desc="战机",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{629}}}},
    [269] = {id=2235,desc="是战机",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{629}}}},
    [270] = {id=2236,desc="当手牌中有2张或更多战机牌时才能打出此牌。",target=1,type=11,minValue=2,maxValue=-1,args={valueKey="cardCount",area={2},cardTag={{629}}}},
    [271] = {id=2237,desc="武装神机",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10634,10635}}},
    [272] = {id=2238,desc="是激光",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{630}}}},
    [273] = {id=2239,desc="不是激光",target=1,type=5,minValue=1,maxValue=1,args={noTag={630}}},
    [274] = {id=2240,desc="怒火激光",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10666,10667}}},
    [275] = {id=2241,desc="所有炮击",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10214}}},
    [276] = {id=2242,desc="当前攻击力大于5",target=1,type=11,minValue=5,maxValue=-1,args={valueKey="attk"}},
    [277] = {id=2243,desc="所在列没有敌方机体",target=2,type=11,minValue=0,maxValue=0,args={valueKey="droneCount",gridCheck={colTarget=1}}},
    [278] = {id=2244,desc="所有埃阿斯",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10703}}},
    [279] = {id=2245,desc="当前攻击力大于10",target=1,type=11,minValue=10,maxValue=-1,args={valueKey="attk"}},
    [280] = {id=2246,desc="当前攻击力大于15",target=1,type=11,minValue=15,maxValue=-1,args={valueKey="attk"}},
    [281] = {id=2247,desc="所有哈姆雷特",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10708}}},
    [282] = {id=2248,desc="所有阿克琉斯",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10704}}},
    [283] = {id=2249,desc="鬼魂",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10709}}},
    [284] = {id=2250,desc="一百次失败",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10711}}},
    [285] = {id=2251,desc="绝境绝景",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10712}}},
    [286] = {id=2253,desc="冥河之水",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10713}}},
    [287] = {id=2254,desc="奥德修斯之勇",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10714}}},
    [288] = {id=2255,desc="手牌大等于4张",target=1,type=11,minValue=4,maxValue=-1,args={valueKey="cardCount",area={2}}},
    [289] = {id=2256,desc="玩家血量小等于10",target=1,type=1,minValue=0,maxValue=10,args={base=1}},
    [290] = {id=2257,desc="当前攻击力大于7",target=1,type=11,minValue=7,maxValue=-1,args={valueKey="attk"}},
    [291] = {id=2258,desc="[炮击][射击][振剑势]",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2012,2127,10307}}},
    [292] = {id=2259,desc="高能炮击",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10188}}},
    [293] = {id=2260,desc="主将＆僚机",target=1,type=5,minValue=0,maxValue=1,args={cardTag={{6},{7}}}},
    [294] = {id=2261,desc="恒星贯射",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10214}}},
    [295] = {id=2262,desc="振剑式",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10307}}},
    [296] = {id=2263,desc="血量>=40",target=1,type=1,minValue=40,maxValue=-1,args={base=1}},
    [297] = {id=2264,desc="血量<40",target=1,type=1,minValue=0,maxValue=39,args={base=1}},
    [298] = {id=2265,desc="是带伤害激光",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{6301}}}},
    [299] = {id=2266,desc="是带伤害战术",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{31}}}},
    [300] = {id=2267,desc="薮猫-剑卫",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10050}}},
    [301] = {id=2268,desc="薮猫-牵制",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10730}}},
    [302] = {id=2269,desc="特里格拉夫α",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10180,10736}}},
    [303] = {id=2270,desc="武装神机",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10634,10635}}},
    [304] = {id=2271,desc="猎户座-狂热",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10497}}},
    [305] = {id=2272,desc="伊米尔改-集约",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10184}}},
    [306] = {id=2273,desc="追猎者-强袭",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10045}}},
    [307] = {id=2274,desc="薮猫-游侠式",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10394}}},
    [308] = {id=2275,desc="猎户座-精准",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10502}}},
    [309] = {id=2276,desc="猎户座-刺神",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10747}}},
    [310] = {id=2277,desc="特里格拉夫β",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10506}}},
    [311] = {id=2278,desc="白矮星强袭",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2204}}},
    [312] = {id=2279,desc="追猎者哨戒",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10750}}},
    [313] = {id=2280,desc="手牌大等于5张",target=1,type=11,minValue=5,maxValue=-1,args={valueKey="cardCount",area={2}}},
    [314] = {id=2281,desc="血量<=50",target=1,type=1,minValue=1,maxValue=50,args={base=1}},
    [315] = {id=2282,desc="场上存在精英敌人",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardTag={{9}}}},
    [316] = {id=2283,desc="所有圣域之锚",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10778}}},
    [317] = {id=2284,desc="所有圣域崩塌",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10786}}},
    [318] = {id=2285,desc="星核数量在200以上",target=1,type=11,minValue=200,maxValue=-1,args={valueKey="gold"}},
    [319] = {id=2286,desc="星核数量在100以下",target=1,type=11,minValue=-1,maxValue=99,args={valueKey="gold"}},
    [320] = {id=2287,desc="造成3以上伤害",target=1,type=11,minValue=3,maxValue=-1,args={}},
    [321] = {id=2288,desc="黎明、黄昏矩阵",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10561,10560}}},
    [322] = {id=2289,desc="剑装牌",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{617}}}},
    [323] = {id=2290,desc="所有恒星贯射、仇星贯射",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10214,10671}}},
    [324] = {id=2291,desc="剑意化形牌",target=1,type=5,minValue=0,maxValue=-1,args={cardTag={{634}}}},
    [325] = {id=2292,desc="疾驰幻影",target=1,type=5,minValue=0,maxValue=-1,args={cardId={10843}}},
    [326] = {id=2293,desc="出力干扰模块",target=1,type=5,minValue=0,maxValue=-1,args={cardId={11048}}},
    [327] = {id=2294,desc="通讯干扰模块",target=1,type=5,minValue=0,maxValue=-1,args={cardId={11047}}},
    [328] = {id=2295,desc="支援协议B",target=1,type=5,minValue=0,maxValue=1,args={cardId={11046}}},
    [329] = {id=2296,desc="支援协议A",target=1,type=5,minValue=0,maxValue=1,args={cardId={11045}}},
    [330] = {id=2297,desc="场上存在[天线]",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="droneCount",cardId={21015}}},
    [331] = {id=2298,desc="场上不存在[天线]",target=1,type=11,minValue=0,maxValue=0,args={valueKey="droneCount",cardId={21015}}},
    [332] = {id=2299,desc="复制工蜂",target=1,type=5,minValue=1,maxValue=-1,args={cardId={21044}}},
    [333] = {id=2300,desc="手牌",target=1,type=5,minValue=0,maxValue=1,args={}},
    [334] = {id=2301,desc="手牌中的协同牌",target=1,type=5,minValue=-1,maxValue=1,args={cardTag={{627}}}},
    [335] = {id=2302,desc="是激光",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{630}}}},
    [336] = {id=2303,desc="是指令",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{626}}}},
    [337] = {id=2304,desc="是武装",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{610}}}},
    [338] = {id=2305,desc="是协同",target=1,type=5,minValue=1,maxValue=1,args={cardTag={{627}}}},
    [339] = {id=2306,desc="白矮星僚机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{425}}}},
    [340] = {id=2307,desc="猎户座僚机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{427}}}},
    [341] = {id=2308,desc="薮猫僚机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{428}}}},
    [342] = {id=2309,desc="刃型观测机僚机",target=1,type=5,minValue=1,maxValue=-1,args={cardTag={{701}}}},
    [343] = {id=2310,desc="目标机体至少搭乘1名机师",target=1,type=11,minValue=1,maxValue=-1,args={valueKey="heroCount"}},
    [344] = {id=2311,desc="重锤/长矛武装",target=1,type=5,minValue=1,maxValue=-1,args={cardId={7617,7618,7619,7620}}},
    [345] = {id=2312,desc="影隼α/利爪α",target=1,type=5,minValue=1,maxValue=-1,args={cardId={10370,10378}}},
    [346] = {id=2313,desc="射击/射击+",target=1,type=5,minValue=1,maxValue=-1,args={cardId={2127,2128}}},
    [347] = {id=2315,desc="当前攻击力小等于3",target=1,type=11,minValue=0,maxValue=3,args={valueKey="attk"}},
}
local config = {}
local config_loaded = {}
local config_languages = {}

local function config_load(index)
    if index == nil then return nil end
    if config_loaded[index] then return config[index] end
    local source = config_source[index]
    if source == nil then return nil end
    local rowLanguage = config_languages[index] or nil
    local data = ConfigRowRuntime.Build(source,config_runtime_schema,"battle_condition_def",rowLanguage)
    config[index] = data
    config_loaded[index] = true
    return data
end

function battle_condition_def.config_index(index)
    return config_load(index)
end

function battle_condition_def.config_set(index,data)
    config[index] = data
    config_loaded[index] = true
end

function battle_condition_def.config_num()
    return config_num
end

local config_id =
{
    [1001]=1,[1002]=2,[1003]=3,[1004]=4,[1005]=5,[1006]=6,[1007]=7,[1008]=8,[1009]=9,[1010]=10,[1011]=11,[1012]=12,[1013]=13,[1014]=14,[1015]=15,[1016]=16,[1017]=17,[1018]=18,[1019]=19,[1020]=20,[1021]=21,[1022]=22,[1023]=23,[501]=24,[502]=25,[503]=26,[504]=27,[505]=28,[601]=29,[602]=30,[603]=31,[60]=32,[61]=33,[2000]=34,[2001]=35,[2002]=36,[2003]=37,[2004]=38,[2005]=39,[2006]=40,[2007]=41,[2008]=42,[2009]=43,[2010]=44,[2011]=45,[2012]=46,[2013]=47,[2014]=48,[2015]=49,[2016]=50,[2017]=51,[2018]=52,[2019]=53,[2020]=54,[2021]=55,[2022]=56,[2023]=57,[2024]=58,[2025]=59,[2026]=60,[2027]=61,[2028]=62,[2029]=63,[2030]=64,[2031]=65,[2032]=66,[2033]=67,[2034]=68,[2035]=69,[2036]=70,[2037]=71,[2038]=72,[2039]=73,[2040]=74,[2041]=75,[2042]=76,[2043]=77,[2044]=78,[2045]=79,[2046]=80,[2047]=81,[2048]=82,[2049]=83,[2050]=84,[2051]=85,[2052]=86,[2053]=87,[2054]=88,[2055]=89,[2056]=90,[2057]=91,[2058]=92,[2059]=93,[2060]=94,[2061]=95,[2062]=96,[2063]=97,[2064]=98,[2065]=99,[2066]=100,[2067]=101,[2068]=102,[2069]=103,[2070]=104,[2071]=105,[2072]=106,[2073]=107,[2074]=108,[2075]=109,[2076]=110,[2077]=111,[2078]=112,[2079]=113,[2080]=114,[2081]=115,[2082]=116,[2083]=117,[2084]=118,[2085]=119,[2086]=120,[2087]=121,[2088]=122,[2089]=123,[2090]=124,[2091]=125,[2092]=126,[2093]=127,[2094]=128,[2095]=129,[2096]=130,[2097]=131,[2098]=132,[2099]=133,[2100]=134,[2101]=135,[2102]=136,[2103]=137,[2104]=138,[2105]=139,[2106]=140,[2107]=141,[2108]=142,[2109]=143,[2110]=144,[2111]=145,[2112]=146,[2113]=147,[2114]=148,[2115]=149,[2116]=150,[2117]=151,[2118]=152,[2119]=153,[2120]=154,[2121]=155,[2122]=156,[2123]=157,[2124]=158,[2125]=159,[2126]=160,[2127]=161,[2128]=162,[2129]=163,[2130]=164,[2131]=165,[2132]=166,[2133]=167,[2134]=168,[2135]=169,[2136]=170,[2137]=171,[2138]=172,[2139]=173,[2140]=174,[2141]=175,[2142]=176,[2143]=177,[2144]=178,[2145]=179,[2146]=180,[2147]=181,[2148]=182,[2149]=183,[2150]=184,[2151]=185,[2152]=186,[2153]=187,[2154]=188,[2155]=189,[2156]=190,[2157]=191,[2158]=192,[2159]=193,[2160]=194,[2161]=195,[2162]=196,[2163]=197,[2164]=198,[2165]=199,[2166]=200,[2167]=201,[2168]=202,[2169]=203,[2170]=204,[2171]=205,[2172]=206,[2173]=207,[2174]=208,[2175]=209,[2176]=210,[2177]=211,[2178]=212,[2179]=213,[2180]=214,[2181]=215,[2182]=216,[2183]=217,[2184]=218,[2185]=219,[2186]=220,[2187]=221,[2188]=222,[2189]=223,[2190]=224,[2191]=225,[2192]=226,[2193]=227,[2194]=228,[2195]=229,[2196]=230,[2197]=231,[2198]=232,[2199]=233,[2200]=234,[2201]=235,[2202]=236,[2203]=237,[2204]=238,[2205]=239,[2206]=240,[2207]=241,[2208]=242,[2209]=243,[2210]=244,[2211]=245,[2212]=246,[2213]=247,[2214]=248,[2215]=249,[2216]=250,[2217]=251,[2218]=252,[2219]=253,[2220]=254,[2221]=255,[2222]=256,[2223]=257,[2224]=258,[2225]=259,[2226]=260,[2227]=261,[2228]=262,[2229]=263,[2230]=264,[2231]=265,[2232]=266,[2233]=267,[2234]=268,[2235]=269,[2236]=270,[2237]=271,[2238]=272,[2239]=273,[2240]=274,[2241]=275,[2242]=276,[2243]=277,[2244]=278,[2245]=279,[2246]=280,[2247]=281,[2248]=282,[2249]=283,[2250]=284,[2251]=285,[2253]=286,[2254]=287,[2255]=288,[2256]=289,[2257]=290,[2258]=291,[2259]=292,[2260]=293,[2261]=294,[2262]=295,[2263]=296,[2264]=297,[2265]=298,[2266]=299,[2267]=300,[2268]=301,[2269]=302,[2270]=303,[2271]=304,[2272]=305,[2273]=306,[2274]=307,[2275]=308,[2276]=309,[2277]=310,[2278]=311,[2279]=312,[2280]=313,[2281]=314,[2282]=315,[2283]=316,[2284]=317,[2285]=318,[2286]=319,[2287]=320,[2288]=321,[2289]=322,[2290]=323,[2291]=324,[2292]=325,[2293]=326,[2294]=327,[2295]=328,[2296]=329,[2297]=330,[2298]=331,[2299]=332,[2300]=333,[2301]=334,[2302]=335,[2303]=336,[2304]=337,[2305]=338,[2306]=339,[2307]=340,[2308]=341,[2309]=342,[2310]=343,[2311]=344,[2312]=345,[2313]=346,[2315]=347
}

function battle_condition_def.config_id(key)
    local index = config_id[key]
    return battle_condition_def.config_index(index)
end

local configSheets =
{
    ["config"] =
    {
        schema = config_schema,
        indexes =
        {
            { indexKey = "id", fields = {"id"}, fieldTypes = {"int"}, group = false },
        },
    },
}

local configSheetRuntimes =
{
    ["config"] =
    {
        getRows = function() return config_source end,
        getLanguages = function() return config_languages end,
        getSchema = function() return config_runtime_schema end,
        publish = function(rows,indexes,schema,languages)
            config_source = rows
            config_runtime_schema = schema or config_schema
            config_languages = languages or {}
            config = {}
            config_loaded = {}
            config_num = #rows
            config_id = indexes["id"] or {}
        end,
    },
}

local function BuildIndexKey(row,fields)
    if #fields == 1 then return row[fields[1]] end
    local values = {}
    for index,fieldName in ipairs(fields) do
        values[index] = tostring(row[fieldName])
    end
    return table.concat(values,"_")
end

local function BuildIndexKeyFromValue(value,fields)
    if #fields == 1 then return value end
    if type(value) ~= "table" or #value ~= #fields then return nil end
    local values = {}
    for index = 1,#fields do values[index] = tostring(value[index]) end
    return table.concat(values,"_")
end

local function ValidateRowsTable(rows)
    if type(rows) ~= "table" then return false,"配置行集合需要 table" end
    local count = 0
    for key in pairs(rows) do
        if type(key) ~= "number" or key < 1 or key % 1 ~= 0 then
            return false,string.format("配置行集合包含无效数组键[%s]",tostring(key))
        end
        count = count + 1
    end
    for index = 1,count do
        if rows[index] == nil then return false,string.format("配置行集合存在空洞[%s]",index) end
    end
    return true
end

local function GetIndexRule(info,installKey)
    local indexKey = nil
    if type(installKey) == "string" then
        indexKey = installKey
    elseif type(installKey) == "table" then
        local valid,err = ValidateRowsTable(installKey)
        if not valid then return nil,err end
        local fields = {}
        for index,fieldName in ipairs(installKey) do
            if type(fieldName) ~= "string" then return nil,string.format("installKey第%s项需要 string",index) end
            fields[index] = fieldName
        end
        indexKey = table.concat(fields,",")
    else
        return nil,string.format("installKey需要 string 或有序字段数组，实际为 %s",type(installKey))
    end
    for _,rule in ipairs(info.indexes) do
        if rule.indexKey == indexKey then return rule end
    end
    return nil,string.format("installKey未匹配现有查询索引[%s]",tostring(indexKey))
end

function battle_condition_def.GetSheetInfo(sheetName)
    return configSheets[sheetName]
end

function battle_condition_def.CaptureState(sheetName)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    return { rows = runtime.getRows(), languages = runtime.getLanguages(), schema = runtime.getSchema() }
end

function battle_condition_def.RestoreState(sheetName,state)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    if type(state) ~= "table" or type(state.rows) ~= "table" or type(state.languages) ~= "table" or type(state.schema) ~= "table" then
        return false,"配置快照无效"
    end
    local indexes,indexErr = battle_condition_def.BuildIndexes(sheetName,state.rows,true,state.schema)
    if indexes == nil then return false,indexErr end
    runtime.publish(state.rows,indexes,state.schema,state.languages)
    return true
end

function battle_condition_def.ValidateRow(sheetName,row,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return false,schemaErr end
    return ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
end

function battle_condition_def.BuildIndexes(sheetName,rows,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    local rowsValid,rowsErr = ValidateRowsTable(rows)
    if not rowsValid then return nil,rowsErr end
    local indexes = {}
    for _,rule in ipairs(info.indexes) do indexes[rule.indexKey] = {} end
    for index,row in ipairs(rows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",index,err) end
        for _,rule in ipairs(info.indexes) do
            local key = BuildIndexKey(row,rule.fields)
            local target = indexes[rule.indexKey]
            if rule.group then
                target[key] = target[key] or {}
                table.insert(target[key],index)
            else
                target[key] = index
            end
        end
    end
    return indexes
end

local function RemoveRowOwners(info,owners,row,rowIndex)
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local key = BuildIndexKey(row,rule.fields)
            local keyOwners = owners[rule.indexKey][key]
            if keyOwners ~= nil then
                for ownerIndex = #keyOwners,1,-1 do
                    if keyOwners[ownerIndex] == rowIndex then table.remove(keyOwners,ownerIndex) end
                end
                if #keyOwners == 0 then owners[rule.indexKey][key] = nil end
            end
        end
    end
end

local function ResolveNewRowConflicts(info,groupRule,rows,languages,newRowIndexes)
    local owners = {}
    local active = {}
    local isNew = {}
    local conflicts = {}
    for _,rowIndex in ipairs(newRowIndexes) do isNew[rowIndex] = true end
    for _,rule in ipairs(info.indexes) do if not rule.group then owners[rule.indexKey] = {} end end
    for rowIndex,row in ipairs(rows) do
        active[rowIndex] = true
        if not isNew[rowIndex] then
            for _,rule in ipairs(info.indexes) do
                if not rule.group then
                    local key = BuildIndexKey(row,rule.fields)
                    local keyOwners = owners[rule.indexKey][key] or {}
                    table.insert(keyOwners,rowIndex)
                    owners[rule.indexKey][key] = keyOwners
                end
            end
        end
    end
    for _,rowIndex in ipairs(newRowIndexes) do
        local row = rows[rowIndex]
        local removeIndexes = {}
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                local keyOwners = owners[rule.indexKey][key]
                if keyOwners ~= nil then
                    for _,oldIndex in ipairs(keyOwners) do
                        if active[oldIndex] then
                            removeIndexes[oldIndex] = true
                            table.insert(conflicts,{
                                indexKey = rule.indexKey,
                                key = key,
                                oldIndex = oldIndex,
                                newIndex = rowIndex,
                                oldGroupKey = BuildIndexKey(rows[oldIndex],groupRule.fields),
                                newGroupKey = BuildIndexKey(row,groupRule.fields),
                            })
                        end
                    end
                end
            end
        end
        for oldIndex in pairs(removeIndexes) do
            active[oldIndex] = false
            RemoveRowOwners(info,owners,rows[oldIndex],oldIndex)
        end
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                owners[rule.indexKey][key] = {rowIndex}
            end
        end
    end
    local result = {}
    local resultLanguages = {}
    for rowIndex,row in ipairs(rows) do
        if active[rowIndex] then
            table.insert(result,row)
            table.insert(resultLanguages,languages[rowIndex] or false)
        end
    end
    return result,resultLanguages,conflicts
end

local function CollectAppendConflicts(info,currentCount,rows)
    local conflicts = {}
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local latest = {}
            for rowIndex,row in ipairs(rows) do
                local key = BuildIndexKey(row,rule.fields)
                local oldIndex = latest[key]
                if rowIndex > currentCount and oldIndex ~= nil then
                    table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=oldIndex,newIndex=rowIndex})
                end
                latest[key] = rowIndex
            end
        end
    end
    return conflicts
end

function battle_condition_def.ApplyBatch(sheetName,batch,allowUnknown,schemaOverride,rowLanguage)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local runtime = configSheetRuntimes[sheetName]
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    if type(batch) ~= "table" then return nil,"配置批次需要 table" end
    for key in pairs(batch) do
        if key ~= "installKey" and key ~= "installValue" and key ~= "operation" and key ~= "rows" then
            return nil,string.format("配置批次包含未知字段[%s]",tostring(key))
        end
    end
    local newRows = batch.rows
    local rowsValid,rowsErr = ValidateRowsTable(newRows)
    if not rowsValid then return nil,rowsErr end
    for rowIndex,row in ipairs(newRows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",rowIndex,err) end
    end
    local warnings = {}
    if #newRows == 0 and batch.installKey == nil then
        return { operation = "append", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} }
    end
    local currentRows = runtime.getRows()
    local currentLanguages = runtime.getLanguages()
    local candidateRows = {}
    local candidateLanguages = {}
    local newRowIndexes = {}
    if batch.installKey == nil then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"无 installKey 批次不能声明 installValue/operation" end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
        end
        local indexes,indexErr = battle_condition_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        local conflicts = CollectAppendConflicts(info,#currentRows,candidateRows)
        if #conflicts > 0 then table.insert(warnings,string.format("无 installKey 追加产生 %s 个普通查询键冲突；后写结果生效",#conflicts)) end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "append", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    local rule,ruleErr = GetIndexRule(info,batch.installKey)
    if rule == nil then return nil,ruleErr end
    if not rule.group then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"普通 upsert 不能声明 installValue/operation" end
        if #newRows == 0 then return { operation = "upsert", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} } end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        local conflicts = {}
        for _,newRow in ipairs(newRows) do
            local key = BuildIndexKey(newRow,rule.fields)
            local matched = {}
            for rowIndex,oldRow in ipairs(candidateRows) do
                if BuildIndexKey(oldRow,rule.fields) == key then table.insert(matched,rowIndex) end
            end
            if #matched > 1 then return nil,string.format("安装身份歧义[index:%s][key:%s][rows:%s]",rule.indexKey,tostring(key),table.concat(matched,",")) end
            if #matched == 1 then
                table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=matched[1],newIndex=matched[1]})
                candidateRows[matched[1]] = newRow
                candidateLanguages[matched[1]] = rowLanguage or false
            else
                table.insert(candidateRows,newRow)
                table.insert(candidateLanguages,rowLanguage or false)
            end
        end
        local indexes,indexErr = battle_condition_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "upsert", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    if batch.installValue == nil then return nil,"组批次缺少 installValue" end
    local groupKey = BuildIndexKeyFromValue(batch.installValue,rule.fields)
    if groupKey == nil then return nil,"installValue 与组查询字段不匹配" end
    local operation = batch.operation or "replace"
    if operation ~= "replace" and operation ~= "append" then return nil,string.format("无效组操作[%s]",tostring(operation)) end
    for rowIndex,row in ipairs(newRows) do
        local rowGroupKey = BuildIndexKey(row,rule.fields)
        if rowGroupKey ~= groupKey then return nil,string.format("组键不一致[目标:%s][第%s行:%s]",tostring(groupKey),rowIndex,tostring(rowGroupKey)) end
    end
    if operation == "append" and #newRows == 0 then return { operation = operation, groupKey = groupKey, rows = runtime.getRows(), warnings = {"空组 append 未修改配置"}, conflicts = {} } end
    local firstGroupIndex = nil
    local oldGroupCount = 0
    if operation == "replace" then
        for rowIndex,row in ipairs(currentRows) do
            if BuildIndexKey(row,rule.fields) == groupKey then
                oldGroupCount = oldGroupCount + 1
                if firstGroupIndex == nil then firstGroupIndex = #candidateRows + 1 end
            else
                table.insert(candidateRows,row)
                table.insert(candidateLanguages,currentLanguages[rowIndex] or false)
            end
        end
        local insertIndex = firstGroupIndex or (#candidateRows + 1)
        for offset,row in ipairs(newRows) do
            table.insert(candidateRows,insertIndex + offset - 1,row)
            table.insert(candidateLanguages,insertIndex + offset - 1,rowLanguage or false)
        end
        for offset = 1,#newRows do table.insert(newRowIndexes,insertIndex + offset - 1) end
    else
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
            table.insert(newRowIndexes,#candidateRows)
        end
    end
    if operation == "replace" and oldGroupCount == 0 and #newRows == 0 then table.insert(warnings,"清空不存在的组未修改配置") end
    local resultRows,resultLanguages,conflicts = ResolveNewRowConflicts(info,rule,candidateRows,candidateLanguages,newRowIndexes)
    local indexes,indexErr = battle_condition_def.BuildIndexes(sheetName,resultRows,allowUnknown,schemaOverride)
    if indexes == nil then return nil,indexErr end
    runtime.publish(resultRows,indexes,schema,resultLanguages)
    return { operation = operation, groupKey = groupKey, rows = resultRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
end

local sheetFunc = 
{
    ["config"] = 
    {
        ["index"] = "config_index",
        ["@num"] = "config_num",
        ["@set"] = "config_set",
        ["id"] = "config_id",
    },
}

function battle_condition_def.Get(sheetName,keyIndex,key)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return nil,1 end
    local funName = funcIndexs[keyIndex]
    if not funName then return nil,2 end
    return battle_condition_def[funName](key),nil
end

function battle_condition_def.Set(sheetName,index,data)
    if index == nil then return false end
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return false end
    local funName = funcIndexs["@set"]
    battle_condition_def[funName](index,data)
    return true
end

function battle_condition_def.GetNum(sheetName)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return 0 end
    local funName = funcIndexs["@num"]
    return battle_condition_def[funName]()
end

return battle_condition_def