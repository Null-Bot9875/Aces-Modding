local battle_target_def = {}
local ConfigRowRuntime = require("common/config/ConfigRowRuntime")

--config
local config_num = 484
local config_schema =
{
    ["id"] = { type = "int" },
    ["actor"] = { type = "int" },
    ["target"] = { type = "int" },
    ["area"] = { type = "list", item = { type = "int" } },
    ["flag"] = { type = "lua" },
    ["conditionList"] = { type = "list", item = { type = "int" } },
    ["conditionType"] = { type = "int" },
    ["minValue"] = { type = "int" },
    ["maxValue"] = { type = "int" },
}
local config_runtime_schema = config_schema
local config_source =
{
    [1] = {id=10,actor=1,target=1,area={11},flag={},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [2] = {id=20,actor=1,target=1,area={13},flag={empty=1,equip=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [3] = {id=21,actor=1,target=1,area={13},flag={equip=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [4] = {id=22,actor=1,target=1,area={13},flag={empty=0,hero=0},conditionList={2015},conditionType=1,minValue=1,maxValue=1},
    [5] = {id=23,actor=1,target=1,area={13},flag={equip=1,empty=0},conditionList={2016},conditionType=1,minValue=1,maxValue=1},
    [6] = {id=24,actor=1,target=2,area={15},flag={seq=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [7] = {id=30,actor=1,target=2,area={14},flag={attkTarget=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [8] = {id=31,actor=1,target=2,area={14},flag={attkTarget=5},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [9] = {id=40,actor=1,target=2,area={14},flag={},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [10] = {id=50,actor=1,target=1,area={2},flag={},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [11] = {id=60,actor=1,target=1,area={14},flag={},conditionList={60},conditionType=1,minValue=1,maxValue=1},
    [12] = {id=61,actor=1,target=1,area={14},flag={},conditionList={61},conditionType=1,minValue=1,maxValue=1},
    [13] = {id=62,actor=1,target=2,area={1},flag={seq=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [14] = {id=63,actor=1,target=1,area={1},flag={seq=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [15] = {id=100,actor=1,target=1,area={8},flag={selfPlayer = 1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [16] = {id=101,actor=1,target=2,area={8},flag={},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [17] = {id=102,actor=1,target=2,area={14},flag={rowOne = 1},conditionList={0},conditionType=1,minValue=1,maxValue=3},
    [18] = {id=103,actor=1,target=1,area={14},flag={self=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [19] = {id=104,actor=1,target=1,area={14},flag={},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [20] = {id=105,actor=1,target=1,area={13},flag={rowOne = 1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=3},
    [21] = {id=106,actor=1,target=2,area={14},flag={attkTarget=3},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [22] = {id=107,actor=1,target=1,area={14},flag={rowOne = 1},conditionList={0},conditionType=1,minValue=1,maxValue=3},
    [23] = {id=108,actor=1,target=1,area={14},flag={},conditionList={1002},conditionType=1,minValue=1,maxValue=1},
    [24] = {id=109,actor=1,target=2,area={14},flag={},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [25] = {id=110,actor=1,target=1,area={14},flag={},conditionList={1007},conditionType=1,minValue=0,maxValue=-1},
    [26] = {id=111,actor=1,target=1,area={14},flag={empty=0},conditionList={2001},conditionType=1,minValue=0,maxValue=-1},
    [27] = {id=112,actor=1,target=1,area={14},flag={},conditionList={1003},conditionType=1,minValue=0,maxValue=6},
    [28] = {id=113,actor=1,target=2,area={14},flag={colTarget=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [29] = {id=114,actor=1,target=1,area={8,14},flag={},conditionList={0},conditionType=1,minValue=1,maxValue=-1},
    [30] = {id=115,actor=1,target=1,area={2},flag={},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [31] = {id=116,actor=1,target=1,area={6},flag={self=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [32] = {id=117,actor=1,target=2,area={14},flag={attkTarget=2},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [33] = {id=118,actor=1,target=1,area={2},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [34] = {id=119,actor=1,target=1,area={13},flag={rowSide=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=-1},
    [35] = {id=120,actor=1,target=1,area={13},flag={lastPos=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [36] = {id=121,actor=1,target=1,area={13},flag={},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [37] = {id=122,actor=1,target=1,area={14},flag={},conditionList={1010},conditionType=1,minValue=-1,maxValue=-1},
    [38] = {id=123,actor=1,target=1,area={14},flag={side=1},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [39] = {id=124,actor=1,target=1,area={13},flag={randPosition={4},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [40] = {id=125,actor=1,target=1,area={13},flag={randPosition={6},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [41] = {id=126,actor=1,target=1,area={13},flag={side=1,empty=1,randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [42] = {id=127,actor=1,target=1,area={14},flag={colNext=1},conditionList={0},conditionType=1,minValue=0,maxValue=1},
    [43] = {id=128,actor=1,target=1,area={5},flag={},conditionList={1013},conditionType=1,minValue=1,maxValue=1},
    [44] = {id=129,actor=1,target=1,area={14},flag={},conditionList={1011},conditionType=1,minValue=0,maxValue=-1},
    [45] = {id=130,actor=1,target=1,area={14},flag={empty=0},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [46] = {id=131,actor=1,target=1,area={13},flag={randPosition={1},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [47] = {id=132,actor=1,target=1,area={13},flag={randPosition={3},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [48] = {id=133,actor=1,target=1,area={5},flag={},conditionList={1015},conditionType=1,minValue=1,maxValue=1},
    [49] = {id=134,actor=1,target=3,area={14},flag={self=0},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [50] = {id=135,actor=1,target=1,area={13},flag={randPosition={5},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [51] = {id=136,actor=1,target=1,area={14},flag={},conditionList={1018},conditionType=1,minValue=1,maxValue=1},
    [52] = {id=137,actor=1,target=1,area={14},flag={},conditionList={1007},conditionType=1,minValue=0,maxValue=-1},
    [53] = {id=138,actor=1,target=2,area={14},flag={attkTarget=4},conditionList={0},conditionType=1,minValue=1,maxValue=3},
    [54] = {id=139,actor=1,target=1,area={14},flag={},conditionList={1019},conditionType=1,minValue=0,maxValue=1},
    [55] = {id=140,actor=1,target=1,area={14},flag={},conditionList={1021},conditionType=1,minValue=-1,maxValue=-1},
    [56] = {id=201,actor=1,target=1,area={13},flag={randPosition={4,6},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [57] = {id=202,actor=1,target=1,area={13},flag={row=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [58] = {id=203,actor=1,target=1,area={13},flag={dir={8},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [59] = {id=204,actor=1,target=1,area={13},flag={randPosition={2},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [60] = {id=205,actor=1,target=1,area={13},flag={randPosition={2,4,6},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [61] = {id=206,actor=1,target=1,area={13},flag={selPosition={4,6},empty=1,equip=1},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [62] = {id=207,actor=1,target=1,area={13},flag={selPosition={1,3},empty=1},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [63] = {id=301,actor=1,target=2,area={14},flag={attkTarget=2},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [64] = {id=302,actor=1,target=1,area={14},flag={},conditionList={1014},conditionType=1,minValue=0,maxValue=-1},
    [65] = {id=303,actor=1,target=1,area={14},flag={colNext=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [66] = {id=304,actor=1,target=2,area={14},flag={sort="minHp"},conditionList={0},conditionType=1,minValue=2,maxValue=2},
    [67] = {id=401,actor=1,target=2,area={13},flag={empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [68] = {id=402,actor=1,target=1,area={2},flag={},conditionList={601},conditionType=1,minValue=-1,maxValue=-1},
    [69] = {id=403,actor=1,target=1,area={14},flag={},conditionList={602},conditionType=1,minValue=-1,maxValue=-1},
    [70] = {id=404,actor=1,target=1,area={13},flag={colSide=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=-1},
    [71] = {id=405,actor=1,target=1,area={14},flag={sameRow=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [72] = {id=406,actor=1,target=1,area={13},flag={empty=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [73] = {id=407,actor=1,target=1,area={14},flag={row=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [74] = {id=408,actor=1,target=1,area={14},flag={row=2},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [75] = {id=409,actor=1,target=1,area={13},flag={empty=1,row=2},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [76] = {id=410,actor=1,target=1,area={14},flag={},conditionList={603},conditionType=1,minValue=1,maxValue=1},
    [77] = {id=411,actor=1,target=1,area={13},flag={empty=1,row=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [78] = {id=412,actor=1,target=3,area={14},flag={self=0},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [79] = {id=413,actor=1,target=1,area={13},flag={dir={4,6}},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [80] = {id=70,actor=1,target=2,area={14},flag={},conditionList={60},conditionType=1,minValue=1,maxValue=1},
    [81] = {id=501,actor=1,target=1,area={14},flag={},conditionList={2001},conditionType=1,minValue=0,maxValue=-1},
    [82] = {id=502,actor=1,target=2,area={14},flag={row=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [83] = {id=503,actor=1,target=2,area={14},flag={colOne = 1},conditionList={0},conditionType=1,minValue=1,maxValue=3},
    [84] = {id=504,actor=1,target=2,area={14},flag={rowOne = 1,randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=3},
    [85] = {id=505,actor=1,target=2,area={14},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [86] = {id=506,actor=1,target=2,area={14},flag={rowOne = 1},conditionList={2016},conditionType=1,minValue=1,maxValue=3},
    [87] = {id=507,actor=1,target=3,area={14},flag={colOne = 1},conditionList={501},conditionType=1,minValue=1,maxValue=3},
    [88] = {id=508,actor=1,target=1,area={14},flag={},conditionList={501},conditionType=1,minValue=0,maxValue=-1},
    [89] = {id=509,actor=1,target=1,area={13},flag={empty=1,equip=1,row=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [90] = {id=510,actor=1,target=1,area={14},flag={},conditionList={60},conditionType=1,minValue=1,maxValue=1},
    [91] = {id=511,actor=1,target=1,area={13},flag={rowSide=1,empty=1,equip=1},conditionList={0},conditionType=1,minValue=1,maxValue=-1},
    [92] = {id=512,actor=1,target=1,area={14},flag={},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [93] = {id=513,actor=1,target=1,area={14},flag={},conditionList={2003},conditionType=1,minValue=-1,maxValue=-1},
    [94] = {id=514,actor=1,target=2,area={14},flag={},conditionList={1007},conditionType=1,minValue=0,maxValue=-1},
    [95] = {id=515,actor=1,target=2,area={14},flag={colOne = 1},conditionList={0},conditionType=1,minValue=1,maxValue=3},
    [96] = {id=516,actor=1,target=1,area={14},flag={row=2},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [97] = {id=517,actor=1,target=1,area={14},flag={row=3},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [98] = {id=518,actor=1,target=1,area={13},flag={empty=1,row=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [99] = {id=519,actor=1,target=1,area={13},flag={empty=1,row=2,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [100] = {id=520,actor=1,target=1,area={13},flag={dir={4}},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [101] = {id=521,actor=1,target=1,area={13},flag={dir={6}},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [102] = {id=522,actor=1,target=1,area={13},flag={empty=1,row=3},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [103] = {id=523,actor=1,target=1,area={14},flag={},conditionList={2005},conditionType=1,minValue=0,maxValue=-1},
    [104] = {id=524,actor=1,target=1,area={13},flag={dir={2}},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [105] = {id=525,actor=1,target=2,area={14},flag={randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [106] = {id=526,actor=1,target=1,area={14},flag={},conditionList={2007},conditionType=1,minValue=-1,maxValue=-1},
    [107] = {id=527,actor=1,target=1,area={14},flag={},conditionList={2008},conditionType=1,minValue=0,maxValue=-1},
    [108] = {id=528,actor=1,target=1,area={13},flag={empty=0,row=1,equip=0},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [109] = {id=529,actor=1,target=1,area={14},flag={self=0},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [110] = {id=530,actor=1,target=1,area={14},flag={},conditionList={602},conditionType=1,minValue=-1,maxValue=-1},
    [111] = {id=531,actor=1,target=1,area={13},flag={dir={4}},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [112] = {id=532,actor=1,target=1,area={13},flag={dir={6}},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [113] = {id=533,actor=1,target=1,area={14},flag={},conditionList={2009},conditionType=1,minValue=-1,maxValue=-1},
    [114] = {id=534,actor=1,target=2,area={14},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [115] = {id=535,actor=1,target=1,area={14},flag={},conditionList={2014},conditionType=1,minValue=-1,maxValue=-1},
    [116] = {id=536,actor=1,target=2,area={14},flag={},conditionList={60},conditionType=1,minValue=1,maxValue=1},
    [117] = {id=537,actor=1,target=1,area={13},flag={selPosition={7,9},empty=1,equip=1},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [118] = {id=538,actor=1,target=1,area={13},flag={selPosition={8},empty=1,equip=1},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [119] = {id=539,actor=1,target=1,area={13},flag={selPosition={1,3},empty=1,equip=1},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [120] = {id=540,actor=1,target=1,area={14},flag={self=0},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [121] = {id=541,actor=1,target=2,area={14},flag={},conditionList={2015},conditionType=1,minValue=0,maxValue=-1},
    [122] = {id=542,actor=1,target=1,area={14},flag={},conditionList={2016},conditionType=1,minValue=0,maxValue=-1},
    [123] = {id=543,actor=1,target=2,area={14},flag={rowOne = 1},conditionList={0},conditionType=1,minValue=-1,maxValue=3},
    [124] = {id=544,actor=1,target=2,area={14},flag={colOne = 1},conditionList={0},conditionType=1,minValue=-1,maxValue=3},
    [125] = {id=545,actor=1,target=2,area={14},flag={},conditionList={2016},conditionType=1,minValue=-1,maxValue=-1},
    [126] = {id=546,actor=1,target=1,area={14},flag={},conditionList={2015},conditionType=1,minValue=1,maxValue=1},
    [127] = {id=547,actor=1,target=1,area={14},flag={},conditionList={2015},conditionType=1,minValue=-1,maxValue=-1},
    [128] = {id=548,actor=1,target=1,area={14},flag={},conditionList={60},conditionType=1,minValue=1,maxValue=1},
    [129] = {id=549,actor=1,target=2,area={14},flag={row=2},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [130] = {id=550,actor=1,target=2,area={14},flag={colOne = 1},conditionList={0},conditionType=1,minValue=1,maxValue=3},
    [131] = {id=551,actor=1,target=1,area={4},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [132] = {id=552,actor=1,target=2,area={14},flag={rowOne = 1,randNum=1},conditionList={2015},conditionType=1,minValue=1,maxValue=3},
    [133] = {id=553,actor=1,target=1,area={14},flag={},conditionList={2020},conditionType=1,minValue=0,maxValue=-1},
    [134] = {id=554,actor=1,target=1,area={13},flag={empty=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [135] = {id=555,actor=1,target=1,area={14},flag={},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [136] = {id=601,actor=1,target=1,area={13},flag={randPosition={1},equip=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [137] = {id=602,actor=1,target=1,area={13},flag={randPosition={2},equip=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [138] = {id=603,actor=1,target=1,area={13},flag={randPosition={3},equip=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [139] = {id=604,actor=1,target=1,area={13},flag={randPosition={4},equip=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [140] = {id=605,actor=1,target=1,area={13},flag={randPosition={5},equip=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [141] = {id=606,actor=1,target=1,area={13},flag={randPosition={6},equip=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [142] = {id=607,actor=1,target=1,area={13},flag={randPosition={7},equip=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [143] = {id=608,actor=1,target=1,area={13},flag={randPosition={8},equip=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [144] = {id=609,actor=1,target=1,area={13},flag={randPosition={9},equip=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [145] = {id=610,actor=1,target=1,area={14},flag={},conditionList={2021},conditionType=1,minValue=0,maxValue=-1},
    [146] = {id=611,actor=1,target=1,area={14},flag={},conditionList={2022},conditionType=1,minValue=0,maxValue=-1},
    [147] = {id=612,actor=1,target=1,area={13},flag={selPosition={4,6},empty=1,equip=1},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [148] = {id=613,actor=1,target=1,area={14},flag={},conditionList={2016},conditionType=1,minValue=1,maxValue=1},
    [149] = {id=614,actor=1,target=2,area={14},flag={rowOne = 1},conditionList={0},conditionType=1,minValue=1,maxValue=-1},
    [150] = {id=615,actor=1,target=2,area={14},flag={},conditionList={2016},conditionType=1,minValue=0,maxValue=-1},
    [151] = {id=616,actor=1,target=1,area={14},flag={},conditionList={61},conditionType=1,minValue=0,maxValue=-1},
    [152] = {id=617,actor=1,target=1,area={14},flag={},conditionList={61},conditionType=1,minValue=1,maxValue=1},
    [153] = {id=618,actor=1,target=2,area={14},flag={randNum=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [154] = {id=619,actor=1,target=2,area={14},flag={rowOne = 1,randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=3},
    [155] = {id=620,actor=1,target=1,area={14},flag={},conditionList={2032},conditionType=1,minValue=0,maxValue=-1},
    [156] = {id=621,actor=1,target=1,area={14},flag={},conditionList={2033},conditionType=1,minValue=0,maxValue=-1},
    [157] = {id=622,actor=1,target=1,area={14},flag={},conditionList={2034},conditionType=1,minValue=0,maxValue=-1},
    [158] = {id=623,actor=1,target=1,area={14},flag={},conditionList={2035},conditionType=1,minValue=0,maxValue=-1},
    [159] = {id=624,actor=1,target=1,area={14},flag={},conditionList={2036},conditionType=1,minValue=0,maxValue=-1},
    [160] = {id=625,actor=1,target=1,area={13},flag={randPosition={1,2,3,7,8,9},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [161] = {id=626,actor=1,target=1,area={14},flag={},conditionList={2037},conditionType=1,minValue=0,maxValue=-1},
    [162] = {id=627,actor=1,target=1,area={13},flag={selPosition={2,4,6,8},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [163] = {id=628,actor=1,target=1,area={13},flag={selPosition={1,3,7,9},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [164] = {id=629,actor=1,target=3,area={14},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [165] = {id=630,actor=1,target=1,area={13},flag={selPosition={1,4,7},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [166] = {id=631,actor=1,target=1,area={13},flag={selPosition={2,5,8},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [167] = {id=632,actor=1,target=1,area={13},flag={selPosition={3,6,9},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [168] = {id=633,actor=1,target=1,area={14},flag={row=2},conditionList={0},conditionType=1,minValue=1,maxValue=3},
    [169] = {id=634,actor=1,target=2,area={14},flag={},conditionList={2015},conditionType=1,minValue=1,maxValue=1},
    [170] = {id=635,actor=1,target=1,area={13},flag={selPosition={4,6,8},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [171] = {id=636,actor=1,target=1,area={14},flag={},conditionList={2039},conditionType=1,minValue=0,maxValue=-1},
    [172] = {id=637,actor=1,target=2,area={14},flag={rowOne = 1},conditionList={2016},conditionType=1,minValue=1,maxValue=-1},
    [173] = {id=638,actor=1,target=1,area={14},flag={side=1},conditionList={2016},conditionType=1,minValue=0,maxValue=-1},
    [174] = {id=639,actor=1,target=2,area={14},flag={},conditionList={2016},conditionType=1,minValue=1,maxValue=1},
    [175] = {id=640,actor=1,target=2,area={14},flag={colOne = 1,randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=3},
    [176] = {id=641,actor=1,target=1,area={14},flag={},conditionList={2044},conditionType=1,minValue=0,maxValue=-1},
    [177] = {id=642,actor=1,target=1,area={14},flag={},conditionList={2045},conditionType=1,minValue=0,maxValue=-1},
    [178] = {id=643,actor=1,target=1,area={14},flag={},conditionList={2046},conditionType=1,minValue=0,maxValue=-1},
    [179] = {id=644,actor=1,target=1,area={14},flag={},conditionList={2047},conditionType=1,minValue=0,maxValue=-1},
    [180] = {id=645,actor=1,target=1,area={14},flag={},conditionList={2048},conditionType=1,minValue=0,maxValue=-1},
    [181] = {id=646,actor=1,target=1,area={14},flag={},conditionList={2038},conditionType=1,minValue=0,maxValue=-1},
    [182] = {id=647,actor=1,target=1,area={14},flag={rowOne = 1},conditionList={2016},conditionType=1,minValue=1,maxValue=-1},
    [183] = {id=648,actor=1,target=1,area={14},flag={},conditionList={2016},conditionType=1,minValue=1,maxValue=1},
    [184] = {id=649,actor=1,target=2,area={14},flag={rowOne = 1,randNum=1},conditionList={2015},conditionType=1,minValue=1,maxValue=-1},
    [185] = {id=650,actor=1,target=2,area={14},flag={row=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [186] = {id=651,actor=1,target=1,area={3},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [187] = {id=652,actor=1,target=3,area={14},flag={},conditionList={1007},conditionType=1,minValue=-1,maxValue=-1},
    [188] = {id=653,actor=1,target=1,area={14},flag={rowOne = 1},conditionList={2016},conditionType=1,minValue=1,maxValue=3},
    [189] = {id=654,actor=1,target=3,area={14},flag={row=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [190] = {id=655,actor=1,target=1,area={13},flag={side=1,empty=1},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [191] = {id=656,actor=1,target=1,area={13},flag={dir={5},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [192] = {id=657,actor=1,target=1,area={13},flag={empty=1,randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [193] = {id=658,actor=1,target=1,area={14},flag={},conditionList={2066},conditionType=1,minValue=-1,maxValue=-1},
    [194] = {id=659,actor=1,target=1,area={14},flag={},conditionList={2067},conditionType=1,minValue=0,maxValue=-1},
    [195] = {id=660,actor=1,target=1,area={14},flag={},conditionList={2068},conditionType=1,minValue=0,maxValue=-1},
    [196] = {id=661,actor=1,target=1,area={14},flag={},conditionList={2069},conditionType=1,minValue=0,maxValue=-1},
    [197] = {id=662,actor=1,target=1,area={13},flag={selPosition={1,3},empty=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [198] = {id=663,actor=1,target=2,area={13},flag={selPosition={7,9},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [199] = {id=664,actor=1,target=1,area={13},flag={selPosition={7,9},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [200] = {id=665,actor=1,target=1,area={13},flag={selPosition={4,6},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [201] = {id=666,actor=1,target=1,area={3},flag={},conditionList={1007},conditionType=1,minValue=0,maxValue=-1},
    [202] = {id=667,actor=1,target=3,area={14},flag={},conditionList={2074,2016},conditionType=1,minValue=1,maxValue=1},
    [203] = {id=668,actor=1,target=1,area={4},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [204] = {id=669,actor=1,target=2,area={4},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [205] = {id=670,actor=1,target=3,area={14},flag={},conditionList={60},conditionType=1,minValue=-1,maxValue=-1},
    [206] = {id=671,actor=1,target=1,area={2},flag={randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [207] = {id=672,actor=1,target=2,area={14},flag={row=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [208] = {id=673,actor=1,target=2,area={14},flag={row=2},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [209] = {id=674,actor=1,target=2,area={14},flag={row=3},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [210] = {id=675,actor=1,target=2,area={14},flag={col=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [211] = {id=676,actor=1,target=2,area={14},flag={col=2},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [212] = {id=677,actor=1,target=2,area={14},flag={col=3},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [213] = {id=678,actor=1,target=1,area={2},flag={},conditionList={2078},conditionType=1,minValue=-1,maxValue=-1},
    [214] = {id=679,actor=1,target=1,area={14},flag={self=0},conditionList={2078},conditionType=1,minValue=0,maxValue=-1},
    [215] = {id=680,actor=1,target=1,area={13},flag={empty=0,equip=1},conditionList={2016},conditionType=1,minValue=1,maxValue=1},
    [216] = {id=681,actor=1,target=1,area={4},flag={},conditionList={2080},conditionType=1,minValue=-1,maxValue=-1},
    [217] = {id=682,actor=1,target=2,area={14},flag={rowOne = 1},conditionList={2016},conditionType=1,minValue=1,maxValue=-1},
    [218] = {id=683,actor=1,target=2,area={14},flag={},conditionList={2016},conditionType=1,minValue=1,maxValue=1},
    [219] = {id=684,actor=1,target=1,area={2},flag={},conditionList={2082},conditionType=1,minValue=-1,maxValue=-1},
    [220] = {id=685,actor=1,target=1,area={14},flag={},conditionList={2082},conditionType=1,minValue=-1,maxValue=-1},
    [221] = {id=686,actor=1,target=1,area={13},flag={empty=1,row=3},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [222] = {id=687,actor=1,target=1,area={14},flag={rowOne = 1},conditionList={2016},conditionType=1,minValue=1,maxValue=3},
    [223] = {id=688,actor=1,target=3,area={14},flag={},conditionList={2016},conditionType=1,minValue=-1,maxValue=-1},
    [224] = {id=689,actor=1,target=2,area={14},flag={},conditionList={2016},conditionType=1,minValue=-1,maxValue=-1},
    [225] = {id=690,actor=1,target=2,area={14},flag={selPosition={7,9}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [226] = {id=691,actor=1,target=3,area={14},flag={},conditionList={2088,2016},conditionType=1,minValue=-1,maxValue=-1},
    [227] = {id=692,actor=1,target=2,area={6},flag={},conditionList={2089},conditionType=1,minValue=-1,maxValue=-1},
    [228] = {id=693,actor=1,target=2,area={2},flag={seq=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [229] = {id=694,actor=1,target=2,area={3},flag={},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [230] = {id=695,actor=1,target=2,area={13},flag={randNum=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [231] = {id=696,actor=1,target=2,area={14},flag={selPosition={1,3,4,6,7,9}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [232] = {id=697,actor=1,target=1,area={14},flag={},conditionList={2097},conditionType=1,minValue=1,maxValue=1},
    [233] = {id=698,actor=1,target=1,area={14},flag={},conditionList={2098},conditionType=1,minValue=1,maxValue=1},
    [234] = {id=699,actor=1,target=1,area={14},flag={},conditionList={2100},conditionType=1,minValue=-1,maxValue=-1},
    [235] = {id=700,actor=1,target=1,area={14},flag={},conditionList={2101},conditionType=1,minValue=-1,maxValue=-1},
    [236] = {id=701,actor=1,target=1,area={2},flag={},conditionList={2098},conditionType=1,minValue=-1,maxValue=-1},
    [237] = {id=702,actor=1,target=3,area={14},flag={},conditionList={2103,2098},conditionType=1,minValue=-1,maxValue=-1},
    [238] = {id=703,actor=1,target=1,area={2},flag={},conditionList={2098},conditionType=1,minValue=-1,maxValue=-1},
    [239] = {id=704,actor=1,target=2,area={13},flag={randNum=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [240] = {id=705,actor=1,target=2,area={13},flag={randNum=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [241] = {id=706,actor=1,target=2,area={13},flag={randNum=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [242] = {id=707,actor=1,target=2,area={13},flag={randNum=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [243] = {id=708,actor=1,target=2,area={13},flag={randNum=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [244] = {id=709,actor=1,target=2,area={13},flag={randNum=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [245] = {id=710,actor=1,target=2,area={13},flag={randNum=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [246] = {id=711,actor=1,target=2,area={13},flag={randNum=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [247] = {id=712,actor=1,target=1,area={2},flag={},conditionList={2101},conditionType=1,minValue=-1,maxValue=-1},
    [248] = {id=713,actor=1,target=2,area={3},flag={seq=1},conditionList={0},conditionType=1,minValue=-1,maxValue=2},
    [249] = {id=714,actor=1,target=2,area={1},flag={seq=1},conditionList={0},conditionType=1,minValue=-1,maxValue=2},
    [250] = {id=720,actor=1,target=2,area={14},flag={selPosition={1}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [251] = {id=721,actor=1,target=2,area={14},flag={selPosition={2}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [252] = {id=722,actor=1,target=2,area={14},flag={selPosition={3}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [253] = {id=723,actor=1,target=2,area={14},flag={selPosition={4}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [254] = {id=724,actor=1,target=2,area={14},flag={selPosition={5}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [255] = {id=725,actor=1,target=2,area={14},flag={selPosition={6}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [256] = {id=726,actor=1,target=2,area={14},flag={selPosition={7}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [257] = {id=727,actor=1,target=2,area={14},flag={selPosition={8}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [258] = {id=728,actor=1,target=2,area={14},flag={selPosition={9}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [259] = {id=730,actor=1,target=1,area={14},flag={selPosition={1}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [260] = {id=731,actor=1,target=1,area={14},flag={selPosition={2}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [261] = {id=732,actor=1,target=1,area={14},flag={selPosition={3}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [262] = {id=733,actor=1,target=1,area={14},flag={selPosition={4}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [263] = {id=734,actor=1,target=1,area={14},flag={selPosition={5}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [264] = {id=735,actor=1,target=1,area={14},flag={selPosition={6}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [265] = {id=736,actor=1,target=1,area={14},flag={selPosition={7}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [266] = {id=737,actor=1,target=1,area={14},flag={selPosition={8}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [267] = {id=738,actor=1,target=1,area={14},flag={selPosition={9}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [268] = {id=739,actor=1,target=1,area={4},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [269] = {id=740,actor=1,target=2,area={3},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [270] = {id=741,actor=1,target=2,area={1},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [271] = {id=742,actor=1,target=1,area={3},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [272] = {id=743,actor=1,target=2,area={14},flag={row=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [273] = {id=744,actor=1,target=1,area={1},flag={seq=1},conditionList={2124},conditionType=1,minValue=1,maxValue=1},
    [274] = {id=745,actor=1,target=1,area={14},flag={},conditionList={2015},conditionType=1,minValue=1,maxValue=1},
    [275] = {id=746,actor=1,target=1,area={14},flag={},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [276] = {id=747,actor=1,target=2,area={14},flag={row=2},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [277] = {id=748,actor=1,target=2,area={14},flag={row=3},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [278] = {id=749,actor=1,target=2,area={14},flag={col=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [279] = {id=750,actor=1,target=2,area={14},flag={col=2},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [280] = {id=751,actor=1,target=2,area={14},flag={col=3},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [281] = {id=752,actor=1,target=2,area={14},flag={},conditionList={2107},conditionType=1,minValue=1,maxValue=1},
    [282] = {id=753,actor=1,target=1,area={14},flag={},conditionList={2730},conditionType=1,minValue=-1,maxValue=-1},
    [283] = {id=754,actor=1,target=1,area={4},flag={},conditionList={1007},conditionType=1,minValue=0,maxValue=-1},
    [284] = {id=755,actor=1,target=1,area={2},flag={randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [285] = {id=756,actor=1,target=1,area={14},flag={},conditionList={2139},conditionType=1,minValue=-1,maxValue=-1},
    [286] = {id=757,actor=1,target=1,area={14},flag={},conditionList={2141},conditionType=1,minValue=-1,maxValue=-1},
    [287] = {id=758,actor=1,target=2,area={14},flag={randNum=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [288] = {id=759,actor=1,target=2,area={14},flag={randNum=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [289] = {id=760,actor=1,target=2,area={14},flag={randNum=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [290] = {id=761,actor=1,target=1,area={14},flag={},conditionList={2142},conditionType=1,minValue=-1,maxValue=-1},
    [291] = {id=762,actor=1,target=1,area={14},flag={},conditionList={2143},conditionType=1,minValue=-1,maxValue=-1},
    [292] = {id=763,actor=1,target=1,area={14},flag={},conditionList={2144},conditionType=1,minValue=-1,maxValue=-1},
    [293] = {id=764,actor=1,target=1,area={14},flag={},conditionList={2144},conditionType=1,minValue=1,maxValue=1},
    [294] = {id=765,actor=1,target=1,area={14},flag={},conditionList={2145},conditionType=1,minValue=-1,maxValue=-1},
    [295] = {id=766,actor=1,target=1,area={13},flag={dir={2},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [296] = {id=767,actor=1,target=1,area={13},flag={selPosition={4,6,7,9},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [297] = {id=768,actor=1,target=1,area={2},flag={},conditionList={2082},conditionType=1,minValue=1,maxValue=1},
    [298] = {id=769,actor=1,target=1,area={13},flag={selPosition={1,2,3},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [299] = {id=770,actor=1,target=1,area={13},flag={empty=1,randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [300] = {id=771,actor=1,target=1,area={13},flag={empty=1,randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [301] = {id=772,actor=1,target=1,area={13},flag={empty=1,randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [302] = {id=773,actor=1,target=1,area={13},flag={empty=1,randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [303] = {id=775,actor=1,target=2,area={14},flag={sort="maxAttk"},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [304] = {id=776,actor=1,target=1,area={13},flag={randPosition={1,3,4,6,7,9},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [305] = {id=777,actor=1,target=2,area={8},flag={},conditionList={2138},conditionType=1,minValue=-1,maxValue=-1},
    [306] = {id=778,actor=1,target=3,area={4},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [307] = {id=779,actor=1,target=1,area={14},flag={randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [308] = {id=780,actor=1,target=1,area={14},flag={},conditionList={2161},conditionType=1,minValue=1,maxValue=1},
    [309] = {id=781,actor=1,target=1,area={14},flag={},conditionList={2161},conditionType=1,minValue=-1,maxValue=-1},
    [310] = {id=782,actor=1,target=1,area={14},flag={},conditionList={2162},conditionType=1,minValue=-1,maxValue=-1},
    [311] = {id=783,actor=1,target=1,area={2},flag={},conditionList={2163},conditionType=1,minValue=-1,maxValue=-1},
    [312] = {id=784,actor=1,target=1,area={3},flag={},conditionList={2163},conditionType=1,minValue=-1,maxValue=-1},
    [313] = {id=785,actor=1,target=1,area={1},flag={},conditionList={2163},conditionType=1,minValue=-1,maxValue=-1},
    [314] = {id=786,actor=1,target=1,area={2},flag={},conditionList={2164},conditionType=1,minValue=-1,maxValue=-1},
    [315] = {id=787,actor=1,target=1,area={3},flag={},conditionList={2164},conditionType=1,minValue=-1,maxValue=-1},
    [316] = {id=788,actor=1,target=1,area={1},flag={},conditionList={2164},conditionType=1,minValue=-1,maxValue=-1},
    [317] = {id=789,actor=1,target=1,area={14},flag={selPosition={4,6,8}},conditionList={2167},conditionType=1,minValue=-1,maxValue=-1},
    [318] = {id=790,actor=1,target=1,area={13},flag={selPosition={4,6,8}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [319] = {id=791,actor=1,target=1,area={14},flag={randPosition={2}},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [320] = {id=792,actor=1,target=2,area={14},flag={},conditionList={2015},conditionType=1,minValue=1,maxValue=1},
    [321] = {id=793,actor=1,target=1,area={2},flag={},conditionList={2171},conditionType=1,minValue=-1,maxValue=-1},
    [322] = {id=794,actor=1,target=1,area={3},flag={},conditionList={2171},conditionType=1,minValue=-1,maxValue=-1},
    [323] = {id=795,actor=1,target=1,area={1},flag={},conditionList={2171},conditionType=1,minValue=-1,maxValue=-1},
    [324] = {id=796,actor=1,target=1,area={2},flag={},conditionList={2172},conditionType=1,minValue=-1,maxValue=-1},
    [325] = {id=797,actor=1,target=1,area={3},flag={},conditionList={2172},conditionType=1,minValue=-1,maxValue=-1},
    [326] = {id=798,actor=1,target=1,area={1},flag={},conditionList={2172},conditionType=1,minValue=-1,maxValue=-1},
    [327] = {id=799,actor=1,target=1,area={2},flag={},conditionList={2169},conditionType=1,minValue=-1,maxValue=-1},
    [328] = {id=800,actor=1,target=1,area={3},flag={},conditionList={2169},conditionType=1,minValue=-1,maxValue=-1},
    [329] = {id=801,actor=1,target=1,area={1},flag={},conditionList={2169},conditionType=1,minValue=-1,maxValue=-1},
    [330] = {id=802,actor=1,target=1,area={2},flag={},conditionList={2170},conditionType=1,minValue=-1,maxValue=-1},
    [331] = {id=803,actor=1,target=1,area={3},flag={},conditionList={2170},conditionType=1,minValue=-1,maxValue=-1},
    [332] = {id=804,actor=1,target=1,area={1},flag={},conditionList={2170},conditionType=1,minValue=-1,maxValue=-1},
    [333] = {id=805,actor=1,target=1,area={13},flag={randPosition={1,2,3,4,6,7,8,9},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [334] = {id=806,actor=1,target=1,area={13},flag={randPosition={1,2,3,4,6,7,8,9},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [335] = {id=807,actor=1,target=1,area={13},flag={randPosition={1,2,3,4,6,7,8,9},empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [336] = {id=808,actor=1,target=2,area={14},flag={selPosition={1,2,3,5,8}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [337] = {id=809,actor=1,target=2,area={14},flag={selPosition={4,2,6,5,8}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [338] = {id=810,actor=1,target=1,area={14},flag={randNum=1},conditionList={2015},conditionType=1,minValue=1,maxValue=1},
    [339] = {id=811,actor=1,target=1,area={14},flag={},conditionList={2168},conditionType=1,minValue=-1,maxValue=-1},
    [340] = {id=812,actor=1,target=1,area={14},flag={selPosition={2}},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [341] = {id=813,actor=1,target=2,area={14},flag={attkTarget=3},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [342] = {id=814,actor=1,target=2,area={14},flag={attkTarget=3},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
    [343] = {id=815,actor=1,target=1,area={1},flag={seq=1},conditionList={2121},conditionType=1,minValue=1,maxValue=1},
    [344] = {id=816,actor=1,target=1,area={2},flag={},conditionList={2176},conditionType=1,minValue=-1,maxValue=-1},
    [345] = {id=817,actor=1,target=1,area={1},flag={seq=1},conditionList={1007,2177},conditionType=1,minValue=-1,maxValue=1},
    [346] = {id=818,actor=1,target=1,area={1},flag={seq=1},conditionList={1007,2178},conditionType=1,minValue=-1,maxValue=1},
    [347] = {id=819,actor=1,target=1,area={1},flag={seq=1},conditionList={2179},conditionType=1,minValue=1,maxValue=1},
    [348] = {id=820,actor=1,target=1,area={14},flag={},conditionList={2181},conditionType=1,minValue=-1,maxValue=-1},
    [349] = {id=821,actor=1,target=1,area={14},flag={self=0},conditionList={2016},conditionType=1,minValue=0,maxValue=-1},
    [350] = {id=822,actor=1,target=1,area={14},flag={},conditionList={2015},conditionType=1,minValue=1,maxValue=1},
    [351] = {id=823,actor=1,target=1,area={2},flag={},conditionList={2188},conditionType=1,minValue=-1,maxValue=-1},
    [352] = {id=824,actor=1,target=1,area={2},flag={},conditionList={2189},conditionType=1,minValue=-1,maxValue=-1},
    [353] = {id=825,actor=1,target=1,area={2},flag={randNum=1},conditionList={2188},conditionType=1,minValue=1,maxValue=1},
    [354] = {id=826,actor=1,target=2,area={14},flag={},conditionList={2015},conditionType=1,minValue=1,maxValue=1},
    [355] = {id=827,actor=1,target=2,area={14},flag={sort="minHp",sortType="random"},conditionList={2016},conditionType=1,minValue=1,maxValue=1},
    [356] = {id=828,actor=1,target=2,area={14},flag={sort="minHp",sortType="normal"},conditionList={2016},conditionType=1,minValue=-1,maxValue=-1},
    [357] = {id=829,actor=1,target=3,area={14},flag={},conditionList={2016},conditionType=1,minValue=-1,maxValue=-1},
    [358] = {id=830,actor=1,target=1,area={14},flag={},conditionList={2016},conditionType=1,minValue=0,maxValue=-1},
    [359] = {id=831,actor=1,target=1,area={13},flag={dir={5}},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [360] = {id=832,actor=1,target=1,area={14},flag={},conditionList={2016,2192},conditionType=1,minValue=1,maxValue=1},
    [361] = {id=833,actor=1,target=1,area={14},flag={},conditionList={2016,2193},conditionType=1,minValue=1,maxValue=1},
    [362] = {id=834,actor=1,target=3,area={8},flag={selfPlayer = 1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [363] = {id=835,actor=1,target=1,area={14},flag={},conditionList={2216},conditionType=1,minValue=1,maxValue=1},
    [364] = {id=836,actor=1,target=1,area={15},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [365] = {id=837,actor=1,target=1,area={14},flag={},conditionList={2217},conditionType=1,minValue=-1,maxValue=-1},
    [366] = {id=838,actor=1,target=1,area={13},flag={colOne = 1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=3},
    [367] = {id=839,actor=1,target=1,area={14},flag={},conditionList={2234},conditionType=1,minValue=-1,maxValue=-1},
    [368] = {id=840,actor=1,target=1,area={2},flag={randNum=1},conditionList={2235},conditionType=1,minValue=1,maxValue=1},
    [369] = {id=841,actor=1,target=1,area={14},flag={},conditionList={2015},conditionType=1,minValue=-1,maxValue=-1},
    [370] = {id=852,actor=1,target=1,area={14},flag={},conditionList={2235},conditionType=1,minValue=-1,maxValue=-1},
    [371] = {id=853,actor=1,target=1,area={1},flag={seq=1},conditionList={2235},conditionType=1,minValue=1,maxValue=1},
    [372] = {id=854,actor=1,target=1,area={14},flag={},conditionList={2235},conditionType=1,minValue=1,maxValue=1},
    [373] = {id=855,actor=1,target=1,area={2},flag={},conditionList={2241},conditionType=1,minValue=-1,maxValue=-1},
    [374] = {id=856,actor=1,target=1,area={3},flag={},conditionList={2241},conditionType=1,minValue=-1,maxValue=-1},
    [375] = {id=857,actor=1,target=1,area={1},flag={},conditionList={2241},conditionType=1,minValue=-1,maxValue=-1},
    [376] = {id=858,actor=1,target=2,area={14},flag={randNum=1},conditionList={2016},conditionType=1,minValue=-1,maxValue=-1},
    [377] = {id=859,actor=1,target=2,area={14},flag={randNum=1},conditionList={2016},conditionType=1,minValue=-1,maxValue=-1},
    [378] = {id=860,actor=1,target=2,area={14},flag={},conditionList={2015},conditionType=1,minValue=1,maxValue=1},
    [379] = {id=861,actor=1,target=2,area={14},flag={},conditionList={2015},conditionType=1,minValue=1,maxValue=1},
    [380] = {id=862,actor=1,target=2,area={14},flag={},conditionList={2015},conditionType=1,minValue=1,maxValue=1},
    [381] = {id=863,actor=1,target=1,area={14},flag={},conditionList={2016,2185},conditionType=1,minValue=1,maxValue=1},
    [382] = {id=864,actor=1,target=1,area={14},flag={},conditionList={2016,2186},conditionType=1,minValue=1,maxValue=1},
    [383] = {id=865,actor=1,target=1,area={14},flag={},conditionList={2218},conditionType=1,minValue=-1,maxValue=-1},
    [384] = {id=866,actor=1,target=1,area={14},flag={},conditionList={2219},conditionType=1,minValue=-1,maxValue=-1},
    [385] = {id=867,actor=1,target=1,area={14},flag={},conditionList={2220},conditionType=1,minValue=-1,maxValue=-1},
    [386] = {id=868,actor=1,target=1,area={14},flag={},conditionList={2288},conditionType=1,minValue=-1,maxValue=-1},
    [387] = {id=869,actor=1,target=1,area={14},flag={},conditionList={2227},conditionType=1,minValue=1,maxValue=1},
    [388] = {id=870,actor=1,target=1,area={14},flag={},conditionList={2220},conditionType=1,minValue=1,maxValue=1},
    [389] = {id=871,actor=1,target=1,area={14},flag={},conditionList={2078},conditionType=1,minValue=0,maxValue=-1},
    [390] = {id=872,actor=1,target=1,area={13},flag={selPosition={1,2,3,7,8,9},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [391] = {id=873,actor=1,target=2,area={13},flag={empty=1,randNum=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [392] = {id=874,actor=1,target=1,area={13},flag={selPosition={2,8},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [393] = {id=875,actor=1,target=1,area={14},flag={},conditionList={2244},conditionType=1,minValue=-1,maxValue=-1},
    [394] = {id=876,actor=1,target=1,area={14},flag={},conditionList={2247},conditionType=1,minValue=-1,maxValue=-1},
    [395] = {id=877,actor=1,target=1,area={14},flag={},conditionList={2248},conditionType=1,minValue=-1,maxValue=-1},
    [396] = {id=878,actor=1,target=1,area={14},flag={randNum=1},conditionList={2249},conditionType=1,minValue=1,maxValue=1},
    [397] = {id=879,actor=1,target=2,area={14},flag={sort="minAttk"},conditionList={2016},conditionType=1,minValue=1,maxValue=1},
    [398] = {id=880,actor=1,target=1,area={14},flag={randNum=1},conditionList={2016},conditionType=1,minValue=1,maxValue=1},
    [399] = {id=881,actor=1,target=1,area={14},flag={randNum=1},conditionList={2016},conditionType=1,minValue=1,maxValue=1},
    [400] = {id=882,actor=1,target=1,area={14},flag={randNum=1},conditionList={2016},conditionType=1,minValue=1,maxValue=1},
    [401] = {id=883,actor=1,target=1,area={2},flag={},conditionList={2250},conditionType=1,minValue=-1,maxValue=-1},
    [402] = {id=884,actor=1,target=1,area={3},flag={},conditionList={2250},conditionType=1,minValue=-1,maxValue=-1},
    [403] = {id=885,actor=1,target=1,area={1},flag={},conditionList={2250},conditionType=1,minValue=-1,maxValue=-1},
    [404] = {id=886,actor=1,target=1,area={15},flag={},conditionList={2250},conditionType=1,minValue=-1,maxValue=-1},
    [405] = {id=887,actor=1,target=1,area={2},flag={},conditionList={2251},conditionType=1,minValue=-1,maxValue=-1},
    [406] = {id=888,actor=1,target=1,area={3},flag={},conditionList={2251},conditionType=1,minValue=-1,maxValue=-1},
    [407] = {id=889,actor=1,target=1,area={1},flag={},conditionList={2251},conditionType=1,minValue=-1,maxValue=-1},
    [408] = {id=890,actor=1,target=1,area={15},flag={},conditionList={2251},conditionType=1,minValue=-1,maxValue=-1},
    [409] = {id=891,actor=1,target=1,area={2},flag={},conditionList={2252},conditionType=1,minValue=-1,maxValue=-1},
    [410] = {id=892,actor=1,target=1,area={3},flag={},conditionList={2252},conditionType=1,minValue=-1,maxValue=-1},
    [411] = {id=893,actor=1,target=1,area={1},flag={},conditionList={2252},conditionType=1,minValue=-1,maxValue=-1},
    [412] = {id=894,actor=1,target=1,area={15},flag={},conditionList={2252},conditionType=1,minValue=-1,maxValue=-1},
    [413] = {id=895,actor=1,target=1,area={2},flag={},conditionList={2253},conditionType=1,minValue=-1,maxValue=-1},
    [414] = {id=896,actor=1,target=1,area={3},flag={},conditionList={2253},conditionType=1,minValue=-1,maxValue=-1},
    [415] = {id=897,actor=1,target=1,area={1},flag={},conditionList={2253},conditionType=1,minValue=-1,maxValue=-1},
    [416] = {id=898,actor=1,target=1,area={15},flag={},conditionList={2253},conditionType=1,minValue=-1,maxValue=-1},
    [417] = {id=899,actor=1,target=2,area={14},flag={randNum=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [418] = {id=900,actor=1,target=2,area={14},flag={randNum=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [419] = {id=901,actor=1,target=2,area={6},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [420] = {id=902,actor=1,target=1,area={14},flag={},conditionList={2260},conditionType=1,minValue=0,maxValue=-1},
    [421] = {id=903,actor=1,target=1,area={14},flag={sort="maxAttk"},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [422] = {id=904,actor=1,target=1,area={14},flag={},conditionList={2267},conditionType=1,minValue=1,maxValue=1},
    [423] = {id=905,actor=1,target=1,area={14},flag={},conditionList={2268},conditionType=1,minValue=1,maxValue=1},
    [424] = {id=906,actor=1,target=1,area={14},flag={},conditionList={2269},conditionType=1,minValue=1,maxValue=1},
    [425] = {id=907,actor=1,target=1,area={14},flag={},conditionList={2269},conditionType=1,minValue=0,maxValue=-1},
    [426] = {id=908,actor=1,target=1,area={2},flag={self=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [427] = {id=909,actor=1,target=1,area={14},flag={},conditionList={2271},conditionType=1,minValue=1,maxValue=1},
    [428] = {id=910,actor=1,target=1,area={14},flag={},conditionList={2272},conditionType=1,minValue=1,maxValue=1},
    [429] = {id=911,actor=1,target=1,area={14},flag={},conditionList={2273},conditionType=1,minValue=1,maxValue=1},
    [430] = {id=912,actor=1,target=1,area={14},flag={},conditionList={2274},conditionType=1,minValue=1,maxValue=1},
    [431] = {id=913,actor=1,target=2,area={6},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [432] = {id=914,actor=1,target=1,area={14},flag={},conditionList={2274},conditionType=1,minValue=-1,maxValue=-1},
    [433] = {id=915,actor=1,target=1,area={14},flag={},conditionList={2275},conditionType=1,minValue=1,maxValue=1},
    [434] = {id=916,actor=1,target=1,area={14},flag={},conditionList={2276},conditionType=1,minValue=-1,maxValue=-1},
    [435] = {id=917,actor=1,target=1,area={14},flag={},conditionList={2277},conditionType=1,minValue=1,maxValue=1},
    [436] = {id=918,actor=1,target=1,area={14},flag={},conditionList={2278},conditionType=1,minValue=1,maxValue=1},
    [437] = {id=919,actor=1,target=1,area={14},flag={},conditionList={2279},conditionType=1,minValue=1,maxValue=1},
    [438] = {id=920,actor=1,target=1,area={14},flag={self=0},conditionList={2101},conditionType=1,minValue=-1,maxValue=-1},
    [439] = {id=921,actor=1,target=1,area={2},flag={},conditionList={2087},conditionType=1,minValue=-1,maxValue=-1},
    [440] = {id=922,actor=1,target=1,area={1},flag={},conditionList={2087},conditionType=1,minValue=-1,maxValue=-1},
    [441] = {id=923,actor=1,target=1,area={3},flag={},conditionList={2087},conditionType=1,minValue=-1,maxValue=-1},
    [442] = {id=924,actor=1,target=1,area={3},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [443] = {id=925,actor=1,target=2,area={14},flag={},conditionList={2283},conditionType=1,minValue=1,maxValue=1},
    [444] = {id=926,actor=1,target=2,area={13},flag={randNum=1,empty=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [445] = {id=927,actor=1,target=2,area={14},flag={sort="minAttk"},conditionList={2015},conditionType=1,minValue=1,maxValue=1},
    [446] = {id=928,actor=1,target=2,area={4},flag={sort="maxCost"},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [447] = {id=929,actor=1,target=1,area={15},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [448] = {id=930,actor=1,target=1,area={1},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [449] = {id=931,actor=1,target=2,area={14},flag={},conditionList={2016},conditionType=1,minValue=0,maxValue=-1},
    [450] = {id=932,actor=1,target=2,area={8},flag={selfPlayer = 1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [451] = {id=933,actor=1,target=1,area={14},flag={},conditionList={2289},conditionType=1,minValue=0,maxValue=-1},
    [452] = {id=934,actor=1,target=1,area={2},flag={},conditionList={2290},conditionType=1,minValue=-1,maxValue=-1},
    [453] = {id=935,actor=1,target=1,area={3},flag={},conditionList={2290},conditionType=1,minValue=-1,maxValue=-1},
    [454] = {id=936,actor=1,target=1,area={1},flag={},conditionList={2290},conditionType=1,minValue=-1,maxValue=-1},
    [455] = {id=937,actor=1,target=1,area={2},flag={},conditionList={2289},conditionType=1,minValue=-1,maxValue=-1},
    [456] = {id=938,actor=1,target=1,area={1},flag={seq=1},conditionList={2121},conditionType=1,minValue=1,maxValue=1},
    [457] = {id=939,actor=1,target=1,area={14},flag={self=0},conditionList={2078},conditionType=1,minValue=0,maxValue=-1},
    [458] = {id=940,actor=1,target=3,area={14},flag={selfRound=1},conditionList={2016},conditionType=1,minValue=-1,maxValue=-1},
    [459] = {id=941,actor=1,target=1,area={14},flag={},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [460] = {id=942,actor=1,target=2,area={13},flag={randNum=1,empty=1,row=1},conditionList={0},conditionType=1,minValue=1,maxValue=1},
    [461] = {id=943,actor=1,target=1,area={1},flag={seq=1},conditionList={1007},conditionType=1,minValue=1,maxValue=1},
    [462] = {id=944,actor=1,target=3,area={14},flag={},conditionList={2293},conditionType=1,minValue=-1,maxValue=-1},
    [463] = {id=945,actor=1,target=3,area={14},flag={},conditionList={2294},conditionType=1,minValue=-1,maxValue=-1},
    [464] = {id=946,actor=1,target=1,area={2},flag={},conditionList={2295},conditionType=1,minValue=-1,maxValue=-1},
    [465] = {id=947,actor=1,target=1,area={2},flag={},conditionList={2296},conditionType=1,minValue=-1,maxValue=-1},
    [466] = {id=949,actor=1,target=2,area={13},flag={empty=1,equip=1,row=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [467] = {id=1201,actor=1,target=2,area={14},flag={row=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [468] = {id=1202,actor=1,target=2,area={14},flag={row=2},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [469] = {id=1203,actor=1,target=2,area={14},flag={row=3},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [470] = {id=1211,actor=1,target=2,area={14},flag={randNum=3},conditionList={0},conditionType=1,minValue=-1,maxValue=3},
    [471] = {id=1212,actor=1,target=1,area={13},flag={selPosition={2},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [472] = {id=1213,actor=1,target=1,area={13},flag={selPosition={4,6},empty=1,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [473] = {id=1214,actor=1,target=1,area={13},flag={empty=1,row=3,equip=1},conditionList={0},conditionType=1,minValue=-1,maxValue=-1},
    [474] = {id=1215,actor=1,target=1,area={14},flag={},conditionList={2305},conditionType=1,minValue=0,maxValue=-1},
    [475] = {id=1216,actor=1,target=1,area={14},flag={},conditionList={2304},conditionType=1,minValue=0,maxValue=-1},
    [476] = {id=1217,actor=1,target=1,area={13},flag={empty=0,hero=0},conditionList={2098},conditionType=1,minValue=1,maxValue=1},
    [477] = {id=1218,actor=1,target=1,area={13},flag={empty=0,hero=0},conditionList={2102},conditionType=1,minValue=1,maxValue=1},
    [478] = {id=1219,actor=1,target=1,area={13},flag={empty=0,hero=0},conditionList={2101},conditionType=1,minValue=1,maxValue=1},
    [479] = {id=1220,actor=1,target=1,area={14},flag={},conditionList={2102},conditionType=1,minValue=0,maxValue=-1},
    [480] = {id=1221,actor=1,target=1,area={13},flag={empty=0,hero=0},conditionList={2306},conditionType=1,minValue=1,maxValue=1},
    [481] = {id=1222,actor=1,target=1,area={13},flag={empty=0,hero=0},conditionList={2307},conditionType=1,minValue=1,maxValue=1},
    [482] = {id=1223,actor=1,target=1,area={13},flag={empty=0,hero=0},conditionList={2308},conditionType=1,minValue=1,maxValue=1},
    [483] = {id=1224,actor=1,target=1,area={13},flag={empty=0,hero=0},conditionList={2309},conditionType=1,minValue=1,maxValue=1},
    [484] = {id=1225,actor=1,target=1,area={14},flag={hero=1},conditionList={0},conditionType=1,minValue=0,maxValue=-1},
}
local config = {}
local config_loaded = {}
local config_languages = {}

local function config_load(index)
    if index == nil then return nil end
    if config_loaded[index] then return config[index] end
    local source = config_source[index]
    if source == nil then return nil end
    local rowLanguage = config_languages[index] or nil
    local data = ConfigRowRuntime.Build(source,config_runtime_schema,"battle_target_def",rowLanguage)
    config[index] = data
    config_loaded[index] = true
    return data
end

function battle_target_def.config_index(index)
    return config_load(index)
end

function battle_target_def.config_set(index,data)
    config[index] = data
    config_loaded[index] = true
end

function battle_target_def.config_num()
    return config_num
end

local config_id =
{
    [10]=1,[20]=2,[21]=3,[22]=4,[23]=5,[24]=6,[30]=7,[31]=8,[40]=9,[50]=10,[60]=11,[61]=12,[62]=13,[63]=14,[100]=15,[101]=16,[102]=17,[103]=18,[104]=19,[105]=20,[106]=21,[107]=22,[108]=23,[109]=24,[110]=25,[111]=26,[112]=27,[113]=28,[114]=29,[115]=30,[116]=31,[117]=32,[118]=33,[119]=34,[120]=35,[121]=36,[122]=37,[123]=38,[124]=39,[125]=40,[126]=41,[127]=42,[128]=43,[129]=44,[130]=45,[131]=46,[132]=47,[133]=48,[134]=49,[135]=50,[136]=51,[137]=52,[138]=53,[139]=54,[140]=55,[201]=56,[202]=57,[203]=58,[204]=59,[205]=60,[206]=61,[207]=62,[301]=63,[302]=64,[303]=65,[304]=66,[401]=67,[402]=68,[403]=69,[404]=70,[405]=71,[406]=72,[407]=73,[408]=74,[409]=75,[410]=76,[411]=77,[412]=78,[413]=79,[70]=80,[501]=81,[502]=82,[503]=83,[504]=84,[505]=85,[506]=86,[507]=87,[508]=88,[509]=89,[510]=90,[511]=91,[512]=92,[513]=93,[514]=94,[515]=95,[516]=96,[517]=97,[518]=98,[519]=99,[520]=100,[521]=101,[522]=102,[523]=103,[524]=104,[525]=105,[526]=106,[527]=107,[528]=108,[529]=109,[530]=110,[531]=111,[532]=112,[533]=113,[534]=114,[535]=115,[536]=116,[537]=117,[538]=118,[539]=119,[540]=120,[541]=121,[542]=122,[543]=123,[544]=124,[545]=125,[546]=126,[547]=127,[548]=128,[549]=129,[550]=130,[551]=131,[552]=132,[553]=133,[554]=134,[555]=135,[601]=136,[602]=137,[603]=138,[604]=139,[605]=140,[606]=141,[607]=142,[608]=143,[609]=144,[610]=145,[611]=146,[612]=147,[613]=148,[614]=149,[615]=150,[616]=151,[617]=152,[618]=153,[619]=154,[620]=155,[621]=156,[622]=157,[623]=158,[624]=159,[625]=160,[626]=161,[627]=162,[628]=163,[629]=164,[630]=165,[631]=166,[632]=167,[633]=168,[634]=169,[635]=170,[636]=171,[637]=172,[638]=173,[639]=174,[640]=175,[641]=176,[642]=177,[643]=178,[644]=179,[645]=180,[646]=181,[647]=182,[648]=183,[649]=184,[650]=185,[651]=186,[652]=187,[653]=188,[654]=189,[655]=190,[656]=191,[657]=192,[658]=193,[659]=194,[660]=195,[661]=196,[662]=197,[663]=198,[664]=199,[665]=200,[666]=201,[667]=202,[668]=203,[669]=204,[670]=205,[671]=206,[672]=207,[673]=208,[674]=209,[675]=210,[676]=211,[677]=212,[678]=213,[679]=214,[680]=215,[681]=216,[682]=217,[683]=218,[684]=219,[685]=220,[686]=221,[687]=222,[688]=223,[689]=224,[690]=225,[691]=226,[692]=227,[693]=228,[694]=229,[695]=230,[696]=231,[697]=232,[698]=233,[699]=234,[700]=235,[701]=236,[702]=237,[703]=238,[704]=239,[705]=240,[706]=241,[707]=242,[708]=243,[709]=244,[710]=245,[711]=246,[712]=247,[713]=248,[714]=249,[720]=250,[721]=251,[722]=252,[723]=253,[724]=254,[725]=255,[726]=256,[727]=257,[728]=258,[730]=259,[731]=260,[732]=261,[733]=262,[734]=263,[735]=264,[736]=265,[737]=266,[738]=267,[739]=268,[740]=269,[741]=270,[742]=271,[743]=272,[744]=273,[745]=274,[746]=275,[747]=276,[748]=277,[749]=278,[750]=279,[751]=280,[752]=281,[753]=282,[754]=283,[755]=284,[756]=285,[757]=286,[758]=287,[759]=288,[760]=289,[761]=290,[762]=291,[763]=292,[764]=293,[765]=294,[766]=295,[767]=296,[768]=297,[769]=298,[770]=299,[771]=300,[772]=301,[773]=302,[775]=303,[776]=304,[777]=305,[778]=306,[779]=307,[780]=308,[781]=309,[782]=310,[783]=311,[784]=312,[785]=313,[786]=314,[787]=315,[788]=316,[789]=317,[790]=318,[791]=319,[792]=320,[793]=321,[794]=322,[795]=323,[796]=324,[797]=325,[798]=326,[799]=327,[800]=328,[801]=329,[802]=330,[803]=331,[804]=332,[805]=333,[806]=334,[807]=335,[808]=336,[809]=337,[810]=338,[811]=339,[812]=340,[813]=341,[814]=342,[815]=343,[816]=344,[817]=345,[818]=346,[819]=347,[820]=348,[821]=349,[822]=350,[823]=351,[824]=352,[825]=353,[826]=354,[827]=355,[828]=356,[829]=357,[830]=358,[831]=359,[832]=360,[833]=361,[834]=362,[835]=363,[836]=364,[837]=365,[838]=366,[839]=367,[840]=368,[841]=369,[852]=370,[853]=371,[854]=372,[855]=373,[856]=374,[857]=375,[858]=376,[859]=377,[860]=378,[861]=379,[862]=380,[863]=381,[864]=382,[865]=383,[866]=384,[867]=385,[868]=386,[869]=387,[870]=388,[871]=389,[872]=390,[873]=391,[874]=392,[875]=393,[876]=394,[877]=395,[878]=396,[879]=397,[880]=398,[881]=399,[882]=400,[883]=401,[884]=402,[885]=403,[886]=404,[887]=405,[888]=406,[889]=407,[890]=408,[891]=409,[892]=410,[893]=411,[894]=412,[895]=413,[896]=414,[897]=415,[898]=416,[899]=417,[900]=418,[901]=419,[902]=420,[903]=421,[904]=422,[905]=423,[906]=424,[907]=425,[908]=426,[909]=427,[910]=428,[911]=429,[912]=430,[913]=431,[914]=432,[915]=433,[916]=434,[917]=435,[918]=436,[919]=437,[920]=438,[921]=439,[922]=440,[923]=441,[924]=442,[925]=443,[926]=444,[927]=445,[928]=446,[929]=447,[930]=448,[931]=449,[932]=450,[933]=451,[934]=452,[935]=453,[936]=454,[937]=455,[938]=456,[939]=457,[940]=458,[941]=459,[942]=460,[943]=461,[944]=462,[945]=463,[946]=464,[947]=465,[949]=466,[1201]=467,[1202]=468,[1203]=469,[1211]=470,[1212]=471,[1213]=472,[1214]=473,[1215]=474,[1216]=475,[1217]=476,[1218]=477,[1219]=478,[1220]=479,[1221]=480,[1222]=481,[1223]=482,[1224]=483,[1225]=484
}

function battle_target_def.config_id(key)
    local index = config_id[key]
    return battle_target_def.config_index(index)
end

local configSheets =
{
    ["config"] =
    {
        schema = config_schema,
        indexes =
        {
            { indexKey = "id", fields = {"id"}, fieldTypes = {"int"}, group = false },
        },
    },
}

local configSheetRuntimes =
{
    ["config"] =
    {
        getRows = function() return config_source end,
        getLanguages = function() return config_languages end,
        getSchema = function() return config_runtime_schema end,
        publish = function(rows,indexes,schema,languages)
            config_source = rows
            config_runtime_schema = schema or config_schema
            config_languages = languages or {}
            config = {}
            config_loaded = {}
            config_num = #rows
            config_id = indexes["id"] or {}
        end,
    },
}

local function BuildIndexKey(row,fields)
    if #fields == 1 then return row[fields[1]] end
    local values = {}
    for index,fieldName in ipairs(fields) do
        values[index] = tostring(row[fieldName])
    end
    return table.concat(values,"_")
end

local function BuildIndexKeyFromValue(value,fields)
    if #fields == 1 then return value end
    if type(value) ~= "table" or #value ~= #fields then return nil end
    local values = {}
    for index = 1,#fields do values[index] = tostring(value[index]) end
    return table.concat(values,"_")
end

local function ValidateRowsTable(rows)
    if type(rows) ~= "table" then return false,"配置行集合需要 table" end
    local count = 0
    for key in pairs(rows) do
        if type(key) ~= "number" or key < 1 or key % 1 ~= 0 then
            return false,string.format("配置行集合包含无效数组键[%s]",tostring(key))
        end
        count = count + 1
    end
    for index = 1,count do
        if rows[index] == nil then return false,string.format("配置行集合存在空洞[%s]",index) end
    end
    return true
end

local function GetIndexRule(info,installKey)
    local indexKey = nil
    if type(installKey) == "string" then
        indexKey = installKey
    elseif type(installKey) == "table" then
        local valid,err = ValidateRowsTable(installKey)
        if not valid then return nil,err end
        local fields = {}
        for index,fieldName in ipairs(installKey) do
            if type(fieldName) ~= "string" then return nil,string.format("installKey第%s项需要 string",index) end
            fields[index] = fieldName
        end
        indexKey = table.concat(fields,",")
    else
        return nil,string.format("installKey需要 string 或有序字段数组，实际为 %s",type(installKey))
    end
    for _,rule in ipairs(info.indexes) do
        if rule.indexKey == indexKey then return rule end
    end
    return nil,string.format("installKey未匹配现有查询索引[%s]",tostring(indexKey))
end

function battle_target_def.GetSheetInfo(sheetName)
    return configSheets[sheetName]
end

function battle_target_def.CaptureState(sheetName)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    return { rows = runtime.getRows(), languages = runtime.getLanguages(), schema = runtime.getSchema() }
end

function battle_target_def.RestoreState(sheetName,state)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    if type(state) ~= "table" or type(state.rows) ~= "table" or type(state.languages) ~= "table" or type(state.schema) ~= "table" then
        return false,"配置快照无效"
    end
    local indexes,indexErr = battle_target_def.BuildIndexes(sheetName,state.rows,true,state.schema)
    if indexes == nil then return false,indexErr end
    runtime.publish(state.rows,indexes,state.schema,state.languages)
    return true
end

function battle_target_def.ValidateRow(sheetName,row,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return false,schemaErr end
    return ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
end

function battle_target_def.BuildIndexes(sheetName,rows,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    local rowsValid,rowsErr = ValidateRowsTable(rows)
    if not rowsValid then return nil,rowsErr end
    local indexes = {}
    for _,rule in ipairs(info.indexes) do indexes[rule.indexKey] = {} end
    for index,row in ipairs(rows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",index,err) end
        for _,rule in ipairs(info.indexes) do
            local key = BuildIndexKey(row,rule.fields)
            local target = indexes[rule.indexKey]
            if rule.group then
                target[key] = target[key] or {}
                table.insert(target[key],index)
            else
                target[key] = index
            end
        end
    end
    return indexes
end

local function RemoveRowOwners(info,owners,row,rowIndex)
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local key = BuildIndexKey(row,rule.fields)
            local keyOwners = owners[rule.indexKey][key]
            if keyOwners ~= nil then
                for ownerIndex = #keyOwners,1,-1 do
                    if keyOwners[ownerIndex] == rowIndex then table.remove(keyOwners,ownerIndex) end
                end
                if #keyOwners == 0 then owners[rule.indexKey][key] = nil end
            end
        end
    end
end

local function ResolveNewRowConflicts(info,groupRule,rows,languages,newRowIndexes)
    local owners = {}
    local active = {}
    local isNew = {}
    local conflicts = {}
    for _,rowIndex in ipairs(newRowIndexes) do isNew[rowIndex] = true end
    for _,rule in ipairs(info.indexes) do if not rule.group then owners[rule.indexKey] = {} end end
    for rowIndex,row in ipairs(rows) do
        active[rowIndex] = true
        if not isNew[rowIndex] then
            for _,rule in ipairs(info.indexes) do
                if not rule.group then
                    local key = BuildIndexKey(row,rule.fields)
                    local keyOwners = owners[rule.indexKey][key] or {}
                    table.insert(keyOwners,rowIndex)
                    owners[rule.indexKey][key] = keyOwners
                end
            end
        end
    end
    for _,rowIndex in ipairs(newRowIndexes) do
        local row = rows[rowIndex]
        local removeIndexes = {}
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                local keyOwners = owners[rule.indexKey][key]
                if keyOwners ~= nil then
                    for _,oldIndex in ipairs(keyOwners) do
                        if active[oldIndex] then
                            removeIndexes[oldIndex] = true
                            table.insert(conflicts,{
                                indexKey = rule.indexKey,
                                key = key,
                                oldIndex = oldIndex,
                                newIndex = rowIndex,
                                oldGroupKey = BuildIndexKey(rows[oldIndex],groupRule.fields),
                                newGroupKey = BuildIndexKey(row,groupRule.fields),
                            })
                        end
                    end
                end
            end
        end
        for oldIndex in pairs(removeIndexes) do
            active[oldIndex] = false
            RemoveRowOwners(info,owners,rows[oldIndex],oldIndex)
        end
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                owners[rule.indexKey][key] = {rowIndex}
            end
        end
    end
    local result = {}
    local resultLanguages = {}
    for rowIndex,row in ipairs(rows) do
        if active[rowIndex] then
            table.insert(result,row)
            table.insert(resultLanguages,languages[rowIndex] or false)
        end
    end
    return result,resultLanguages,conflicts
end

local function CollectAppendConflicts(info,currentCount,rows)
    local conflicts = {}
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local latest = {}
            for rowIndex,row in ipairs(rows) do
                local key = BuildIndexKey(row,rule.fields)
                local oldIndex = latest[key]
                if rowIndex > currentCount and oldIndex ~= nil then
                    table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=oldIndex,newIndex=rowIndex})
                end
                latest[key] = rowIndex
            end
        end
    end
    return conflicts
end

function battle_target_def.ApplyBatch(sheetName,batch,allowUnknown,schemaOverride,rowLanguage)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local runtime = configSheetRuntimes[sheetName]
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    if type(batch) ~= "table" then return nil,"配置批次需要 table" end
    for key in pairs(batch) do
        if key ~= "installKey" and key ~= "installValue" and key ~= "operation" and key ~= "rows" then
            return nil,string.format("配置批次包含未知字段[%s]",tostring(key))
        end
    end
    local newRows = batch.rows
    local rowsValid,rowsErr = ValidateRowsTable(newRows)
    if not rowsValid then return nil,rowsErr end
    for rowIndex,row in ipairs(newRows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",rowIndex,err) end
    end
    local warnings = {}
    if #newRows == 0 and batch.installKey == nil then
        return { operation = "append", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} }
    end
    local currentRows = runtime.getRows()
    local currentLanguages = runtime.getLanguages()
    local candidateRows = {}
    local candidateLanguages = {}
    local newRowIndexes = {}
    if batch.installKey == nil then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"无 installKey 批次不能声明 installValue/operation" end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
        end
        local indexes,indexErr = battle_target_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        local conflicts = CollectAppendConflicts(info,#currentRows,candidateRows)
        if #conflicts > 0 then table.insert(warnings,string.format("无 installKey 追加产生 %s 个普通查询键冲突；后写结果生效",#conflicts)) end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "append", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    local rule,ruleErr = GetIndexRule(info,batch.installKey)
    if rule == nil then return nil,ruleErr end
    if not rule.group then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"普通 upsert 不能声明 installValue/operation" end
        if #newRows == 0 then return { operation = "upsert", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} } end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        local conflicts = {}
        for _,newRow in ipairs(newRows) do
            local key = BuildIndexKey(newRow,rule.fields)
            local matched = {}
            for rowIndex,oldRow in ipairs(candidateRows) do
                if BuildIndexKey(oldRow,rule.fields) == key then table.insert(matched,rowIndex) end
            end
            if #matched > 1 then return nil,string.format("安装身份歧义[index:%s][key:%s][rows:%s]",rule.indexKey,tostring(key),table.concat(matched,",")) end
            if #matched == 1 then
                table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=matched[1],newIndex=matched[1]})
                candidateRows[matched[1]] = newRow
                candidateLanguages[matched[1]] = rowLanguage or false
            else
                table.insert(candidateRows,newRow)
                table.insert(candidateLanguages,rowLanguage or false)
            end
        end
        local indexes,indexErr = battle_target_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "upsert", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    if batch.installValue == nil then return nil,"组批次缺少 installValue" end
    local groupKey = BuildIndexKeyFromValue(batch.installValue,rule.fields)
    if groupKey == nil then return nil,"installValue 与组查询字段不匹配" end
    local operation = batch.operation or "replace"
    if operation ~= "replace" and operation ~= "append" then return nil,string.format("无效组操作[%s]",tostring(operation)) end
    for rowIndex,row in ipairs(newRows) do
        local rowGroupKey = BuildIndexKey(row,rule.fields)
        if rowGroupKey ~= groupKey then return nil,string.format("组键不一致[目标:%s][第%s行:%s]",tostring(groupKey),rowIndex,tostring(rowGroupKey)) end
    end
    if operation == "append" and #newRows == 0 then return { operation = operation, groupKey = groupKey, rows = runtime.getRows(), warnings = {"空组 append 未修改配置"}, conflicts = {} } end
    local firstGroupIndex = nil
    local oldGroupCount = 0
    if operation == "replace" then
        for rowIndex,row in ipairs(currentRows) do
            if BuildIndexKey(row,rule.fields) == groupKey then
                oldGroupCount = oldGroupCount + 1
                if firstGroupIndex == nil then firstGroupIndex = #candidateRows + 1 end
            else
                table.insert(candidateRows,row)
                table.insert(candidateLanguages,currentLanguages[rowIndex] or false)
            end
        end
        local insertIndex = firstGroupIndex or (#candidateRows + 1)
        for offset,row in ipairs(newRows) do
            table.insert(candidateRows,insertIndex + offset - 1,row)
            table.insert(candidateLanguages,insertIndex + offset - 1,rowLanguage or false)
        end
        for offset = 1,#newRows do table.insert(newRowIndexes,insertIndex + offset - 1) end
    else
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
            table.insert(newRowIndexes,#candidateRows)
        end
    end
    if operation == "replace" and oldGroupCount == 0 and #newRows == 0 then table.insert(warnings,"清空不存在的组未修改配置") end
    local resultRows,resultLanguages,conflicts = ResolveNewRowConflicts(info,rule,candidateRows,candidateLanguages,newRowIndexes)
    local indexes,indexErr = battle_target_def.BuildIndexes(sheetName,resultRows,allowUnknown,schemaOverride)
    if indexes == nil then return nil,indexErr end
    runtime.publish(resultRows,indexes,schema,resultLanguages)
    return { operation = operation, groupKey = groupKey, rows = resultRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
end

local sheetFunc = 
{
    ["config"] = 
    {
        ["index"] = "config_index",
        ["@num"] = "config_num",
        ["@set"] = "config_set",
        ["id"] = "config_id",
    },
}

function battle_target_def.Get(sheetName,keyIndex,key)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return nil,1 end
    local funName = funcIndexs[keyIndex]
    if not funName then return nil,2 end
    return battle_target_def[funName](key),nil
end

function battle_target_def.Set(sheetName,index,data)
    if index == nil then return false end
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return false end
    local funName = funcIndexs["@set"]
    battle_target_def[funName](index,data)
    return true
end

function battle_target_def.GetNum(sheetName)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return 0 end
    local funName = funcIndexs["@num"]
    return battle_target_def[funName]()
end

return battle_target_def