local reward_def = {}
local ConfigRowRuntime = require("common/config/ConfigRowRuntime")
local language = Language.Instance

--config
local config_num = 341
local config_schema =
{
    ["id"] = { type = "int" },
    ["title"] = { type = "string", i18n = true },
    ["icon"] = { type = "string" },
    ["value"] = { type = "lua" },
    ["cardId"] = { type = "int" },
    ["chipId"] = { type = "int" },
    ["itemId"] = { type = "int" },
}
local config_runtime_schema = config_schema
local config_source =
{
    [1] = {id=4001,title="星火币+15",icon="image_decision",value={{gold={count=15}}},cardId=0,chipId=0,itemId=0},
    [2] = {id=4002,title="星火币+10",icon="image_decision",value={{gold={count=10}}},cardId=0,chipId=0,itemId=0},
    [3] = {id=4003,title="星火币+20",icon="image_decision",value={{gold={count=20}}},cardId=0,chipId=0,itemId=0},
    [4] = {id=4004,title="星火币+30",icon="image_decision",value={{gold={count=30}}},cardId=0,chipId=0,itemId=0},
    [5] = {id=4005,title="星火币+50",icon="image_decision",value={{gold={count=50}}},cardId=0,chipId=0,itemId=0},
    [6] = {id=4006,title="星火币+60",icon="image_decision",value={{gold={count=60}}},cardId=0,chipId=0,itemId=0},
    [7] = {id=4007,title="[刃型观测机]星火币+20",icon="image_decision",value={{gold={count=20}}},cardId=0,chipId=0,itemId=0},
    [8] = {id=4008,title="[额外投资]星火币+50",icon="image_decision",value={{gold={count=50}}},cardId=0,chipId=0,itemId=0},
    [9] = {id=4101,title="升级一张卡牌",icon="image_decision",value={{cardUpgrade={}}},cardId=0,chipId=0,itemId=0},
    [10] = {id=4102,title="删除一张卡牌",icon="image_decision",value={{cardDelete={count=1}}},cardId=0,chipId=0,itemId=0},
    [11] = {id=1006,title="获得一张卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={1}}}},cardId=0,chipId=0,itemId=0},
    [12] = {id=1007,title="升级一张卡牌",icon="image_decision",value={{cardUpgrade={}}},cardId=0,chipId=0,itemId=0},
    [13] = {id=1008,title="获得武装",icon="image_decision",value={{arm={list={1101,1102}}}},cardId=0,chipId=0,itemId=0},
    [14] = {id=1009,title="获得武装",icon="image_decision",value={{arm={list={1111,1112}}}},cardId=0,chipId=0,itemId=0},
    [15] = {id=1010,title="获得武装",icon="image_decision",value={{arm={list={1121,1122}}}},cardId=0,chipId=0,itemId=0},
    [16] = {id=1100,title="获得赝波",icon="image_decision",value={{card={count=1,pool={11}}}},cardId=0,chipId=0,itemId=0},
    [17] = {id=1101,title="获得薮猫",icon="image_decision",value={{card={count=1,pool={122}}}},cardId=0,chipId=0,itemId=0},
    [18] = {id=1102,title="卡牌二选一",icon="image_decision",value={{card={count=2,choose=1,pool={13}}}},cardId=0,chipId=0,itemId=0},
    [19] = {id=1103,title="卡牌二选一",icon="image_decision",value={{card={count=2,choose=1,pool={14}}}},cardId=0,chipId=0,itemId=0},
    [20] = {id=1104,title="卡牌二选一",icon="image_decision",value={{card={count=2,choose=1,pool={15}}}},cardId=0,chipId=0,itemId=0},
    [21] = {id=1105,title="卡牌二选一",icon="image_decision",value={{card={count=2,choose=1,pool={16}}}},cardId=0,chipId=0,itemId=0},
    [22] = {id=1106,title="获得武装",icon="image_decision",value={{arm={list={1123}}}},cardId=0,chipId=0,itemId=0},
    [23] = {id=1107,title="获得武装",icon="image_decision",value={{arm={list={1124}}}},cardId=0,chipId=0,itemId=0},
    [24] = {id=1108,title="获得武装",icon="image_decision",value={{arm={list={1125,1126}}}},cardId=0,chipId=0,itemId=0},
    [25] = {id=2002,title="多种奖励",icon="image_decision",value={{list={1001,1002}}},cardId=0,chipId=0,itemId=0},
    [26] = {id=2003,title="多种奖励",icon="image_decision",value={{list={1001,1002,1004}}},cardId=0,chipId=0,itemId=0},
    [27] = {id=2004,title="获得一张卡牌",icon="image_decision",value={{card={count=1,choose=1,pool={17}}}},cardId=0,chipId=0,itemId=0},
    [28] = {id=2005,title="星火币+50",icon="image_decision",value={{id=1001,count=50}},cardId=0,chipId=0,itemId=0},
    [29] = {id=1201,title="获得一张卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={21}}}},cardId=0,chipId=0,itemId=0},
    [30] = {id=1202,title="获得僚机卡牌[猎户座]",icon="image_decision",value={{card={count=1,pool={22}}}},cardId=0,chipId=0,itemId=0},
    [31] = {id=1203,title="获得僚机卡牌[特里格拉夫]",icon="image_decision",value={{card={count=1,pool={123}}}},cardId=10180,chipId=0,itemId=0},
    [32] = {id=1204,title="获得僚机卡牌[薮猫]",icon="image_decision",value={{card={count=1,pool={122}}}},cardId=0,chipId=0,itemId=0},
    [33] = {id=1303,title="获得僚机卡牌[十字星]",icon="image_decision",value={{card={count=1,pool={24}}}},cardId=0,chipId=0,itemId=0},
    [34] = {id=1304,title="获得大招卡牌[新星觉醒]",icon="image_decision",value={{card={count=1,pool={26}}}},cardId=0,chipId=0,itemId=0},
    [35] = {id=1501,title="获得道具[紧急损害管制]",icon="image_decision",value={{battleItem={id=2002, count=1}}},cardId=0,chipId=0,itemId=0},
    [36] = {id=1502,title="获得道具[私有密钥]",icon="image_decision",value={{battleItem={id=2003, count=1}}},cardId=0,chipId=0,itemId=0},
    [37] = {id=1503,title="获得道具[一次性打桩机]",icon="image_decision",value={{battleItem={id=2004, count=1}}},cardId=0,chipId=0,itemId=0},
    [38] = {id=1504,title="获得道具[高能电容]",icon="image_decision",value={{battleItem={id=2005, count=1}}},cardId=0,chipId=0,itemId=0},
    [39] = {id=1505,title="获得道具[雷云炸弹]",icon="image_decision",value={{battleItem={id=2006, count=1}}},cardId=0,chipId=0,itemId=0},
    [40] = {id=1506,title="获得道具[聚焦]",icon="image_decision",value={{battleItem={id=2007, count=1}}},cardId=0,chipId=0,itemId=0},
    [41] = {id=1507,title="获得道具[过载核心]",icon="image_decision",value={{battleItem={id=2008, count=1}}},cardId=0,chipId=0,itemId=0},
    [42] = {id=1508,title="获得道具[嗜血代码]",icon="image_decision",value={{battleItem={id=2009, count=1}}},cardId=0,chipId=0,itemId=0},
    [43] = {id=1509,title="获得道具[影绰投射器]",icon="image_decision",value={{battleItem={id=2010, count=1}}},cardId=0,chipId=0,itemId=0},
    [44] = {id=1510,title="获得道具[冯诺依曼机]",icon="image_decision",value={{battleItem={id=2011, count=1}}},cardId=0,chipId=0,itemId=0},
    [45] = {id=2100,title="获得卡牌[干扰射击]",icon="image_decision",value={{card={count=1,pool={51}}}},cardId=2010,chipId=0,itemId=0},
    [46] = {id=2101,title="获得晶片[引擎出力提升]",icon="image_decision",value={{chip={count=1,pool={11}}}},cardId=0,chipId=4000,itemId=0},
    [47] = {id=2102,title="获得卡牌[晋升指令]",icon="image_decision",value={{card={count=1,pool={52}}}},cardId=2016,chipId=0,itemId=0},
    [48] = {id=2103,title="获得卡牌[新星觉醒]",icon="image_decision",value={{card={count=1,pool={53}}}},cardId=2018,chipId=0,itemId=0},
    [49] = {id=2104,title="获得卡牌[通用组件]",icon="image_decision",value={{card={count=1,pool={54}}}},cardId=2027,chipId=0,itemId=0},
    [50] = {id=2105,title="获得卡牌[狂风组件]",icon="image_decision",value={{card={count=1,pool={55}}}},cardId=2029,chipId=0,itemId=0},
    [51] = {id=2106,title="获得道具[猎手支援]",icon="image_decision",value={{battleItem={id=3018, count=1}}},cardId=0,chipId=0,itemId=3018},
    [52] = {id=2107,title="获得道具[十字支援]",icon="image_decision",value={{battleItem={id=3021, count=1}}},cardId=0,chipId=0,itemId=3021},
    [53] = {id=2200,title="获得一张卡牌[通用act_reward中更换]",icon="image_decision",value={{card={count=3,choose=1,pool={1}}}},cardId=0,chipId=0,itemId=0},
    [54] = {id=2201,title="获得一张白矮星卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={70,802}}}},cardId=0,chipId=0,itemId=0},
    [55] = {id=2202,title="获得一张十字星卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={71}}}},cardId=0,chipId=0,itemId=0},
    [56] = {id=2203,title="获得一张猎户座卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={72,802}}}},cardId=0,chipId=0,itemId=0},
    [57] = {id=2204,title="获得一张可集成卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={110}}}},cardId=0,chipId=0,itemId=0},
    [58] = {id=2205,title="获得一张薮猫卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={73,802}}}},cardId=0,chipId=0,itemId=0},
    [59] = {id=2206,title="获得一张高级卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={120}}}},cardId=0,chipId=0,itemId=0},
    [60] = {id=2108,title="获得卡牌[紧急废弃]",icon="image_decision",value={{card={count=1,pool={56}}}},cardId=2067,chipId=0,itemId=0},
    [61] = {id=2109,title="获得晶片[内存调度优化]",icon="image_decision",value={{chip={count=1,pool={12}}}},cardId=0,chipId=4004,itemId=0},
    [62] = {id=2110,title="获得卡牌[利刃无人机]",icon="image_decision",value={{card={count=1,pool={57}}}},cardId=2081,chipId=0,itemId=0},
    [63] = {id=2111,title="获得卡牌[护盾无人机β]",icon="image_decision",value={{card={count=1,pool={58}}}},cardId=2083,chipId=0,itemId=0},
    [64] = {id=2112,title="获得卡牌[强能护盾]",icon="image_decision",value={{card={count=1,pool={59}}}},cardId=2085,chipId=0,itemId=0},
    [65] = {id=2113,title="获得卡牌[防御支援机]",icon="image_decision",value={{card={count=1,pool={60}}}},cardId=2089,chipId=0,itemId=0},
    [66] = {id=2114,title="获得道具[新星支援]",icon="image_decision",value={{battleItem={id=3017, count=1}}},cardId=0,chipId=0,itemId=3017},
    [67] = {id=2115,title="获得道具[猎手支援]",icon="image_decision",value={{battleItem={id=3018, count=1}}},cardId=0,chipId=0,itemId=3018},
    [68] = {id=2116,title="获得晶片[载重投射算法]",icon="image_decision",value={{chip={count=1,pool={14}}}},cardId=0,chipId=4024,itemId=0},
    [69] = {id=2117,title="获得晶片[废热投射算法]",icon="image_decision",value={{chip={count=1,pool={15}}}},cardId=0,chipId=4026,itemId=0},
    [70] = {id=2118,title="获得晶片[结构投射算法]",icon="image_decision",value={{chip={count=1,pool={16}}}},cardId=0,chipId=4028,itemId=0},
    [71] = {id=2119,title="获得道具[剑豪支援]",icon="image_decision",value={{battleItem={id=3020, count=1}}},cardId=0,chipId=0,itemId=3020},
    [72] = {id=2120,title="获得道具[三重支援]",icon="image_decision",value={{battleItem={id=3019, count=1}}},cardId=0,chipId=0,itemId=3019},
    [73] = {id=2121,title="获得道具[转运服务]",icon="image_decision",value={{battleItem={id=3001, count=1}}},cardId=0,chipId=0,itemId=3001},
    [74] = {id=2122,title="获得道具[输能服务]",icon="image_decision",value={{battleItem={id=3002, count=1}}},cardId=0,chipId=0,itemId=3002},
    [75] = {id=2123,title="获得道具[炮击服务]",icon="image_decision",value={{battleItem={id=3007, count=1}}},cardId=0,chipId=0,itemId=3007},
    [76] = {id=2124,title="恢复全部CA",icon="image_decision",value={{hp={percent=100}}},cardId=0,chipId=0,itemId=0},
    [77] = {id=2125,title="恢复5CA",icon="image_decision",value={{hp={value=5}}},cardId=0,chipId=0,itemId=0},
    [78] = {id=2126,title="恢复10CA",icon="image_decision",value={{hp={value=10}}},cardId=0,chipId=0,itemId=0},
    [79] = {id=2127,title="获得一枚晶片",icon="image_decision",value={{chip={count=3,choose=1,pool={20}}}},cardId=0,chipId=0,itemId=0},
    [80] = {id=2128,title="获得一枚三层后晶片",icon="image_decision",value={{chip={count=3,choose=1,pool={50}}}},cardId=0,chipId=0,itemId=0},
    [81] = {id=2130,title="获得道具[转运服务]",icon="image_decision",value={{battleItem={id=3001, count=1}}},cardId=0,chipId=0,itemId=3001},
    [82] = {id=2131,title="获得道具[输能服务]",icon="image_decision",value={{battleItem={id=3002, count=1}}},cardId=0,chipId=0,itemId=3002},
    [83] = {id=2132,title="获得道具[聚能炮管]",icon="image_decision",value={{battleItem={id=3003, count=1}}},cardId=0,chipId=0,itemId=3003},
    [84] = {id=2133,title="获得道具[临时弹药包]",icon="image_decision",value={{battleItem={id=3004, count=1}}},cardId=0,chipId=0,itemId=3004},
    [85] = {id=2134,title="获得道具[外置运存]",icon="image_decision",value={{battleItem={id=3005, count=1}}},cardId=0,chipId=0,itemId=3005},
    [86] = {id=2135,title="获得道具[战斗保险]",icon="image_decision",value={{battleItem={id=3006, count=1}}},cardId=0,chipId=0,itemId=3006},
    [87] = {id=2136,title="获得道具[炮击服务]",icon="image_decision",value={{battleItem={id=3007, count=1}}},cardId=0,chipId=0,itemId=3007},
    [88] = {id=2137,title="获得道具[高爆炸弹]",icon="image_decision",value={{battleItem={id=3008, count=1}}},cardId=0,chipId=0,itemId=3008},
    [89] = {id=2138,title="获得道具[便携式打印机]",icon="image_decision",value={{battleItem={id=3009, count=1}}},cardId=0,chipId=0,itemId=3009},
    [90] = {id=2139,title="获得道具[便携式发射器]",icon="image_decision",value={{battleItem={id=3010, count=1}}},cardId=0,chipId=0,itemId=3010},
    [91] = {id=2140,title="获得道具[战线优化许可]",icon="image_decision",value={{battleItem={id=3011, count=1}}},cardId=0,chipId=0,itemId=3011},
    [92] = {id=2141,title="获得道具[阻滞力场]",icon="image_decision",value={{battleItem={id=3012, count=1}}},cardId=0,chipId=0,itemId=3012},
    [93] = {id=2142,title="获得道具[战备调动许可]",icon="image_decision",value={{battleItem={id=3013, count=1}}},cardId=0,chipId=0,itemId=3013},
    [94] = {id=2143,title="获得道具[库存优化许可]",icon="image_decision",value={{battleItem={id=3014, count=1}}},cardId=0,chipId=0,itemId=3014},
    [95] = {id=2144,title="获得道具[雇佣服务]",icon="image_decision",value={{battleItem={id=3015, count=1}}},cardId=0,chipId=0,itemId=3015},
    [96] = {id=2145,title="获得道具[新星支援]",icon="image_decision",value={{battleItem={id=3017, count=1}}},cardId=0,chipId=0,itemId=3017},
    [97] = {id=2146,title="获得道具[猎手支援]",icon="image_decision",value={{battleItem={id=3018, count=1}}},cardId=0,chipId=0,itemId=3018},
    [98] = {id=2147,title="获得道具[三重支援]",icon="image_decision",value={{battleItem={id=3019, count=1}}},cardId=0,chipId=0,itemId=3019},
    [99] = {id=2148,title="获得道具[剑豪支援]",icon="image_decision",value={{battleItem={id=3020, count=1}}},cardId=0,chipId=0,itemId=3020},
    [100] = {id=2149,title="获得道具[十字支援]",icon="image_decision",value={{battleItem={id=3021, count=1}}},cardId=0,chipId=0,itemId=3021},
    [101] = {id=2150,title="获得道具[发薪日]",icon="image_decision",value={{battleItem={id=3022, count=1}}},cardId=0,chipId=0,itemId=3022},
    [102] = {id=2151,title="获得道具[算力冗余]",icon="image_decision",value={{battleItem={id=3023, count=1}}},cardId=0,chipId=0,itemId=3023},
    [103] = {id=2152,title="获得一个随机道具",icon="image_decision",value={{random={id=2,count=1}}},cardId=0,chipId=0,itemId=0},
    [104] = {id=2160,title="获得僚机[ACE-001 白矮星]。",icon="image_decision",value={{card={count=1,pool={80}}}},cardId=2204,chipId=0,itemId=0},
    [105] = {id=2161,title="获得僚机[ACE-002 十字星]。",icon="image_decision",value={{card={count=1,pool={81}}}},cardId=2208,chipId=0,itemId=0},
    [106] = {id=2162,title="获得僚机[ACE-003 猎户座]。",icon="image_decision",value={{card={count=1,pool={82}}}},cardId=2212,chipId=0,itemId=0},
    [107] = {id=2163,title="获得僚机[TM31R 薮猫]。",icon="image_decision",value={{card={count=1,pool={122}}}},cardId=10050,chipId=0,itemId=0},
    [108] = {id=2164,title="获得僚机[ACE-008 特里格拉夫]。",icon="image_decision",value={{card={count=1,pool={123}}}},cardId=10180,chipId=0,itemId=0},
    [109] = {id=2165,title="获得卡牌[电流涌动]。",icon="image_decision",value={{card={count=1,pool={61}}}},cardId=2171,chipId=0,itemId=0},
    [110] = {id=2166,title="获得晶片[后勤运输前置]。",icon="image_decision",value={{chip={count=1,pool={13}}}},cardId=0,chipId=4012,itemId=0},
    [111] = {id=2167,title="获得卡牌[全弹射击]。",icon="image_decision",value={{card={count=1,pool={62}}}},cardId=2133,chipId=0,itemId=0},
    [112] = {id=2168,title="获得卡牌[武装组件]。",icon="image_decision",value={{card={count=1,pool={63}}}},cardId=2147,chipId=0,itemId=0},
    [113] = {id=2169,title="获得卡牌[连发射击]。",icon="image_decision",value={{card={count=1,pool={64}}}},cardId=2131,chipId=0,itemId=0},
    [114] = {id=2170,title="获得卡牌[掠夺射击]。",icon="image_decision",value={{card={count=1,pool={65}}}},cardId=2135,chipId=0,itemId=0},
    [115] = {id=2171,title="获得道具[新星支援]",icon="image_decision",value={{battleItem={id=3017, count=1}}},cardId=0,chipId=0,itemId=3017},
    [116] = {id=2172,title="获得道具[十字支援]",icon="image_decision",value={{battleItem={id=3021, count=1}}},cardId=0,chipId=0,itemId=3021},
    [117] = {id=2173,title="获得卡牌[集群单元+]",icon="image_decision",value={{card={count=1,pool={85}}}},cardId=7532,chipId=0,itemId=0},
    [118] = {id=2174,title="获得机师[邓肯23]",icon="image_decision",value={{hero={id=100}}},cardId=7000,chipId=0,itemId=0},
    [119] = {id=2175,title="获得机师[邓肯76]",icon="image_decision",value={{hero={id=101}}},cardId=7003,chipId=0,itemId=0},
    [120] = {id=2176,title="获得机师[久卡·马可尼]",icon="image_decision",value={{hero={id=102}}},cardId=7006,chipId=0,itemId=0},
    [121] = {id=2177,title="获得机师[冬子]",icon="image_decision",value={{hero={id=103}}},cardId=7008,chipId=0,itemId=0},
    [122] = {id=2178,title="获得机师[夏洛]",icon="image_decision",value={{hero={id=104}}},cardId=7011,chipId=0,itemId=0},
    [123] = {id=2179,title="获得机师[奥斯陆]",icon="image_decision",value={{hero={id=105}}},cardId=7015,chipId=0,itemId=0},
    [124] = {id=2180,title="获得卡牌[代号：斯瓦洛格]。",icon="image_decision",value={{card={count=1,pool={86}}}},cardId=2221,chipId=0,itemId=0},
    [125] = {id=2181,title="获得卡牌[团结无人机]。",icon="image_decision",value={{card={count=1,pool={87}}}},cardId=2031,chipId=0,itemId=0},
    [126] = {id=2182,title="获得卡牌[团结无人机+]。",icon="image_decision",value={{card={count=1,pool={88}}}},cardId=2032,chipId=0,itemId=0},
    [127] = {id=2183,title="获得卡牌[爱之镀膜]。",icon="image_decision",value={{card={count=1,pool={89}}}},cardId=7005,chipId=0,itemId=0},
    [128] = {id=2184,title="获得卡牌[紧急维修]。",icon="image_decision",value={{card={count=1,pool={90}}}},cardId=7002,chipId=0,itemId=0},
    [129] = {id=2185,title="获得卡牌[铭字导弹]。",icon="image_decision",value={{card={count=1,pool={91}}}},cardId=7010,chipId=0,itemId=0},
    [130] = {id=2186,title="获得卡牌[剑气]。",icon="image_decision",value={{card={count=1,pool={92}}}},cardId=7014,chipId=0,itemId=0},
    [131] = {id=2187,title="获得卡牌[爆破指令]。",icon="image_decision",value={{card={count=1,pool={93}}}},cardId=7016,chipId=0,itemId=0},
    [132] = {id=2188,title="获得卡牌[共振黄蜂]。",icon="image_decision",value={{card={count=1,pool={94}}}},cardId=2179,chipId=0,itemId=0},
    [133] = {id=2189,title="获得卡牌[恒星贯射]。",icon="image_decision",value={{card={count=1,pool={94}}}},cardId=10215,chipId=0,itemId=0},
    [134] = {id=2190,title="获得卡牌[不协辉光]。",icon="image_decision",value={{card={count=1,pool={95}}}},cardId=2481,chipId=0,itemId=0},
    [135] = {id=2191,title="获得卡牌[月神之箭]。",icon="image_decision",value={{card={count=1,pool={96}}}},cardId=2482,chipId=0,itemId=0},
    [136] = {id=2192,title="获得卡牌[UN里技·怒涛]。",icon="image_decision",value={{card={count=1,pool={97}}}},cardId=2483,chipId=0,itemId=0},
    [137] = {id=2193,title="获得卡牌[代号：戴博格]。",icon="image_decision",value={{card={count=1,pool={98}}}},cardId=2484,chipId=0,itemId=0},
    [138] = {id=2194,title="获得强力卡牌[代号：戴博格]。",icon="image_decision",value={{card={count=1,pool={100}}}},cardId=2484,chipId=0,itemId=0},
    [139] = {id=2195,title="获得强力卡牌[不协辉光]。",icon="image_decision",value={{card={count=1,pool={101}}}},cardId=2481,chipId=0,itemId=0},
    [140] = {id=2196,title="恢复20CA",icon="image_decision",value={{hp={value=20}}},cardId=0,chipId=0,itemId=0},
    [141] = {id=2197,title="恢复全部CA",icon="image_decision",value={{hp={value=100}}},cardId=0,chipId=0,itemId=0},
    [142] = {id=3000,title="[商会信标]星火币+10",icon="image_decision",value={{gold={count=10}}},cardId=0,chipId=0,itemId=0},
    [143] = {id=3001,title="获得卡牌[数据干扰]",icon="image_decision",value={{card={count=1,pool={111}}}},cardId=2067,chipId=0,itemId=0},
    [144] = {id=3002,title="获得卡牌[遗憾]",icon="image_decision",value={{card={count=1,pool={112},force=1}}},cardId=2067,chipId=0,itemId=0},
    [145] = {id=3003,title="获得道具[碎星矿]",icon="image_decision",value={{battleItem={id=3024, count=1}}},cardId=0,chipId=0,itemId=3017},
    [146] = {id=3004,title="获得卡牌[接触不良]",icon="image_decision",value={{card={count=1,pool={113}}}},cardId=2067,chipId=0,itemId=0},
    [147] = {id=3005,title="失去5CA",icon="image_decision",value={{hp={value=-5}}},cardId=0,chipId=0,itemId=0},
    [148] = {id=3006,title="失去10CA",icon="image_decision",value={{hp={value=-10}}},cardId=0,chipId=0,itemId=0},
    [149] = {id=3007,title="获得一张商会卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={114}}}},cardId=0,chipId=0,itemId=0},
    [150] = {id=3008,title="获得道具[对海盗的怨念]",icon="image_decision",value={{battleItem={id=3025, count=1}}},cardId=0,chipId=0,itemId=3018},
    [151] = {id=3009,title="获得晶片[不屈的意志]",icon="image_decision",value={{chip={count=1,pool={31}}}},cardId=0,chipId=4012,itemId=0},
    [152] = {id=3010,title="获得卡牌[裁决]",icon="image_decision",value={{card={count=1,pool={115}}}},cardId=2067,chipId=0,itemId=0},
    [153] = {id=3011,title="获得道具[复仇的预告]",icon="image_decision",value={{battleItem={id=3026, count=1}}},cardId=0,chipId=0,itemId=3018},
    [154] = {id=3012,title="获得一张海盗卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={116}}}},cardId=0,chipId=0,itemId=0},
    [155] = {id=3013,title="失去0CA",icon="image_decision",value={{hp={value=0}}},cardId=0,chipId=0,itemId=0},
    [156] = {id=3014,title="获得晶片[机师A.I.]",icon="image_decision",value={{chip={count=1,pool={32}}}},cardId=0,chipId=4012,itemId=0},
    [157] = {id=3015,title="获得晶片[新型能源α]",icon="image_decision",value={{chip={count=1,pool={33}}}},cardId=0,chipId=4012,itemId=0},
    [158] = {id=3016,title="获得晶片[新型能源β]",icon="image_decision",value={{chip={count=1,pool={34}}}},cardId=0,chipId=4012,itemId=0},
    [159] = {id=3017,title="获得晶片[新型能源γ]",icon="image_decision",value={{chip={count=1,pool={35}}}},cardId=0,chipId=4012,itemId=0},
    [160] = {id=3018,title="获得晶片[征服旗标]",icon="image_decision",value={{chip={count=1,pool={36}}}},cardId=0,chipId=4012,itemId=0},
    [161] = {id=3019,title="恢复30CA",icon="image_decision",value={{hp={value=30}}},cardId=0,chipId=0,itemId=0},
    [162] = {id=3020,title="获得晶片[为了成为最强]",icon="image_decision",value={{chip={count=1,pool={37}}}},cardId=0,chipId=4012,itemId=0},
    [163] = {id=3021,title="获得晶片[跨越最强的理想]",icon="image_decision",value={{chip={count=1,pool={38}}}},cardId=0,chipId=4012,itemId=0},
    [164] = {id=3022,title="获得晶片[跨越安乐的愿望]",icon="image_decision",value={{chip={count=1,pool={39}}}},cardId=0,chipId=4012,itemId=0},
    [165] = {id=3023,title="获得晶片[战术劣势]",icon="image_decision",value={{chip={count=1,pool={40}}}},cardId=0,chipId=4012,itemId=0},
    [166] = {id=3024,title="获得晶片[遭受突袭]",icon="image_decision",value={{chip={count=1,pool={41}}}},cardId=0,chipId=4012,itemId=0},
    [167] = {id=3025,title="星核-20",icon="image_decision",value={{gold={count=-20}}},cardId=0,chipId=0,itemId=0},
    [168] = {id=3026,title="获得卡牌[连击组件+]。",icon="image_decision",value={{card={count=1,pool={121}}}},cardId=2034,chipId=0,itemId=0},
    [169] = {id=3027,title="获得卡牌[薮猫]。",icon="image_decision",value={{card={count=1,pool={122}}}},cardId=10050,chipId=0,itemId=0},
    [170] = {id=3028,title="获得卡牌[特里格拉夫]。",icon="image_decision",value={{card={count=1,pool={123}}}},cardId=10180,chipId=0,itemId=0},
    [171] = {id=3029,title="获得晶片[核心过载]",icon="image_decision",value={{chip={count=1,pool={51}}}},cardId=0,chipId=4030,itemId=0},
    [172] = {id=3030,title="获得晶片[结构循环算法]",icon="image_decision",value={{chip={count=1,pool={52}}}},cardId=0,chipId=4029,itemId=0},
    [173] = {id=3031,title="获得晶片[精英支援]",icon="image_decision",value={{chip={count=1,pool={53}}}},cardId=0,chipId=4011,itemId=0},
    [174] = {id=3032,title="获得晶片[末端情报收集]",icon="image_decision",value={{chip={count=1,pool={54}}}},cardId=0,chipId=4001,itemId=0},
    [175] = {id=3033,title="失去15CA",icon="image_decision",value={{hp={value=-15}}},cardId=0,chipId=0,itemId=0},
    [176] = {id=3034,title="失去3CA",icon="image_decision",value={{hp={value=-3}}},cardId=0,chipId=0,itemId=0},
    [177] = {id=3035,title="获得晶片[孢子覆膜]",icon="image_decision",value={{chip={count=1,pool={60}}}},cardId=0,chipId=4056,itemId=0},
    [178] = {id=3036,title="获得晶片[反物质锚]",icon="image_decision",value={{chip={count=1,pool={61}}}},cardId=0,chipId=4057,itemId=0},
    [179] = {id=3037,title="获得晶片[古代协议]",icon="image_decision",value={{chip={count=1,pool={62}}}},cardId=0,chipId=4058,itemId=0},
    [180] = {id=3038,title="获得晶片[富氧虹吸装置]",icon="image_decision",value={{chip={count=1,pool={63}}}},cardId=0,chipId=4059,itemId=0},
    [181] = {id=3039,title="获得晶片[歌者卵]",icon="image_decision",value={{chip={count=1,pool={64}}}},cardId=0,chipId=4060,itemId=0},
    [182] = {id=3040,title="星核-30",icon="image_decision",value={{gold={count=-30}}},cardId=0,chipId=0,itemId=0},
    [183] = {id=3041,title="获得晶片[战术协议+]",icon="image_decision",value={{chip={count=1,pool={65}}}},cardId=0,chipId=4053,itemId=0},
    [184] = {id=3042,title="获得晶片[闪击协议+]",icon="image_decision",value={{chip={count=1,pool={66}}}},cardId=0,chipId=4054,itemId=0},
    [185] = {id=3043,title="获得晶片[保护协议+]",icon="image_decision",value={{chip={count=1,pool={67}}}},cardId=0,chipId=4055,itemId=0},
    [186] = {id=3044,title="获得晶片[战术协议]",icon="image_decision",value={{chip={count=1,pool={68}}}},cardId=0,chipId=4064,itemId=0},
    [187] = {id=3045,title="获得晶片[闪击协议]",icon="image_decision",value={{chip={count=1,pool={69}}}},cardId=0,chipId=4065,itemId=0},
    [188] = {id=3046,title="获得晶片[保护协议]",icon="image_decision",value={{chip={count=1,pool={70}}}},cardId=0,chipId=4066,itemId=0},
    [189] = {id=3047,title="获得卡牌[恒星余烬]",icon="image_decision",value={{card={count=1,pool={131}}}},cardId=10412,chipId=0,itemId=0},
    [190] = {id=3048,title="获得卡牌[辐射风暴]",icon="image_decision",value={{card={count=1,pool={132}}}},cardId=10413,chipId=0,itemId=0},
    [191] = {id=3049,title="获得晶片[蜃景]",icon="image_decision",value={{chip={count=1,pool={71}}}},cardId=0,chipId=4061,itemId=0},
    [192] = {id=3050,title="获得晶片[维度坍缩]",icon="image_decision",value={{chip={count=1,pool={72}}}},cardId=0,chipId=4062,itemId=0},
    [193] = {id=3051,title="获得卡牌[疾风连斩]。",icon="image_decision",value={{card={count=1,pool={134}}}},cardId=10308,chipId=0,itemId=0},
    [194] = {id=3052,title="获得一张僚机",icon="image_decision",value={{card={count=3,choose=1,pool={150}}}},cardId=0,chipId=0,itemId=0},
    [195] = {id=3053,title="获得卡牌[海盗老兵]",icon="image_decision",value={{card={count=1,pool={151}}}},cardId=0,chipId=0,itemId=0},
    [196] = {id=3054,title="获得卡牌[海盗统帅]",icon="image_decision",value={{card={count=1,pool={152}}}},cardId=0,chipId=0,itemId=0},
    [197] = {id=3055,title="获得卡牌组1",icon="image_decision",value={{card={count=1,pool={200}}}},cardId=0,chipId=0,itemId=0},
    [198] = {id=3056,title="获得卡牌组1",icon="image_decision",value={{card={count=1,pool={201}}}},cardId=0,chipId=0,itemId=0},
    [199] = {id=3057,title="获得卡牌组1",icon="image_decision",value={{card={count=1,pool={202}}}},cardId=0,chipId=0,itemId=0},
    [200] = {id=3058,title="获得卡牌组2",icon="image_decision",value={{card={count=1,pool={203}}}},cardId=0,chipId=0,itemId=0},
    [201] = {id=3059,title="获得卡牌组2",icon="image_decision",value={{card={count=1,pool={204}}}},cardId=0,chipId=0,itemId=0},
    [202] = {id=3060,title="获得卡牌组2",icon="image_decision",value={{card={count=1,pool={205}}}},cardId=0,chipId=0,itemId=0},
    [203] = {id=3061,title="获得卡牌组3",icon="image_decision",value={{card={count=1,pool={206}}}},cardId=0,chipId=0,itemId=0},
    [204] = {id=3062,title="获得卡牌组3",icon="image_decision",value={{card={count=1,pool={207}}}},cardId=0,chipId=0,itemId=0},
    [205] = {id=3063,title="获得卡牌组3",icon="image_decision",value={{card={count=1,pool={208}}}},cardId=0,chipId=0,itemId=0},
    [206] = {id=3064,title="获得晶片[补充装甲]",icon="image_decision",value={{chip={count=1,pool={300}}}},cardId=0,chipId=4099,itemId=0},
    [207] = {id=3065,title="获得一张随机海盗卡牌",icon="image_decision",value={{card={count=1,pool={116}}}},cardId=0,chipId=0,itemId=0},
    [208] = {id=3066,title="获得一张随机商会卡牌",icon="image_decision",value={{card={count=1,pool={114}}}},cardId=0,chipId=0,itemId=0},
    [209] = {id=3067,title="获得一张随机星骸卡牌",icon="image_decision",value={{card={count=1,pool={210}}}},cardId=0,chipId=0,itemId=0},
    [210] = {id=3068,title="获得晶片[补充装甲+]",icon="image_decision",value={{chip={count=1,pool={301}}}},cardId=0,chipId=4098,itemId=0},
    [211] = {id=3069,title="获得晶片[装甲损伤]",icon="image_decision",value={{chip={count=1,pool={302},force=1}}},cardId=0,chipId=4097,itemId=0},
    [212] = {id=3070,title="获得晶片[测试打折]",icon="image_decision",value={{chip={count=1,pool={303},force=1}}},cardId=0,chipId=1000,itemId=0},
    [213] = {id=3071,title="失去20CA",icon="image_decision",value={{hp={value=-20}}},cardId=0,chipId=0,itemId=0},
    [214] = {id=3072,title="星核-30",icon="image_decision",value={{gold={count=-30}}},cardId=0,chipId=0,itemId=0},
    [215] = {id=3073,title="获得卡牌[厄运]",icon="image_decision",value={{card={count=1,pool={222},force=1}}},cardId=10728,chipId=0,itemId=0},
    [216] = {id=3074,title="获得一张卡牌[通用act_reward中更换]",icon="image_decision",value={{card={count=1,pool={1}}}},cardId=0,chipId=0,itemId=0},
    [217] = {id=3075,title="获得一张白矮星卡牌",icon="image_decision",value={{card={count=1,pool={70,802},force=1}}},cardId=0,chipId=0,itemId=0},
    [218] = {id=3076,title="获得一张猎户座卡牌",icon="image_decision",value={{card={count=1,pool={72,802},force=1}}},cardId=0,chipId=0,itemId=0},
    [219] = {id=3077,title="获得一张薮猫卡牌",icon="image_decision",value={{card={count=1,pool={73,802},force=1}}},cardId=0,chipId=0,itemId=0},
    [220] = {id=3078,title="获得随机一张高级卡牌",icon="image_decision",value={{card={count=1,pool={10005}}}},cardId=0,chipId=0,itemId=0},
    [221] = {id=3079,title="获得一枚初始晶片",icon="image_decision",value={{chip={count=3,choose=1,pool={500}}}},cardId=0,chipId=0,itemId=0},
    [222] = {id=3080,title="获得随机初始晶片",icon="image_decision",value={{chip={count=1,pool={500},force=1}}},cardId=0,chipId=4097,itemId=0},
    [223] = {id=3081,title="星核+90",icon="image_decision",value={{gold={count=90}}},cardId=0,chipId=0,itemId=0},
    [224] = {id=3082,title="清理卡组",icon="image_decision",value={{cardClear={}}},cardId=0,chipId=0,itemId=0},
    [225] = {id=3083,title="复制三次卡组",icon="image_decision",value={{cardCopy={times=3}}},cardId=0,chipId=0,itemId=0},
    [226] = {id=3084,title="获得一张其他机体高级卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={212}}}},cardId=0,chipId=0,itemId=0},
    [227] = {id=3085,title="获得一张卡牌[通用act_reward中更换]",icon="image_decision",value={{card={count=1,pool={1},countFill=12}}},cardId=0,chipId=0,itemId=0},
    [228] = {id=3086,title="获得一张白矮星卡牌到12张",icon="image_decision",value={{card={pool={70},countFill=12}}},cardId=0,chipId=0,itemId=0},
    [229] = {id=3087,title="获得一张猎户座卡牌到12张",icon="image_decision",value={{card={pool={72},countFill=12}}},cardId=0,chipId=0,itemId=0},
    [230] = {id=3088,title="获得一张薮猫卡牌到12张",icon="image_decision",value={{card={pool={73},countFill=12}}},cardId=0,chipId=0,itemId=0},
    [231] = {id=3089,title="海盗1",icon="image_decision",value={{card={count=1,pool={501}}}},cardId=0,chipId=0,itemId=0},
    [232] = {id=3090,title="海盗2",icon="image_decision",value={{card={count=1,pool={502}}}},cardId=0,chipId=0,itemId=0},
    [233] = {id=3091,title="海盗3",icon="image_decision",value={{card={count=1,pool={503}}}},cardId=0,chipId=0,itemId=0},
    [234] = {id=3092,title="海盗4",icon="image_decision",value={{card={count=1,pool={504}}}},cardId=0,chipId=0,itemId=0},
    [235] = {id=3093,title="海盗5",icon="image_decision",value={{card={count=1,pool={505}}}},cardId=0,chipId=0,itemId=0},
    [236] = {id=3094,title="海盗6",icon="image_decision",value={{card={count=1,pool={506}}}},cardId=0,chipId=0,itemId=0},
    [237] = {id=3095,title="海盗7",icon="image_decision",value={{card={count=1,pool={507}}}},cardId=0,chipId=0,itemId=0},
    [238] = {id=3096,title="商会1",icon="image_decision",value={{card={count=1,pool={508}}}},cardId=0,chipId=0,itemId=0},
    [239] = {id=3097,title="商会2",icon="image_decision",value={{card={count=1,pool={509}}}},cardId=0,chipId=0,itemId=0},
    [240] = {id=3098,title="商会3",icon="image_decision",value={{card={count=1,pool={510}}}},cardId=0,chipId=0,itemId=0},
    [241] = {id=3099,title="商会4",icon="image_decision",value={{card={count=1,pool={511}}}},cardId=0,chipId=0,itemId=0},
    [242] = {id=3100,title="商会5",icon="image_decision",value={{card={count=1,pool={512}}}},cardId=0,chipId=0,itemId=0},
    [243] = {id=3101,title="商会6",icon="image_decision",value={{card={count=1,pool={513}}}},cardId=0,chipId=0,itemId=0},
    [244] = {id=3102,title="商会7",icon="image_decision",value={{card={count=1,pool={514}}}},cardId=0,chipId=0,itemId=0},
    [245] = {id=3103,title="星骸1",icon="image_decision",value={{card={count=1,pool={515}}}},cardId=0,chipId=0,itemId=0},
    [246] = {id=3104,title="星骸2",icon="image_decision",value={{card={count=1,pool={516}}}},cardId=0,chipId=0,itemId=0},
    [247] = {id=3105,title="星骸3",icon="image_decision",value={{card={count=1,pool={517}}}},cardId=0,chipId=0,itemId=0},
    [248] = {id=3106,title="星骸4",icon="image_decision",value={{card={count=1,pool={518}}}},cardId=0,chipId=0,itemId=0},
    [249] = {id=3107,title="星骸5",icon="image_decision",value={{card={count=1,pool={519}}}},cardId=0,chipId=0,itemId=0},
    [250] = {id=3108,title="星骸6",icon="image_decision",value={{card={count=1,pool={520}}}},cardId=0,chipId=0,itemId=0},
    [251] = {id=3109,title="星骸7",icon="image_decision",value={{card={count=1,pool={521}}}},cardId=0,chipId=0,itemId=0},
    [252] = {id=3110,title="立即抵达第一层的最终节点。",icon="image_decision",value={{mapMove={id=230082}}},cardId=0,chipId=0,itemId=0},
    [253] = {id=3111,title="获得一张高级卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={10005}}}},cardId=0,chipId=0,itemId=0},
    [254] = {id=3112,title="-10生命上限",icon="image_decision",value={{maxHp={value=-10}}},cardId=0,chipId=0,itemId=0},
    [255] = {id=3113,title="+20生命上限",icon="image_decision",value={{maxHp={value=20}}},cardId=0,chipId=0,itemId=0},
    [256] = {id=3114,title="+10生命上限",icon="image_decision",value={{maxHp={value=10}}},cardId=0,chipId=0,itemId=0},
    [257] = {id=3115,title="立即抵达第一层的最终节点。（短战役）",icon="image_decision",value={{mapMove={id=30052}}},cardId=0,chipId=0,itemId=0},
    [258] = {id=3116,title="获得一枚晶片（白洞）",icon="image_decision",value={{chip={count=2,choose=1,pool={508}}}},cardId=0,chipId=0,itemId=0},
    [259] = {id=3117,title="获得道具[三重支援]",icon="image_decision",value={{battleItem={id=3026, count=1}}},cardId=0,chipId=0,itemId=3026},
    [260] = {id=3118,title="获得卡牌组1",icon="image_decision",value={{card={count=1,pool={200},notice=0}}},cardId=0,chipId=0,itemId=0},
    [261] = {id=3119,title="获得卡牌组1",icon="image_decision",value={{card={count=1,pool={201},notice=0}}},cardId=0,chipId=0,itemId=0},
    [262] = {id=3120,title="获得卡牌组1",icon="image_decision",value={{card={count=1,pool={202},notice=0}}},cardId=0,chipId=0,itemId=0},
    [263] = {id=3121,title="星核-9999",icon="image_decision",value={{gold={count=-9999}}},cardId=0,chipId=0,itemId=0},
    [264] = {id=3122,title="获得晶片[主炮受损]",icon="image_decision",value={{chip={count=1,pool={509}}}},cardId=0,chipId=5109,itemId=0},
    [265] = {id=3123,title="获得晶片[中枢磨损]",icon="image_decision",value={{chip={count=1,pool={510}}}},cardId=0,chipId=5110,itemId=0},
    [266] = {id=3124,title="获得晶片[缓启动]",icon="image_decision",value={{chip={count=1,pool={511}}}},cardId=0,chipId=5111,itemId=0},
    [267] = {id=3125,title="获得晶片[装甲薄弱]",icon="image_decision",value={{chip={count=1,pool={512}}}},cardId=0,chipId=5112,itemId=0},
    [268] = {id=3126,title="获得晶片[副炮损伤]",icon="image_decision",value={{chip={count=1,pool={513}}}},cardId=0,chipId=5113,itemId=0},
    [269] = {id=3127,title="获得晶片[故障引擎]",icon="image_decision",value={{chip={count=1,pool={514}}}},cardId=0,chipId=5114,itemId=0},
    [270] = {id=3128,title="获得晶片[高速回收]",icon="image_decision",value={{chip={count=1,pool={515}}}},cardId=0,chipId=5115,itemId=0},
    [271] = {id=3129,title="获得一张晶片",icon="image_decision",value={{chip={count=3,choose=1,pool={100},force=1}}},cardId=0,chipId=0,itemId=0},
    [272] = {id=3130,title="随机预期删除一张卡牌",icon="image_decision",value={{randomDel = {count = 1}}},cardId=0,chipId=0,itemId=0},
    [273] = {id=3131,title="恢复15CA",icon="image_decision",value={{hp={value=15}}},cardId=0,chipId=0,itemId=0},
    [274] = {id=3132,title="获得卡牌[薮猫]。",icon="image_decision",value={{card={count=1,pool={122}}}},cardId=10050,chipId=0,itemId=0},
    [275] = {id=3133,title="获得卡牌[特里格拉夫]。",icon="image_decision",value={{card={count=1,pool={123}}}},cardId=10180,chipId=0,itemId=0},
    [276] = {id=3134,title="获得一张僚机",icon="image_decision",value={{card={count=3,choose=1,pool={74}}}},cardId=0,chipId=0,itemId=0},
    [277] = {id=3135,title="获得一张僚机",icon="image_decision",value={{card={count=3,choose=1,pool={75}}}},cardId=0,chipId=0,itemId=0},
    [278] = {id=3136,title="获得一张僚机",icon="image_decision",value={{card={count=3,choose=1,pool={76}}}},cardId=0,chipId=0,itemId=0},
    [279] = {id=3137,title="获得一张僚机",icon="image_decision",value={{card={count=3,choose=1,pool={77}}}},cardId=0,chipId=0,itemId=0},
    [280] = {id=3138,title="获得一张僚机",icon="image_decision",value={{card={count=3,choose=1,pool={78}}}},cardId=0,chipId=0,itemId=0},
    [281] = {id=3139,title="获得一张特殊卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={220}}}},cardId=0,chipId=0,itemId=0},
    [282] = {id=3140,title="获得一张特殊卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={221}}}},cardId=0,chipId=0,itemId=0},
    [283] = {id=3141,title="获得一张特殊卡牌",icon="image_decision",value={{card={count=3,choose=1,pool={222}}}},cardId=0,chipId=0,itemId=0},
    [284] = {id=3142,title="获得一张僚机",icon="image_decision",value={{card={count=3,choose=1,pool={300}}}},cardId=0,chipId=0,itemId=0},
    [285] = {id=3143,title="",icon="image_decision",value={{mapMove={node=3200}},{gold={count=200}}},cardId=0,chipId=0,itemId=0},
    [286] = {id=3144,title="+5生命上限",icon="image_decision",value={{maxHp={value=5}}},cardId=0,chipId=0,itemId=0},
    [287] = {id=3145,title="获得一张晶片",icon="image_decision",value={{chip={count=3,choose=1,pool={101},force=1}}},cardId=0,chipId=0,itemId=0},
    [288] = {id=3146,title="获得200星核",icon="image_decision",value={{gold={count=200}}},cardId=0,chipId=0,itemId=0},
    [289] = {id=3147,title="获得一个晶片",icon="image_decision",value={{chip={count=1,pool={801}}}},cardId=0,chipId=0,itemId=0},
    [290] = {id=3148,title="获得晶片[会员服务]",icon="image_decision",value={{chip={count=1,pool={802}}}},cardId=0,chipId=4108,itemId=0},
    [291] = {id=3149,title="获得晶片[会员折扣]",icon="image_decision",value={{chip={count=1,pool={803}}}},cardId=0,chipId=4109,itemId=0},
    [292] = {id=1004,title="获得40星核",icon="image_decision",value={{gold={count=40}}},cardId=0,chipId=0,itemId=0},
    [293] = {id=3150,title="获得卡牌[遗憾]",icon="image_decision",value={{card={count=1,pool={112}}}},cardId=2743,chipId=0,itemId=0},
    [294] = {id=3152,title="获得卡牌[辐射风暴]",icon="image_decision",value={{card={count=1,pool={132}}}},cardId=10413,chipId=0,itemId=0},
    [295] = {id=3151,title="获得50星核",icon="image_decision",value={{gold={count=50}}},cardId=0,chipId=0,itemId=0},
    [296] = {id=3160,title="获得一个随机晶片",icon="image_decision",value={{chip={count=1,pool={20}}}},cardId=0,chipId=0,itemId=0},
    [297] = {id=4104,title="获得防御端卡牌",icon="image_decision",value={{card={count=1,pool={801}}}},cardId=0,chipId=0,itemId=0},
    [298] = {id=4105,title="获得基础卡牌",icon="image_decision",value={{card={count=1,pool={801}}}},cardId=0,chipId=0,itemId=0},
    [299] = {id=4110,title="获得随机卡牌",icon="image_decision",value={{randomCard={count=1,pool={70,72,73}}}},cardId=0,chipId=0,itemId=0},
    [300] = {id=4106,title="债务欠条",icon="image_decision",value={{card={count=1,pool={900}}}},cardId=11029,chipId=0,itemId=0},
    [301] = {id=4108,title="获得150星核",icon="",value={{gold={count=150}}},cardId=0,chipId=0,itemId=0},
    [302] = {id=2351,title="获得随机3枚晶片",icon="image_decision",value={{chip={count=3,pool={20}}}},cardId=0,chipId=0,itemId=0},
    [303] = {id=1002,title="获得80星核",icon="image_decision",value={{gold={count=80}}},cardId=0,chipId=0,itemId=0},
    [304] = {id=10003,title="获得一次卡牌奖励",icon="image_decision",value={{card={count=3,choose=1,pool={10003}}}},cardId=0,chipId=0,itemId=0},
    [305] = {id=10004,title="获得一次卡牌奖励",icon="image_decision",value={{card={count=3,choose=1,pool={10004}}}},cardId=0,chipId=0,itemId=0},
    [306] = {id=10005,title="获得一次卡牌奖励",icon="image_decision",value={{card={count=3,choose=1,pool={10005}}}},cardId=0,chipId=0,itemId=0},
    [307] = {id=3161,title="获得一张晶片",icon="image_decision",value={{chip={count=3,choose=1,pool={804}}}},cardId=0,chipId=0,itemId=0},
    [308] = {id=5101,title="",icon="",value={{flag={id="bet_base", value=50}}},cardId=0,chipId=0,itemId=0},
    [309] = {id=5102,title="",icon="",value={{flag={id="bet_base", value=100}}},cardId=0,chipId=0,itemId=0},
    [310] = {id=5104,title="",icon="",value={{flag={id="bet_multiplier", value=1}}},cardId=0,chipId=0,itemId=0},
    [311] = {id=5105,title="",icon="",value={{flag={id="bet_multiplier", value={A=0,B={flag="bet_multiplier"},C=2}}}},cardId=0,chipId=0,itemId=0},
    [312] = {id=5111,title="",icon="",value={{replaceNode={nodeId=510303}}},cardId=0,chipId=0,itemId=0},
    [313] = {id=5112,title="",icon="",value={{replaceNode={nodeId=510306}}},cardId=0,chipId=0,itemId=0},
    [314] = {id=5121,title="",icon="",value={{replaceNode={nodeId=510304}}},cardId=0,chipId=0,itemId=0},
    [315] = {id=5131,title="",icon="",value={{replaceNode={nodeId=510305}}},cardId=0,chipId=0,itemId=0},
    [316] = {id=5200,title="",icon="",value={
    {gold={count={A=0,B={flag="bet_base"},C={flag="bet_multiplier"}}}},
    {flag={id="bet_base", clear=true}},
    {flag={id="bet_multiplier", clear=true}}
},cardId=0,chipId=0,itemId=0},
    [317] = {id=5201,title="",icon="",value={
    {flag={id="bet_base", clear=true}},
    {flag={id="bet_multiplier", clear=true}},
    {replaceNode={nodeId=510306}}
},cardId=0,chipId=0,itemId=0},
    [318] = {id=5202,title="",icon="",value={{battleItem={id=3025, count=1}}},cardId=0,chipId=0,itemId=0},
    [319] = {id=5000,title="",icon="image_decision",value={{mapMove={node=5102}}},cardId=0,chipId=0,itemId=0},
    [320] = {id=5001,title="获得100星核",icon="image_decision",value={{gold={count=100}}},cardId=0,chipId=0,itemId=0},
    [321] = {id=6001,title="获得机师[奥斯陆]",icon="image_decision",value={{hero={id=21062}}},cardId=21062,chipId=0,itemId=0},
    [322] = {id=6002,title="获得机师[铁木]",icon="image_decision",value={{hero={id=21063}}},cardId=21063,chipId=0,itemId=0},
    [323] = {id=6003,title="获得机师[夏洛]",icon="image_decision",value={{hero={id=21064}}},cardId=21064,chipId=0,itemId=0},
    [324] = {id=6004,title="获得机师[商人·机师支援]",icon="image_decision",value={{hero={id=21070}}},cardId=21070,chipId=0,itemId=0},
    [325] = {id=6005,title="获得机师[商人·白矮星]",icon="image_decision",value={{hero={id=21071}}},cardId=21071,chipId=0,itemId=0},
    [326] = {id=6006,title="获得机师[商人·猎户座]",icon="image_decision",value={{hero={id=21072}}},cardId=21072,chipId=0,itemId=0},
    [327] = {id=6007,title="获得机师[商人·薮猫]",icon="image_decision",value={{hero={id=21073}}},cardId=21073,chipId=0,itemId=0},
    [328] = {id=6008,title="获得机师[奥斯陆]",icon="image_decision",value={{hero={id=21078}}},cardId=21078,chipId=0,itemId=0},
    [329] = {id=6009,title="获得机师[希尔达]",icon="image_decision",value={{hero={id=21079}}},cardId=21079,chipId=0,itemId=0},
    [330] = {id=6010,title="获得机师[玩家（男）]",icon="image_decision",value={{hero={id=21080}}},cardId=21080,chipId=0,itemId=0},
    [331] = {id=6011,title="获得机师[玩家（女）]",icon="image_decision",value={{hero={id=21069}}},cardId=21069,chipId=0,itemId=0},
    [332] = {id=6012,title="返回主线路。",icon="image_decision",value={{mapMove={id=232082}}},cardId=0,chipId=0,itemId=0},
    [333] = {id=10006,title="获得道具[新星支援]",icon="image_decision",value={{battleItem={id=3027, count=1}}},cardId=0,chipId=0,itemId=3027},
    [334] = {id=10007,title="获得道具[猎户支援]",icon="image_decision",value={{battleItem={id=3028, count=1}}},cardId=0,chipId=0,itemId=3028},
    [335] = {id=10008,title="获得道具[剑圣支援]",icon="image_decision",value={{battleItem={id=3029, count=1}}},cardId=0,chipId=0,itemId=3029},
    [336] = {id=6013,title="获得机师[另一位邮差]+标准无人机×4",icon="image_decision",value={{hero={id=21085}},{card={id=2025,count=4}}},cardId=21085,chipId=0,itemId=0},
    [337] = {id=6014,title="获得机师[另一位邮差]+重锤武装×2+长矛武装×2",icon="image_decision",value={{hero={id=21086}},{card={id=7617,count=2}},{card={id=7619,count=2}}},cardId=21086,chipId=0,itemId=0},
    [338] = {id=6015,title="获得机师[另一位邮差]+影隼侦察机α×2+利爪突击机α×2",icon="image_decision",value={{hero={id=21087}},{card={id=10370,count=2}},{card={id=10378,count=2}}},cardId=21087,chipId=0,itemId=0},
    [339] = {id=6016,title="获得机师[另一位邮差]+炮击×4",icon="image_decision",value={{hero={id=21088}},{card={id=2012,count=4}}},cardId=21088,chipId=0,itemId=0},
    [340] = {id=6017,title="获得机师[另一位邮差]+射击×4",icon="image_decision",value={{hero={id=21089}},{card={id=2127,count=4}}},cardId=21089,chipId=0,itemId=0},
    [341] = {id=6018,title="获得机师[另一位邮差]+奔袭势×2",icon="image_decision",value={{hero={id=21090}},{card={id=10316,count=2}}},cardId=21090,chipId=0,itemId=0},
}
local config = {}
local config_loaded = {}
local config_languages = {}

local function config_load(index)
    if index == nil then return nil end
    if config_loaded[index] then return config[index] end
    local source = config_source[index]
    if source == nil then return nil end
    local rowLanguage = config_languages[index] or language
    local data = ConfigRowRuntime.Build(source,config_runtime_schema,"reward_def",rowLanguage)
    config[index] = data
    config_loaded[index] = true
    return data
end

function reward_def.config_index(index)
    return config_load(index)
end

function reward_def.config_set(index,data)
    config[index] = data
    config_loaded[index] = true
end

function reward_def.config_num()
    return config_num
end

local config_id =
{
    [4001]=1,[4002]=2,[4003]=3,[4004]=4,[4005]=5,[4006]=6,[4007]=7,[4008]=8,[4101]=9,[4102]=10,[1006]=11,[1007]=12,[1008]=13,[1009]=14,[1010]=15,[1100]=16,[1101]=17,[1102]=18,[1103]=19,[1104]=20,[1105]=21,[1106]=22,[1107]=23,[1108]=24,[2002]=25,[2003]=26,[2004]=27,[2005]=28,[1201]=29,[1202]=30,[1203]=31,[1204]=32,[1303]=33,[1304]=34,[1501]=35,[1502]=36,[1503]=37,[1504]=38,[1505]=39,[1506]=40,[1507]=41,[1508]=42,[1509]=43,[1510]=44,[2100]=45,[2101]=46,[2102]=47,[2103]=48,[2104]=49,[2105]=50,[2106]=51,[2107]=52,[2200]=53,[2201]=54,[2202]=55,[2203]=56,[2204]=57,[2205]=58,[2206]=59,[2108]=60,[2109]=61,[2110]=62,[2111]=63,[2112]=64,[2113]=65,[2114]=66,[2115]=67,[2116]=68,[2117]=69,[2118]=70,[2119]=71,[2120]=72,[2121]=73,[2122]=74,[2123]=75,[2124]=76,[2125]=77,[2126]=78,[2127]=79,[2128]=80,[2130]=81,[2131]=82,[2132]=83,[2133]=84,[2134]=85,[2135]=86,[2136]=87,[2137]=88,[2138]=89,[2139]=90,[2140]=91,[2141]=92,[2142]=93,[2143]=94,[2144]=95,[2145]=96,[2146]=97,[2147]=98,[2148]=99,[2149]=100,[2150]=101,[2151]=102,[2152]=103,[2160]=104,[2161]=105,[2162]=106,[2163]=107,[2164]=108,[2165]=109,[2166]=110,[2167]=111,[2168]=112,[2169]=113,[2170]=114,[2171]=115,[2172]=116,[2173]=117,[2174]=118,[2175]=119,[2176]=120,[2177]=121,[2178]=122,[2179]=123,[2180]=124,[2181]=125,[2182]=126,[2183]=127,[2184]=128,[2185]=129,[2186]=130,[2187]=131,[2188]=132,[2189]=133,[2190]=134,[2191]=135,[2192]=136,[2193]=137,[2194]=138,[2195]=139,[2196]=140,[2197]=141,[3000]=142,[3001]=143,[3002]=144,[3003]=145,[3004]=146,[3005]=147,[3006]=148,[3007]=149,[3008]=150,[3009]=151,[3010]=152,[3011]=153,[3012]=154,[3013]=155,[3014]=156,[3015]=157,[3016]=158,[3017]=159,[3018]=160,[3019]=161,[3020]=162,[3021]=163,[3022]=164,[3023]=165,[3024]=166,[3025]=167,[3026]=168,[3027]=169,[3028]=170,[3029]=171,[3030]=172,[3031]=173,[3032]=174,[3033]=175,[3034]=176,[3035]=177,[3036]=178,[3037]=179,[3038]=180,[3039]=181,[3040]=182,[3041]=183,[3042]=184,[3043]=185,[3044]=186,[3045]=187,[3046]=188,[3047]=189,[3048]=190,[3049]=191,[3050]=192,[3051]=193,[3052]=194,[3053]=195,[3054]=196,[3055]=197,[3056]=198,[3057]=199,[3058]=200,[3059]=201,[3060]=202,[3061]=203,[3062]=204,[3063]=205,[3064]=206,[3065]=207,[3066]=208,[3067]=209,[3068]=210,[3069]=211,[3070]=212,[3071]=213,[3072]=214,[3073]=215,[3074]=216,[3075]=217,[3076]=218,[3077]=219,[3078]=220,[3079]=221,[3080]=222,[3081]=223,[3082]=224,[3083]=225,[3084]=226,[3085]=227,[3086]=228,[3087]=229,[3088]=230,[3089]=231,[3090]=232,[3091]=233,[3092]=234,[3093]=235,[3094]=236,[3095]=237,[3096]=238,[3097]=239,[3098]=240,[3099]=241,[3100]=242,[3101]=243,[3102]=244,[3103]=245,[3104]=246,[3105]=247,[3106]=248,[3107]=249,[3108]=250,[3109]=251,[3110]=252,[3111]=253,[3112]=254,[3113]=255,[3114]=256,[3115]=257,[3116]=258,[3117]=259,[3118]=260,[3119]=261,[3120]=262,[3121]=263,[3122]=264,[3123]=265,[3124]=266,[3125]=267,[3126]=268,[3127]=269,[3128]=270,[3129]=271,[3130]=272,[3131]=273,[3132]=274,[3133]=275,[3134]=276,[3135]=277,[3136]=278,[3137]=279,[3138]=280,[3139]=281,[3140]=282,[3141]=283,[3142]=284,[3143]=285,[3144]=286,[3145]=287,[3146]=288,[3147]=289,[3148]=290,[3149]=291,[1004]=292,[3150]=293,[3152]=294,[3151]=295,[3160]=296,[4104]=297,[4105]=298,[4110]=299,[4106]=300,[4108]=301,[2351]=302,[1002]=303,[10003]=304,[10004]=305,[10005]=306,[3161]=307,[5101]=308,[5102]=309,[5104]=310,[5105]=311,[5111]=312,[5112]=313,[5121]=314,[5131]=315,[5200]=316,[5201]=317,[5202]=318,[5000]=319,[5001]=320,[6001]=321,[6002]=322,[6003]=323,[6004]=324,[6005]=325,[6006]=326,[6007]=327,[6008]=328,[6009]=329,[6010]=330,[6011]=331,[6012]=332,[10006]=333,[10007]=334,[10008]=335,[6013]=336,[6014]=337,[6015]=338,[6016]=339,[6017]=340,[6018]=341
}

function reward_def.config_id(key)
    local index = config_id[key]
    return reward_def.config_index(index)
end

--cost
local cost_num = 23
local cost_schema =
{
    ["id"] = { type = "int" },
    ["value"] = { type = "lua" },
}
local cost_runtime_schema = cost_schema
local cost_source =
{
    [1] = {id=1001,value={gold={count=15}}},
    [2] = {id=1002,value={gold={count=10}}},
    [3] = {id=1003,value={gold={count=20}}},
    [4] = {id=1004,value={card={id=1001,count=1}}},
    [5] = {id=1005,value={gold={count=50}}},
    [6] = {id=1006,value={gold={count=60}}},
    [7] = {id=1007,value={gold={count=30}}},
    [8] = {id=3005,value={hp={count=5}}},
    [9] = {id=3071,value={hp={count=20}}},
    [10] = {id=1008,value={gold={count=40}}},
    [11] = {id=1009,value={gold={count=100}}},
    [12] = {id=2010,value={hp={count=10}}},
    [13] = {id=2020,value={hp={count=20}}},
    [14] = {id=2030,value={hp={count=30}}},
    [15] = {id=2040,value={hp={count=40}}},
    [16] = {id=3010,value={gold={count=10}}},
    [17] = {id=3020,value={gold={count=20}}},
    [18] = {id=3030,value={gold={count=30}}},
    [19] = {id=3040,value={gold={count=40}}},
    [20] = {id=3015,value={hp={count=15}}},
    [21] = {id=3050,value={gold={count=100}}},
    [22] = {id=3059,value={flag={id="bet_base", value={A=0,B={flag="ep_gold"},C=1}}}},
    [23] = {id=3060,value={gold={count={A=0,B={flag="ep_gold"},C=1}}}},
}
local cost = {}
local cost_loaded = {}
local cost_languages = {}

local function cost_load(index)
    if index == nil then return nil end
    if cost_loaded[index] then return cost[index] end
    local source = cost_source[index]
    if source == nil then return nil end
    local rowLanguage = cost_languages[index] or nil
    local data = ConfigRowRuntime.Build(source,cost_runtime_schema,"reward_def",rowLanguage)
    cost[index] = data
    cost_loaded[index] = true
    return data
end

function reward_def.cost_index(index)
    return cost_load(index)
end

function reward_def.cost_set(index,data)
    cost[index] = data
    cost_loaded[index] = true
end

function reward_def.cost_num()
    return cost_num
end

local cost_id =
{
    [1001]=1,[1002]=2,[1003]=3,[1004]=4,[1005]=5,[1006]=6,[1007]=7,[3005]=8,[3071]=9,[1008]=10,[1009]=11,[2010]=12,[2020]=13,[2030]=14,[2040]=15,[3010]=16,[3020]=17,[3030]=18,[3040]=19,[3015]=20,[3050]=21,[3059]=22,[3060]=23
}

function reward_def.cost_id(key)
    local index = cost_id[key]
    return reward_def.cost_index(index)
end

local configSheets =
{
    ["config"] =
    {
        schema = config_schema,
        indexes =
        {
            { indexKey = "id", fields = {"id"}, fieldTypes = {"int"}, group = false },
        },
    },
    ["cost"] =
    {
        schema = cost_schema,
        indexes =
        {
            { indexKey = "id", fields = {"id"}, fieldTypes = {"int"}, group = false },
        },
    },
}

local configSheetRuntimes =
{
    ["config"] =
    {
        getRows = function() return config_source end,
        getLanguages = function() return config_languages end,
        getSchema = function() return config_runtime_schema end,
        publish = function(rows,indexes,schema,languages)
            config_source = rows
            config_runtime_schema = schema or config_schema
            config_languages = languages or {}
            config = {}
            config_loaded = {}
            config_num = #rows
            config_id = indexes["id"] or {}
        end,
    },
    ["cost"] =
    {
        getRows = function() return cost_source end,
        getLanguages = function() return cost_languages end,
        getSchema = function() return cost_runtime_schema end,
        publish = function(rows,indexes,schema,languages)
            cost_source = rows
            cost_runtime_schema = schema or cost_schema
            cost_languages = languages or {}
            cost = {}
            cost_loaded = {}
            cost_num = #rows
            cost_id = indexes["id"] or {}
        end,
    },
}

local function BuildIndexKey(row,fields)
    if #fields == 1 then return row[fields[1]] end
    local values = {}
    for index,fieldName in ipairs(fields) do
        values[index] = tostring(row[fieldName])
    end
    return table.concat(values,"_")
end

local function BuildIndexKeyFromValue(value,fields)
    if #fields == 1 then return value end
    if type(value) ~= "table" or #value ~= #fields then return nil end
    local values = {}
    for index = 1,#fields do values[index] = tostring(value[index]) end
    return table.concat(values,"_")
end

local function ValidateRowsTable(rows)
    if type(rows) ~= "table" then return false,"配置行集合需要 table" end
    local count = 0
    for key in pairs(rows) do
        if type(key) ~= "number" or key < 1 or key % 1 ~= 0 then
            return false,string.format("配置行集合包含无效数组键[%s]",tostring(key))
        end
        count = count + 1
    end
    for index = 1,count do
        if rows[index] == nil then return false,string.format("配置行集合存在空洞[%s]",index) end
    end
    return true
end

local function GetIndexRule(info,installKey)
    local indexKey = nil
    if type(installKey) == "string" then
        indexKey = installKey
    elseif type(installKey) == "table" then
        local valid,err = ValidateRowsTable(installKey)
        if not valid then return nil,err end
        local fields = {}
        for index,fieldName in ipairs(installKey) do
            if type(fieldName) ~= "string" then return nil,string.format("installKey第%s项需要 string",index) end
            fields[index] = fieldName
        end
        indexKey = table.concat(fields,",")
    else
        return nil,string.format("installKey需要 string 或有序字段数组，实际为 %s",type(installKey))
    end
    for _,rule in ipairs(info.indexes) do
        if rule.indexKey == indexKey then return rule end
    end
    return nil,string.format("installKey未匹配现有查询索引[%s]",tostring(indexKey))
end

function reward_def.GetSheetInfo(sheetName)
    return configSheets[sheetName]
end

function reward_def.CaptureState(sheetName)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    return { rows = runtime.getRows(), languages = runtime.getLanguages(), schema = runtime.getSchema() }
end

function reward_def.RestoreState(sheetName,state)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    if type(state) ~= "table" or type(state.rows) ~= "table" or type(state.languages) ~= "table" or type(state.schema) ~= "table" then
        return false,"配置快照无效"
    end
    local indexes,indexErr = reward_def.BuildIndexes(sheetName,state.rows,true,state.schema)
    if indexes == nil then return false,indexErr end
    runtime.publish(state.rows,indexes,state.schema,state.languages)
    return true
end

function reward_def.ValidateRow(sheetName,row,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return false,schemaErr end
    return ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
end

function reward_def.BuildIndexes(sheetName,rows,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    local rowsValid,rowsErr = ValidateRowsTable(rows)
    if not rowsValid then return nil,rowsErr end
    local indexes = {}
    for _,rule in ipairs(info.indexes) do indexes[rule.indexKey] = {} end
    for index,row in ipairs(rows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",index,err) end
        for _,rule in ipairs(info.indexes) do
            local key = BuildIndexKey(row,rule.fields)
            local target = indexes[rule.indexKey]
            if rule.group then
                target[key] = target[key] or {}
                table.insert(target[key],index)
            else
                target[key] = index
            end
        end
    end
    return indexes
end

local function RemoveRowOwners(info,owners,row,rowIndex)
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local key = BuildIndexKey(row,rule.fields)
            local keyOwners = owners[rule.indexKey][key]
            if keyOwners ~= nil then
                for ownerIndex = #keyOwners,1,-1 do
                    if keyOwners[ownerIndex] == rowIndex then table.remove(keyOwners,ownerIndex) end
                end
                if #keyOwners == 0 then owners[rule.indexKey][key] = nil end
            end
        end
    end
end

local function ResolveNewRowConflicts(info,groupRule,rows,languages,newRowIndexes)
    local owners = {}
    local active = {}
    local isNew = {}
    local conflicts = {}
    for _,rowIndex in ipairs(newRowIndexes) do isNew[rowIndex] = true end
    for _,rule in ipairs(info.indexes) do if not rule.group then owners[rule.indexKey] = {} end end
    for rowIndex,row in ipairs(rows) do
        active[rowIndex] = true
        if not isNew[rowIndex] then
            for _,rule in ipairs(info.indexes) do
                if not rule.group then
                    local key = BuildIndexKey(row,rule.fields)
                    local keyOwners = owners[rule.indexKey][key] or {}
                    table.insert(keyOwners,rowIndex)
                    owners[rule.indexKey][key] = keyOwners
                end
            end
        end
    end
    for _,rowIndex in ipairs(newRowIndexes) do
        local row = rows[rowIndex]
        local removeIndexes = {}
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                local keyOwners = owners[rule.indexKey][key]
                if keyOwners ~= nil then
                    for _,oldIndex in ipairs(keyOwners) do
                        if active[oldIndex] then
                            removeIndexes[oldIndex] = true
                            table.insert(conflicts,{
                                indexKey = rule.indexKey,
                                key = key,
                                oldIndex = oldIndex,
                                newIndex = rowIndex,
                                oldGroupKey = BuildIndexKey(rows[oldIndex],groupRule.fields),
                                newGroupKey = BuildIndexKey(row,groupRule.fields),
                            })
                        end
                    end
                end
            end
        end
        for oldIndex in pairs(removeIndexes) do
            active[oldIndex] = false
            RemoveRowOwners(info,owners,rows[oldIndex],oldIndex)
        end
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                owners[rule.indexKey][key] = {rowIndex}
            end
        end
    end
    local result = {}
    local resultLanguages = {}
    for rowIndex,row in ipairs(rows) do
        if active[rowIndex] then
            table.insert(result,row)
            table.insert(resultLanguages,languages[rowIndex] or false)
        end
    end
    return result,resultLanguages,conflicts
end

local function CollectAppendConflicts(info,currentCount,rows)
    local conflicts = {}
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local latest = {}
            for rowIndex,row in ipairs(rows) do
                local key = BuildIndexKey(row,rule.fields)
                local oldIndex = latest[key]
                if rowIndex > currentCount and oldIndex ~= nil then
                    table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=oldIndex,newIndex=rowIndex})
                end
                latest[key] = rowIndex
            end
        end
    end
    return conflicts
end

function reward_def.ApplyBatch(sheetName,batch,allowUnknown,schemaOverride,rowLanguage)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local runtime = configSheetRuntimes[sheetName]
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    if type(batch) ~= "table" then return nil,"配置批次需要 table" end
    for key in pairs(batch) do
        if key ~= "installKey" and key ~= "installValue" and key ~= "operation" and key ~= "rows" then
            return nil,string.format("配置批次包含未知字段[%s]",tostring(key))
        end
    end
    local newRows = batch.rows
    local rowsValid,rowsErr = ValidateRowsTable(newRows)
    if not rowsValid then return nil,rowsErr end
    for rowIndex,row in ipairs(newRows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",rowIndex,err) end
    end
    local warnings = {}
    if #newRows == 0 and batch.installKey == nil then
        return { operation = "append", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} }
    end
    local currentRows = runtime.getRows()
    local currentLanguages = runtime.getLanguages()
    local candidateRows = {}
    local candidateLanguages = {}
    local newRowIndexes = {}
    if batch.installKey == nil then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"无 installKey 批次不能声明 installValue/operation" end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
        end
        local indexes,indexErr = reward_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        local conflicts = CollectAppendConflicts(info,#currentRows,candidateRows)
        if #conflicts > 0 then table.insert(warnings,string.format("无 installKey 追加产生 %s 个普通查询键冲突；后写结果生效",#conflicts)) end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "append", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    local rule,ruleErr = GetIndexRule(info,batch.installKey)
    if rule == nil then return nil,ruleErr end
    if not rule.group then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"普通 upsert 不能声明 installValue/operation" end
        if #newRows == 0 then return { operation = "upsert", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} } end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        local conflicts = {}
        for _,newRow in ipairs(newRows) do
            local key = BuildIndexKey(newRow,rule.fields)
            local matched = {}
            for rowIndex,oldRow in ipairs(candidateRows) do
                if BuildIndexKey(oldRow,rule.fields) == key then table.insert(matched,rowIndex) end
            end
            if #matched > 1 then return nil,string.format("安装身份歧义[index:%s][key:%s][rows:%s]",rule.indexKey,tostring(key),table.concat(matched,",")) end
            if #matched == 1 then
                table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=matched[1],newIndex=matched[1]})
                candidateRows[matched[1]] = newRow
                candidateLanguages[matched[1]] = rowLanguage or false
            else
                table.insert(candidateRows,newRow)
                table.insert(candidateLanguages,rowLanguage or false)
            end
        end
        local indexes,indexErr = reward_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "upsert", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    if batch.installValue == nil then return nil,"组批次缺少 installValue" end
    local groupKey = BuildIndexKeyFromValue(batch.installValue,rule.fields)
    if groupKey == nil then return nil,"installValue 与组查询字段不匹配" end
    local operation = batch.operation or "replace"
    if operation ~= "replace" and operation ~= "append" then return nil,string.format("无效组操作[%s]",tostring(operation)) end
    for rowIndex,row in ipairs(newRows) do
        local rowGroupKey = BuildIndexKey(row,rule.fields)
        if rowGroupKey ~= groupKey then return nil,string.format("组键不一致[目标:%s][第%s行:%s]",tostring(groupKey),rowIndex,tostring(rowGroupKey)) end
    end
    if operation == "append" and #newRows == 0 then return { operation = operation, groupKey = groupKey, rows = runtime.getRows(), warnings = {"空组 append 未修改配置"}, conflicts = {} } end
    local firstGroupIndex = nil
    local oldGroupCount = 0
    if operation == "replace" then
        for rowIndex,row in ipairs(currentRows) do
            if BuildIndexKey(row,rule.fields) == groupKey then
                oldGroupCount = oldGroupCount + 1
                if firstGroupIndex == nil then firstGroupIndex = #candidateRows + 1 end
            else
                table.insert(candidateRows,row)
                table.insert(candidateLanguages,currentLanguages[rowIndex] or false)
            end
        end
        local insertIndex = firstGroupIndex or (#candidateRows + 1)
        for offset,row in ipairs(newRows) do
            table.insert(candidateRows,insertIndex + offset - 1,row)
            table.insert(candidateLanguages,insertIndex + offset - 1,rowLanguage or false)
        end
        for offset = 1,#newRows do table.insert(newRowIndexes,insertIndex + offset - 1) end
    else
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
            table.insert(newRowIndexes,#candidateRows)
        end
    end
    if operation == "replace" and oldGroupCount == 0 and #newRows == 0 then table.insert(warnings,"清空不存在的组未修改配置") end
    local resultRows,resultLanguages,conflicts = ResolveNewRowConflicts(info,rule,candidateRows,candidateLanguages,newRowIndexes)
    local indexes,indexErr = reward_def.BuildIndexes(sheetName,resultRows,allowUnknown,schemaOverride)
    if indexes == nil then return nil,indexErr end
    runtime.publish(resultRows,indexes,schema,resultLanguages)
    return { operation = operation, groupKey = groupKey, rows = resultRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
end

local sheetFunc = 
{
    ["config"] = 
    {
        ["index"] = "config_index",
        ["@num"] = "config_num",
        ["@set"] = "config_set",
        ["id"] = "config_id",
    },

    ["cost"] = 
    {
        ["index"] = "cost_index",
        ["@num"] = "cost_num",
        ["@set"] = "cost_set",
        ["id"] = "cost_id",
    },
}

function reward_def.Get(sheetName,keyIndex,key)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return nil,1 end
    local funName = funcIndexs[keyIndex]
    if not funName then return nil,2 end
    return reward_def[funName](key),nil
end

function reward_def.Set(sheetName,index,data)
    if index == nil then return false end
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return false end
    local funName = funcIndexs["@set"]
    reward_def[funName](index,data)
    return true
end

function reward_def.GetNum(sheetName)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return 0 end
    local funName = funcIndexs["@num"]
    return reward_def[funName]()
end

return reward_def