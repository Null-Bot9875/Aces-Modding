local robot_chain_def = {}
local ConfigRowRuntime = require("common/config/ConfigRowRuntime")

--config
local config_num = 317
local config_schema =
{
    ["id"] = { type = "int" },
    ["type"] = { type = "int" },
    ["poolId"] = { type = "int" },
    ["weight"] = { type = "int" },
    ["useConditions"] = { type = "list", item = { type = "int" } },
    ["cardId"] = { type = "int" },
    ["assetId"] = { type = "string" },
    ["extend"] = { type = "lua" },
}
local config_runtime_schema = config_schema
local config_source =
{
    [1] = {id=1,type=1,poolId=1,weight=30,useConditions={},cardId=8000,assetId="buff_1",extend={}},
    [2] = {id=2,type=1,poolId=1,weight=30,useConditions={},cardId=8001,assetId="buff_1",extend={}},
    [3] = {id=3,type=1,poolId=1,weight=30,useConditions={},cardId=8002,assetId="buff_1",extend={}},
    [4] = {id=4,type=1,poolId=2,weight=50,useConditions={},cardId=8001,assetId="buff_1",extend={}},
    [5] = {id=5,type=1,poolId=3,weight=100,useConditions={},cardId=8002,assetId="buff_1",extend={}},
    [6] = {id=6,type=1,poolId=4,weight=100,useConditions={},cardId=8003,assetId="buff_1",extend={}},
    [7] = {id=7,type=1,poolId=5,weight=20,useConditions={},cardId=8005,assetId="buff_1",extend={}},
    [8] = {id=8,type=1,poolId=6,weight=20,useConditions={},cardId=8006,assetId="buff_1",extend={}},
    [9] = {id=9,type=1,poolId=7,weight=20,useConditions={},cardId=8007,assetId="buff_1",extend={}},
    [10] = {id=10,type=1,poolId=8,weight=20,useConditions={},cardId=6091,assetId="q_mark",extend={}},
    [11] = {id=11,type=1,poolId=9,weight=20,useConditions={},cardId=6092,assetId="e_mark",extend={}},
    [12] = {id=12,type=4,poolId=10,weight=20,useConditions={1016},cardId=6093,assetId="attack_aoe",extend={}},
    [13] = {id=13,type=1,poolId=11,weight=20,useConditions={},cardId=6099,assetId="summon_1",extend={}},
    [14] = {id=14,type=1,poolId=12,weight=20,useConditions={},cardId=6097,assetId="summon_2",extend={}},
    [15] = {id=15,type=1,poolId=13,weight=20,useConditions={},cardId=6096,assetId="summon_1",extend={}},
    [16] = {id=16,type=1,poolId=14,weight=20,useConditions={},cardId=6094,assetId="attack_2",extend={}},
    [17] = {id=17,type=1,poolId=15,weight=20,useConditions={1017},cardId=6025,assetId="attack_1",extend={}},
    [18] = {id=18,type=1,poolId=16,weight=20,useConditions={},cardId=6041,assetId="summon_1",extend={}},
    [19] = {id=19,type=1,poolId=17,weight=20,useConditions={},cardId=6097,assetId="summon_2",extend={}},
    [20] = {id=20,type=1,poolId=18,weight=20,useConditions={},cardId=6064,assetId="buff_1",extend={}},
    [21] = {id=21,type=1,poolId=19,weight=20,useConditions={},cardId=6072,assetId="summon_1",extend={}},
    [22] = {id=22,type=1,poolId=20,weight=20,useConditions={},cardId=6094,assetId="attack_2",extend={}},
    [23] = {id=23,type=1,poolId=21,weight=20,useConditions={},cardId=6099,assetId="summon_1",extend={}},
    [24] = {id=24,type=1,poolId=21,weight=20,useConditions={},cardId=6096,assetId="summon_1",extend={}},
    [25] = {id=25,type=1,poolId=21,weight=20,useConditions={},cardId=6072,assetId="summon_1",extend={}},
    [26] = {id=26,type=1,poolId=22,weight=20,useConditions={},cardId=6099,assetId="summon_1",extend={}},
    [27] = {id=27,type=1,poolId=23,weight=20,useConditions={},cardId=9013,assetId="summon_2",extend={}},
    [28] = {id=28,type=1,poolId=24,weight=20,useConditions={},cardId=9014,assetId="buff_1",extend={}},
    [29] = {id=29,type=1,poolId=25,weight=20,useConditions={},cardId=9015,assetId="attack_1",extend={}},
    [30] = {id=30,type=1,poolId=26,weight=20,useConditions={},cardId=9016,assetId="summon_2",extend={}},
    [31] = {id=31,type=1,poolId=27,weight=20,useConditions={},cardId=9018,assetId="summon_2",extend={}},
    [32] = {id=32,type=4,poolId=29,weight=29,useConditions={},cardId=6071,assetId="attack_1",extend={}},
    [33] = {id=33,type=4,poolId=30,weight=30,useConditions={},cardId=9017,assetId="summon_1",extend={}},
    [34] = {id=34,type=1,poolId=31,weight=31,useConditions={},cardId=8015,assetId="summon_1",extend={}},
    [35] = {id=35,type=1,poolId=32,weight=32,useConditions={},cardId=8016,assetId="summon_1",extend={}},
    [36] = {id=36,type=2,poolId=33,weight=33,useConditions={},cardId=6096,assetId="summon_2",extend={}},
    [37] = {id=37,type=4,poolId=34,weight=34,useConditions={},cardId=9001,assetId="summon_1",extend={}},
    [38] = {id=38,type=2,poolId=35,weight=35,useConditions={},cardId=9004,assetId="attack_1",extend={}},
    [39] = {id=39,type=1,poolId=36,weight=1,useConditions={},cardId=9426,assetId="attack_1",extend={}},
    [40] = {id=40,type=1,poolId=37,weight=1,useConditions={},cardId=9427,assetId="buff_1",extend={}},
    [41] = {id=41,type=1,poolId=38,weight=1,useConditions={},cardId=9428,assetId="attack_1",extend={}},
    [42] = {id=42,type=1,poolId=39,weight=1,useConditions={},cardId=9429,assetId="buff_2",extend={}},
    [43] = {id=43,type=1,poolId=40,weight=1,useConditions={},cardId=9430,assetId="attack_1",extend={}},
    [44] = {id=44,type=1,poolId=41,weight=1,useConditions={},cardId=9431,assetId="buff_2",extend={}},
    [45] = {id=45,type=1,poolId=42,weight=1,useConditions={},cardId=9437,assetId="attack_1",extend={}},
    [46] = {id=46,type=1,poolId=43,weight=1,useConditions={},cardId=9432,assetId="summon_2",extend={}},
    [47] = {id=47,type=1,poolId=44,weight=1,useConditions={},cardId=9433,assetId="attack_1",extend={}},
    [48] = {id=48,type=1,poolId=45,weight=1,useConditions={},cardId=9434,assetId="attack_2",extend={}},
    [49] = {id=49,type=1,poolId=46,weight=1,useConditions={},cardId=9435,assetId="buff_2",extend={}},
    [50] = {id=50,type=1,poolId=47,weight=1,useConditions={},cardId=9436,assetId="attack_1",extend={}},
    [51] = {id=51,type=1,poolId=48,weight=1,useConditions={},cardId=9438,assetId="buff_1",extend={}},
    [52] = {id=52,type=1,poolId=49,weight=1,useConditions={},cardId=9439,assetId="buff_1",extend={}},
    [53] = {id=53,type=1,poolId=50,weight=1,useConditions={},cardId=9440,assetId="buff_1",extend={}},
    [54] = {id=54,type=1,poolId=51,weight=1,useConditions={},cardId=9236,assetId="attack_1",extend={}},
    [55] = {id=55,type=1,poolId=52,weight=1,useConditions={},cardId=9239,assetId="summon_2",extend={}},
    [56] = {id=56,type=1,poolId=53,weight=1,useConditions={},cardId=9434,assetId="attack_2",extend={}},
    [57] = {id=57,type=1,poolId=54,weight=1,useConditions={},cardId=9452,assetId="attack_2",extend={}},
    [58] = {id=58,type=1,poolId=55,weight=1,useConditions={},cardId=9453,assetId="buff_2",extend={}},
    [59] = {id=59,type=1,poolId=56,weight=1,useConditions={},cardId=9469,assetId="attack_1",extend={}},
    [60] = {id=60,type=1,poolId=57,weight=1,useConditions={},cardId=9454,assetId="attack_1",extend={}},
    [61] = {id=61,type=1,poolId=58,weight=1,useConditions={},cardId=9473,assetId="buff_1",extend={}},
    [62] = {id=62,type=1,poolId=59,weight=1,useConditions={},cardId=9471,assetId="buff_1",extend={}},
    [63] = {id=63,type=1,poolId=60,weight=1,useConditions={},cardId=9472,assetId="buff_1",extend={}},
    [64] = {id=64,type=1,poolId=61,weight=1,useConditions={},cardId=9474,assetId="summon_1",extend={}},
    [65] = {id=65,type=1,poolId=61,weight=1,useConditions={},cardId=9475,assetId="summon_1",extend={}},
    [66] = {id=66,type=1,poolId=62,weight=1,useConditions={},cardId=9478,assetId="buff_1",extend={}},
    [67] = {id=67,type=1,poolId=63,weight=1,useConditions={},cardId=9476,assetId="buff_1",extend={}},
    [68] = {id=68,type=1,poolId=64,weight=50,useConditions={},cardId=9484,assetId="summon_1",extend={}},
    [69] = {id=69,type=1,poolId=64,weight=50,useConditions={},cardId=9485,assetId="summon_1",extend={}},
    [70] = {id=70,type=1,poolId=65,weight=1,useConditions={},cardId=9491,assetId="buff_1",extend={}},
    [71] = {id=71,type=1,poolId=66,weight=1,useConditions={},cardId=9492,assetId="summon_1",extend={}},
    [72] = {id=72,type=1,poolId=67,weight=1,useConditions={},cardId=9493,assetId="summon_1",extend={}},
    [73] = {id=73,type=1,poolId=68,weight=1,useConditions={},cardId=9495,assetId="summon_1",extend={}},
    [74] = {id=74,type=1,poolId=69,weight=1,useConditions={},cardId=9496,assetId="summon_1",extend={}},
    [75] = {id=75,type=1,poolId=70,weight=50,useConditions={},cardId=9499,assetId="buff_1",extend={}},
    [76] = {id=76,type=1,poolId=71,weight=50,useConditions={},cardId=9500,assetId="summon_1",extend={}},
    [77] = {id=77,type=1,poolId=72,weight=50,useConditions={},cardId=9501,assetId="summon_1",extend={}},
    [78] = {id=78,type=1,poolId=73,weight=50,useConditions={},cardId=9502,assetId="summon_1",extend={}},
    [79] = {id=79,type=1,poolId=74,weight=50,useConditions={},cardId=9498,assetId="summon_1",extend={}},
    [80] = {id=80,type=1,poolId=75,weight=50,useConditions={},cardId=9719,assetId="summon_1",extend={}},
    [81] = {id=81,type=1,poolId=76,weight=1,useConditions={},cardId=9510,assetId="summon_2",extend={}},
    [82] = {id=82,type=1,poolId=77,weight=1,useConditions={},cardId=9504,assetId="summon_2",extend={}},
    [83] = {id=83,type=1,poolId=78,weight=1,useConditions={},cardId=9507,assetId="summon_1",extend={}},
    [84] = {id=84,type=1,poolId=79,weight=1,useConditions={},cardId=9508,assetId="buff_1",extend={}},
    [85] = {id=85,type=1,poolId=80,weight=50,useConditions={},cardId=9509,assetId="attack_1",extend={}},
    [86] = {id=86,type=1,poolId=81,weight=50,useConditions={},cardId=9853,assetId="summon_1",extend={}},
    [87] = {id=87,type=1,poolId=82,weight=50,useConditions={},cardId=9512,assetId="attack_aoe",extend={}},
    [88] = {id=88,type=1,poolId=83,weight=50,useConditions={},cardId=9513,assetId="summon_1",extend={}},
    [89] = {id=511,type=1,poolId=84,weight=1,useConditions={},cardId=9704,assetId="summon_1",extend={}},
    [90] = {id=512,type=1,poolId=85,weight=1,useConditions={},cardId=9706,assetId="summon_1",extend={}},
    [91] = {id=513,type=1,poolId=85,weight=1,useConditions={},cardId=9702,assetId="summon_1",extend={}},
    [92] = {id=514,type=1,poolId=87,weight=1,useConditions={},cardId=9705,assetId="summon_1",extend={}},
    [93] = {id=515,type=1,poolId=87,weight=1,useConditions={},cardId=9708,assetId="buff_1",extend={}},
    [94] = {id=516,type=1,poolId=89,weight=1,useConditions={},cardId=9707,assetId="summon_1",extend={}},
    [95] = {id=517,type=1,poolId=89,weight=1,useConditions={},cardId=9720,assetId="summon_1",extend={}},
    [96] = {id=518,type=1,poolId=91,weight=1,useConditions={},cardId=9709,assetId="buff_1",extend={}},
    [97] = {id=89,type=1,poolId=92,weight=1,useConditions={},cardId=9710,assetId="buff_1",extend={}},
    [98] = {id=90,type=1,poolId=93,weight=50,useConditions={},cardId=9716,assetId="summon_2",extend={}},
    [99] = {id=91,type=1,poolId=94,weight=50,useConditions={},cardId=9715,assetId="summon_1",extend={}},
    [100] = {id=92,type=1,poolId=95,weight=50,useConditions={},cardId=9717,assetId="summon_2",extend={}},
    [101] = {id=93,type=1,poolId=96,weight=50,useConditions={},cardId=9718,assetId="buff_1",extend={}},
    [102] = {id=94,type=1,poolId=97,weight=1,useConditions={},cardId=9819,assetId="buff_1",extend={}},
    [103] = {id=95,type=1,poolId=98,weight=1,useConditions={},cardId=9820,assetId="buff_1",extend={}},
    [104] = {id=96,type=1,poolId=99,weight=1,useConditions={},cardId=9821,assetId="buff_1",extend={}},
    [105] = {id=97,type=1,poolId=100,weight=50,useConditions={},cardId=9223,assetId="attack_1",extend={}},
    [106] = {id=98,type=1,poolId=101,weight=50,useConditions={},cardId=9221,assetId="attack_1",extend={}},
    [107] = {id=99,type=1,poolId=102,weight=50,useConditions={},cardId=9222,assetId="attack_1",extend={}},
    [108] = {id=100,type=1,poolId=103,weight=1,useConditions={},cardId=9819,assetId="summon_1",extend={}},
    [109] = {id=101,type=1,poolId=104,weight=1,useConditions={},cardId=9820,assetId="buff_1",extend={}},
    [110] = {id=102,type=1,poolId=105,weight=1,useConditions={},cardId=9821,assetId="attack_1",extend={}},
    [111] = {id=103,type=1,poolId=106,weight=50,useConditions={},cardId=9830,assetId="attack_1",extend={}},
    [112] = {id=104,type=1,poolId=107,weight=50,useConditions={},cardId=9831,assetId="attack_1",extend={}},
    [113] = {id=105,type=1,poolId=108,weight=50,useConditions={},cardId=9832,assetId="attack_1",extend={}},
    [114] = {id=106,type=1,poolId=109,weight=50,useConditions={},cardId=9524,assetId="e_mark",extend={}},
    [115] = {id=107,type=1,poolId=110,weight=50,useConditions={},cardId=9833,assetId="q_mark",extend={}},
    [116] = {id=108,type=1,poolId=111,weight=1,useConditions={},cardId=9510,assetId="summon_1",extend={}},
    [117] = {id=109,type=1,poolId=112,weight=1,useConditions={},cardId=9835,assetId="summon_1",extend={}},
    [118] = {id=110,type=1,poolId=113,weight=1,useConditions={},cardId=9858,assetId="summon_1",extend={}},
    [119] = {id=111,type=1,poolId=114,weight=50,useConditions={},cardId=9842,assetId="attack_2",extend={}},
    [120] = {id=112,type=1,poolId=115,weight=1,useConditions={},cardId=9845,assetId="summon_1",extend={}},
    [121] = {id=113,type=1,poolId=116,weight=1,useConditions={},cardId=9846,assetId="summon_1",extend={}},
    [122] = {id=115,type=1,poolId=117,weight=50,useConditions={},cardId=9849,assetId="summon_1",extend={}},
    [123] = {id=116,type=1,poolId=118,weight=1,useConditions={},cardId=9860,assetId="attack_1",extend={}},
    [124] = {id=117,type=1,poolId=119,weight=1,useConditions={},cardId=9854,assetId="summon_2",extend={}},
    [125] = {id=118,type=1,poolId=120,weight=1,useConditions={},cardId=9804,assetId="summon_1",extend={}},
    [126] = {id=119,type=1,poolId=121,weight=1,useConditions={},cardId=9862,assetId="attack_1",extend={}},
    [127] = {id=120,type=1,poolId=122,weight=1,useConditions={},cardId=9916,assetId="summon_1",extend={}},
    [128] = {id=121,type=1,poolId=123,weight=1,useConditions={},cardId=9917,assetId="summon_1",extend={}},
    [129] = {id=122,type=1,poolId=124,weight=1,useConditions={},cardId=9806,assetId="summon_2",extend={}},
    [130] = {id=123,type=1,poolId=131,weight=1,useConditions={},cardId=9863,assetId="attack_2",extend={}},
    [131] = {id=124,type=1,poolId=132,weight=1,useConditions={},cardId=9861,assetId="attack_2",extend={}},
    [132] = {id=125,type=1,poolId=125,weight=50,useConditions={},cardId=9809,assetId="summon_1",extend={}},
    [133] = {id=126,type=1,poolId=126,weight=50,useConditions={},cardId=9812,assetId="buff_1",extend={}},
    [134] = {id=127,type=1,poolId=127,weight=50,useConditions={},cardId=9813,assetId="buff_1",extend={}},
    [135] = {id=128,type=1,poolId=128,weight=50,useConditions={},cardId=9814,assetId="summon_1",extend={}},
    [136] = {id=129,type=1,poolId=129,weight=50,useConditions={},cardId=9816,assetId="summon_1",extend={}},
    [137] = {id=130,type=1,poolId=130,weight=50,useConditions={},cardId=9817,assetId="summon_1",extend={}},
    [138] = {id=131,type=1,poolId=133,weight=1,useConditions={},cardId=9867,assetId="summon_2",extend={}},
    [139] = {id=132,type=1,poolId=134,weight=1,useConditions={},cardId=9868,assetId="buff_1",extend={}},
    [140] = {id=133,type=1,poolId=135,weight=1,useConditions={},cardId=9869,assetId="summon_1",extend={}},
    [141] = {id=134,type=1,poolId=135,weight=1,useConditions={},cardId=9870,assetId="summon_1",extend={}},
    [142] = {id=135,type=1,poolId=135,weight=1,useConditions={},cardId=9871,assetId="summon_1",extend={}},
    [143] = {id=136,type=1,poolId=136,weight=1,useConditions={},cardId=9872,assetId="attack_2",extend={}},
    [144] = {id=137,type=1,poolId=136,weight=1,useConditions={},cardId=9873,assetId="attack_2",extend={}},
    [145] = {id=138,type=1,poolId=136,weight=1,useConditions={},cardId=9874,assetId="attack_2",extend={}},
    [146] = {id=139,type=1,poolId=137,weight=50,useConditions={},cardId=9890,assetId="summon_2",extend={}},
    [147] = {id=140,type=1,poolId=138,weight=50,useConditions={},cardId=9215,assetId="buff_1",extend={}},
    [148] = {id=141,type=1,poolId=139,weight=1,useConditions={},cardId=9804,assetId="summon_1",extend={}},
    [149] = {id=142,type=1,poolId=139,weight=1,useConditions={},cardId=9862,assetId="attack_1",extend={}},
    [150] = {id=143,type=1,poolId=140,weight=1,useConditions={},cardId=9801,assetId="summon_1",extend={}},
    [151] = {id=144,type=1,poolId=140,weight=1,useConditions={},cardId=9802,assetId="summon_1",extend={}},
    [152] = {id=145,type=1,poolId=141,weight=1,useConditions={},cardId=9806,assetId="summon_2",extend={}},
    [153] = {id=146,type=1,poolId=141,weight=1,useConditions={},cardId=9863,assetId="attack_2",extend={}},
    [154] = {id=147,type=1,poolId=142,weight=1,useConditions={},cardId=9801,assetId="summon_1",extend={}},
    [155] = {id=148,type=1,poolId=143,weight=1,useConditions={},cardId=9802,assetId="summon_1",extend={}},
    [156] = {id=149,type=1,poolId=144,weight=50,useConditions={},cardId=9924,assetId="buff_1",extend={}},
    [157] = {id=150,type=1,poolId=145,weight=50,useConditions={},cardId=9925,assetId="attack_2",extend={}},
    [158] = {id=151,type=1,poolId=146,weight=1,useConditions={},cardId=2341,assetId="buff_1",extend={}},
    [159] = {id=152,type=1,poolId=147,weight=1,useConditions={},cardId=2345,assetId="attack_1",extend={}},
    [160] = {id=153,type=1,poolId=147,weight=1,useConditions={},cardId=2346,assetId="e_mark",extend={}},
    [161] = {id=154,type=1,poolId=148,weight=1,useConditions={},cardId=2350,assetId="attack_1",extend={showGrid={camp=1,index=5}}},
    [162] = {id=155,type=1,poolId=149,weight=1,useConditions={},cardId=2351,assetId="attack_2",extend={}},
    [163] = {id=156,type=1,poolId=149,weight=1,useConditions={},cardId=2352,assetId="q_mark",extend={}},
    [164] = {id=157,type=1,poolId=150,weight=1,useConditions={},cardId=2353,assetId="attack_aoe",extend={}},
    [165] = {id=158,type=1,poolId=151,weight=1,useConditions={},cardId=2355,assetId="summon_2",extend={}},
    [166] = {id=159,type=1,poolId=152,weight=1,useConditions={},cardId=2356,assetId="summon_2",extend={}},
    [167] = {id=160,type=1,poolId=153,weight=1,useConditions={},cardId=2369,assetId="attack_aoe",extend={}},
    [168] = {id=161,type=1,poolId=154,weight=1,useConditions={},cardId=2375,assetId="buff_2",extend={}},
    [169] = {id=162,type=1,poolId=154,weight=1,useConditions={},cardId=2376,assetId="attack_1",extend={}},
    [170] = {id=163,type=1,poolId=157,weight=1,useConditions={},cardId=2389,assetId="summon_1",extend={}},
    [171] = {id=164,type=1,poolId=158,weight=1,useConditions={},cardId=2391,assetId="buff_1",extend={}},
    [172] = {id=165,type=1,poolId=159,weight=1,useConditions={},cardId=2394,assetId="attack_1",extend={}},
    [173] = {id=166,type=1,poolId=159,weight=1,useConditions={},cardId=2395,assetId="attack_2",extend={}},
    [174] = {id=167,type=1,poolId=160,weight=1,useConditions={},cardId=2397,assetId="q_mark",extend={}},
    [175] = {id=168,type=1,poolId=160,weight=1,useConditions={},cardId=2399,assetId="attack_2",extend={}},
    [176] = {id=169,type=1,poolId=161,weight=1,useConditions={},cardId=2402,assetId="summon_2",extend={}},
    [177] = {id=170,type=1,poolId=161,weight=1,useConditions={},cardId=2405,assetId="attack_2",extend={}},
    [178] = {id=171,type=1,poolId=162,weight=1,useConditions={},cardId=2407,assetId="summon_2",extend={}},
    [179] = {id=172,type=1,poolId=163,weight=1,useConditions={},cardId=2409,assetId="attack_2",extend={}},
    [180] = {id=173,type=1,poolId=162,weight=1,useConditions={},cardId=2410,assetId="summon_2",extend={}},
    [181] = {id=174,type=1,poolId=164,weight=1,useConditions={},cardId=2412,assetId="attack_2",extend={}},
    [182] = {id=175,type=1,poolId=162,weight=1,useConditions={},cardId=2413,assetId="summon_1",extend={}},
    [183] = {id=176,type=1,poolId=165,weight=1,useConditions={},cardId=2419,assetId="attack_aoe",extend={}},
    [184] = {id=177,type=1,poolId=166,weight=1,useConditions={},cardId=2421,assetId="summon_2",extend={}},
    [185] = {id=178,type=1,poolId=166,weight=1,useConditions={},cardId=2422,assetId="summon_2",extend={}},
    [186] = {id=179,type=1,poolId=165,weight=1,useConditions={},cardId=2423,assetId="attack_2",extend={}},
    [187] = {id=180,type=1,poolId=167,weight=1,useConditions={},cardId=2424,assetId="buff_1",extend={}},
    [188] = {id=181,type=1,poolId=168,weight=1,useConditions={},cardId=2446,assetId="buff_2",extend={}},
    [189] = {id=182,type=1,poolId=168,weight=1,useConditions={},cardId=2452,assetId="buff_1",extend={}},
    [190] = {id=183,type=1,poolId=168,weight=1,useConditions={},cardId=2453,assetId="attack_2",extend={}},
    [191] = {id=184,type=1,poolId=169,weight=1,useConditions={},cardId=2455,assetId="buff_2",extend={}},
    [192] = {id=185,type=1,poolId=169,weight=1,useConditions={},cardId=2456,assetId="attack_2",extend={}},
    [193] = {id=186,type=1,poolId=169,weight=1,useConditions={},cardId=2457,assetId="summon_2",extend={}},
    [194] = {id=187,type=1,poolId=170,weight=1,useConditions={},cardId=2426,assetId="summon_2",extend={showChainEffect=true}},
    [195] = {id=188,type=1,poolId=170,weight=1,useConditions={},cardId=2429,assetId="summon_1",extend={}},
    [196] = {id=189,type=1,poolId=171,weight=1,useConditions={},cardId=2432,assetId="attack_aoe",extend={}},
    [197] = {id=190,type=1,poolId=171,weight=1,useConditions={},cardId=2826,assetId="attack_2",extend={}},
    [198] = {id=191,type=1,poolId=170,weight=1,useConditions={},cardId=2434,assetId="summon_2",extend={}},
    [199] = {id=192,type=1,poolId=171,weight=1,useConditions={},cardId=10756,assetId="attack_2",extend={}},
    [200] = {id=193,type=1,poolId=172,weight=1,useConditions={},cardId=2438,assetId="e_mark",extend={}},
    [201] = {id=194,type=1,poolId=172,weight=1,useConditions={},cardId=2439,assetId="buff_2",extend={}},
    [202] = {id=195,type=1,poolId=173,weight=1,useConditions={},cardId=2440,assetId="attack_2",extend={}},
    [203] = {id=196,type=1,poolId=173,weight=1,useConditions={},cardId=2441,assetId="summon_2",extend={}},
    [204] = {id=197,type=1,poolId=173,weight=1,useConditions={},cardId=2443,assetId="summon_2",extend={}},
    [205] = {id=198,type=1,poolId=174,weight=1,useConditions={},cardId=2301,assetId="summon_1",extend={}},
    [206] = {id=199,type=1,poolId=174,weight=1,useConditions={},cardId=2303,assetId="summon_1",extend={}},
    [207] = {id=200,type=1,poolId=174,weight=1,useConditions={},cardId=2304,assetId="summon_1",extend={}},
    [208] = {id=201,type=1,poolId=174,weight=1,useConditions={},cardId=2305,assetId="summon_1",extend={}},
    [209] = {id=202,type=1,poolId=174,weight=1,useConditions={},cardId=2306,assetId="summon_2",extend={}},
    [210] = {id=203,type=1,poolId=175,weight=1,useConditions={2042},cardId=2301,assetId="summon_2",extend={}},
    [211] = {id=204,type=1,poolId=175,weight=1,useConditions={2042},cardId=2303,assetId="summon_1",extend={}},
    [212] = {id=205,type=1,poolId=175,weight=1,useConditions={2042},cardId=2304,assetId="summon_1",extend={}},
    [213] = {id=206,type=1,poolId=175,weight=1,useConditions={2042},cardId=2305,assetId="summon_1",extend={}},
    [214] = {id=207,type=1,poolId=175,weight=1,useConditions={2042},cardId=2306,assetId="summon_1",extend={}},
    [215] = {id=208,type=1,poolId=176,weight=1,useConditions={},cardId=2319,assetId="buff_1",extend={}},
    [216] = {id=209,type=1,poolId=176,weight=1,useConditions={},cardId=2308,assetId="summon_2",extend={}},
    [217] = {id=210,type=1,poolId=176,weight=1,useConditions={},cardId=2310,assetId="buff_2",extend={}},
    [218] = {id=211,type=1,poolId=177,weight=1,useConditions={2041},cardId=2312,assetId="attack_1",extend={}},
    [219] = {id=212,type=1,poolId=177,weight=1,useConditions={2041},cardId=2313,assetId="attack_2",extend={}},
    [220] = {id=213,type=1,poolId=177,weight=1,useConditions={2041},cardId=2314,assetId="e_mark",extend={}},
    [221] = {id=214,type=1,poolId=178,weight=1,useConditions={2051},cardId=2320,assetId="attack_aoe",extend={}},
    [222] = {id=215,type=1,poolId=178,weight=1,useConditions={2051},cardId=2321,assetId="buff_2",extend={}},
    [223] = {id=216,type=1,poolId=178,weight=1,useConditions={2051},cardId=2322,assetId="buff_2",extend={}},
    [224] = {id=217,type=1,poolId=179,weight=1,useConditions={},cardId=2326,assetId="buff_1",extend={}},
    [225] = {id=218,type=1,poolId=179,weight=1,useConditions={},cardId=2327,assetId="buff_1",extend={}},
    [226] = {id=219,type=1,poolId=179,weight=1,useConditions={},cardId=2324,assetId="summon_1",extend={}},
    [227] = {id=220,type=1,poolId=180,weight=1,useConditions={},cardId=2328,assetId="attack_1",extend={}},
    [228] = {id=221,type=1,poolId=180,weight=1,useConditions={},cardId=2329,assetId="buff_1",extend={}},
    [229] = {id=222,type=1,poolId=181,weight=1,useConditions={},cardId=2330,assetId="attack_aoe",extend={}},
    [230] = {id=223,type=1,poolId=181,weight=1,useConditions={},cardId=2331,assetId="buff_2",extend={}},
    [231] = {id=224,type=1,poolId=182,weight=1,useConditions={},cardId=2333,assetId="buff_1",extend={}},
    [232] = {id=225,type=1,poolId=184,weight=1,useConditions={},cardId=2334,assetId="summon_1",extend={}},
    [233] = {id=226,type=1,poolId=183,weight=1,useConditions={},cardId=2335,assetId="buff_1",extend={}},
    [234] = {id=227,type=1,poolId=183,weight=1,useConditions={},cardId=2336,assetId="summon_1",extend={}},
    [235] = {id=228,type=1,poolId=183,weight=1,useConditions={},cardId=2337,assetId="summon_1",extend={}},
    [236] = {id=229,type=1,poolId=185,weight=1,useConditions={},cardId=2338,assetId="attack_aoe",extend={}},
    [237] = {id=230,type=1,poolId=186,weight=1,useConditions={},cardId=7018,assetId="attack_aoe",extend={}},
    [238] = {id=231,type=1,poolId=187,weight=1,useConditions={},cardId=2216,assetId="summon_1",extend={}},
    [239] = {id=232,type=1,poolId=188,weight=1,useConditions={2056},cardId=2218,assetId="attack_aoe",extend={}},
    [240] = {id=233,type=1,poolId=188,weight=1,useConditions={2056},cardId=2218,assetId="buff_1",extend={}},
    [241] = {id=234,type=1,poolId=189,weight=1,useConditions={2071},cardId=7504,assetId="summon_1",extend={}},
    [242] = {id=235,type=1,poolId=189,weight=1,useConditions={2086},cardId=7509,assetId="summon_2",extend={}},
    [243] = {id=236,type=1,poolId=189,weight=1,useConditions={2086},cardId=7511,assetId="summon_2",extend={}},
    [244] = {id=237,type=1,poolId=189,weight=1,useConditions={2086},cardId=7513,assetId="buff_1",extend={}},
    [245] = {id=238,type=1,poolId=189,weight=1,useConditions={2086},cardId=7514,assetId="attack_aoe",extend={}},
    [246] = {id=239,type=1,poolId=189,weight=1,useConditions={2086},cardId=7515,assetId="attack_aoe",extend={}},
    [247] = {id=240,type=1,poolId=189,weight=1,useConditions={2086},cardId=7516,assetId="buff_1",extend={}},
    [248] = {id=241,type=1,poolId=190,weight=1,useConditions={2070},cardId=7505,assetId="summon_1",extend={}},
    [249] = {id=242,type=1,poolId=190,weight=1,useConditions={2085},cardId=7509,assetId="summon_2",extend={}},
    [250] = {id=243,type=1,poolId=190,weight=1,useConditions={2085},cardId=7511,assetId="summon_2",extend={}},
    [251] = {id=244,type=1,poolId=190,weight=1,useConditions={2085},cardId=7513,assetId="buff_1",extend={}},
    [252] = {id=245,type=1,poolId=190,weight=1,useConditions={2085},cardId=7514,assetId="attack_aoe",extend={}},
    [253] = {id=246,type=1,poolId=190,weight=1,useConditions={2085},cardId=7515,assetId="attack_aoe",extend={}},
    [254] = {id=247,type=1,poolId=190,weight=1,useConditions={2085},cardId=7516,assetId="buff_1",extend={}},
    [255] = {id=248,type=1,poolId=191,weight=1,useConditions={},cardId=7507,assetId="buff_1",extend={}},
    [256] = {id=249,type=1,poolId=191,weight=1,useConditions={},cardId=7509,assetId="summon_2",extend={}},
    [257] = {id=250,type=1,poolId=191,weight=1,useConditions={},cardId=7511,assetId="summon_2",extend={}},
    [258] = {id=251,type=1,poolId=191,weight=1,useConditions={},cardId=7513,assetId="buff_1",extend={}},
    [259] = {id=252,type=1,poolId=191,weight=1,useConditions={},cardId=7514,assetId="attack_aoe",extend={}},
    [260] = {id=253,type=1,poolId=191,weight=1,useConditions={},cardId=7515,assetId="attack_aoe",extend={}},
    [261] = {id=254,type=1,poolId=192,weight=1,useConditions={},cardId=7518,assetId="summon_2",extend={}},
    [262] = {id=255,type=1,poolId=193,weight=1,useConditions={},cardId=7520,assetId="summon_2",extend={}},
    [263] = {id=256,type=1,poolId=193,weight=1,useConditions={},cardId=7522,assetId="summon_1",extend={}},
    [264] = {id=257,type=1,poolId=193,weight=1,useConditions={},cardId=7523,assetId="summon_2",extend={}},
    [265] = {id=258,type=1,poolId=193,weight=1,useConditions={},cardId=7525,assetId="summon_2",extend={}},
    [266] = {id=259,type=1,poolId=194,weight=1,useConditions={},cardId=2812,assetId="buff_1",extend={}},
    [267] = {id=260,type=1,poolId=195,weight=1,useConditions={},cardId=10093,assetId="attack_aoe",extend={}},
    [268] = {id=261,type=1,poolId=195,weight=1,useConditions={},cardId=10755,assetId="summon_1",extend={}},
    [269] = {id=262,type=1,poolId=195,weight=1,useConditions={},cardId=7531,assetId="summon_1",extend={}},
    [270] = {id=263,type=1,poolId=195,weight=1,useConditions={},cardId=2037,assetId="summon_1",extend={}},
    [271] = {id=264,type=1,poolId=195,weight=1,useConditions={},cardId=7106,assetId="summon_1",extend={}},
    [272] = {id=265,type=1,poolId=195,weight=1,useConditions={},cardId=2000,assetId="summon_1",extend={}},
    [273] = {id=266,type=1,poolId=200,weight=1,useConditions={},cardId=10745,assetId="attack_1",extend={showChainEffect=true}},
    [274] = {id=267,type=1,poolId=195,weight=1,useConditions={},cardId=2453,assetId="attack_2",extend={}},
    [275] = {id=268,type=1,poolId=196,weight=1,useConditions={},cardId=10737,assetId="buff_1",extend={showChainEffect=true}},
    [276] = {id=269,type=1,poolId=197,weight=1,useConditions={},cardId=2004,assetId="buff_1",extend={}},
    [277] = {id=270,type=1,poolId=198,weight=1,useConditions={},cardId=10095,assetId="buff_1",extend={}},
    [278] = {id=271,type=1,poolId=199,weight=1,useConditions={},cardId=10034,assetId="attack_1",extend={}},
    [279] = {id=272,type=1,poolId=210,weight=1,useConditions={},cardId=11013,assetId="buff_1",extend={}},
    [280] = {id=273,type=1,poolId=211,weight=1,useConditions={},cardId=11014,assetId="attack_1",extend={}},
    [281] = {id=300,type=1,poolId=212,weight=1,useConditions={},cardId=2341,assetId="buff_1",extend={}},
    [282] = {id=301,type=1,poolId=213,weight=1,useConditions={},cardId=21006,assetId="attack_1",extend={}},
    [283] = {id=302,type=1,poolId=214,weight=1,useConditions={},cardId=21006,assetId="attack_1",extend={}},
    [284] = {id=303,type=1,poolId=215,weight=1,useConditions={},cardId=21007,assetId="buff_1",extend={}},
    [285] = {id=450,type=1,poolId=216,weight=1,useConditions={},cardId=21009,assetId="attack_aoe",extend={showChainEffect=true}},
    [286] = {id=453,type=1,poolId=217,weight=1,useConditions={},cardId=2389,assetId="summon_1",extend={}},
    [287] = {id=454,type=1,poolId=218,weight=1,useConditions={},cardId=21010,assetId="buff_1",extend={}},
    [288] = {id=455,type=1,poolId=219,weight=1,useConditions={},cardId=2395,assetId="attack_2",extend={}},
    [289] = {id=456,type=1,poolId=220,weight=1,useConditions={},cardId=2407,assetId="summon_2",extend={}},
    [290] = {id=457,type=1,poolId=221,weight=1,useConditions={},cardId=21031,assetId="summon_1",extend={}},
    [291] = {id=458,type=1,poolId=222,weight=1,useConditions={},cardId=21014,assetId="attack_aoe",extend={showChainEffect=true}},
    [292] = {id=459,type=1,poolId=223,weight=1,useConditions={},cardId=21020,assetId="summon_1",extend={}},
    [293] = {id=460,type=1,poolId=224,weight=1,useConditions={},cardId=21021,assetId="summon_1",extend={}},
    [294] = {id=461,type=1,poolId=225,weight=1,useConditions={},cardId=21018,assetId="e_mark",extend={}},
    [295] = {id=462,type=1,poolId=226,weight=1,useConditions={},cardId=21023,assetId="attack_1",extend={}},
    [296] = {id=463,type=1,poolId=227,weight=1,useConditions={},cardId=21024,assetId="attack_2",extend={}},
    [297] = {id=464,type=1,poolId=228,weight=1,useConditions={},cardId=21025,assetId="attack_aoe",extend={showChainEffect=true}},
    [298] = {id=465,type=1,poolId=229,weight=1,useConditions={},cardId=21012,assetId="summon_2",extend={}},
    [299] = {id=466,type=1,poolId=230,weight=1,useConditions={},cardId=2402,assetId="summon_2",extend={}},
    [300] = {id=467,type=1,poolId=231,weight=1,useConditions={},cardId=2405,assetId="attack_aoe",extend={}},
    [301] = {id=468,type=1,poolId=232,weight=1,useConditions={},cardId=21016,assetId="summon_2",extend={}},
    [302] = {id=469,type=1,poolId=233,weight=1,useConditions={},cardId=21017,assetId="attack_1",extend={showChainEffect=true}},
    [303] = {id=470,type=1,poolId=234,weight=1,useConditions={},cardId=21018,assetId="buff_1",extend={}},
    [304] = {id=471,type=1,poolId=235,weight=1,useConditions={},cardId=21028,assetId="summon_2",extend={}},
    [305] = {id=472,type=1,poolId=236,weight=1,useConditions={},cardId=21029,assetId="summon_2",extend={}},
    [306] = {id=473,type=1,poolId=237,weight=1,useConditions={},cardId=21030,assetId="q_mark",extend={}},
    [307] = {id=500,type=1,poolId=300,weight=1,useConditions={},cardId=11040,assetId="buff_1",extend={}},
    [308] = {id=501,type=1,poolId=301,weight=1,useConditions={},cardId=11041,assetId="buff_1",extend={}},
    [309] = {id=502,type=1,poolId=302,weight=1,useConditions={},cardId=11042,assetId="buff_1",extend={}},
    [310] = {id=503,type=1,poolId=303,weight=1,useConditions={},cardId=11043,assetId="buff_2",extend={}},
    [311] = {id=504,type=1,poolId=304,weight=1,useConditions={},cardId=11044,assetId="attack_aoe",extend={showChainEffect=true}},
    [312] = {id=505,type=1,poolId=305,weight=1,useConditions={},cardId=11040,assetId="buff_1",extend={}},
    [313] = {id=506,type=1,poolId=306,weight=1,useConditions={},cardId=11041,assetId="buff_1",extend={}},
    [314] = {id=507,type=1,poolId=307,weight=1,useConditions={},cardId=21033,assetId="buff_2",extend={showChainEffect=true}},
    [315] = {id=508,type=1,poolId=308,weight=1,useConditions={},cardId=21048,assetId="summon_2",extend={}},
    [316] = {id=509,type=1,poolId=309,weight=1,useConditions={},cardId=21049,assetId="summon_2",extend={}},
    [317] = {id=510,type=1,poolId=310,weight=1,useConditions={},cardId=21050,assetId="summon_2",extend={}},
}
local config = {}
local config_loaded = {}
local config_languages = {}

local function config_load(index)
    if index == nil then return nil end
    if config_loaded[index] then return config[index] end
    local source = config_source[index]
    if source == nil then return nil end
    local rowLanguage = config_languages[index] or nil
    local data = ConfigRowRuntime.Build(source,config_runtime_schema,"robot_chain_def",rowLanguage)
    config[index] = data
    config_loaded[index] = true
    return data
end

function robot_chain_def.config_index(index)
    return config_load(index)
end

function robot_chain_def.config_set(index,data)
    config[index] = data
    config_loaded[index] = true
end

function robot_chain_def.config_num()
    return config_num
end

local config_id =
{
    [1]=1,[2]=2,[3]=3,[4]=4,[5]=5,[6]=6,[7]=7,[8]=8,[9]=9,[10]=10,[11]=11,[12]=12,[13]=13,[14]=14,[15]=15,[16]=16,[17]=17,[18]=18,[19]=19,[20]=20,[21]=21,[22]=22,[23]=23,[24]=24,[25]=25,[26]=26,[27]=27,[28]=28,[29]=29,[30]=30,[31]=31,[32]=32,[33]=33,[34]=34,[35]=35,[36]=36,[37]=37,[38]=38,[39]=39,[40]=40,[41]=41,[42]=42,[43]=43,[44]=44,[45]=45,[46]=46,[47]=47,[48]=48,[49]=49,[50]=50,[51]=51,[52]=52,[53]=53,[54]=54,[55]=55,[56]=56,[57]=57,[58]=58,[59]=59,[60]=60,[61]=61,[62]=62,[63]=63,[64]=64,[65]=65,[66]=66,[67]=67,[68]=68,[69]=69,[70]=70,[71]=71,[72]=72,[73]=73,[74]=74,[75]=75,[76]=76,[77]=77,[78]=78,[79]=79,[80]=80,[81]=81,[82]=82,[83]=83,[84]=84,[85]=85,[86]=86,[87]=87,[88]=88,[511]=89,[512]=90,[513]=91,[514]=92,[515]=93,[516]=94,[517]=95,[518]=96,[89]=97,[90]=98,[91]=99,[92]=100,[93]=101,[94]=102,[95]=103,[96]=104,[97]=105,[98]=106,[99]=107,[100]=108,[101]=109,[102]=110,[103]=111,[104]=112,[105]=113,[106]=114,[107]=115,[108]=116,[109]=117,[110]=118,[111]=119,[112]=120,[113]=121,[115]=122,[116]=123,[117]=124,[118]=125,[119]=126,[120]=127,[121]=128,[122]=129,[123]=130,[124]=131,[125]=132,[126]=133,[127]=134,[128]=135,[129]=136,[130]=137,[131]=138,[132]=139,[133]=140,[134]=141,[135]=142,[136]=143,[137]=144,[138]=145,[139]=146,[140]=147,[141]=148,[142]=149,[143]=150,[144]=151,[145]=152,[146]=153,[147]=154,[148]=155,[149]=156,[150]=157,[151]=158,[152]=159,[153]=160,[154]=161,[155]=162,[156]=163,[157]=164,[158]=165,[159]=166,[160]=167,[161]=168,[162]=169,[163]=170,[164]=171,[165]=172,[166]=173,[167]=174,[168]=175,[169]=176,[170]=177,[171]=178,[172]=179,[173]=180,[174]=181,[175]=182,[176]=183,[177]=184,[178]=185,[179]=186,[180]=187,[181]=188,[182]=189,[183]=190,[184]=191,[185]=192,[186]=193,[187]=194,[188]=195,[189]=196,[190]=197,[191]=198,[192]=199,[193]=200,[194]=201,[195]=202,[196]=203,[197]=204,[198]=205,[199]=206,[200]=207,[201]=208,[202]=209,[203]=210,[204]=211,[205]=212,[206]=213,[207]=214,[208]=215,[209]=216,[210]=217,[211]=218,[212]=219,[213]=220,[214]=221,[215]=222,[216]=223,[217]=224,[218]=225,[219]=226,[220]=227,[221]=228,[222]=229,[223]=230,[224]=231,[225]=232,[226]=233,[227]=234,[228]=235,[229]=236,[230]=237,[231]=238,[232]=239,[233]=240,[234]=241,[235]=242,[236]=243,[237]=244,[238]=245,[239]=246,[240]=247,[241]=248,[242]=249,[243]=250,[244]=251,[245]=252,[246]=253,[247]=254,[248]=255,[249]=256,[250]=257,[251]=258,[252]=259,[253]=260,[254]=261,[255]=262,[256]=263,[257]=264,[258]=265,[259]=266,[260]=267,[261]=268,[262]=269,[263]=270,[264]=271,[265]=272,[266]=273,[267]=274,[268]=275,[269]=276,[270]=277,[271]=278,[272]=279,[273]=280,[300]=281,[301]=282,[302]=283,[303]=284,[450]=285,[453]=286,[454]=287,[455]=288,[456]=289,[457]=290,[458]=291,[459]=292,[460]=293,[461]=294,[462]=295,[463]=296,[464]=297,[465]=298,[466]=299,[467]=300,[468]=301,[469]=302,[470]=303,[471]=304,[472]=305,[473]=306,[500]=307,[501]=308,[502]=309,[503]=310,[504]=311,[505]=312,[506]=313,[507]=314,[508]=315,[509]=316,[510]=317
}

function robot_chain_def.config_id(key)
    local index = config_id[key]
    return robot_chain_def.config_index(index)
end

local config_poolId =
{
    [1]={1,2,3},[2]={4},[3]={5},[4]={6},[5]={7},[6]={8},[7]={9},[8]={10},[9]={11},[10]={12},[11]={13},[12]={14},[13]={15},[14]={16},[15]={17},[16]={18},[17]={19},[18]={20},[19]={21},[20]={22},[21]={23,24,25},[22]={26},[23]={27},[24]={28},[25]={29},[26]={30},[27]={31},[29]={32},[30]={33},[31]={34},[32]={35},[33]={36},[34]={37},[35]={38},[36]={39},[37]={40},[38]={41},[39]={42},[40]={43},[41]={44},[42]={45},[43]={46},[44]={47},[45]={48},[46]={49},[47]={50},[48]={51},[49]={52},[50]={53},[51]={54},[52]={55},[53]={56},[54]={57},[55]={58},[56]={59},[57]={60},[58]={61},[59]={62},[60]={63},[61]={64,65},[62]={66},[63]={67},[64]={68,69},[65]={70},[66]={71},[67]={72},[68]={73},[69]={74},[70]={75},[71]={76},[72]={77},[73]={78},[74]={79},[75]={80},[76]={81},[77]={82},[78]={83},[79]={84},[80]={85},[81]={86},[82]={87},[83]={88},[84]={89},[85]={90,91},[87]={92,93},[89]={94,95},[91]={96},[92]={97},[93]={98},[94]={99},[95]={100},[96]={101},[97]={102},[98]={103},[99]={104},[100]={105},[101]={106},[102]={107},[103]={108},[104]={109},[105]={110},[106]={111},[107]={112},[108]={113},[109]={114},[110]={115},[111]={116},[112]={117},[113]={118},[114]={119},[115]={120},[116]={121},[117]={122},[118]={123},[119]={124},[120]={125},[121]={126},[122]={127},[123]={128},[124]={129},[131]={130},[132]={131},[125]={132},[126]={133},[127]={134},[128]={135},[129]={136},[130]={137},[133]={138},[134]={139},[135]={140,141,142},[136]={143,144,145},[137]={146},[138]={147},[139]={148,149},[140]={150,151},[141]={152,153},[142]={154},[143]={155},[144]={156},[145]={157},[146]={158},[147]={159,160},[148]={161},[149]={162,163},[150]={164},[151]={165},[152]={166},[153]={167},[154]={168,169},[157]={170},[158]={171},[159]={172,173},[160]={174,175},[161]={176,177},[162]={178,180,182},[163]={179},[164]={181},[165]={183,186},[166]={184,185},[167]={187},[168]={188,189,190},[169]={191,192,193},[170]={194,195,198},[171]={196,197,199},[172]={200,201},[173]={202,203,204},[174]={205,206,207,208,209},[175]={210,211,212,213,214},[176]={215,216,217},[177]={218,219,220},[178]={221,222,223},[179]={224,225,226},[180]={227,228},[181]={229,230},[182]={231},[184]={232},[183]={233,234,235},[185]={236},[186]={237},[187]={238},[188]={239,240},[189]={241,242,243,244,245,246,247},[190]={248,249,250,251,252,253,254},[191]={255,256,257,258,259,260},[192]={261},[193]={262,263,264,265},[194]={266},[195]={267,268,269,270,271,272,274},[200]={273},[196]={275},[197]={276},[198]={277},[199]={278},[210]={279},[211]={280},[212]={281},[213]={282},[214]={283},[215]={284},[216]={285},[217]={286},[218]={287},[219]={288},[220]={289},[221]={290},[222]={291},[223]={292},[224]={293},[225]={294},[226]={295},[227]={296},[228]={297},[229]={298},[230]={299},[231]={300},[232]={301},[233]={302},[234]={303},[235]={304},[236]={305},[237]={306},[300]={307},[301]={308},[302]={309},[303]={310},[304]={311},[305]={312},[306]={313},[307]={314},[308]={315},[309]={316},[310]={317}
}

local config_poolId_data = {}
function robot_chain_def.config_poolId(key)
    if config_poolId_data[key] then
        return config_poolId_data[key]
    end
    local indexs = config_poolId[key]
    local datas = {}
    if indexs == nil then return datas end
    for _,index in ipairs(indexs) do
        table.insert(datas,robot_chain_def.config_index(index))
    end
    config_poolId_data[key] = datas
    return datas
end

--sequence
local sequence_num = 356
local sequence_schema =
{
    ["chainId"] = { type = "int" },
    ["seqType"] = { type = "int" },
    ["round"] = { type = "int" },
    ["circle"] = { type = "int" },
    ["poolId"] = { type = "int" },
}
local sequence_runtime_schema = sequence_schema
local sequence_source =
{
    [1] = {chainId=1301,seqType=1,round=1,circle=0,poolId=1},
    [2] = {chainId=1301,seqType=1,round=2,circle=0,poolId=1},
    [3] = {chainId=1301,seqType=1,round=2,circle=0,poolId=2},
    [4] = {chainId=1301,seqType=1,round=3,circle=0,poolId=1},
    [5] = {chainId=1301,seqType=1,round=3,circle=0,poolId=2},
    [6] = {chainId=1301,seqType=1,round=3,circle=0,poolId=3},
    [7] = {chainId=1301,seqType=1,round=4,circle=0,poolId=1},
    [8] = {chainId=1301,seqType=1,round=4,circle=0,poolId=2},
    [9] = {chainId=1301,seqType=1,round=4,circle=0,poolId=3},
    [10] = {chainId=1301,seqType=1,round=4,circle=0,poolId=4},
    [11] = {chainId=1301,seqType=2,round=1,circle=3,poolId=5},
    [12] = {chainId=1301,seqType=2,round=2,circle=3,poolId=5},
    [13] = {chainId=1301,seqType=2,round=2,circle=3,poolId=6},
    [14] = {chainId=1301,seqType=2,round=3,circle=3,poolId=5},
    [15] = {chainId=1301,seqType=2,round=3,circle=3,poolId=6},
    [16] = {chainId=1301,seqType=2,round=3,circle=3,poolId=7},
    [17] = {chainId=1031,seqType=1,round=1,circle=0,poolId=8},
    [18] = {chainId=1031,seqType=1,round=2,circle=0,poolId=9},
    [19] = {chainId=1031,seqType=2,round=1,circle=3,poolId=11},
    [20] = {chainId=1031,seqType=2,round=1,circle=3,poolId=12},
    [21] = {chainId=1031,seqType=2,round=1,circle=3,poolId=13},
    [22] = {chainId=1031,seqType=2,round=1,circle=3,poolId=15},
    [23] = {chainId=1031,seqType=2,round=1,circle=3,poolId=10},
    [24] = {chainId=1031,seqType=2,round=2,circle=3,poolId=11},
    [25] = {chainId=1031,seqType=2,round=2,circle=3,poolId=12},
    [26] = {chainId=1031,seqType=2,round=2,circle=3,poolId=14},
    [27] = {chainId=1031,seqType=2,round=2,circle=3,poolId=15},
    [28] = {chainId=1031,seqType=2,round=2,circle=3,poolId=10},
    [29] = {chainId=1031,seqType=2,round=3,circle=3,poolId=11},
    [30] = {chainId=1031,seqType=2,round=3,circle=3,poolId=12},
    [31] = {chainId=1031,seqType=2,round=3,circle=3,poolId=14},
    [32] = {chainId=1031,seqType=2,round=3,circle=3,poolId=15},
    [33] = {chainId=1031,seqType=2,round=3,circle=3,poolId=10},
    [34] = {chainId=1007,seqType=2,round=1,circle=3,poolId=16},
    [35] = {chainId=1032,seqType=1,round=1,circle=0,poolId=17},
    [36] = {chainId=1032,seqType=1,round=2,circle=0,poolId=18},
    [37] = {chainId=1032,seqType=1,round=2,circle=0,poolId=19},
    [38] = {chainId=1032,seqType=2,round=1,circle=4,poolId=22},
    [39] = {chainId=1032,seqType=2,round=1,circle=4,poolId=17},
    [40] = {chainId=1032,seqType=2,round=2,circle=4,poolId=20},
    [41] = {chainId=1032,seqType=2,round=2,circle=4,poolId=21},
    [42] = {chainId=1032,seqType=2,round=3,circle=4,poolId=22},
    [43] = {chainId=1032,seqType=2,round=3,circle=4,poolId=17},
    [44] = {chainId=1032,seqType=2,round=4,circle=4,poolId=18},
    [45] = {chainId=1032,seqType=2,round=4,circle=4,poolId=21},
    [46] = {chainId=1033,seqType=2,round=1,circle=1,poolId=23},
    [47] = {chainId=1034,seqType=1,round=1,circle=0,poolId=11},
    [48] = {chainId=1034,seqType=1,round=1,circle=0,poolId=12},
    [49] = {chainId=1034,seqType=1,round=1,circle=0,poolId=15},
    [50] = {chainId=1034,seqType=1,round=2,circle=0,poolId=13},
    [51] = {chainId=1034,seqType=1,round=2,circle=0,poolId=18},
    [52] = {chainId=1034,seqType=1,round=2,circle=0,poolId=15},
    [53] = {chainId=1034,seqType=2,round=1,circle=3,poolId=11},
    [54] = {chainId=1034,seqType=2,round=1,circle=3,poolId=12},
    [55] = {chainId=1034,seqType=2,round=1,circle=3,poolId=13},
    [56] = {chainId=1034,seqType=2,round=1,circle=3,poolId=15},
    [57] = {chainId=1034,seqType=2,round=1,circle=3,poolId=10},
    [58] = {chainId=1034,seqType=2,round=2,circle=3,poolId=11},
    [59] = {chainId=1034,seqType=2,round=2,circle=3,poolId=12},
    [60] = {chainId=1034,seqType=2,round=2,circle=3,poolId=14},
    [61] = {chainId=1034,seqType=2,round=2,circle=3,poolId=15},
    [62] = {chainId=1034,seqType=2,round=2,circle=3,poolId=10},
    [63] = {chainId=1034,seqType=2,round=3,circle=3,poolId=11},
    [64] = {chainId=1034,seqType=2,round=3,circle=3,poolId=12},
    [65] = {chainId=1034,seqType=2,round=3,circle=3,poolId=14},
    [66] = {chainId=1034,seqType=2,round=3,circle=3,poolId=15},
    [67] = {chainId=1034,seqType=2,round=3,circle=3,poolId=10},
    [68] = {chainId=1035,seqType=2,round=1,circle=3,poolId=24},
    [69] = {chainId=1035,seqType=2,round=1,circle=3,poolId=26},
    [70] = {chainId=1035,seqType=2,round=2,circle=3,poolId=25},
    [71] = {chainId=1035,seqType=2,round=2,circle=3,poolId=27},
    [72] = {chainId=1035,seqType=2,round=3,circle=3,poolId=24},
    [73] = {chainId=1036,seqType=2,round=1,circle=3,poolId=31},
    [74] = {chainId=1036,seqType=2,round=1,circle=3,poolId=32},
    [75] = {chainId=1036,seqType=2,round=2,circle=3,poolId=29},
    [76] = {chainId=1036,seqType=2,round=2,circle=3,poolId=33},
    [77] = {chainId=1036,seqType=2,round=3,circle=3,poolId=34},
    [78] = {chainId=1036,seqType=2,round=3,circle=3,poolId=35},
    [79] = {chainId=1100,seqType=1,round=1,circle=0,poolId=36},
    [80] = {chainId=1100,seqType=2,round=2,circle=3,poolId=37},
    [81] = {chainId=1100,seqType=2,round=2,circle=3,poolId=38},
    [82] = {chainId=1100,seqType=2,round=3,circle=3,poolId=39},
    [83] = {chainId=1100,seqType=2,round=1,circle=3,poolId=40},
    [84] = {chainId=1100,seqType=2,round=1,circle=3,poolId=41},
    [85] = {chainId=1101,seqType=2,round=1,circle=3,poolId=42},
    [86] = {chainId=1101,seqType=2,round=2,circle=3,poolId=43},
    [87] = {chainId=1101,seqType=2,round=2,circle=3,poolId=44},
    [88] = {chainId=1101,seqType=2,round=2,circle=3,poolId=45},
    [89] = {chainId=1101,seqType=2,round=3,circle=3,poolId=46},
    [90] = {chainId=1101,seqType=2,round=3,circle=3,poolId=47},
    [91] = {chainId=1102,seqType=2,round=1,circle=3,poolId=48},
    [92] = {chainId=1102,seqType=2,round=2,circle=3,poolId=49},
    [93] = {chainId=1102,seqType=2,round=3,circle=3,poolId=50},
    [94] = {chainId=1103,seqType=2,round=1,circle=4,poolId=51},
    [95] = {chainId=1103,seqType=2,round=2,circle=4,poolId=52},
    [96] = {chainId=1103,seqType=2,round=2,circle=4,poolId=53},
    [97] = {chainId=1103,seqType=2,round=3,circle=4,poolId=54},
    [98] = {chainId=1103,seqType=2,round=3,circle=4,poolId=55},
    [99] = {chainId=1103,seqType=2,round=4,circle=4,poolId=56},
    [100] = {chainId=1103,seqType=2,round=4,circle=4,poolId=57},
    [101] = {chainId=1104,seqType=2,round=1,circle=4,poolId=58},
    [102] = {chainId=1104,seqType=2,round=1,circle=4,poolId=59},
    [103] = {chainId=1104,seqType=2,round=2,circle=4,poolId=60},
    [104] = {chainId=1104,seqType=2,round=2,circle=4,poolId=61},
    [105] = {chainId=1104,seqType=2,round=3,circle=4,poolId=58},
    [106] = {chainId=1104,seqType=2,round=3,circle=4,poolId=62},
    [107] = {chainId=1104,seqType=2,round=4,circle=4,poolId=61},
    [108] = {chainId=1104,seqType=2,round=4,circle=4,poolId=63},
    [109] = {chainId=1105,seqType=2,round=1,circle=4,poolId=64},
    [110] = {chainId=1105,seqType=2,round=1,circle=4,poolId=64},
    [111] = {chainId=1106,seqType=1,round=1,circle=0,poolId=65},
    [112] = {chainId=1106,seqType=1,round=1,circle=0,poolId=66},
    [113] = {chainId=1106,seqType=1,round=2,circle=0,poolId=67},
    [114] = {chainId=1106,seqType=1,round=3,circle=0,poolId=68},
    [115] = {chainId=1106,seqType=1,round=3,circle=0,poolId=69},
    [116] = {chainId=1107,seqType=2,round=1,circle=6,poolId=71},
    [117] = {chainId=1107,seqType=2,round=1,circle=6,poolId=72},
    [118] = {chainId=1107,seqType=2,round=2,circle=6,poolId=75},
    [119] = {chainId=1107,seqType=2,round=2,circle=6,poolId=72},
    [120] = {chainId=1107,seqType=2,round=2,circle=6,poolId=70},
    [121] = {chainId=1107,seqType=2,round=3,circle=6,poolId=69},
    [122] = {chainId=1107,seqType=2,round=4,circle=6,poolId=71},
    [123] = {chainId=1107,seqType=2,round=4,circle=6,poolId=72},
    [124] = {chainId=1107,seqType=2,round=4,circle=6,poolId=70},
    [125] = {chainId=1107,seqType=2,round=5,circle=6,poolId=75},
    [126] = {chainId=1107,seqType=2,round=5,circle=6,poolId=72},
    [127] = {chainId=1107,seqType=2,round=6,circle=6,poolId=69},
    [128] = {chainId=1107,seqType=2,round=6,circle=6,poolId=70},
    [129] = {chainId=1108,seqType=2,round=1,circle=3,poolId=76},
    [130] = {chainId=1108,seqType=2,round=2,circle=3,poolId=77},
    [131] = {chainId=1108,seqType=2,round=3,circle=3,poolId=78},
    [132] = {chainId=1108,seqType=2,round=3,circle=3,poolId=79},
    [133] = {chainId=1109,seqType=2,round=1,circle=3,poolId=80},
    [134] = {chainId=1109,seqType=2,round=2,circle=3,poolId=81},
    [135] = {chainId=1109,seqType=2,round=3,circle=3,poolId=82},
    [136] = {chainId=1109,seqType=2,round=3,circle=3,poolId=83},
    [137] = {chainId=1110,seqType=1,round=1,circle=3,poolId=84},
    [138] = {chainId=1110,seqType=2,round=2,circle=4,poolId=85},
    [139] = {chainId=1110,seqType=2,round=3,circle=4,poolId=87},
    [140] = {chainId=1110,seqType=2,round=4,circle=4,poolId=89},
    [141] = {chainId=1110,seqType=2,round=4,circle=4,poolId=91},
    [142] = {chainId=1110,seqType=2,round=1,circle=4,poolId=92},
    [143] = {chainId=1111,seqType=2,round=1,circle=3,poolId=93},
    [144] = {chainId=1111,seqType=2,round=2,circle=3,poolId=94},
    [145] = {chainId=1111,seqType=2,round=2,circle=3,poolId=95},
    [146] = {chainId=1111,seqType=2,round=3,circle=3,poolId=96},
    [147] = {chainId=1112,seqType=2,round=1,circle=4,poolId=97},
    [148] = {chainId=1112,seqType=2,round=2,circle=4,poolId=97},
    [149] = {chainId=1112,seqType=2,round=2,circle=4,poolId=98},
    [150] = {chainId=1112,seqType=2,round=3,circle=4,poolId=97},
    [151] = {chainId=1112,seqType=2,round=4,circle=4,poolId=98},
    [152] = {chainId=1112,seqType=2,round=4,circle=4,poolId=99},
    [153] = {chainId=1113,seqType=2,round=1,circle=3,poolId=100},
    [154] = {chainId=1113,seqType=2,round=2,circle=3,poolId=101},
    [155] = {chainId=1113,seqType=2,round=3,circle=3,poolId=102},
    [156] = {chainId=1114,seqType=2,round=1,circle=3,poolId=103},
    [157] = {chainId=1114,seqType=2,round=2,circle=3,poolId=104},
    [158] = {chainId=1114,seqType=2,round=3,circle=3,poolId=105},
    [159] = {chainId=1115,seqType=2,round=1,circle=4,poolId=106},
    [160] = {chainId=1115,seqType=2,round=2,circle=4,poolId=107},
    [161] = {chainId=1115,seqType=2,round=3,circle=4,poolId=108},
    [162] = {chainId=1115,seqType=2,round=4,circle=4,poolId=109},
    [163] = {chainId=1115,seqType=2,round=4,circle=4,poolId=110},
    [164] = {chainId=1116,seqType=2,round=1,circle=3,poolId=111},
    [165] = {chainId=1116,seqType=2,round=2,circle=3,poolId=112},
    [166] = {chainId=1116,seqType=2,round=3,circle=3,poolId=113},
    [167] = {chainId=1117,seqType=1,round=4,circle=0,poolId=114},
    [168] = {chainId=1118,seqType=2,round=1,circle=2,poolId=115},
    [169] = {chainId=1118,seqType=2,round=2,circle=2,poolId=116},
    [170] = {chainId=1119,seqType=2,round=1,circle=1,poolId=117},
    [171] = {chainId=1120,seqType=1,round=1,circle=0,poolId=118},
    [172] = {chainId=1120,seqType=1,round=1,circle=0,poolId=119},
    [173] = {chainId=1120,seqType=2,round=2,circle=4,poolId=120},
    [174] = {chainId=1120,seqType=2,round=2,circle=4,poolId=121},
    [175] = {chainId=1120,seqType=2,round=3,circle=4,poolId=124},
    [176] = {chainId=1120,seqType=2,round=3,circle=4,poolId=131},
    [177] = {chainId=1120,seqType=2,round=4,circle=4,poolId=122},
    [178] = {chainId=1120,seqType=2,round=4,circle=4,poolId=123},
    [179] = {chainId=1120,seqType=2,round=1,circle=4,poolId=132},
    [180] = {chainId=1120,seqType=2,round=1,circle=4,poolId=119},
    [181] = {chainId=1121,seqType=2,round=1,circle=3,poolId=125},
    [182] = {chainId=1121,seqType=2,round=1,circle=3,poolId=126},
    [183] = {chainId=1121,seqType=2,round=2,circle=3,poolId=127},
    [184] = {chainId=1121,seqType=2,round=2,circle=3,poolId=128},
    [185] = {chainId=1121,seqType=2,round=3,circle=3,poolId=129},
    [186] = {chainId=1121,seqType=2,round=3,circle=3,poolId=130},
    [187] = {chainId=1122,seqType=2,round=1,circle=3,poolId=133},
    [188] = {chainId=1122,seqType=2,round=1,circle=3,poolId=134},
    [189] = {chainId=1122,seqType=2,round=2,circle=3,poolId=135},
    [190] = {chainId=1122,seqType=2,round=2,circle=3,poolId=136},
    [191] = {chainId=1122,seqType=2,round=3,circle=3,poolId=135},
    [192] = {chainId=1122,seqType=2,round=3,circle=3,poolId=136},
    [193] = {chainId=1123,seqType=2,round=1,circle=3,poolId=125},
    [194] = {chainId=1123,seqType=2,round=2,circle=3,poolId=127},
    [195] = {chainId=1123,seqType=2,round=2,circle=3,poolId=130},
    [196] = {chainId=1123,seqType=2,round=3,circle=3,poolId=137},
    [197] = {chainId=1124,seqType=1,round=1,circle=0,poolId=118},
    [198] = {chainId=1124,seqType=1,round=1,circle=0,poolId=119},
    [199] = {chainId=1124,seqType=2,round=2,circle=4,poolId=139},
    [200] = {chainId=1124,seqType=2,round=3,circle=4,poolId=140},
    [201] = {chainId=1124,seqType=2,round=4,circle=4,poolId=121},
    [202] = {chainId=1124,seqType=2,round=1,circle=4,poolId=132},
    [203] = {chainId=1124,seqType=2,round=1,circle=4,poolId=119},
    [204] = {chainId=1125,seqType=1,round=1,circle=0,poolId=118},
    [205] = {chainId=1125,seqType=1,round=1,circle=0,poolId=119},
    [206] = {chainId=1125,seqType=2,round=2,circle=4,poolId=120},
    [207] = {chainId=1125,seqType=2,round=2,circle=4,poolId=121},
    [208] = {chainId=1125,seqType=2,round=3,circle=4,poolId=124},
    [209] = {chainId=1125,seqType=2,round=3,circle=4,poolId=131},
    [210] = {chainId=1125,seqType=2,round=4,circle=4,poolId=142},
    [211] = {chainId=1125,seqType=2,round=4,circle=4,poolId=143},
    [212] = {chainId=1125,seqType=2,round=1,circle=4,poolId=132},
    [213] = {chainId=1125,seqType=2,round=1,circle=4,poolId=119},
    [214] = {chainId=1126,seqType=1,round=2,circle=0,poolId=144},
    [215] = {chainId=1126,seqType=1,round=3,circle=0,poolId=145},
    [216] = {chainId=1129,seqType=1,round=1,circle=0,poolId=146},
    [217] = {chainId=1129,seqType=1,round=1,circle=0,poolId=147},
    [218] = {chainId=1129,seqType=2,round=1,circle=1,poolId=147},
    [219] = {chainId=1129,seqType=2,round=1,circle=1,poolId=147},
    [220] = {chainId=1130,seqType=2,round=1,circle=1,poolId=148},
    [221] = {chainId=1130,seqType=2,round=2,circle=3,poolId=149},
    [222] = {chainId=1130,seqType=2,round=2,circle=3,poolId=149},
    [223] = {chainId=1130,seqType=2,round=3,circle=3,poolId=150},
    [224] = {chainId=1131,seqType=2,round=1,circle=2,poolId=151},
    [225] = {chainId=1131,seqType=2,round=2,circle=2,poolId=152},
    [226] = {chainId=1132,seqType=2,round=1,circle=1,poolId=153},
    [227] = {chainId=1133,seqType=2,round=1,circle=1,poolId=154},
    [228] = {chainId=1134,seqType=2,round=1,circle=1,poolId=157},
    [229] = {chainId=1134,seqType=2,round=1,circle=2,poolId=158},
    [230] = {chainId=1134,seqType=2,round=2,circle=2,poolId=159},
    [231] = {chainId=1135,seqType=2,round=1,circle=1,poolId=160},
    [232] = {chainId=1135,seqType=2,round=1,circle=1,poolId=161},
    [233] = {chainId=1136,seqType=2,round=1,circle=3,poolId=162},
    [234] = {chainId=1136,seqType=2,round=1,circle=3,poolId=163},
    [235] = {chainId=1136,seqType=2,round=2,circle=3,poolId=162},
    [236] = {chainId=1136,seqType=2,round=2,circle=3,poolId=163},
    [237] = {chainId=1136,seqType=2,round=3,circle=3,poolId=164},
    [238] = {chainId=1137,seqType=2,round=1,circle=1,poolId=165},
    [239] = {chainId=1137,seqType=2,round=1,circle=1,poolId=166},
    [240] = {chainId=1137,seqType=2,round=1,circle=1,poolId=167},
    [241] = {chainId=1138,seqType=2,round=1,circle=1,poolId=168},
    [242] = {chainId=1138,seqType=2,round=1,circle=1,poolId=168},
    [243] = {chainId=1139,seqType=2,round=1,circle=1,poolId=169},
    [244] = {chainId=1139,seqType=2,round=1,circle=1,poolId=169},
    [245] = {chainId=1140,seqType=2,round=1,circle=1,poolId=170},
    [246] = {chainId=1140,seqType=2,round=1,circle=1,poolId=171},
    [247] = {chainId=1141,seqType=2,round=1,circle=1,poolId=172},
    [248] = {chainId=1141,seqType=2,round=1,circle=1,poolId=173},
    [249] = {chainId=1142,seqType=2,round=1,circle=3,poolId=174},
    [250] = {chainId=1142,seqType=2,round=1,circle=3,poolId=175},
    [251] = {chainId=1142,seqType=2,round=1,circle=3,poolId=176},
    [252] = {chainId=1142,seqType=2,round=1,circle=3,poolId=177},
    [253] = {chainId=1142,seqType=2,round=1,circle=3,poolId=178},
    [254] = {chainId=1142,seqType=2,round=2,circle=3,poolId=174},
    [255] = {chainId=1142,seqType=2,round=2,circle=3,poolId=175},
    [256] = {chainId=1142,seqType=2,round=2,circle=3,poolId=174},
    [257] = {chainId=1142,seqType=2,round=2,circle=3,poolId=174},
    [258] = {chainId=1142,seqType=2,round=2,circle=3,poolId=177},
    [259] = {chainId=1142,seqType=2,round=2,circle=3,poolId=178},
    [260] = {chainId=1142,seqType=2,round=3,circle=3,poolId=174},
    [261] = {chainId=1142,seqType=2,round=3,circle=3,poolId=175},
    [262] = {chainId=1142,seqType=2,round=3,circle=3,poolId=176},
    [263] = {chainId=1142,seqType=2,round=3,circle=3,poolId=177},
    [264] = {chainId=1142,seqType=2,round=3,circle=3,poolId=178},
    [265] = {chainId=1143,seqType=2,round=1,circle=3,poolId=179},
    [266] = {chainId=1143,seqType=2,round=1,circle=3,poolId=180},
    [267] = {chainId=1143,seqType=2,round=2,circle=3,poolId=186},
    [268] = {chainId=1143,seqType=2,round=2,circle=3,poolId=180},
    [269] = {chainId=1143,seqType=2,round=2,circle=3,poolId=179},
    [270] = {chainId=1143,seqType=2,round=3,circle=3,poolId=179},
    [271] = {chainId=1143,seqType=2,round=3,circle=3,poolId=181},
    [272] = {chainId=1144,seqType=1,round=1,circle=2,poolId=182},
    [273] = {chainId=1144,seqType=1,round=1,circle=2,poolId=184},
    [274] = {chainId=1144,seqType=1,round=1,circle=2,poolId=183},
    [275] = {chainId=1144,seqType=2,round=1,circle=2,poolId=184},
    [276] = {chainId=1144,seqType=2,round=1,circle=2,poolId=183},
    [277] = {chainId=1144,seqType=2,round=2,circle=2,poolId=185},
    [278] = {chainId=1144,seqType=2,round=2,circle=2,poolId=183},
    [279] = {chainId=1145,seqType=2,round=1,circle=3,poolId=174},
    [280] = {chainId=1145,seqType=2,round=1,circle=3,poolId=177},
    [281] = {chainId=1145,seqType=2,round=1,circle=3,poolId=178},
    [282] = {chainId=1145,seqType=2,round=1,circle=3,poolId=187},
    [283] = {chainId=1145,seqType=2,round=1,circle=3,poolId=188},
    [284] = {chainId=1145,seqType=2,round=2,circle=3,poolId=174},
    [285] = {chainId=1145,seqType=2,round=2,circle=3,poolId=174},
    [286] = {chainId=1145,seqType=2,round=2,circle=3,poolId=177},
    [287] = {chainId=1145,seqType=2,round=2,circle=3,poolId=178},
    [288] = {chainId=1145,seqType=2,round=2,circle=3,poolId=188},
    [289] = {chainId=1145,seqType=2,round=3,circle=3,poolId=174},
    [290] = {chainId=1145,seqType=2,round=3,circle=3,poolId=177},
    [291] = {chainId=1145,seqType=2,round=3,circle=3,poolId=178},
    [292] = {chainId=1145,seqType=2,round=3,circle=3,poolId=188},
    [293] = {chainId=1146,seqType=2,round=1,circle=1,poolId=189},
    [294] = {chainId=1146,seqType=2,round=1,circle=1,poolId=190},
    [295] = {chainId=1146,seqType=2,round=1,circle=1,poolId=191},
    [296] = {chainId=1147,seqType=2,round=1,circle=1,poolId=192},
    [297] = {chainId=1147,seqType=2,round=1,circle=1,poolId=193},
    [298] = {chainId=1147,seqType=2,round=1,circle=1,poolId=193},
    [299] = {chainId=714,seqType=2,round=1,circle=1,poolId=194},
    [300] = {chainId=7592,seqType=1,round=1,circle=1,poolId=199},
    [301] = {chainId=7592,seqType=1,round=2,circle=1,poolId=196},
    [302] = {chainId=7592,seqType=1,round=3,circle=1,poolId=197},
    [303] = {chainId=7592,seqType=1,round=3,circle=1,poolId=198},
    [304] = {chainId=7592,seqType=1,round=4,circle=1,poolId=200},
    [305] = {chainId=7592,seqType=2,round=1,circle=3,poolId=195},
    [306] = {chainId=7592,seqType=2,round=2,circle=3,poolId=195},
    [307] = {chainId=7592,seqType=2,round=2,circle=3,poolId=195},
    [308] = {chainId=7592,seqType=2,round=3,circle=3,poolId=195},
    [309] = {chainId=21000,seqType=2,round=1,circle=1,poolId=170},
    [310] = {chainId=21000,seqType=2,round=1,circle=1,poolId=171},
    [311] = {chainId=21000,seqType=2,round=1,circle=1,poolId=170},
    [312] = {chainId=21000,seqType=2,round=1,circle=1,poolId=171},
    [313] = {chainId=200,seqType=2,round=1,circle=3,poolId=210},
    [314] = {chainId=200,seqType=2,round=2,circle=3,poolId=211},
    [315] = {chainId=200,seqType=2,round=3,circle=3,poolId=211},
    [316] = {chainId=1148,seqType=2,round=1,circle=4,poolId=212},
    [317] = {chainId=1148,seqType=2,round=2,circle=4,poolId=213},
    [318] = {chainId=1148,seqType=2,round=3,circle=4,poolId=214},
    [319] = {chainId=1148,seqType=2,round=4,circle=4,poolId=215},
    [320] = {chainId=1149,seqType=2,round=1,circle=3,poolId=151},
    [321] = {chainId=1149,seqType=2,round=2,circle=3,poolId=152},
    [322] = {chainId=1149,seqType=2,round=3,circle=3,poolId=216},
    [323] = {chainId=1150,seqType=2,round=1,circle=3,poolId=217},
    [324] = {chainId=1150,seqType=2,round=2,circle=3,poolId=218},
    [325] = {chainId=1150,seqType=2,round=3,circle=3,poolId=219},
    [326] = {chainId=1152,seqType=2,round=1,circle=3,poolId=220},
    [327] = {chainId=1152,seqType=2,round=2,circle=3,poolId=221},
    [328] = {chainId=1152,seqType=2,round=3,circle=3,poolId=222},
    [329] = {chainId=1154,seqType=2,round=1,circle=3,poolId=223},
    [330] = {chainId=1154,seqType=2,round=2,circle=3,poolId=224},
    [331] = {chainId=1154,seqType=2,round=3,circle=3,poolId=225},
    [332] = {chainId=1155,seqType=2,round=1,circle=3,poolId=226},
    [333] = {chainId=1155,seqType=2,round=2,circle=3,poolId=227},
    [334] = {chainId=1155,seqType=2,round=3,circle=3,poolId=228},
    [335] = {chainId=1151,seqType=2,round=1,circle=3,poolId=229},
    [336] = {chainId=1151,seqType=2,round=2,circle=3,poolId=230},
    [337] = {chainId=1151,seqType=2,round=3,circle=3,poolId=231},
    [338] = {chainId=1153,seqType=2,round=1,circle=3,poolId=232},
    [339] = {chainId=1153,seqType=2,round=2,circle=3,poolId=233},
    [340] = {chainId=1153,seqType=2,round=3,circle=3,poolId=234},
    [341] = {chainId=1156,seqType=2,round=1,circle=3,poolId=235},
    [342] = {chainId=1156,seqType=2,round=2,circle=3,poolId=236},
    [343] = {chainId=1156,seqType=2,round=3,circle=3,poolId=237},
    [344] = {chainId=500,seqType=1,round=1,circle=1,poolId=300},
    [345] = {chainId=500,seqType=1,round=2,circle=2,poolId=301},
    [346] = {chainId=500,seqType=1,round=3,circle=3,poolId=302},
    [347] = {chainId=500,seqType=1,round=4,circle=4,poolId=303},
    [348] = {chainId=500,seqType=2,round=2,circle=2,poolId=304},
    [349] = {chainId=500,seqType=2,round=3,circle=3,poolId=305},
    [350] = {chainId=500,seqType=2,round=1,circle=1,poolId=306},
    [351] = {chainId=501,seqType=1,round=1,circle=1,poolId=308},
    [352] = {chainId=501,seqType=1,round=2,circle=1,poolId=309},
    [353] = {chainId=501,seqType=1,round=3,circle=1,poolId=307},
    [354] = {chainId=501,seqType=2,round=1,circle=3,poolId=308},
    [355] = {chainId=501,seqType=2,round=2,circle=3,poolId=309},
    [356] = {chainId=501,seqType=2,round=3,circle=3,poolId=310},
}
local sequence = {}
local sequence_loaded = {}
local sequence_languages = {}

local function sequence_load(index)
    if index == nil then return nil end
    if sequence_loaded[index] then return sequence[index] end
    local source = sequence_source[index]
    if source == nil then return nil end
    local rowLanguage = sequence_languages[index] or nil
    local data = ConfigRowRuntime.Build(source,sequence_runtime_schema,"robot_chain_def",rowLanguage)
    sequence[index] = data
    sequence_loaded[index] = true
    return data
end

function robot_chain_def.sequence_index(index)
    return sequence_load(index)
end

function robot_chain_def.sequence_set(index,data)
    sequence[index] = data
    sequence_loaded[index] = true
end

function robot_chain_def.sequence_num()
    return sequence_num
end

local sequence_chainId =
{
    [1301]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16},[1031]={17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33},[1007]={34},[1032]={35,36,37,38,39,40,41,42,43,44,45},[1033]={46},[1034]={47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67},[1035]={68,69,70,71,72},[1036]={73,74,75,76,77,78},[1100]={79,80,81,82,83,84},[1101]={85,86,87,88,89,90},[1102]={91,92,93},[1103]={94,95,96,97,98,99,100},[1104]={101,102,103,104,105,106,107,108},[1105]={109,110},[1106]={111,112,113,114,115},[1107]={116,117,118,119,120,121,122,123,124,125,126,127,128},[1108]={129,130,131,132},[1109]={133,134,135,136},[1110]={137,138,139,140,141,142},[1111]={143,144,145,146},[1112]={147,148,149,150,151,152},[1113]={153,154,155},[1114]={156,157,158},[1115]={159,160,161,162,163},[1116]={164,165,166},[1117]={167},[1118]={168,169},[1119]={170},[1120]={171,172,173,174,175,176,177,178,179,180},[1121]={181,182,183,184,185,186},[1122]={187,188,189,190,191,192},[1123]={193,194,195,196},[1124]={197,198,199,200,201,202,203},[1125]={204,205,206,207,208,209,210,211,212,213},[1126]={214,215},[1129]={216,217,218,219},[1130]={220,221,222,223},[1131]={224,225},[1132]={226},[1133]={227},[1134]={228,229,230},[1135]={231,232},[1136]={233,234,235,236,237},[1137]={238,239,240},[1138]={241,242},[1139]={243,244},[1140]={245,246},[1141]={247,248},[1142]={249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264},[1143]={265,266,267,268,269,270,271},[1144]={272,273,274,275,276,277,278},[1145]={279,280,281,282,283,284,285,286,287,288,289,290,291,292},[1146]={293,294,295},[1147]={296,297,298},[714]={299},[7592]={300,301,302,303,304,305,306,307,308},[21000]={309,310,311,312},[200]={313,314,315},[1148]={316,317,318,319},[1149]={320,321,322},[1150]={323,324,325},[1152]={326,327,328},[1154]={329,330,331},[1155]={332,333,334},[1151]={335,336,337},[1153]={338,339,340},[1156]={341,342,343},[500]={344,345,346,347,348,349,350},[501]={351,352,353,354,355,356}
}

local sequence_chainId_data = {}
function robot_chain_def.sequence_chainId(key)
    if sequence_chainId_data[key] then
        return sequence_chainId_data[key]
    end
    local indexs = sequence_chainId[key]
    local datas = {}
    if indexs == nil then return datas end
    for _,index in ipairs(indexs) do
        table.insert(datas,robot_chain_def.sequence_index(index))
    end
    sequence_chainId_data[key] = datas
    return datas
end

local configSheets =
{
    ["config"] =
    {
        schema = config_schema,
        indexes =
        {
            { indexKey = "id", fields = {"id"}, fieldTypes = {"int"}, group = false },
            { indexKey = "poolId", fields = {"poolId"}, fieldTypes = {"int"}, group = true },
        },
    },
    ["sequence"] =
    {
        schema = sequence_schema,
        indexes =
        {
            { indexKey = "chainId", fields = {"chainId"}, fieldTypes = {"int"}, group = true },
        },
    },
}

local configSheetRuntimes =
{
    ["config"] =
    {
        getRows = function() return config_source end,
        getLanguages = function() return config_languages end,
        getSchema = function() return config_runtime_schema end,
        publish = function(rows,indexes,schema,languages)
            config_source = rows
            config_runtime_schema = schema or config_schema
            config_languages = languages or {}
            config = {}
            config_loaded = {}
            config_num = #rows
            config_id = indexes["id"] or {}
            config_poolId = indexes["poolId"] or {}
            config_poolId_data = {}
        end,
    },
    ["sequence"] =
    {
        getRows = function() return sequence_source end,
        getLanguages = function() return sequence_languages end,
        getSchema = function() return sequence_runtime_schema end,
        publish = function(rows,indexes,schema,languages)
            sequence_source = rows
            sequence_runtime_schema = schema or sequence_schema
            sequence_languages = languages or {}
            sequence = {}
            sequence_loaded = {}
            sequence_num = #rows
            sequence_chainId = indexes["chainId"] or {}
            sequence_chainId_data = {}
        end,
    },
}

local function BuildIndexKey(row,fields)
    if #fields == 1 then return row[fields[1]] end
    local values = {}
    for index,fieldName in ipairs(fields) do
        values[index] = tostring(row[fieldName])
    end
    return table.concat(values,"_")
end

local function BuildIndexKeyFromValue(value,fields)
    if #fields == 1 then return value end
    if type(value) ~= "table" or #value ~= #fields then return nil end
    local values = {}
    for index = 1,#fields do values[index] = tostring(value[index]) end
    return table.concat(values,"_")
end

local function ValidateRowsTable(rows)
    if type(rows) ~= "table" then return false,"配置行集合需要 table" end
    local count = 0
    for key in pairs(rows) do
        if type(key) ~= "number" or key < 1 or key % 1 ~= 0 then
            return false,string.format("配置行集合包含无效数组键[%s]",tostring(key))
        end
        count = count + 1
    end
    for index = 1,count do
        if rows[index] == nil then return false,string.format("配置行集合存在空洞[%s]",index) end
    end
    return true
end

local function GetIndexRule(info,installKey)
    local indexKey = nil
    if type(installKey) == "string" then
        indexKey = installKey
    elseif type(installKey) == "table" then
        local valid,err = ValidateRowsTable(installKey)
        if not valid then return nil,err end
        local fields = {}
        for index,fieldName in ipairs(installKey) do
            if type(fieldName) ~= "string" then return nil,string.format("installKey第%s项需要 string",index) end
            fields[index] = fieldName
        end
        indexKey = table.concat(fields,",")
    else
        return nil,string.format("installKey需要 string 或有序字段数组，实际为 %s",type(installKey))
    end
    for _,rule in ipairs(info.indexes) do
        if rule.indexKey == indexKey then return rule end
    end
    return nil,string.format("installKey未匹配现有查询索引[%s]",tostring(indexKey))
end

function robot_chain_def.GetSheetInfo(sheetName)
    return configSheets[sheetName]
end

function robot_chain_def.CaptureState(sheetName)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    return { rows = runtime.getRows(), languages = runtime.getLanguages(), schema = runtime.getSchema() }
end

function robot_chain_def.RestoreState(sheetName,state)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    if type(state) ~= "table" or type(state.rows) ~= "table" or type(state.languages) ~= "table" or type(state.schema) ~= "table" then
        return false,"配置快照无效"
    end
    local indexes,indexErr = robot_chain_def.BuildIndexes(sheetName,state.rows,true,state.schema)
    if indexes == nil then return false,indexErr end
    runtime.publish(state.rows,indexes,state.schema,state.languages)
    return true
end

function robot_chain_def.ValidateRow(sheetName,row,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return false,schemaErr end
    return ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
end

function robot_chain_def.BuildIndexes(sheetName,rows,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    local rowsValid,rowsErr = ValidateRowsTable(rows)
    if not rowsValid then return nil,rowsErr end
    local indexes = {}
    for _,rule in ipairs(info.indexes) do indexes[rule.indexKey] = {} end
    for index,row in ipairs(rows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",index,err) end
        for _,rule in ipairs(info.indexes) do
            local key = BuildIndexKey(row,rule.fields)
            local target = indexes[rule.indexKey]
            if rule.group then
                target[key] = target[key] or {}
                table.insert(target[key],index)
            else
                target[key] = index
            end
        end
    end
    return indexes
end

local function RemoveRowOwners(info,owners,row,rowIndex)
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local key = BuildIndexKey(row,rule.fields)
            local keyOwners = owners[rule.indexKey][key]
            if keyOwners ~= nil then
                for ownerIndex = #keyOwners,1,-1 do
                    if keyOwners[ownerIndex] == rowIndex then table.remove(keyOwners,ownerIndex) end
                end
                if #keyOwners == 0 then owners[rule.indexKey][key] = nil end
            end
        end
    end
end

local function ResolveNewRowConflicts(info,groupRule,rows,languages,newRowIndexes)
    local owners = {}
    local active = {}
    local isNew = {}
    local conflicts = {}
    for _,rowIndex in ipairs(newRowIndexes) do isNew[rowIndex] = true end
    for _,rule in ipairs(info.indexes) do if not rule.group then owners[rule.indexKey] = {} end end
    for rowIndex,row in ipairs(rows) do
        active[rowIndex] = true
        if not isNew[rowIndex] then
            for _,rule in ipairs(info.indexes) do
                if not rule.group then
                    local key = BuildIndexKey(row,rule.fields)
                    local keyOwners = owners[rule.indexKey][key] or {}
                    table.insert(keyOwners,rowIndex)
                    owners[rule.indexKey][key] = keyOwners
                end
            end
        end
    end
    for _,rowIndex in ipairs(newRowIndexes) do
        local row = rows[rowIndex]
        local removeIndexes = {}
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                local keyOwners = owners[rule.indexKey][key]
                if keyOwners ~= nil then
                    for _,oldIndex in ipairs(keyOwners) do
                        if active[oldIndex] then
                            removeIndexes[oldIndex] = true
                            table.insert(conflicts,{
                                indexKey = rule.indexKey,
                                key = key,
                                oldIndex = oldIndex,
                                newIndex = rowIndex,
                                oldGroupKey = BuildIndexKey(rows[oldIndex],groupRule.fields),
                                newGroupKey = BuildIndexKey(row,groupRule.fields),
                            })
                        end
                    end
                end
            end
        end
        for oldIndex in pairs(removeIndexes) do
            active[oldIndex] = false
            RemoveRowOwners(info,owners,rows[oldIndex],oldIndex)
        end
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                owners[rule.indexKey][key] = {rowIndex}
            end
        end
    end
    local result = {}
    local resultLanguages = {}
    for rowIndex,row in ipairs(rows) do
        if active[rowIndex] then
            table.insert(result,row)
            table.insert(resultLanguages,languages[rowIndex] or false)
        end
    end
    return result,resultLanguages,conflicts
end

local function CollectAppendConflicts(info,currentCount,rows)
    local conflicts = {}
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local latest = {}
            for rowIndex,row in ipairs(rows) do
                local key = BuildIndexKey(row,rule.fields)
                local oldIndex = latest[key]
                if rowIndex > currentCount and oldIndex ~= nil then
                    table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=oldIndex,newIndex=rowIndex})
                end
                latest[key] = rowIndex
            end
        end
    end
    return conflicts
end

function robot_chain_def.ApplyBatch(sheetName,batch,allowUnknown,schemaOverride,rowLanguage)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local runtime = configSheetRuntimes[sheetName]
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    if type(batch) ~= "table" then return nil,"配置批次需要 table" end
    for key in pairs(batch) do
        if key ~= "installKey" and key ~= "installValue" and key ~= "operation" and key ~= "rows" then
            return nil,string.format("配置批次包含未知字段[%s]",tostring(key))
        end
    end
    local newRows = batch.rows
    local rowsValid,rowsErr = ValidateRowsTable(newRows)
    if not rowsValid then return nil,rowsErr end
    for rowIndex,row in ipairs(newRows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",rowIndex,err) end
    end
    local warnings = {}
    if #newRows == 0 and batch.installKey == nil then
        return { operation = "append", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} }
    end
    local currentRows = runtime.getRows()
    local currentLanguages = runtime.getLanguages()
    local candidateRows = {}
    local candidateLanguages = {}
    local newRowIndexes = {}
    if batch.installKey == nil then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"无 installKey 批次不能声明 installValue/operation" end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
        end
        local indexes,indexErr = robot_chain_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        local conflicts = CollectAppendConflicts(info,#currentRows,candidateRows)
        if #conflicts > 0 then table.insert(warnings,string.format("无 installKey 追加产生 %s 个普通查询键冲突；后写结果生效",#conflicts)) end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "append", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    local rule,ruleErr = GetIndexRule(info,batch.installKey)
    if rule == nil then return nil,ruleErr end
    if not rule.group then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"普通 upsert 不能声明 installValue/operation" end
        if #newRows == 0 then return { operation = "upsert", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} } end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        local conflicts = {}
        for _,newRow in ipairs(newRows) do
            local key = BuildIndexKey(newRow,rule.fields)
            local matched = {}
            for rowIndex,oldRow in ipairs(candidateRows) do
                if BuildIndexKey(oldRow,rule.fields) == key then table.insert(matched,rowIndex) end
            end
            if #matched > 1 then return nil,string.format("安装身份歧义[index:%s][key:%s][rows:%s]",rule.indexKey,tostring(key),table.concat(matched,",")) end
            if #matched == 1 then
                table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=matched[1],newIndex=matched[1]})
                candidateRows[matched[1]] = newRow
                candidateLanguages[matched[1]] = rowLanguage or false
            else
                table.insert(candidateRows,newRow)
                table.insert(candidateLanguages,rowLanguage or false)
            end
        end
        local indexes,indexErr = robot_chain_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "upsert", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    if batch.installValue == nil then return nil,"组批次缺少 installValue" end
    local groupKey = BuildIndexKeyFromValue(batch.installValue,rule.fields)
    if groupKey == nil then return nil,"installValue 与组查询字段不匹配" end
    local operation = batch.operation or "replace"
    if operation ~= "replace" and operation ~= "append" then return nil,string.format("无效组操作[%s]",tostring(operation)) end
    for rowIndex,row in ipairs(newRows) do
        local rowGroupKey = BuildIndexKey(row,rule.fields)
        if rowGroupKey ~= groupKey then return nil,string.format("组键不一致[目标:%s][第%s行:%s]",tostring(groupKey),rowIndex,tostring(rowGroupKey)) end
    end
    if operation == "append" and #newRows == 0 then return { operation = operation, groupKey = groupKey, rows = runtime.getRows(), warnings = {"空组 append 未修改配置"}, conflicts = {} } end
    local firstGroupIndex = nil
    local oldGroupCount = 0
    if operation == "replace" then
        for rowIndex,row in ipairs(currentRows) do
            if BuildIndexKey(row,rule.fields) == groupKey then
                oldGroupCount = oldGroupCount + 1
                if firstGroupIndex == nil then firstGroupIndex = #candidateRows + 1 end
            else
                table.insert(candidateRows,row)
                table.insert(candidateLanguages,currentLanguages[rowIndex] or false)
            end
        end
        local insertIndex = firstGroupIndex or (#candidateRows + 1)
        for offset,row in ipairs(newRows) do
            table.insert(candidateRows,insertIndex + offset - 1,row)
            table.insert(candidateLanguages,insertIndex + offset - 1,rowLanguage or false)
        end
        for offset = 1,#newRows do table.insert(newRowIndexes,insertIndex + offset - 1) end
    else
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
            table.insert(newRowIndexes,#candidateRows)
        end
    end
    if operation == "replace" and oldGroupCount == 0 and #newRows == 0 then table.insert(warnings,"清空不存在的组未修改配置") end
    local resultRows,resultLanguages,conflicts = ResolveNewRowConflicts(info,rule,candidateRows,candidateLanguages,newRowIndexes)
    local indexes,indexErr = robot_chain_def.BuildIndexes(sheetName,resultRows,allowUnknown,schemaOverride)
    if indexes == nil then return nil,indexErr end
    runtime.publish(resultRows,indexes,schema,resultLanguages)
    return { operation = operation, groupKey = groupKey, rows = resultRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
end

local sheetFunc = 
{
    ["config"] = 
    {
        ["index"] = "config_index",
        ["@num"] = "config_num",
        ["@set"] = "config_set",
        ["id"] = "config_id",
        ["poolId"] = "config_poolId",
    },

    ["sequence"] = 
    {
        ["index"] = "sequence_index",
        ["@num"] = "sequence_num",
        ["@set"] = "sequence_set",
        ["chainId"] = "sequence_chainId",
    },
}

function robot_chain_def.Get(sheetName,keyIndex,key)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return nil,1 end
    local funName = funcIndexs[keyIndex]
    if not funName then return nil,2 end
    return robot_chain_def[funName](key),nil
end

function robot_chain_def.Set(sheetName,index,data)
    if index == nil then return false end
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return false end
    local funName = funcIndexs["@set"]
    robot_chain_def[funName](index,data)
    return true
end

function robot_chain_def.GetNum(sheetName)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return 0 end
    local funName = funcIndexs["@num"]
    return robot_chain_def[funName]()
end

return robot_chain_def