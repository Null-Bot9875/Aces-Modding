local robot_def = {}
local ConfigRowRuntime = require("common/config/ConfigRowRuntime")
local language = Language.Instance

--config
local config_num = 159
local config_schema =
{
    ["id"] = { type = "int" },
    ["name"] = { type = "string", i18n = true },
    ["groupId"] = { type = "int" },
    ["baseId"] = { type = "int" },
    ["chainId"] = { type = "int" },
    ["newCards"] = { type = "int" },
    ["noSuffle"] = { type = "int" },
    ["roundAction"] = { type = "int" },
    ["noCardCheck"] = { type = "int" },
    ["roomRobot"] = { type = "int" },
    ["robotType"] = { type = "int" },
}
local config_runtime_schema = config_schema
local config_source =
{
    [1] = {id=1,name="白矮星",groupId=1,baseId=101,chainId=0,newCards=2,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=2},
    [2] = {id=2,name="薮猫",groupId=1,baseId=102,chainId=0,newCards=1,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=2},
    [3] = {id=3,name="猎户座",groupId=1,baseId=103,chainId=0,newCards=1,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=2},
    [4] = {id=4,name="特里格拉夫",groupId=1,baseId=104,chainId=0,newCards=1,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=2},
    [5] = {id=301,name="猎户座",groupId=0,baseId=301,chainId=1031,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [6] = {id=302,name="民间私人武装",groupId=0,baseId=302,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [7] = {id=303,name="不明测试机构",groupId=0,baseId=303,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [8] = {id=304,name="白矮星黑化",groupId=0,baseId=304,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [9] = {id=305,name="监控站",groupId=0,baseId=305,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [10] = {id=306,name="监控站2",groupId=0,baseId=306,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [11] = {id=308,name="猎户座",groupId=0,baseId=301,chainId=1032,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=3},
    [12] = {id=309,name="赝波",groupId=0,baseId=308,chainId=1033,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=3},
    [13] = {id=310,name="猎户座",groupId=0,baseId=301,chainId=1034,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=3},
    [14] = {id=311,name="指挥伪装枢纽",groupId=0,baseId=306,chainId=1035,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [15] = {id=312,name="特里格拉夫",groupId=0,baseId=309,chainId=1036,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [16] = {id=350,name="监控站",groupId=0,baseId=305,chainId=1100,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [17] = {id=351,name="监控站2",groupId=0,baseId=306,chainId=1101,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [18] = {id=352,name="不明测试机构",groupId=0,baseId=303,chainId=1102,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [19] = {id=358,name="特里格拉夫",groupId=0,baseId=309,chainId=1103,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [20] = {id=359,name="猎户座",groupId=0,baseId=301,chainId=1104,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=3},
    [21] = {id=362,name="白鸟",groupId=0,baseId=319,chainId=1107,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [22] = {id=364,name="猎户座",groupId=0,baseId=320,chainId=1109,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=3},
    [23] = {id=376,name="特里格拉夫",groupId=0,baseId=339,chainId=1121,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [24] = {id=377,name="猎户座",groupId=0,baseId=340,chainId=1122,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=3},
    [25] = {id=378,name="特里格拉夫",groupId=0,baseId=339,chainId=1123,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [26] = {id=379,name="薮猫",groupId=0,baseId=341,chainId=1101,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [27] = {id=380,name="十字星的残响",groupId=0,baseId=342,chainId=1124,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [28] = {id=382,name="追击者",groupId=0,baseId=344,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [29] = {id=383,name="通讯船",groupId=0,baseId=345,chainId=1126,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [30] = {id=384,name="白鸟",groupId=0,baseId=346,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [31] = {id=511,name="白矮星",groupId=0,baseId=511,chainId=1142,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [32] = {id=512,name="薮猫",groupId=0,baseId=512,chainId=1143,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [33] = {id=513,name="特里格拉夫",groupId=0,baseId=513,chainId=1144,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [34] = {id=514,name="自成长核心",groupId=0,baseId=514,chainId=1129,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [35] = {id=515,name="战术型核心",groupId=0,baseId=515,chainId=1130,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [36] = {id=516,name="魔王型核心",groupId=0,baseId=516,chainId=1131,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [37] = {id=517,name="传递枪手",groupId=0,baseId=517,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [38] = {id=518,name="侧袭型核心",groupId=0,baseId=518,chainId=1132,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [39] = {id=519,name="被动型核心",groupId=0,baseId=519,chainId=1133,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [40] = {id=520,name="多米诺核心",groupId=0,baseId=520,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [41] = {id=521,name="爆炸队核心",groupId=0,baseId=521,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [42] = {id=522,name="UGM47",groupId=0,baseId=522,chainId=1134,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [43] = {id=523,name="UGM46",groupId=0,baseId=523,chainId=1135,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [44] = {id=524,name="指挥船",groupId=0,baseId=524,chainId=1136,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [45] = {id=525,name="通讯船",groupId=0,baseId=525,chainId=1137,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [46] = {id=526,name="猎户座",groupId=0,baseId=526,chainId=1140,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [47] = {id=527,name="黑洞",groupId=0,baseId=527,chainId=1141,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [48] = {id=528,name="防御中枢",groupId=0,baseId=528,chainId=1138,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [49] = {id=529,name="火力中枢",groupId=0,baseId=529,chainId=1139,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [50] = {id=530,name="初始灾祸",groupId=0,baseId=530,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [51] = {id=531,name="猎户座",groupId=2,baseId=603,chainId=0,newCards=2,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=2},
    [52] = {id=532,name="白矮星",groupId=1,baseId=601,chainId=0,newCards=2,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=2},
    [53] = {id=600,name="展会-白矮星",groupId=0,baseId=511,chainId=1145,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [54] = {id=601,name="展会-薮猫",groupId=0,baseId=512,chainId=1143,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [55] = {id=602,name="展会-特里格拉夫",groupId=0,baseId=513,chainId=1144,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [56] = {id=999,name="???",groupId=2,baseId=603,chainId=0,newCards=2,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=2},
    [57] = {id=614,name="枷锁囚徒",groupId=0,baseId=614,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [58] = {id=615,name="将军",groupId=0,baseId=615,chainId=1146,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [59] = {id=616,name="电子战中枢",groupId=0,baseId=616,chainId=1147,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [60] = {id=617,name="加姆",groupId=617,baseId=617,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [61] = {id=618,name="飞骑兵",groupId=618,baseId=618,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [62] = {id=619,name="斯库尔",groupId=619,baseId=619,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [63] = {id=620,name="空域捕手",groupId=620,baseId=620,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [64] = {id=621,name="腐柯",groupId=621,baseId=621,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [65] = {id=622,name="阵列兵器",groupId=622,baseId=622,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [66] = {id=700,name="琉璃光",groupId=700,baseId=700,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [67] = {id=701,name="薮猫",groupId=701,baseId=701,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [68] = {id=702,name="薮猫",groupId=702,baseId=702,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [69] = {id=703,name="特里格拉夫-暴君",groupId=703,baseId=703,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [70] = {id=704,name="猎户座-海盗之王",groupId=704,baseId=704,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [71] = {id=708,name="十字星-掠影",groupId=708,baseId=708,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [72] = {id=709,name="大将军",groupId=709,baseId=709,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [73] = {id=710,name="白鸟",groupId=710,baseId=710,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [74] = {id=711,name="薮猫",groupId=711,baseId=711,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [75] = {id=712,name="拳击手",groupId=0,baseId=712,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [76] = {id=713,name="定锚观测机",groupId=713,baseId=713,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [77] = {id=714,name="巨人",groupId=0,baseId=714,chainId=714,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [78] = {id=715,name="黑矮星",groupId=715,baseId=715,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=1,robotType=2},
    [79] = {id=716,name="UGM-46-将军",groupId=716,baseId=716,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [80] = {id=717,name="UGM-46-背水",groupId=717,baseId=716,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [81] = {id=718,name="UGM-47-堡垒",groupId=718,baseId=717,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [82] = {id=719,name="UGM-47-热射线",groupId=719,baseId=717,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [83] = {id=720,name="指挥船",groupId=720,baseId=720,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [84] = {id=721,name="指挥船-储卡型",groupId=721,baseId=721,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [85] = {id=722,name="法斯特-均衡型",groupId=722,baseId=722,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [86] = {id=723,name="法斯特-巨炮型",groupId=723,baseId=722,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [87] = {id=7231,name="UGM46-将军",groupId=7231,baseId=723,chainId=0,newCards=3,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [88] = {id=7232,name="UGM46-背水",groupId=7232,baseId=723,chainId=0,newCards=3,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [89] = {id=7241,name="UGM46-强能",groupId=7241,baseId=724,chainId=0,newCards=3,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [90] = {id=7242,name="UGM46-坚盾",groupId=7242,baseId=724,chainId=0,newCards=3,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [91] = {id=7243,name="UGM46-战将",groupId=7243,baseId=724,chainId=0,newCards=3,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [92] = {id=7251,name="UGM47-堡垒",groupId=7251,baseId=725,chainId=0,newCards=3,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [93] = {id=7252,name="UGM47-热射线",groupId=7252,baseId=725,chainId=0,newCards=3,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [94] = {id=7261,name="阿尔法法斯特-加姆",groupId=7261,baseId=726,chainId=0,newCards=2,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [95] = {id=7262,name="阿尔法法斯特-囚徒",groupId=7262,baseId=726,chainId=0,newCards=2,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [96] = {id=7271,name="火萤搭载机",groupId=7271,baseId=727,chainId=0,newCards=2,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [97] = {id=7281,name="蜻蜓（八尺玉）",groupId=7281,baseId=728,chainId=0,newCards=2,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [98] = {id=7291,name="通讯船",groupId=7291,baseId=729,chainId=0,newCards=2,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [99] = {id=7301,name="通讯船指挥官型",groupId=7301,baseId=730,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [100] = {id=7311,name="白矮星",groupId=7311,baseId=731,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [101] = {id=7321,name="薮猫",groupId=7321,baseId=732,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [102] = {id=7322,name="薮猫",groupId=7322,baseId=732,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [103] = {id=7331,name="猎户座",groupId=7331,baseId=733,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [104] = {id=7341,name="特里格拉夫",groupId=7341,baseId=734,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [105] = {id=7351,name="黑洞",groupId=7351,baseId=735,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [106] = {id=7361,name="白洞",groupId=7361,baseId=736,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [107] = {id=7371,name="伊米尔改-万众",groupId=7371,baseId=737,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [108] = {id=7372,name="伊米尔改-一心",groupId=7372,baseId=737,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [109] = {id=7373,name="伊米尔改",groupId=7373,baseId=737,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=1,robotType=2},
    [110] = {id=7381,name="白鸟-屏息",groupId=7381,baseId=738,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [111] = {id=7382,name="白鸟-虚像",groupId=7382,baseId=738,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [112] = {id=7391,name="日晷",groupId=7391,baseId=739,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [113] = {id=7401,name="赝波-空域捕手",groupId=7401,baseId=740,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [114] = {id=7402,name="赝波-飞骑兵",groupId=7402,baseId=740,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [115] = {id=7411,name="追猎者",groupId=7411,baseId=741,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [116] = {id=7421,name="黑矮星",groupId=7421,baseId=742,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [117] = {id=7431,name="十字星",groupId=7431,baseId=743,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=1,robotType=2},
    [118] = {id=7441,name="极境",groupId=7441,baseId=744,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [119] = {id=7442,name="极境",groupId=7442,baseId=744,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=1,robotType=2},
    [120] = {id=7501,name="决战型作战核心",groupId=7501,baseId=750,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [121] = {id=7511,name="主管无人机",groupId=7511,baseId=751,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [122] = {id=7521,name="轨道弹射舰",groupId=7521,baseId=752,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [123] = {id=7531,name="γ巨人",groupId=7531,baseId=753,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [124] = {id=7541,name="电磁主宰",groupId=7541,baseId=754,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [125] = {id=7551,name="白矮星-鸣响",groupId=7551,baseId=755,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [126] = {id=7561,name="猎户座-狂热",groupId=7561,baseId=756,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [127] = {id=7571,name="白鸟-渐隐",groupId=7571,baseId=757,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [128] = {id=7581,name="猎户座-决斗",groupId=7581,baseId=758,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [129] = {id=7591,name="伊米尔改-龙",groupId=7591,baseId=759,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [130] = {id=7592,name="伊米尔改",groupId=0,baseId=760,chainId=7592,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [131] = {id=1000,name="ACE-003 猎户座",groupId=0,baseId=2100,chainId=21000,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=1,robotType=2},
    [132] = {id=1001,name="薮猫",groupId=7321,baseId=2101,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=1,robotType=2},
    [133] = {id=1002,name="特里格拉夫",groupId=7341,baseId=2102,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=1,robotType=2},
    [134] = {id=7611,name="多米诺核心",groupId=0,baseId=761,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [135] = {id=7612,name="多米诺核心",groupId=0,baseId=761,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [136] = {id=7621,name="多米诺核心",groupId=0,baseId=762,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [137] = {id=7622,name="多米诺核心",groupId=0,baseId=762,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [138] = {id=5261,name="黑洞",groupId=7351,baseId=7351,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [139] = {id=5271,name="白洞",groupId=7361,baseId=7361,chainId=0,newCards=4,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [140] = {id=7362,name="装甲堡垒",groupId=0,baseId=7362,chainId=0,newCards=3,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [141] = {id=7363,name="连击核心",groupId=0,baseId=7363,chainId=0,newCards=3,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [142] = {id=7364,name="穿甲炮台",groupId=7860,baseId=7364,chainId=0,newCards=3,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [143] = {id=7365,name="商会执行官",groupId=7861,baseId=7365,chainId=0,newCards=3,noSuffle=0,roundAction=-1,noCardCheck=1,roomRobot=0,robotType=2},
    [144] = {id=31001,name="自成长核心",groupId=0,baseId=7366,chainId=1148,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [145] = {id=31002,name="魔王型核心",groupId=0,baseId=7367,chainId=1149,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [146] = {id=31003,name="STX-26",groupId=0,baseId=7368,chainId=1150,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [147] = {id=31005,name="指挥船",groupId=0,baseId=7370,chainId=1152,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [148] = {id=31007,name="防御中枢",groupId=0,baseId=7372,chainId=1154,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [149] = {id=31008,name="火力中枢",groupId=0,baseId=7373,chainId=1155,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [150] = {id=31004,name="UGM46",groupId=0,baseId=7369,chainId=1151,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [151] = {id=31006,name="通讯船",groupId=0,baseId=7371,chainId=1153,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [152] = {id=31009,name="电子战中枢",groupId=0,baseId=7374,chainId=1156,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [153] = {id=11001,name="日晷",groupId=0,baseId=7375,chainId=500,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [154] = {id=11002,name="废料处理机“饰带”",groupId=0,baseId=7377,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [155] = {id=11003,name="UGM-46 干扰者",groupId=0,baseId=7378,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [156] = {id=11004,name="CEF-102 扫除者",groupId=0,baseId=7380,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [157] = {id=12001,name="UGM-47 干扰者改进型",groupId=0,baseId=7379,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [158] = {id=13001,name="ACE-003 猎户座",groupId=0,baseId=7376,chainId=0,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
    [159] = {id=33001,name="归来的猎户座",groupId=0,baseId=7381,chainId=501,newCards=0,noSuffle=0,roundAction=-1,noCardCheck=2,roomRobot=0,robotType=1},
}
local config = {}
local config_loaded = {}
local config_languages = {}

local function config_load(index)
    if index == nil then return nil end
    if config_loaded[index] then return config[index] end
    local source = config_source[index]
    if source == nil then return nil end
    local rowLanguage = config_languages[index] or language
    local data = ConfigRowRuntime.Build(source,config_runtime_schema,"robot_def",rowLanguage)
    config[index] = data
    config_loaded[index] = true
    return data
end

function robot_def.config_index(index)
    return config_load(index)
end

function robot_def.config_set(index,data)
    config[index] = data
    config_loaded[index] = true
end

function robot_def.config_num()
    return config_num
end

local config_id =
{
    [1]=1,[2]=2,[3]=3,[4]=4,[301]=5,[302]=6,[303]=7,[304]=8,[305]=9,[306]=10,[308]=11,[309]=12,[310]=13,[311]=14,[312]=15,[350]=16,[351]=17,[352]=18,[358]=19,[359]=20,[362]=21,[364]=22,[376]=23,[377]=24,[378]=25,[379]=26,[380]=27,[382]=28,[383]=29,[384]=30,[511]=31,[512]=32,[513]=33,[514]=34,[515]=35,[516]=36,[517]=37,[518]=38,[519]=39,[520]=40,[521]=41,[522]=42,[523]=43,[524]=44,[525]=45,[526]=46,[527]=47,[528]=48,[529]=49,[530]=50,[531]=51,[532]=52,[600]=53,[601]=54,[602]=55,[999]=56,[614]=57,[615]=58,[616]=59,[617]=60,[618]=61,[619]=62,[620]=63,[621]=64,[622]=65,[700]=66,[701]=67,[702]=68,[703]=69,[704]=70,[708]=71,[709]=72,[710]=73,[711]=74,[712]=75,[713]=76,[714]=77,[715]=78,[716]=79,[717]=80,[718]=81,[719]=82,[720]=83,[721]=84,[722]=85,[723]=86,[7231]=87,[7232]=88,[7241]=89,[7242]=90,[7243]=91,[7251]=92,[7252]=93,[7261]=94,[7262]=95,[7271]=96,[7281]=97,[7291]=98,[7301]=99,[7311]=100,[7321]=101,[7322]=102,[7331]=103,[7341]=104,[7351]=105,[7361]=106,[7371]=107,[7372]=108,[7373]=109,[7381]=110,[7382]=111,[7391]=112,[7401]=113,[7402]=114,[7411]=115,[7421]=116,[7431]=117,[7441]=118,[7442]=119,[7501]=120,[7511]=121,[7521]=122,[7531]=123,[7541]=124,[7551]=125,[7561]=126,[7571]=127,[7581]=128,[7591]=129,[7592]=130,[1000]=131,[1001]=132,[1002]=133,[7611]=134,[7612]=135,[7621]=136,[7622]=137,[5261]=138,[5271]=139,[7362]=140,[7363]=141,[7364]=142,[7365]=143,[31001]=144,[31002]=145,[31003]=146,[31005]=147,[31007]=148,[31008]=149,[31004]=150,[31006]=151,[31009]=152,[11001]=153,[11002]=154,[11003]=155,[11004]=156,[12001]=157,[13001]=158,[33001]=159
}

function robot_def.config_id(key)
    local index = config_id[key]
    return robot_def.config_index(index)
end

local configSheets =
{
    ["config"] =
    {
        schema = config_schema,
        indexes =
        {
            { indexKey = "id", fields = {"id"}, fieldTypes = {"int"}, group = false },
        },
    },
}

local configSheetRuntimes =
{
    ["config"] =
    {
        getRows = function() return config_source end,
        getLanguages = function() return config_languages end,
        getSchema = function() return config_runtime_schema end,
        publish = function(rows,indexes,schema,languages)
            config_source = rows
            config_runtime_schema = schema or config_schema
            config_languages = languages or {}
            config = {}
            config_loaded = {}
            config_num = #rows
            config_id = indexes["id"] or {}
        end,
    },
}

local function BuildIndexKey(row,fields)
    if #fields == 1 then return row[fields[1]] end
    local values = {}
    for index,fieldName in ipairs(fields) do
        values[index] = tostring(row[fieldName])
    end
    return table.concat(values,"_")
end

local function BuildIndexKeyFromValue(value,fields)
    if #fields == 1 then return value end
    if type(value) ~= "table" or #value ~= #fields then return nil end
    local values = {}
    for index = 1,#fields do values[index] = tostring(value[index]) end
    return table.concat(values,"_")
end

local function ValidateRowsTable(rows)
    if type(rows) ~= "table" then return false,"配置行集合需要 table" end
    local count = 0
    for key in pairs(rows) do
        if type(key) ~= "number" or key < 1 or key % 1 ~= 0 then
            return false,string.format("配置行集合包含无效数组键[%s]",tostring(key))
        end
        count = count + 1
    end
    for index = 1,count do
        if rows[index] == nil then return false,string.format("配置行集合存在空洞[%s]",index) end
    end
    return true
end

local function GetIndexRule(info,installKey)
    local indexKey = nil
    if type(installKey) == "string" then
        indexKey = installKey
    elseif type(installKey) == "table" then
        local valid,err = ValidateRowsTable(installKey)
        if not valid then return nil,err end
        local fields = {}
        for index,fieldName in ipairs(installKey) do
            if type(fieldName) ~= "string" then return nil,string.format("installKey第%s项需要 string",index) end
            fields[index] = fieldName
        end
        indexKey = table.concat(fields,",")
    else
        return nil,string.format("installKey需要 string 或有序字段数组，实际为 %s",type(installKey))
    end
    for _,rule in ipairs(info.indexes) do
        if rule.indexKey == indexKey then return rule end
    end
    return nil,string.format("installKey未匹配现有查询索引[%s]",tostring(indexKey))
end

function robot_def.GetSheetInfo(sheetName)
    return configSheets[sheetName]
end

function robot_def.CaptureState(sheetName)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    return { rows = runtime.getRows(), languages = runtime.getLanguages(), schema = runtime.getSchema() }
end

function robot_def.RestoreState(sheetName,state)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    if type(state) ~= "table" or type(state.rows) ~= "table" or type(state.languages) ~= "table" or type(state.schema) ~= "table" then
        return false,"配置快照无效"
    end
    local indexes,indexErr = robot_def.BuildIndexes(sheetName,state.rows,true,state.schema)
    if indexes == nil then return false,indexErr end
    runtime.publish(state.rows,indexes,state.schema,state.languages)
    return true
end

function robot_def.ValidateRow(sheetName,row,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return false,schemaErr end
    return ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
end

function robot_def.BuildIndexes(sheetName,rows,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    local rowsValid,rowsErr = ValidateRowsTable(rows)
    if not rowsValid then return nil,rowsErr end
    local indexes = {}
    for _,rule in ipairs(info.indexes) do indexes[rule.indexKey] = {} end
    for index,row in ipairs(rows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",index,err) end
        for _,rule in ipairs(info.indexes) do
            local key = BuildIndexKey(row,rule.fields)
            local target = indexes[rule.indexKey]
            if rule.group then
                target[key] = target[key] or {}
                table.insert(target[key],index)
            else
                target[key] = index
            end
        end
    end
    return indexes
end

local function RemoveRowOwners(info,owners,row,rowIndex)
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local key = BuildIndexKey(row,rule.fields)
            local keyOwners = owners[rule.indexKey][key]
            if keyOwners ~= nil then
                for ownerIndex = #keyOwners,1,-1 do
                    if keyOwners[ownerIndex] == rowIndex then table.remove(keyOwners,ownerIndex) end
                end
                if #keyOwners == 0 then owners[rule.indexKey][key] = nil end
            end
        end
    end
end

local function ResolveNewRowConflicts(info,groupRule,rows,languages,newRowIndexes)
    local owners = {}
    local active = {}
    local isNew = {}
    local conflicts = {}
    for _,rowIndex in ipairs(newRowIndexes) do isNew[rowIndex] = true end
    for _,rule in ipairs(info.indexes) do if not rule.group then owners[rule.indexKey] = {} end end
    for rowIndex,row in ipairs(rows) do
        active[rowIndex] = true
        if not isNew[rowIndex] then
            for _,rule in ipairs(info.indexes) do
                if not rule.group then
                    local key = BuildIndexKey(row,rule.fields)
                    local keyOwners = owners[rule.indexKey][key] or {}
                    table.insert(keyOwners,rowIndex)
                    owners[rule.indexKey][key] = keyOwners
                end
            end
        end
    end
    for _,rowIndex in ipairs(newRowIndexes) do
        local row = rows[rowIndex]
        local removeIndexes = {}
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                local keyOwners = owners[rule.indexKey][key]
                if keyOwners ~= nil then
                    for _,oldIndex in ipairs(keyOwners) do
                        if active[oldIndex] then
                            removeIndexes[oldIndex] = true
                            table.insert(conflicts,{
                                indexKey = rule.indexKey,
                                key = key,
                                oldIndex = oldIndex,
                                newIndex = rowIndex,
                                oldGroupKey = BuildIndexKey(rows[oldIndex],groupRule.fields),
                                newGroupKey = BuildIndexKey(row,groupRule.fields),
                            })
                        end
                    end
                end
            end
        end
        for oldIndex in pairs(removeIndexes) do
            active[oldIndex] = false
            RemoveRowOwners(info,owners,rows[oldIndex],oldIndex)
        end
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                owners[rule.indexKey][key] = {rowIndex}
            end
        end
    end
    local result = {}
    local resultLanguages = {}
    for rowIndex,row in ipairs(rows) do
        if active[rowIndex] then
            table.insert(result,row)
            table.insert(resultLanguages,languages[rowIndex] or false)
        end
    end
    return result,resultLanguages,conflicts
end

local function CollectAppendConflicts(info,currentCount,rows)
    local conflicts = {}
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local latest = {}
            for rowIndex,row in ipairs(rows) do
                local key = BuildIndexKey(row,rule.fields)
                local oldIndex = latest[key]
                if rowIndex > currentCount and oldIndex ~= nil then
                    table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=oldIndex,newIndex=rowIndex})
                end
                latest[key] = rowIndex
            end
        end
    end
    return conflicts
end

function robot_def.ApplyBatch(sheetName,batch,allowUnknown,schemaOverride,rowLanguage)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local runtime = configSheetRuntimes[sheetName]
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    if type(batch) ~= "table" then return nil,"配置批次需要 table" end
    for key in pairs(batch) do
        if key ~= "installKey" and key ~= "installValue" and key ~= "operation" and key ~= "rows" then
            return nil,string.format("配置批次包含未知字段[%s]",tostring(key))
        end
    end
    local newRows = batch.rows
    local rowsValid,rowsErr = ValidateRowsTable(newRows)
    if not rowsValid then return nil,rowsErr end
    for rowIndex,row in ipairs(newRows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",rowIndex,err) end
    end
    local warnings = {}
    if #newRows == 0 and batch.installKey == nil then
        return { operation = "append", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} }
    end
    local currentRows = runtime.getRows()
    local currentLanguages = runtime.getLanguages()
    local candidateRows = {}
    local candidateLanguages = {}
    local newRowIndexes = {}
    if batch.installKey == nil then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"无 installKey 批次不能声明 installValue/operation" end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
        end
        local indexes,indexErr = robot_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        local conflicts = CollectAppendConflicts(info,#currentRows,candidateRows)
        if #conflicts > 0 then table.insert(warnings,string.format("无 installKey 追加产生 %s 个普通查询键冲突；后写结果生效",#conflicts)) end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "append", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    local rule,ruleErr = GetIndexRule(info,batch.installKey)
    if rule == nil then return nil,ruleErr end
    if not rule.group then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"普通 upsert 不能声明 installValue/operation" end
        if #newRows == 0 then return { operation = "upsert", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} } end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        local conflicts = {}
        for _,newRow in ipairs(newRows) do
            local key = BuildIndexKey(newRow,rule.fields)
            local matched = {}
            for rowIndex,oldRow in ipairs(candidateRows) do
                if BuildIndexKey(oldRow,rule.fields) == key then table.insert(matched,rowIndex) end
            end
            if #matched > 1 then return nil,string.format("安装身份歧义[index:%s][key:%s][rows:%s]",rule.indexKey,tostring(key),table.concat(matched,",")) end
            if #matched == 1 then
                table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=matched[1],newIndex=matched[1]})
                candidateRows[matched[1]] = newRow
                candidateLanguages[matched[1]] = rowLanguage or false
            else
                table.insert(candidateRows,newRow)
                table.insert(candidateLanguages,rowLanguage or false)
            end
        end
        local indexes,indexErr = robot_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "upsert", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    if batch.installValue == nil then return nil,"组批次缺少 installValue" end
    local groupKey = BuildIndexKeyFromValue(batch.installValue,rule.fields)
    if groupKey == nil then return nil,"installValue 与组查询字段不匹配" end
    local operation = batch.operation or "replace"
    if operation ~= "replace" and operation ~= "append" then return nil,string.format("无效组操作[%s]",tostring(operation)) end
    for rowIndex,row in ipairs(newRows) do
        local rowGroupKey = BuildIndexKey(row,rule.fields)
        if rowGroupKey ~= groupKey then return nil,string.format("组键不一致[目标:%s][第%s行:%s]",tostring(groupKey),rowIndex,tostring(rowGroupKey)) end
    end
    if operation == "append" and #newRows == 0 then return { operation = operation, groupKey = groupKey, rows = runtime.getRows(), warnings = {"空组 append 未修改配置"}, conflicts = {} } end
    local firstGroupIndex = nil
    local oldGroupCount = 0
    if operation == "replace" then
        for rowIndex,row in ipairs(currentRows) do
            if BuildIndexKey(row,rule.fields) == groupKey then
                oldGroupCount = oldGroupCount + 1
                if firstGroupIndex == nil then firstGroupIndex = #candidateRows + 1 end
            else
                table.insert(candidateRows,row)
                table.insert(candidateLanguages,currentLanguages[rowIndex] or false)
            end
        end
        local insertIndex = firstGroupIndex or (#candidateRows + 1)
        for offset,row in ipairs(newRows) do
            table.insert(candidateRows,insertIndex + offset - 1,row)
            table.insert(candidateLanguages,insertIndex + offset - 1,rowLanguage or false)
        end
        for offset = 1,#newRows do table.insert(newRowIndexes,insertIndex + offset - 1) end
    else
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
            table.insert(newRowIndexes,#candidateRows)
        end
    end
    if operation == "replace" and oldGroupCount == 0 and #newRows == 0 then table.insert(warnings,"清空不存在的组未修改配置") end
    local resultRows,resultLanguages,conflicts = ResolveNewRowConflicts(info,rule,candidateRows,candidateLanguages,newRowIndexes)
    local indexes,indexErr = robot_def.BuildIndexes(sheetName,resultRows,allowUnknown,schemaOverride)
    if indexes == nil then return nil,indexErr end
    runtime.publish(resultRows,indexes,schema,resultLanguages)
    return { operation = operation, groupKey = groupKey, rows = resultRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
end

local sheetFunc = 
{
    ["config"] = 
    {
        ["index"] = "config_index",
        ["@num"] = "config_num",
        ["@set"] = "config_set",
        ["id"] = "config_id",
    },
}

function robot_def.Get(sheetName,keyIndex,key)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return nil,1 end
    local funName = funcIndexs[keyIndex]
    if not funName then return nil,2 end
    return robot_def[funName](key),nil
end

function robot_def.Set(sheetName,index,data)
    if index == nil then return false end
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return false end
    local funName = funcIndexs["@set"]
    robot_def[funName](index,data)
    return true
end

function robot_def.GetNum(sheetName)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return 0 end
    local funName = funcIndexs["@num"]
    return robot_def[funName]()
end

return robot_def