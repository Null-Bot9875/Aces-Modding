local static_skill_def = {}
local ConfigRowRuntime = require("common/config/ConfigRowRuntime")
local language = Language.Instance

--config
local config_num = 1288
local config_schema =
{
    ["id"] = { type = "int" },
    ["name"] = { type = "string", i18n = true },
    ["desc"] = { type = "string", i18n = true },
    ["srcArea"] = { type = "list", item = { type = "int" } },
    ["targetArea"] = { type = "list", item = { type = "int" } },
    ["effect"] = { type = "lua" },
    ["flag"] = { type = "lua" },
    ["conditionList"] = { type = "list", item = { type = "int" } },
    ["conditionListSelf"] = { type = "list", item = { type = "int" } },
    ["visibility"] = { type = "int" },
    ["keywordList"] = { type = "list", item = { type = "dict", key = { type = "string" }, value = { type = "int" } } },
    ["disable"] = { type = "int" },
    ["showEffects"] = { type = "list", item = { type = "string" } },
}
local config_runtime_schema = config_schema
local config_source =
{
    [1] = {id=104,name="增加连击数",desc="测试",srcArea={14},targetArea={14},effect={miscFunc={valueType = "targetCount", effectKey="attkTwice",targetId = 123,A=0,B=1}},flag={self=1},conditionList={0},conditionListSelf={1},visibility=0,keywordList={},disable=0,showEffects={}},
    [2] = {id=105,name="背刺测试",desc="测试",srcArea={14},targetArea={14},effect={attkBack=1},flag={self=1},conditionList={0},conditionListSelf={1},visibility=0,keywordList={},disable=0,showEffects={}},
    [3] = {id=106,name="复生测试",desc="测试",srcArea={14},targetArea={14},effect={relive=1},flag={self=1},conditionList={0},conditionListSelf={1},visibility=0,keywordList={},disable=0,showEffects={}},
    [4] = {id=992651,name="咆哮",desc="+2/+0直到回合结束",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [5] = {id=993251,name="孤注一掷",desc="+10/+0直到回合结束",srcArea={14},targetArea={14},effect={attkAdd = 10},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [6] = {id=200651,name="叹息长阶",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [7] = {id=200751,name="叹息长阶+",desc="+4/+0",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [8] = {id=201051,name="干扰射击",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [9] = {id=201651,name="晋升指令",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [10] = {id=201751,name="晋升指令+",desc="+3/+3",srcArea={14},targetArea={14},effect={attkAdd = 3,hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [11] = {id=201851,name="白矮星",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,damage=-99},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [12] = {id=201852,name="白矮星",desc="受到的伤害减少2。",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1},conditionList={60},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [13] = {id=201853,name="白矮星",desc="获得+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [14] = {id=201951,name="白矮星-新星模式",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [15] = {id=201952,name="白矮星-新星模式",desc="你的机体获得+2/+0。",srcArea={14},targetArea={2,6,14},effect={attkAdd = 2},flag={},conditionList={2052},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [16] = {id=201953,name="白矮星-新星模式",desc="每当你派出机体时，抽1张牌。",srcArea={14},targetArea={14},effect={skillAdd = 201901},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [17] = {id=202151,name="覆膜",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [18] = {id=202251,name="覆膜+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [19] = {id=202252,name="覆膜+",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [20] = {id=203051,name="狂风组件",desc="[连击]1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [21] = {id=203151,name="团结无人机",desc="+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [22] = {id=203251,name="团结无人机+",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [23] = {id=203351,name="连击组件",desc="[连击]2",srcArea={14},targetArea={14},effect={attkTwice = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [24] = {id=203551,name="回收组件",desc="被摧毁时：抽1张牌",srcArea={14},targetArea={14},effect={skillAdd = 203501},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [25] = {id=203751,name="连击无人机",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [26] = {id=203752,name="连击无人机",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [27] = {id=203951,name="原型组件",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [28] = {id=204351,name="学习型作战核心+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [29] = {id=204451,name="学习型作战核心++",desc="[覆膜]，[连击]1",srcArea={14},targetArea={14},effect={attkShield = 1,attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [30] = {id=204551,name="学习型作战核心+++",desc="[覆膜]，[连击]1",srcArea={14},targetArea={14},effect={attkShield = 1,attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [31] = {id=204651,name="历战型作战核心",desc="[覆膜]，[连击]1",srcArea={14},targetArea={14},effect={attkShield = 1,attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [32] = {id=204751,name="一次性防御结构",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [33] = {id=204951,name="回收组件",desc="被摧毁时，对所有敌方机体造成<attackValue = 1/>点伤害。",srcArea={14},targetArea={14},effect={skillAdd = 204901},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [34] = {id=205051,name="回收组件",desc="被摧毁时，对所有敌方机体造成<attackValue = 2/>点伤害。",srcArea={14},targetArea={14},effect={skillAdd = 205001},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [35] = {id=205351,name="冲击型“鲨尾”",desc="+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [36] = {id=205451,name="冲击型“鲨尾”+",desc="+3/+0",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [37] = {id=205551,name="覆膜投射器",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [38] = {id=206351,name="运算过载",desc="-4攻击力",srcArea={14},targetArea={14},effect={attkAdd = -4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [39] = {id=206751,name="紧急废弃",desc="你的下一张牌消耗减2。",srcArea={8},targetArea={2},effect={costVal=-2},flag={removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [40] = {id=207551,name="兵备无人机",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [41] = {id=208051,name="标准无人机β+",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1,stackcard=0},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [42] = {id=208351,name="护盾无人机β",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [43] = {id=208551,name="强能护盾",desc="↓：受到的伤害减少2。",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [44] = {id=208651,name="强能护盾+",desc="↓：受到的伤害减少3。",srcArea={14},targetArea={14},effect={damage = -3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [45] = {id=208751,name="决战兵器",desc="+4/+4",srcArea={14},targetArea={14},effect={attkAdd = 4,hpAddDrone = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [46] = {id=208951,name="防御支援机",desc="[激怒]：获得[覆膜]。",srcArea={14},targetArea={14},effect={skillAdd = 208901},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [47] = {id=208952,name="防御支援机",desc="[覆膜]。",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [48] = {id=209151,name="强击支援机",desc="[连击]1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [49] = {id=210551,name="无人机2105",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [50] = {id=210552,name="无人机2105",desc="[覆膜]。",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [51] = {id=210553,name="无人机2105",desc="[连击]1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [52] = {id=210751,name="一次性护盾",desc="[覆膜]。",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [53] = {id=212351,name="十字升",desc="你的下一张牌消耗减3。",srcArea={8},targetArea={2},effect={costVal=-3},flag={removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [54] = {id=300251,name="高能电容",desc="你的能量上限+2",srcArea={8},targetArea={8},effect={powerMax = 2},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [55] = {id=300351,name="聚能炮管",desc="直到本回合结束，你的主将机体获得[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [56] = {id=300352,name="聚能炮管",desc="直到本回合结束，你的主将机体获得+5/+0。",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [57] = {id=300451,name="临时弹药包",desc="直到本回合结束，你的场上单位获得+2/+0。",srcArea={8},targetArea={14},effect={attkAdd = 2},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [58] = {id=300551,name="外置运存",desc="直到回合结束，你的战术牌伤害增加2。",srcArea={8},targetArea={2,6},effect={damageAdd = 2},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={1020},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [59] = {id=300651,name="战斗保险",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={60},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [60] = {id=301251,name="阻滞力场",desc="使所有敌方机体获得[延缓] 。",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [61] = {id=213951,name="联结指令",desc="此无人机方向异能对自身生效",srcArea={14},targetArea={14},effect={dirSelf = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [62] = {id=214351,name="坚守指令",desc="[圣盾]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [63] = {id=214551,name="战术大师",desc="你的战术牌费用减少1点",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={},conditionList={2017},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [64] = {id=217951,name="共振黄蜂",desc="此机体获得+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [65] = {id=218051,name="共振黄蜂",desc="此机体获得+3/+3",srcArea={14},targetArea={14},effect={attkAdd = 3,hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [66] = {id=214752,name="武装组件",desc="+1/+1。",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [67] = {id=214852,name="武装组件+",desc="+2/+2。",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [68] = {id=214951,name="护盾组件",desc="+1/+1。",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [69] = {id=215051,name="护盾组件+",desc="+2/+2。",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [70] = {id=215151,name="加速组件",desc="赋予[在你的回合开始时，抽1张牌。]",srcArea={14},targetArea={14},effect={skillAdd = 215101},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [71] = {id=215551,name="猎神武装",desc="赋予[战斗破坏机体时，获得+1/+0。]",srcArea={14},targetArea={14},effect={skillAdd = 215501},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [72] = {id=215552,name="猎神武装",desc="+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [73] = {id=215651,name="猎神武装+",desc="赋予[战斗破坏机体时，获得+3/+0。]",srcArea={14},targetArea={14},effect={skillAdd = 215601},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [74] = {id=215652,name="猎神武装+",desc="+3/+0",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [75] = {id=215951,name="护盾无人机",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [76] = {id=215952,name="护盾无人机",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [77] = {id=216052,name="护盾无人机+",desc="+4/+0",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [78] = {id=216951,name="电能灌注",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [79] = {id=217051,name="电能灌注+",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [80] = {id=217351,name="召唤矩阵",desc="你的僚机牌能量消耗减少1。",srcArea={14},targetArea={2,6},effect={costVal = -1},flag={},conditionList={61},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [81] = {id=217451,name="召唤矩阵+",desc="你的僚机牌能量消耗减少2。",srcArea={14},targetArea={2,6},effect={costVal = -2},flag={},conditionList={61},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [82] = {id=217751,name="海神武装",desc="[连击]1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [83] = {id=217851,name="海神武装+",desc="[连击]2。",srcArea={14},targetArea={14},effect={attkTwice = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [84] = {id=217752,name="海神武装",desc="+1/+0。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [85] = {id=217852,name="海神武装+",desc="+3/+0。",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [86] = {id=218151,name="调度矩阵",desc="你的战术牌消耗减少1。",srcArea={14},targetArea={2,6},effect={costVal = -1},flag={},conditionList={2017},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [87] = {id=230451,name="脉冲步枪",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [88] = {id=230551,name="能量背包",desc="[连击]2",srcArea={14},targetArea={14},effect={attkTwice = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [89] = {id=230751,name="角无人机",desc="+1/+2。",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [90] = {id=230951,name="幻影无人机",desc="+1/+1。",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [91] = {id=231051,name="原型改修",desc="[原型无人机]获得+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={},conditionList={2031},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [92] = {id=231651,name="新星模式",desc="+3攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [93] = {id=231951,name="无人机强化",desc="+1/+1。",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [94] = {id=232151,name="叹息长阶",desc="亡语：己方主将获得+4/+0",srcArea={14},targetArea={14},effect={skillAdd = 232102},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [95] = {id=232152,name="叹息长阶",desc="+4/+0。",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [96] = {id=232551,name="剑气存储器",desc="延缓。",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [97] = {id=232651,name="战意涌动",desc="直到回合结束，获得+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [98] = {id=232751,name="防御姿态",desc="直到下个己方回合结束，受到伤害-2.",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [99] = {id=232851,name="剑无人机",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [100] = {id=233151,name="以战养战",desc="+4/+4",srcArea={14},targetArea={14},effect={attkAdd = 4,hpAddDrone = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [101] = {id=233351,name="热启动",desc="主将获得[回合结束时对双方全部机体造成1伤害]。",srcArea={14},targetArea={14},effect={skillAdd = 233302},flag={self=1},conditionList={60},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [102] = {id=233451,name="护盾无人机",desc="受到伤害-2.",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [103] = {id=233551,name="α兵装",desc="直到下个己方回合开始，受到伤害-2.",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [104] = {id=233651,name="β兵装",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [105] = {id=233751,name="γ兵装",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [106] = {id=234151,name="学习装置",desc="攻击时获得+1/+0",srcArea={14},targetArea={14},effect={skillAdd = 234102},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [107] = {id=234152,name="学习装置",desc="+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [108] = {id=234251,name="贯穿组件",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [109] = {id=234351,name="灵活组件-6",desc="[连击]1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [110] = {id=234451,name="强能组件-8",desc="+3/+0",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [111] = {id=241451,name="强能支援机-4",desc="延缓。",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [112] = {id=241452,name="强能支援机-4",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [113] = {id=241551,name="敏捷支援机-6",desc="延缓。",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [114] = {id=241552,name="敏捷支援机-6",desc="[连击]1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [115] = {id=241751,name="电磁干扰船-2",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [116] = {id=241851,name="聚焦棱镜-8",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [117] = {id=242051,name="长剑无人机-2",desc="受到伤害-1.",srcArea={14},targetArea={14},effect={damage = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [118] = {id=242451,name="升级行动",desc="其他机体获得+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=0},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [119] = {id=243051,name="充电桩",desc="[连击]1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [120] = {id=243151,name="充电器",desc="战术伤害增加1",srcArea={14},targetArea={2,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [121] = {id=243451,name="磁桩",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [122] = {id=243452,name="磁桩",desc="攻击+1",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [123] = {id=243453,name="磁桩",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [124] = {id=244651,name="覆膜强化",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [125] = {id=244751,name="机炮",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [126] = {id=244951,name="米尼岗",desc="[连击]1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [127] = {id=245051,name="充能中枢",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=0,gridCheck={side=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [128] = {id=245251,name="充能中枢",desc="+2/+0，[贯穿]",srcArea={14},targetArea={14},effect={attkAdd = 2,tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [129] = {id=245551,name="中线抢夺",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=0,gridCheck={side=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [130] = {id=235451,name="小怪-魔王",desc="初始为2行动力的链规划\n回路3：+3/+0\n回路4：连击2",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={2025},visibility=0,keywordList={},disable=1,showEffects={}},
    [131] = {id=235452,name="小怪-魔王",desc="初始为2行动力的链规划\n回路3：+3/+0\n回路4：连击2",srcArea={14},targetArea={14},effect={attkTwice = 2},flag={self=1},conditionList={0},conditionListSelf={2026},visibility=0,keywordList={},disable=1,showEffects={}},
    [132] = {id=235851,name="2-围攻无人机",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [133] = {id=236251,name="小怪-传递枪手",desc="回路2：连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={2024},visibility=0,keywordList={},disable=1,showEffects={}},
    [134] = {id=236252,name="小怪-传递枪手",desc="回路3：+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={2025},visibility=0,keywordList={},disable=1,showEffects={}},
    [135] = {id=236351,name="2-护盾无人机",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [136] = {id=236451,name="1-管道无人机",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [137] = {id=236551,name="4-武器组件",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [138] = {id=236751,name="左舷护卫",desc="（初始在4号位）\n→：受到伤害减少2",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [139] = {id=236851,name="右舷护卫",desc="（初始在4号位）\n→：受到伤害减少2",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [140] = {id=236951,name="突击指令",desc="延缓主将机体",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [141] = {id=237151,name="小怪-被动式",desc="↓：回合开始时获得+1攻击",srcArea={14},targetArea={14},effect={skillAdd = 237101},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [142] = {id=237152,name="小怪-被动式",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [143] = {id=237153,name="小怪-被动式",desc="使无人机获得回合开始时-5ca",srcArea={14},targetArea={14},effect={skillAdd = 237102},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [144] = {id=237551,name="强化贯穿",desc="直到回合结束，主将获得[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [145] = {id=237851,name="1-装填无人机",desc="→：受到伤害减少1",srcArea={14},targetArea={14},effect={damage = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [146] = {id=238951,name="注能防御者",desc="回合结束时，在2号位召唤一个注能防御者",srcArea={14},targetArea={14},effect={skillAdd = 238901},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [147] = {id=239051,name="注能防御者",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [148] = {id=239052,name="注能防御者",desc="↓：攻击+2",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [149] = {id=239151,name="填装机炮",desc="主将攻击力+1",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [150] = {id=239251,name="左侧填装-4",desc="→：贯穿，攻击+1",srcArea={14},targetArea={14},effect={attkAdd = 1,tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [151] = {id=239351,name="右侧填装-6",desc="←：连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [152] = {id=240051,name="电磁风机",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [153] = {id=240451,name="铀炮8",desc="贯穿",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [154] = {id=243751,name="蓄能电球2",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [155] = {id=243752,name="蓄能电球2",desc="↓：攻击+2",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [156] = {id=243951,name="强化协议",desc="回合结束时，获得+3攻击力，连击1到下回合",srcArea={14},targetArea={14},effect={attkAdd = 3,attkTwice = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [157] = {id=243952,name="强化协议",desc="回合结束时，获得+3攻击力，连击1到下回合",srcArea={14},targetArea={14},effect={skillAdd = 243901},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [158] = {id=244251,name="南十字",desc="其他南十字获得+1+1",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=0},conditionList={2039},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [159] = {id=244252,name="南十字",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [160] = {id=244451,name="天津四",desc="相邻无人机+1+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=0,gridCheck={side=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [161] = {id=244452,name="天津四",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [162] = {id=400051,name="引擎出力提升",desc="你的主将机体获得+2/+0。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [163] = {id=400151,name="末端情报收集",desc="当你派出无人机时，直到回合结束，你的主将机体获得+1/+0。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={60},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [164] = {id=400851,name="覆膜预置算法",desc="当你的主将机体受到伤害时，其获得[覆膜]。此效应每场战斗只能触发1次。",srcArea={14},targetArea={14},effect={attkShield = 1},flag={},conditionList={60},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [165] = {id=401151,name="精英支援",desc="你的僚机获得+2/+2。",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={},conditionList={61},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [166] = {id=401351,name="能量再分配a",desc="EPM+1。你的主将机体获得-2/-0。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [167] = {id=401352,name="能量再分配a",desc="EPM+1。你的主将机体获得-2/-0。",srcArea={8},targetArea={14},effect={attkAdd = -2},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [168] = {id=401451,name="战区能量增幅",desc="EPM+1。所有敌方无人机获得+1/+0。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [169] = {id=401452,name="战区能量增幅",desc="EPM+1。所有敌方无人机获得+1/+0。",srcArea={8},targetArea={14},effect={attkAdd = 1},flag={self=1,targetCamp=1},conditionList={2016},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [170] = {id=401551,name="整备效率提升",desc="你的僚机费用减少1",srcArea={8},targetArea={2,6},effect={costVal=-1},flag={},conditionList={61},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [171] = {id=402051,name="覆膜攻性化",desc="持有[覆膜]的无人机攻击+2",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={},conditionList={2012},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [172] = {id=402151,name="引擎冷却优化",desc="持有[连击]的无人机连击层数+1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={},conditionList={2013},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [173] = {id=402251,name="火力掩护优化",desc="你前排无人机受到的伤害-1",srcArea={14},targetArea={14},effect={damage = -1},flag={},conditionList={2043},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [174] = {id=402351,name="回路拓扑优化",desc="己方全场的无人机的方向异能不会发生短路",srcArea={8},targetArea={14},effect={dirLoop = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [175] = {id=403051,name="核心过载",desc="EPM+1。在你的回合开始时，对你的主将机体造成1点伤害。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [176] = {id=403151,name="能量再分配b",desc="EPM+1。所有己方无人机派出时获得[延缓]。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [177] = {id=403152,name="能量再分配b",desc="EPM+1。所有己方无人机派出时获得[延缓]。",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2016},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [178] = {id=403251,name="冷启动",desc="你的无人机获得[延缓]与+2/+0。",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2016},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [179] = {id=403252,name="装甲内藏存储",desc="你的无人机获得[延缓]与+2/+0。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={},conditionList={2016},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [180] = {id=403351,name="装甲内藏存储",desc="当你的主将机体受到伤害时，抽1张牌。此效应每场战斗只能触发3次。",srcArea={14},targetArea={14},effect={skillAdd = 403301},flag={},conditionList={60},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [181] = {id=403451,name="拓扑解构",desc="己方无人机的方向异能也会对自身生效。",srcArea={14},targetArea={14},effect={dirSelf = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [182] = {id=403551,name="悖论模拟",desc="EPM-2。你的所有卡牌消耗减少1。",srcArea={8},targetArea={8},effect={powerMax = -2},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [183] = {id=403552,name="悖论模拟",desc="EPM-2。你的所有卡牌消耗减少1。",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [184] = {id=403651,name="能量回收算法",desc="你的机体被摧毁时，直到你的下个回合结束，你的EPM增加1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [185] = {id=220352,name="猎户座",desc="猎户座获得+4攻击直到己方回合结束。",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [186] = {id=220651,name="白矮星伴生2",desc="+4/+4",srcArea={14},targetArea={14},effect={attkAdd = 4,hpAddDrone = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [187] = {id=220751,name="白矮星伴生3",desc="直到回合结束，你的机体牌消耗减少1点",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2052},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [188] = {id=220851,name="十字星僚机",desc="战术伤害增加1",srcArea={14},targetArea={2,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [189] = {id=221151,name="十字星伴生3",desc="获得[回合结束时，抽2张牌]。",srcArea={14},targetArea={14},effect={skillAdd = 221102},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [190] = {id=221451,name="猎户座伴生2",desc="此无人机方向异能对自身生效",srcArea={14},targetArea={14},effect={dirSelf = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [191] = {id=221551,name="猎户座伴生3",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [192] = {id=221751,name="薮猫伴生1",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [193] = {id=221752,name="薮猫伴生1",desc="获得[每当你使用战术牌时，薮猫进行一次攻击]",srcArea={14},targetArea={14},effect={skillAdd = 221702},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [194] = {id=221753,name="投影薮猫伴生1",desc="获得[每当你使用战术牌时，投影薮猫进行一次攻击]",srcArea={14},targetArea={14},effect={skillAdd = 221703},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [195] = {id=222251,name="特里格拉夫伴生2",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [196] = {id=222252,name="特里格拉夫伴生2",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [197] = {id=220151,name="白矮星",desc="回路3：你的手牌费用减少1。",srcArea={14},targetArea={2,6},effect={costVal=-1},flag={},conditionList={0},conditionListSelf={2025},visibility=0,keywordList={},disable=0,showEffects={}},
    [198] = {id=220152,name="白矮星",desc="回路4：你的机体获得+2/+0。",srcArea={14},targetArea={2,6,14},effect={attkAdd = 2},flag={},conditionList={2052},conditionListSelf={2026},visibility=0,keywordList={},disable=1,showEffects={}},
    [199] = {id=220153,name="白矮星",desc="你的下一张无人机牌消耗减1。",srcArea={8},targetArea={2},effect={costVal=-1},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2064}},count=1}},conditionList={2064},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [200] = {id=220251,name="十字星",desc="回路3：EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={2025},visibility=0,keywordList={},disable=0,showEffects={}},
    [201] = {id=220351,name="猎户座",desc="回路2：EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={2024},visibility=0,keywordList={},disable=0,showEffects={}},
    [202] = {id=220353,name="猎户座",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [203] = {id=234851,name="拘束手臂α",desc="战术伤害增加1",srcArea={14},targetArea={2,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [204] = {id=234951,name="拘束手臂β",desc="战术伤害增加1",srcArea={14},targetArea={2,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [205] = {id=234852,name="拘束手臂α",desc="-2攻击力",srcArea={14},targetArea={14},effect={attkAdd = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [206] = {id=234952,name="拘束手臂β",desc="-2攻击力",srcArea={14},targetArea={14},effect={attkAdd = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [207] = {id=503551,name="悖论模拟",desc="EPM-1。你的所有卡牌消耗减少1。",srcArea={8},targetArea={8},effect={powerMax = -1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [208] = {id=503552,name="悖论模拟",desc="EPM-1。你的所有卡牌消耗减少1。",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [209] = {id=700051,name="邓肯23",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1,reserve=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [210] = {id=700151,name="万能镀膜",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [211] = {id=700351,name="邓肯76",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1,reserve=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [212] = {id=700551,name="爱之镀膜",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [213] = {id=700651,name="久卡·马可尼",desc="[连击]1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1,reserve=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [214] = {id=700751,name="钢铁之心",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [215] = {id=700851,name="冬子",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1,reserve=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [216] = {id=701051,name="铭字导弹",desc="被摧毁时，对方抽两张牌。",srcArea={14},targetArea={14},effect={skillAdd = 701002},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [217] = {id=701151,name="夏洛",desc="回合开始时，创造一张[薮猫突袭]",srcArea={14},targetArea={14},effect={skillAdd = 701103},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [218] = {id=701551,name="奥斯陆",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [219] = {id=701552,name="奥斯陆",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [220] = {id=701701,name="贯穿战略",desc="直到本回合结束，你的主将机体获得[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [221] = {id=248151,name="不协辉光",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [222] = {id=700251,name="紧急维修",desc="+5生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [223] = {id=700451,name="镀膜装甲",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [224] = {id=710351,name="联防模组",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [225] = {id=710451,name="斗争无人机",desc="+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [226] = {id=710551,name="斗争无人机+",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [227] = {id=711351,name="特化型防御结构+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [228] = {id=711451,name="乱斗无人机",desc="+1攻击力",srcArea={14},targetArea={14},effect={miscFunc={valueType = "targetCount", effectKey="attkAdd",targetId = 542,A=0,B=1}},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [229] = {id=711452,name="乱斗无人机",desc="+1生命值",srcArea={14},targetArea={14},effect={miscFunc={valueType = "targetCount", effectKey="hpAddDrone",targetId = 542,A=0,B=1}},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [230] = {id=711651,name="特攻指令",desc="你的下一张无人机牌消耗减2。",srcArea={8},targetArea={2},effect={costVal=-2},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2064}},count=1}},conditionList={2064},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [231] = {id=711751,name="特攻指令+",desc="你的下一张无人机牌消耗减3。",srcArea={8},targetArea={2},effect={costVal=-3},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2064}},count=1}},conditionList={2064},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [232] = {id=712151,name="团结指令",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1,removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [233] = {id=712251,name="团结指令+",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1,removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [234] = {id=750051,name="斗争无人机",desc="+1/+1",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=1,removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [235] = {id=750151,name="护卫",desc="受到的伤害增加1",srcArea={14},targetArea={14},effect={damage = 1},flag={self=1,removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [236] = {id=750251,name="枷锁",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [237] = {id=750351,name="将军",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [238] = {id=750451,name="远射火炮",desc="+3/+3。",srcArea={14},targetArea={14},effect={attkAdd = 3,hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [239] = {id=750452,name="远射火炮",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [240] = {id=750551,name="突击火炮",desc="+2/+2。",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [241] = {id=750552,name="突击火炮",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [242] = {id=750751,name="拒马防御",desc="+4生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [243] = {id=751051,name="远射炮",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [244] = {id=751251,name="能源栉",desc="+1/+1",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [245] = {id=751351,name="贯穿指令",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1,removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [246] = {id=751451,name="轰炸",desc="轰炸伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2072},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [247] = {id=751551,name="贯射",desc="贯射伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2073},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [248] = {id=751651,name="突击火炮",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [249] = {id=752151,name="重载电浆炮",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [250] = {id=752152,name="重载电浆炮",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [251] = {id=752153,name="重载电浆炮",desc="+1/+1",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [252] = {id=752451,name="强金属射流",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [253] = {id=752452,name="强金属射流",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1,removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [254] = {id=752851,name="突袭无人机+",desc="[连击]1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [255] = {id=753351,name="攻击单元",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [256] = {id=753451,name="攻击单元+",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [257] = {id=753951,name="战术演算核心",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [258] = {id=754051,name="战术演算核心+",desc="+1生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [259] = {id=754351,name="调度指令",desc="直到回合结束，你的机体牌消耗减少1点",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2052},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [260] = {id=755151,name="作战宣言",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [261] = {id=755251,name="作战宣言+",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [262] = {id=756251,name="深渊凝视",desc="-2攻击力",srcArea={14},targetArea={14},effect={attkAdd = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [263] = {id=756351,name="深渊凝视",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [264] = {id=756651,name="高速战斗",desc="回合开始时，额外抽2张牌。",srcArea={14},targetArea={14},effect={skillAdd = 756602},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [265] = {id=756751,name="长枪无人机",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [266] = {id=756851,name="飞马推进器",desc="你造成的战术伤害增加1。",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [267] = {id=758051,name="匿影",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [268] = {id=758151,name="深渊凝视",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [269] = {id=758351,name="热诱饵无人机",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [270] = {id=758651,name="腐柯",desc="你造成的战术伤害增加1。",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [271] = {id=758751,name="增强火力",desc="+4/+0直到回合结束",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [272] = {id=758851,name="增强火力+",desc="+6/+0直到回合结束",srcArea={14},targetArea={14},effect={attkAdd = 6},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [273] = {id=759351,name="弹雨倾泻",desc="-2/+0直到3次攻击结束",srcArea={14},targetArea={14},effect={attkAdd = -2},flag={self=1,removeTrigger={trigger=129,triggerEx={}, count=3}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [274] = {id=759451,name="弹雨倾泻+",desc="-1/+0直到3次攻击结束",srcArea={14},targetArea={14},effect={attkAdd = -1},flag={self=1,removeTrigger={trigger=129,triggerEx={}, count=3}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [275] = {id=759551,name="掠夺指令",desc="[攻击摧毁无人机时，回复3装甲]。",srcArea={14},targetArea={14},effect={skillAdd = 759502},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [276] = {id=759651,name="掠夺指令+",desc="[攻击摧毁无人机时，回复4装甲]。",srcArea={14},targetArea={14},effect={skillAdd = 759602},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [277] = {id=250751,name="白虹贯日",desc="[若此次攻击摧毁了敌方无人机，抽3张牌。]。",srcArea={14},targetArea={14},effect={skillAdd = 250702},flag={self=1,removeTrigger={trigger=129,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [278] = {id=250951,name="破釜沉舟",desc="直到本回合结束，你的主将机体获得+1/+0。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [279] = {id=251151,name="分光掠影",desc="[连击]1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [280] = {id=251351,name="霞二段/曳光弹",desc="直到本回合结束，受到的伤害增加2",srcArea={14},targetArea={14},effect={damage = 2},flag={self=1,removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [281] = {id=251551,name="冷枪无人机",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [282] = {id=251751,name="牵制射击",desc="直到本回合结束，受到的伤害增加1",srcArea={14},targetArea={14},effect={damage = 1},flag={self=1,removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [283] = {id=251951,name="剑舞步",desc="-2/+0直到回合结束",srcArea={14},targetArea={14},effect={attkAdd = -2},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [284] = {id=252151,name="百鬼夜行",desc="直到本回合结束，受到的伤害增加1",srcArea={14},targetArea={14},effect={damage = 1},flag={self=1,removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [285] = {id=253951,name="疾斩-纸油",desc="+3/+3。",srcArea={14},targetArea={14},effect={attkAdd = 3,hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [286] = {id=254151,name="疾斩-纳光",desc="你的下一张牌消耗减2。",srcArea={8},targetArea={2},effect={costVal=-2},flag={removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [287] = {id=254551,name="气合",desc="+2/+0直到回合结束",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [288] = {id=255351,name="卧薪尝胆",desc="直到下个回合开始，你的主将机体获得[<text_back type=1 content=轻载 />抽1张牌]。",srcArea={14},targetArea={14},effect={skillAdd = 255302},flag={removeTrigger={trigger=2,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [289] = {id=255751,name="片刻喘息",desc="直到下个己方回合开始，受到伤害-2.",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [290] = {id=255951,name="透支命运",desc="直到本回合结束，你的手牌消耗减少2。",srcArea={8},targetArea={2},effect={costVal=-2},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [291] = {id=255952,name="透支命运",desc="当你打出1张牌，你的主将机体受到<attackValue value=3 />伤害。",srcArea={14},targetArea={14},effect={skillAdd = 255902},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [292] = {id=256151,name="钥势-变式",desc="直到本回合结束，你的手牌消耗减少1。",srcArea={8},targetArea={2},effect={costVal=-1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [293] = {id=256351,name="临阵换将",desc="直到本回合结束，你的僚机牌消耗减少3。",srcArea={8},targetArea={2},effect={costVal=-3},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={61},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [294] = {id=256551,name="疾斩-突击",desc="直到本回合结束，你的主将机体获得[直到本回合结束，当你抽1张牌，你的主将机体获得+1/+0]。",srcArea={14},targetArea={14},effect={skillAdd = 256502},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [295] = {id=256552,name="疾斩-突击",desc="+1/+0直到回合结束",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [296] = {id=256751,name="免战牌",desc="你的主将机体获得[造成的伤害减少10]与[受到的伤害减少10]直到本回合结束。",srcArea={14},targetArea={14},effect={damage = -10,attkAdd = -10},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [297] = {id=257551,name="UN制式·胁差",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [298] = {id=257751,name="UN武具-大名长刀",desc="+1/+0直到回合结束",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [299] = {id=257951,name="UN支援·能源兵粮",desc="+1/+1",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [300] = {id=258151,name="装甲能源栉",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [301] = {id=760151,name="杀戮回扣",desc="若此无人机被破坏，敌方下一张牌消耗-2",srcArea={14},targetArea={14},effect={skillAdd = 760102},flag={self=1,removeTrigger={trigger=119,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [302] = {id=760152,name="杀戮回扣",desc="下一张牌消耗-2",srcArea={8},targetArea={2},effect={costVal=-2},flag={removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [303] = {id=760351,name="神经元劫持",desc="你的能量上限-1",srcArea={8},targetArea={8},effect={powerMax = -1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [304] = {id=760551,name="废料回收协议",desc="攻击后，摧毁自身。",srcArea={14},targetArea={14},effect={skillAdd = 760502},flag={self=1,removeTrigger={trigger=119,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [305] = {id=760751,name="外接回路构成",desc="回路5：+10/+0",srcArea={14},targetArea={14},effect={attkAdd = 10},flag={self=1},conditionList={0},conditionListSelf={2081},visibility=0,keywordList={},disable=1,showEffects={}},
    [306] = {id=761151,name="猎手箭矢",desc="+4生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [307] = {id=761351,name="屏障战术核心",desc="回合开始时[覆膜]。",srcArea={14},targetArea={14},effect={skillAdd = 761301},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [308] = {id=761352,name="屏障战术核心",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [309] = {id=761551,name="第二指挥中枢",desc="无人机的方向性异能对无人机自身也能生效。",srcArea={14},targetArea={14},effect={dirSelf = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [310] = {id=762151,name="裁决武装",desc="-4攻击力",srcArea={14},targetArea={14},effect={attkAdd = -4},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [311] = {id=762351,name="处刑武装",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [312] = {id=762751,name="武装装配",desc="直到本回合结束，你的[武装]牌消耗减少1。",srcArea={8},targetArea={2},effect={costVal=-1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2082},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [313] = {id=763151,name="电弧武装",desc="+4攻击力",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [314] = {id=763351,name="磁暴无人机",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [315] = {id=763551,name="磁感领域",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [316] = {id=258351,name="电磁加速轨道",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [317] = {id=258551,name="UN绝艺-迅捷之剑",desc="[连击]1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [318] = {id=258751,name="UN锻造-十字长剑",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [319] = {id=258752,name="UN锻造-十字长剑",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [320] = {id=761451,name="屏障战术核心+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [321] = {id=763251,name="电弧武装",desc="+4攻击力,[连击]1",srcArea={14},targetArea={14},effect={attkAdd = 4,attkTwice = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [322] = {id=763451,name="磁暴无人机+",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [323] = {id=763651,name="磁感领域",desc="战术伤害增加3",srcArea={14},targetArea={2,4,6},effect={damageAdd = 3},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [324] = {id=759151,name="无人机强化",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [325] = {id=764351,name="翼装L",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [326] = {id=764451,name="翼装R",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [327] = {id=240851,name="战船",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [328] = {id=242751,name="臂装-L",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [329] = {id=242851,name="臂装-R",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [330] = {id=1600051,name="重装的",desc="主将CA+20。",srcArea={8},targetArea={14},effect={hpAddDrone = 20},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [331] = {id=1600151,name="洋葱的",desc="受到伤害-2",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_debuffhold_01"}},
    [332] = {id=1600251,name="善变的",desc="本回合中下一张战术牌费用+1",srcArea={8},targetArea={2},effect={costVal=1},flag={removeTrigger={trigger=115}},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [333] = {id=1600252,name="善变的",desc="本回合中下一张无人机牌费用+1",srcArea={8},targetArea={2},effect={costVal=1},flag={removeTrigger={trigger=115}},conditionList={2091},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [334] = {id=1600351,name="避战的",desc="双方所有无人机攻击减少2。",srcArea={8},targetArea={14},effect={attkAdd = -2},flag={selfPlayer=0},conditionList={2016},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [335] = {id=1600352,name="避战的",desc="双方所有无人机攻击减少2。",srcArea={8},targetArea={14},effect={attkAdd = -2},flag={selfPlayer=1},conditionList={2016},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [336] = {id=1600451,name="奉献的",desc="己方主将受到伤害增加2",srcArea={8},targetArea={14},effect={damage = 2},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [337] = {id=1600452,name="奉献的",desc="己方无人机获得[连击1]",srcArea={8},targetArea={14},effect={attkTwice = 1},flag={},conditionList={2016},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [338] = {id=1600651,name="爆裂的",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1,removeTrigger={trigger=129,triggerEx={srcCondition={60}},count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [339] = {id=800151,name="CE9842-琉璃光SP",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,damage=-99},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [340] = {id=800351,name="无畏无人机",desc="-2攻击力",srcArea={14},targetArea={14},effect={attkAdd = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [341] = {id=800451,name="杂念无人机",desc="无法攻击",srcArea={14},targetArea={14},effect={attkPause = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [342] = {id=800751,name="平静感",desc="你的下一张牌消耗减1。",srcArea={8},targetArea={2},effect={costVal=-1},flag={removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [343] = {id=800951,name="伟业",desc="战术卡牌费用变为1，战术卡会被直接废弃。",srcArea={8},targetArea={2,6},effect={costSet=1,stackMove=4},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [344] = {id=801051,name="普照",desc="场上所有无人机的攻击、血量和血量上限为1。",srcArea={14},targetArea={14},effect={costVal=-1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [345] = {id=801151,name="清净",desc="沉默",srcArea={14},targetArea={14},effect={disable=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [346] = {id=801351,name="加冠",desc="回路3：主将攻击力-10，受到伤害-10",srcArea={14},targetArea={14},effect={attkAdd = -10,damage = -10},flag={self=1},conditionList={0},conditionListSelf={2025},visibility=0,keywordList={},disable=1,showEffects={}},
    [347] = {id=801701,name="解脱",desc="沉默",srcArea={14},targetArea={14},effect={disable=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [348] = {id=850051,name="智械护盾",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [349] = {id=850052,name="智械护盾",desc="+2/+1",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [350] = {id=850251,name="智械毒刺",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [351] = {id=850252,name="智械毒刺",desc="+2/+1",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [352] = {id=850451,name="超频智械",desc="[连击]1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [353] = {id=850452,name="智械毒刺",desc="+2/+1",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [354] = {id=850651,name="智械网络",desc="集成-智械：回合开始时进行1次攻击为1的攻击，命中的目标获得延缓。",srcArea={14},targetArea={14},effect={skillAdd = 850601},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [355] = {id=850652,name="智械网络",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_debuffhold_01"}},
    [356] = {id=850653,name="智械网络",desc="+2/+1",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [357] = {id=850851,name="智械哨位",desc="集成-智械：每当敌方派出机体，你抽1张牌。",srcArea={14},targetArea={14},effect={skillAdd = 850801},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [358] = {id=850852,name="智械哨位",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [359] = {id=850853,name="智械哨位",desc="+2/+1",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [360] = {id=851051,name="转运智械",desc="集成-智械：被破坏时，你的所有机体获得+1攻击。",srcArea={14},targetArea={14},effect={skillAdd = 851001},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [361] = {id=851052,name="转运智械",desc="+0/+1",srcArea={14},targetArea={14},effect={hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [362] = {id=851053,name="转运智械",desc="+2/+1",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [363] = {id=851054,name="转运智械",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1,removeTrigger={trigger=129,triggerEx={srcCondition={60}},count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [364] = {id=851251,name="智械熔毁",desc="攻击结束后，废弃自身。",srcArea={14},targetArea={14},effect={skillAdd = 851202},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [365] = {id=851451,name="基础蜂群",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [366] = {id=851651,name="猎蜂群",desc="集成-蜂群：+4/+5，集成时创造1张[基础蜂群]。",srcArea={14},targetArea={14},effect={attkAdd = 4,hpAddDrone = 5,skillAdd = 851601},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [367] = {id=851851,name="工蜂群",desc="每张手牌+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={removeTrigger={trigger=7,triggerEx={}, count=1},self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [368] = {id=851852,name="工蜂群",desc="每张手牌+1攻击力",srcArea={14},targetArea={14},effect={skillAdd = 851801},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [369] = {id=852051,name="蜂群蜂王",desc="+6/+6",srcArea={14},targetArea={14},effect={attkAdd = 6,hpAddDrone = 6},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [370] = {id=852251,name="突击海盗",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [371] = {id=852451,name="复仇海盗",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [372] = {id=852651,name="弹射海盗",desc="进场时，弃置你手牌中的所有[海盗]牌，每有1张，给全部敌方机体造成[等同于弃置卡牌合计能量数值]的伤害。",srcArea={14},targetArea={14},effect={skillAdd = 852601},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [373] = {id=852851,name="劫掠海盗",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [374] = {id=853051,name="冲锋海盗",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [375] = {id=853451,name="拾骨海盗",desc="集成-海盗：每当派出海盗，获得+2/+0。",srcArea={14},targetArea={14},effect={skillAdd = 853402},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [376] = {id=853452,name="拾骨海盗",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [377] = {id=853651,name="海盗老兵",desc="集成-海盗：回合开始时，创造1张[海盗新兵]。",srcArea={14},targetArea={14},effect={skillAdd = 853602},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [378] = {id=853851,name="海盗新兵",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={},conditionList={2099},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [379] = {id=854251,name="海盗劫掠",desc="对目标机体造成2伤害。若将其破坏，玩家回复1能量。",srcArea={14},targetArea={14},effect={skillAdd = 854202},flag={self=1,removeTrigger={trigger=119,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [380] = {id=854451,name="海盗血旗",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={},conditionList={2098},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [381] = {id=854651,name="商会护盾",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [382] = {id=854851,name="商会中台",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [383] = {id=855251,name="商会幽浮",desc="+2/+1",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [384] = {id=855252,name="商会幽浮",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [385] = {id=855451,name="商会探针",desc="回合结束时，若你的手牌数在5张或更多，此机体获得+4/+4。",srcArea={14},targetArea={14},effect={skillAdd = 855403},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [386] = {id=855452,name="商会探针",desc="+4/+4",srcArea={14},targetArea={14},effect={attkAdd = 4,hpAddDrone = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [387] = {id=855651,name="商会首脑",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [388] = {id=855652,name="商会首脑",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [389] = {id=855851,name="商会密探",desc="+1生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [390] = {id=855852,name="商会密探",desc="EPM-1。",srcArea={8},targetArea={8},effect={powerMax = -1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [391] = {id=856051,name="商会护卫",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [392] = {id=856251,name="商会信标",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [393] = {id=856451,name="商会的权衡",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [394] = {id=856651,name="未知的穿梭机",desc="不能被选为目标，不能被攻击。",srcArea={14},targetArea={14},effect={noOtherChoose = 1,attkTargetMiss=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [395] = {id=857051,name="混沌星骸",desc="回合结束时抽1张牌",srcArea={14},targetArea={14},effect={skillAdd = 857003},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [396] = {id=857251,name="异域星骸",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [397] = {id=857252,name="混沌星骸",desc="回合结束时，获得[覆膜]",srcArea={14},targetArea={14},effect={skillAdd = 857203},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [398] = {id=857253,name="智械护盾",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [399] = {id=857451,name="混沌星骸",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [400] = {id=857452,name="混沌星骸",desc="[连击]1,[覆膜]",srcArea={14},targetArea={14},effect={attkTwice = 1,attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [401] = {id=857651,name="恒久星骸",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [402] = {id=857652,name="恒久星骸",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [403] = {id=857851,name="新星遗骸",desc="你的星骸牌费用减少1点",srcArea={14},targetArea={2,6},effect={costVal = -1},flag={},conditionList={2102},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [404] = {id=857852,name="新星遗骸",desc="+4/+4",srcArea={14},targetArea={14},effect={attkAdd = 4,hpAddDrone = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [405] = {id=858051,name="灼烧星骸",desc="+3生命，回合结束时对所有敌方机体造成1伤害",srcArea={14},targetArea={14},effect={hpAddDrone = 3,skillAdd = 858002},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [406] = {id=800152,name="CE9842-琉璃光SP",desc="[金印]",srcArea={14},targetArea={14},effect={attkShieldEx = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [407] = {id=403951,name="智械集约",desc="+1/+1",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [408] = {id=404451,name="冲撞上阵",desc="+6攻击力",srcArea={8},targetArea={14},effect={attkAdd = 6},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [409] = {id=404551,name="无害化协议",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [410] = {id=404552,name="无害化协议",desc="-1攻击力",srcArea={14},targetArea={14},effect={attkAdd = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [411] = {id=404251,name="自集成",desc="你的无人机不能集成，但可以获得无人机自身的集成能力。",srcArea={8},targetArea={14},effect={stackcardFail = 1,stackcardSkillSelf = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [412] = {id=403751,name="商会合约",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [413] = {id=403851,name="宝藏金币",desc="+1攻击力",srcArea={8},targetArea={14},effect={attkAdd = 1},flag={},conditionList={2107},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [414] = {id=260151,name="薮猫",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={2120},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [415] = {id=260152,name="薮猫",desc="回路2：当你使用牌时，若手牌为空，则你抽1张牌。",srcArea={14},targetArea={14},effect={skillAdd = 260101},flag={self=1},conditionList={0},conditionListSelf={2024},visibility=0,keywordList={},disable=1,showEffects={}},
    [416] = {id=260351,name="霞二段",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [417] = {id=260551,name="削刀",desc="你的下一张牌消耗减1。",srcArea={8},targetArea={2},effect={costVal=-1},flag={removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [418] = {id=260751,name="枭首",desc="如果被破坏，对方主将剑术牌攻击+1",srcArea={14},targetArea={14},effect={skillAdd = 260702},flag={self=1,removeTrigger={trigger=119,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [419] = {id=260752,name="枭首",desc="剑术伤害增加1",srcArea={8},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2121},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [420] = {id=261351,name="电磁弹射轨道",desc="无法攻击",srcArea={14},targetArea={14},effect={attkPause = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [421] = {id=260753,name="枭首",desc="剑术伤害增加1",srcArea={14},targetArea={14},effect={stanceAdd = 1},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [422] = {id=261751,name="振剑",desc="剑术伤害增加3",srcArea={14},targetArea={2,4,6},effect={damageAdd = 3},flag={},conditionList={2121},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [423] = {id=263351,name="疾斩-纸油",desc="+3/+3",srcArea={14},targetArea={14},effect={attkAdd = 3,hpAddDrone =3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [424] = {id=263551,name="疾斩-纸油",desc="你的下一张牌费用-3。",srcArea={8},targetArea={2},effect={costVal=-3},flag={removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [425] = {id=264151,name="居合斩",desc="手牌获得保留",srcArea={8},targetArea={2,4,6},effect={tagAdd = 302},flag={removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [426] = {id=264351,name="剑气",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [427] = {id=264551,name="振剑A",desc="+5攻击力",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [428] = {id=264751,name="二段振剑A",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [429] = {id=265551,name="雾鸦侦察机",desc="你的下一张无人机牌消耗减1。",srcArea={8},targetArea={2},effect={costVal=-1},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2064}},count=1}},conditionList={2064},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [430] = {id=265552,name="雾鸦侦察机",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [431] = {id=265951,name="利爪突击机",desc="每当回合结束时，失去2攻击。",srcArea={14},targetArea={14},effect={attkAdd = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [432] = {id=266151,name="尖牙突击机",desc="-2/-2",srcArea={14},targetArea={14},effect={attkAdd = -2,hpAddDrone =-2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [433] = {id=266351,name="蓄势突击机",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [434] = {id=266551,name="电磁突击机",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [435] = {id=266951,name="晴空防御机",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [436] = {id=267151,name="双子防御机",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone =2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [437] = {id=267351,name="巨鲨防御机",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone =3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [438] = {id=267551,name="迷宫防御机",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [439] = {id=268151,name="借力弹射",desc="你的下一张牌费用-1。",srcArea={8},targetArea={2},effect={costVal=-1},flag={removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [440] = {id=268351,name="坚壁",desc="+4生命值",srcArea={14},targetArea={14},effect={hpAddDrone =4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [441] = {id=268551,name="诱饵机1",desc="受到伤害-2.",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [442] = {id=268951,name="电磁突击机",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [443] = {id=269751,name="成长机1",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [444] = {id=269951,name="成长机2",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone =2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [445] = {id=270151,name="成长机3",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [446] = {id=270152,name="成长机3",desc="你派出此机体的回合，每当你派出一个其他机体，此机体获得+3攻击。",srcArea={14},targetArea={14},effect={skillAdd = 270102},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [447] = {id=270351,name="成长机4",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [448] = {id=270551,name="刀剑斗技",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [449] = {id=270951,name="干扰机2",desc="-1攻击力",srcArea={14},targetArea={14},effect={attkAdd = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [450] = {id=271751,name="UN二本斩",desc="受到伤害-1.",srcArea={14},targetArea={14},effect={damage = -1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [451] = {id=272351,name="UN中路切",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [452] = {id=272352,name="UN中路切",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [453] = {id=272751,name="片刻喘息",desc="受到伤害-2.",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [454] = {id=272951,name="透支命运",desc="你的牌费用-2。",srcArea={8},targetArea={2},effect={costVal=-2},flag={},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [455] = {id=272952,name="透支命运",desc="直到本回合结束，当你打出1张牌，你的主将机体受到3伤害。",srcArea={14},targetArea={14},effect={skillAdd = 272902},flag={},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [456] = {id=273151,name="白虹贯日",desc="若此次攻击摧毁了敌方无人机，抽3张牌。",srcArea={14},targetArea={14},effect={skillAdd = 273102},flag={self=1,removeTrigger={trigger=129,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [457] = {id=273351,name="破釜沉舟",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [458] = {id=273551,name="分光掠影",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [459] = {id=273951,name="剑字掠影",desc="受到伤害-1.回合开始时，抽2张牌。",srcArea={14},targetArea={14},effect={damage = -1,skillAdd = 273902},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [460] = {id=275051,name="十字掠影",desc="受到伤害-1.回合开始时，抽1张牌。",srcArea={14},targetArea={14},effect={damage = -1,skillAdd = 275002},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [461] = {id=275251,name="贯射蓄能",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [462] = {id=275451,name="灼热之核",desc="受到伤害时，对双方全部无人机造成2伤害",srcArea={14},targetArea={14},effect={skillAdd = 275402},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [463] = {id=275551,name="废料回收",desc="获得[每当你的无人机被破坏时，回复1CA]。",srcArea={14},targetArea={14},effect={skillAdd = 275502},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [464] = {id=276151,name="机控中枢",desc="无人机费用-1",srcArea={8},targetArea={2},effect={costVal=-1},flag={},conditionList={2128},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [465] = {id=276251,name="防御中枢",desc="受到伤害-1.",srcArea={14},targetArea={14},effect={damage = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [466] = {id=276651,name="回收组件",desc="+2/+1",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone =1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [467] = {id=276951,name="白矮星-夺魄",desc="[贯穿],+1攻击力",srcArea={14},targetArea={14},effect={tagAdd = 409,attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [468] = {id=277051,name="夺魄-破弃涂装",desc="你的无人机获得+2攻击",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=0},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [469] = {id=277151,name="夺魄-暗黑新星",desc="EPM+2。",srcArea={14},targetArea={8},effect={powerMax = 2},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [470] = {id=277152,name="夺魄-暗黑新星",desc="你的无人机获得+2攻击",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=0},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [471] = {id=277153,name="夺魄-暗黑新星",desc="战术卡牌费用-1，战术卡会被直接废弃。",srcArea={14},targetArea={2,6},effect={costVal=-1,stackMove=4},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [472] = {id=277251,name="伏击",desc="你所有费用大于3的手牌，费用降低到0。",srcArea={8},targetArea={2,6},effect={costSet=1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [473] = {id=277351,name="援军",desc="你的下一张牌消耗减2。",srcArea={8},targetArea={2},effect={costVal=-2},flag={removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [474] = {id=277551,name="黎明将至",desc="EPM-3",srcArea={8},targetArea={8},effect={costVal=-3},flag={removeTrigger={trigger=1,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [475] = {id=277552,name="黎明将至",desc="EPM-3",srcArea={8},targetArea={8},effect={costVal=-3},flag={removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [476] = {id=277751,name="黑夜无人机",desc="[覆膜]、[延缓]",srcArea={14},targetArea={14},effect={attkShield = 1,attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [477] = {id=277951,name="掠影无人机",desc="主将受到伤害-1",srcArea={14},targetArea={14},effect={damage = -1},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [478] = {id=278101,name="蜃景无人机",desc="+1/+1",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone =1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [479] = {id=278251,name="空响无人机",desc="+5攻击力",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [480] = {id=278351,name="虚廊无人机",desc="-1攻击力",srcArea={14},targetArea={14},effect={attkAdd = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [481] = {id=278451,name="棱界无人机",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [482] = {id=278851,name="影牢",desc="-5攻击力",srcArea={14},targetArea={14},effect={attkAdd = -5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [483] = {id=278951,name="大将军",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [484] = {id=279151,name="哨戒火炮",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone =2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [485] = {id=279251,name="决战指令",desc="卡牌费用-3",srcArea={14},targetArea={2,6},effect={costVal=-3},flag={},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [486] = {id=279351,name="白鸟",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [487] = {id=279352,name="白鸟",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [488] = {id=279751,name="迷彩展开",desc="受到伤害-2.",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1,removeTrigger={trigger=1,triggerEx={},count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [489] = {id=279851,name="渐隐",desc="受到伤害-10,造成伤害-10.",srcArea={14},targetArea={14},effect={damage = -10,attkAdd = -10},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [490] = {id=280151,name="贯穿模式",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [491] = {id=280251,name="背水一战",desc="+6攻击力",srcArea={14},targetArea={14},effect={attkAdd = 6},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [492] = {id=280252,name="背水一战",desc="EPM-2。",srcArea={8},targetArea={8},effect={powerMax = -2},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [493] = {id=1601251,name="新型能源α",desc="EPM+1。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [494] = {id=1601351,name="新型能源β",desc="EPM+1。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [495] = {id=1601352,name="新型能源β",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [496] = {id=1601451,name="新型能源γ",desc="EPM+1。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [497] = {id=1601651,name="征服旗标",desc="当无人机被派出时，其获得延缓",srcArea={14},targetArea={14},effect={skillAdd = 1601602},flag={removeTrigger={trigger=7,triggerEx={}, count=1},self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [498] = {id=1601652,name="征服旗标",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [499] = {id=1602251,name="跨越最强的理想",desc="EPM+1。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [500] = {id=1602252,name="跨越最强的理想",desc="ATK+1。",srcArea={8},targetArea={14},effect={attkAdd = 1},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [501] = {id=1602351,name="跨越安乐的愿望",desc="EPM+1。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [502] = {id=1602352,name="跨越最强的理想",desc="CA+10。",srcArea={8},targetArea={14},effect={ahpAddDrone =10},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [503] = {id=1602551,name="遭受突袭",desc="EPM-1。",srcArea={8},targetArea={8},effect={powerMax = -1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [504] = {id=1603051,name="数据乱流：修补",desc="CA+10。",srcArea={14},targetArea={14},effect={hpAddDrone =10},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [505] = {id=1603151,name="数据乱流：躁狂",desc="所有机体获得[[轻载]：直到本回合结束，此机体受到的伤害增加1]。",srcArea={14},targetArea={14},effect={skillAdd = 1603102},flag={reserve=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [506] = {id=1603152,name="数据乱流：躁狂",desc="直到本回合结束，此机体受到的伤害增加1。",srcArea={14},targetArea={14},effect={damage = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [507] = {id=1603251,name="十字星的残响",desc="当无人机被派出时，其获得+1/+1。其操控者获得[直到本回合结束，你的无人机牌消耗增加1]。",srcArea={14},targetArea={14},effect={skillAdd = 1603202},flag={self=1,reserve=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [508] = {id=1603252,name="十字星的残响",desc="+1/+1",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [509] = {id=1603253,name="十字星的残响",desc="[直到本回合结束，你的无人机牌消耗增加1]",srcArea={8},targetArea={2,6},effect={costVal=1},flag={},conditionList={2091},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [510] = {id=1603351,name="数据乱流：爆裂",desc="+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={},conditionList={2016},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [511] = {id=1603451,name="数据乱流：自锐",desc="所有主将机体获得[[轻载]:获得+1/+0直到其进行1次攻击]。",srcArea={14},targetArea={14},effect={skillAdd = 1603402},flag={self=1,reserve=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [512] = {id=1603452,name="数据乱流：自锐",desc="+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1,removeTrigger={trigger=129,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [513] = {id=1603551,name="数据乱流：封锁",desc="无法攻击",srcArea={14},targetArea={14},effect={attkPause = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [514] = {id=1603651,name="数据乱流：纠缠",desc="当一张牌被使用时，其操控者随机弃1张牌，然后抽1张牌。",srcArea={14},targetArea={14},effect={skillAdd = 1603602},flag={self=1,reserve=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [515] = {id=1603751,name="数据乱流：砥砺",desc="回合开始时，攻击力为0或1的机体获得+1/+0。",srcArea={14},targetArea={14},effect={skillAdd = 1603702},flag={self=1,reserve=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [516] = {id=1603752,name="数据乱流：砥砺",desc="回合开始时，攻击力为0或1的机体获得+1/+0。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [517] = {id=1603851,name="数据乱流：迟滞",desc="双方每回合使用的第一张战术牌费用减少2。",srcArea={14},targetArea={14},effect={skillAdd = 1603802},flag={self=1,reserve=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [518] = {id=1603852,name="数据乱流：迟滞",desc="本回合中下一张战术牌费用-2",srcArea={8},targetArea={2},effect={costVal=-2},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2087}},count=1}},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [519] = {id=1603853,name="数据乱流：迟滞",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [520] = {id=1603854,name="数据乱流：迟滞",desc="双方每回合第一次使用战术牌时，使其主将机体获得[延缓]。",srcArea={14},targetArea={14},effect={skillAdd = 1603803},flag={self=1,reserve=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [521] = {id=280651,name="拳击手",desc="-2攻击力",srcArea={14},targetArea={14},effect={attkAdd = -2},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [522] = {id=280851,name="定锚观测机",desc="连击3。",srcArea={14},targetArea={14},effect={attkTwice = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [523] = {id=280852,name="定锚观测机",desc="-1攻击直到回合结束",srcArea={14},targetArea={14},effect={attkAdd = -1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [524] = {id=281051,name="信号无人机",desc="你的主将攻击+1。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [525] = {id=281151,name="巨人",desc="-1攻击",srcArea={14},targetArea={14},effect={attkAdd = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [526] = {id=281251,name="蓄力",desc="+3攻击",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [527] = {id=1603951,name="数据乱流：相变",desc="双方派出机体时，若主将处于[延缓]状态，延缓该机体，使主将机体失去延缓。",srcArea={14},targetArea={14},effect={skillAdd = 1603902},flag={self=1,reserve=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [528] = {id=1603952,name="数据乱流：迟滞",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [529] = {id=233051,name="剑舞",desc="对敌方全体造成<attackValue value=3 />伤害，延缓自身。",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [530] = {id=701851,name="特里格拉夫支援",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [531] = {id=233851,name="战争残骸",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [532] = {id=281351,name="黑矮星",desc="+1攻击",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [533] = {id=281352,name="垂死的银星",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,damage=-99},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [534] = {id=281451,name="垂死的银星",desc="卡牌费用变为0",srcArea={14},targetArea={2,6},effect={costSet=0,owerMax = -10},flag={},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [535] = {id=281651,name="陨星",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [536] = {id=281652,name="陨星",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [537] = {id=281751,name="人马旋臂",desc="+2攻击",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [538] = {id=281951,name="天鹅旋臂",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [539] = {id=281952,name="天鹅旋臂",desc="你的旋臂获得贯穿",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={},conditionList={2140},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [540] = {id=282051,name="猎户旋臂",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [541] = {id=282052,name="猎户旋臂",desc="你的旋臂获得连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={},conditionList={2140},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [542] = {id=282251,name="太阳耀斑",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [543] = {id=282351,name="黑子风暴",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [544] = {id=282451,name="不灭日冕",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [545] = {id=282452,name="不灭日冕",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [546] = {id=282551,name="波煞脉动",desc="沉默",srcArea={14},targetArea={14},effect={disable=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [547] = {id=1604051,name="数据乱流：寂灭",desc="[延缓]",srcArea={8},targetArea={14},effect={attkDelay = 1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [548] = {id=281851,name="英仙旋臂",desc="+2攻击",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [549] = {id=751552,name="贯射",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [550] = {id=992751,name="白鸟",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={2024},visibility=0,keywordList={},disable=1,showEffects={}},
    [551] = {id=992752,name="白鸟",desc="回路3：+5/+0",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={self=1},conditionList={0},conditionListSelf={2025},visibility=0,keywordList={},disable=1,showEffects={}},
    [552] = {id=1000051,name="UGM46",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [553] = {id=1000151,name="火炮派出",desc="+4/+0",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [554] = {id=1000251,name="拒马派出",desc="+0/+4",srcArea={14},targetArea={14},effect={hpAddDrone =4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [555] = {id=1000451,name="突击火炮",desc="+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={},conditionList={2066},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [556] = {id=1000751,name="火炮派出",desc="+4/+0",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [557] = {id=1001051,name="远射炮",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [558] = {id=1001151,name="能源栉",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [559] = {id=1001251,name="底牌",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [560] = {id=1001351,name="背水",desc="EPM-1。",srcArea={8},targetArea={8},effect={powerMax = -1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [561] = {id=1001451,name="UGM47",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [562] = {id=1001352,name="背水",desc="+4/+0",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [563] = {id=1001651,name="蓄热充能",desc="EPM+2。",srcArea={8},targetArea={8},effect={powerMax = 2},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [564] = {id=1001951,name="热射线",desc="你造成的热射线伤害增加4。",srcArea={8},targetArea={2,4,6},effect={damageAdd = 4},flag={},conditionList={2018},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [565] = {id=1002151,name="灌注",desc="+1/+1",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone =1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [566] = {id=1002451,name="坚盾",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [567] = {id=1002851,name="覆膜",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [568] = {id=1002951,name="指挥官",desc="+1攻击",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [569] = {id=1003051,name="贯通",desc="直到本回合结束，你的主将机体获得[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [570] = {id=1003651,name="储能",desc="本局内你的战术+2伤害",srcArea={8},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [571] = {id=1003851,name="传输协议",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [572] = {id=1003951,name="成长火炮",desc="每次你使用战术牌时，猎户座攻击力+2",srcArea={14},targetArea={8},effect={skillAdd = 1003902},flag={},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [573] = {id=1003952,name="成长火炮",desc="+2攻击",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [574] = {id=1004251,name="新星爆发",desc="直到回合结束，你的机体牌消耗减少1点",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2052},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [575] = {id=1004851,name="枪身冷却外置",desc="连击1，贯穿，延缓。",srcArea={14},targetArea={14},effect={attkDelay = 1,tagAdd = 409,attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [576] = {id=1005151,name="UN剑诀·叠峦",desc="+3/+3",srcArea={14},targetArea={14},effect={attkAdd = 3,hpAddDrone =3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [577] = {id=1005551,name="阿尔法法斯特",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [578] = {id=1006151,name="白矮星",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [579] = {id=1006251,name="数据乱流：迟滞",desc="本回合中下一张战术牌费用-2",srcArea={8},targetArea={2},effect={costVal=-2},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2087}},count=1}},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [580] = {id=1006351,name="猎户座",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [581] = {id=1006551,name="黑洞",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [582] = {id=1006651,name="白洞",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [583] = {id=1006851,name="侦察机",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [584] = {id=1006852,name="侦察机",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [585] = {id=1006951,name="强能",desc="+4攻击力",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [586] = {id=1007051,name="强射",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [587] = {id=1007151,name="抬枪队",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [588] = {id=1007451,name="深渊凝视+",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [589] = {id=1007551,name="电能灌注",desc="战术伤害增加1",srcArea={8},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [590] = {id=1007651,name="护卫机",desc="受到伤害+1",srcArea={14},targetArea={14},effect={damage = 1},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_02"}},
    [591] = {id=1007951,name="白矮星-新星模式",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,damage=-99},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [592] = {id=1008051,name="全域轰炸",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [593] = {id=1008151,name="按下伏兵",desc="EPM+1。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [594] = {id=1008152,name="按下伏兵",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [595] = {id=1008251,name="以战养战",desc="+4攻击力",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [596] = {id=1008551,name="裁决武装",desc="-4攻击力",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [597] = {id=1008651,name="处刑武装",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [598] = {id=1008851,name="电弧武装",desc="+4攻击力",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [599] = {id=1008951,name="障壁无人机",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [600] = {id=1009051,name="按下伏兵",desc="EPM+1。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [601] = {id=1009151,name="处刑武装",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [602] = {id=1009251,name="γ兵装-8",desc="+2/+1",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone =1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [603] = {id=1009451,name="中继引擎",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6,15},effect={damageAdd = 2},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [604] = {id=1009551,name="声援",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [605] = {id=1009651,name="合一",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [606] = {id=1009751,name="盾",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [607] = {id=1009851,name="矛",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [608] = {id=1010051,name="高压蓄能",desc="+8攻击力",srcArea={14},targetArea={14},effect={attkAdd = 8},flag={self=1,removeTrigger={trigger=129,triggerEx={self=1}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [609] = {id=1010151,name="狙击迷彩",desc="受到伤害-2",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1,removeTrigger={trigger=129,triggerEx={self=1}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [610] = {id=1010251,name="爆破助手",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [611] = {id=1010351,name="狙击助手",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [612] = {id=1010451,name="渐隐",desc="受到伤害-10",srcArea={14},targetArea={14},effect={damage = -10},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [613] = {id=1010551,name="锁定目标",desc="受到伤害+1",srcArea={14},targetArea={14},effect={damage = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [614] = {id=1010651,name="全息白鸟",desc="受到伤害-4",srcArea={14},targetArea={14},effect={damage = -4},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [615] = {id=1010951,name="乌羽",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [616] = {id=1011151,name="乌羽改修",desc="乌羽获得+1攻击",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={},conditionList={2148},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [617] = {id=1011251,name="深入思考",desc="你的战术牌费用减少1点",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={},conditionList={2017},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [618] = {id=1011451,name="导弹改修",desc="导弹伤害增加1",srcArea={8},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2149},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [619] = {id=1011551,name="导弹工厂",desc="导弹伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2149},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [620] = {id=1011651,name="高速捕网",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [621] = {id=1011851,name="狙击引擎",desc="EPM-1。",srcArea={8},targetArea={8},effect={powerMax = -1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [622] = {id=1012151,name="聚能浮游炮",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [623] = {id=1012351,name="改修装置",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={},conditionList={2016},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [624] = {id=1000351,name="火炮攻击",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [625] = {id=1000752,name="突击指令",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [626] = {id=1009951,name="强能狙击",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [627] = {id=1010452,name="渐隐",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [628] = {id=1012551,name="垂死的银星",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,damage=-99},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [629] = {id=1012651,name="垂死的银星",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [630] = {id=1012652,name="垂死的银星",desc="受击",srcArea={14},targetArea={14},effect={deathAdd = 1},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [631] = {id=1012851,name="人马旋臂",desc="+1/+1",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone =1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [632] = {id=1012951,name="英仙旋臂",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={},conditionList={60},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [633] = {id=1013151,name="猎户旋臂",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [634] = {id=1013251,name="ACE-003 猎户座",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [635] = {id=1013451,name="CE9842-琉璃光SP",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,damage=-99},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [636] = {id=1013551,name="星体引力",desc="延缓敌方攻击最高的机体。",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [637] = {id=1013851,name="叩响群星之门",desc="每当回合结束时，你的主将获得+10攻击力。",srcArea={14},targetArea={14},effect={skillAdd = 1013802},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [638] = {id=1013852,name="叩响群星之门",desc="+10攻击力",srcArea={14},targetArea={14},effect={attkAdd = 10},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [639] = {id=1014151,name="扰乱节点",desc="EPM-1",srcArea={14},targetArea={8},effect={powerMax = -1},flag={selfPlayer=0},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [640] = {id=1014251,name="电能灌注",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [641] = {id=1014351,name="战术大师",desc="你的战术牌费用减少1点",srcArea={14},targetArea={2,6},effect={costVal = -1},flag={},conditionList={2151},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [642] = {id=1014651,name="ACE-001 白矮星-新星",desc="若本次攻击破坏敌方机体，则此机体获得+4攻击。",srcArea={14},targetArea={14},effect={skillAdd = 1014602},flag={self=1,removeTrigger={trigger=129,triggerEx={self=1}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [643] = {id=1014652,name="ACE-001 白矮星-新星",desc="+4攻击力",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [644] = {id=1015551,name="光翼无人机H",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone =2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [645] = {id=1015951,name="遗忘的史诗",desc="+5攻击力",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [646] = {id=1016151,name="极境-光翼展开",desc="你的手牌获得[保留]。",srcArea={8},targetArea={2},effect={tagAdd = 302},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [647] = {id=1016351,name="缚柱L",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,attkTargetMiss=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [648] = {id=1016451,name="缚柱R",desc="沉默",srcArea={14},targetArea={14},effect={disable=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [649] = {id=1016751,name="伊米尔改-自锐",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [650] = {id=1016851,name="伊米尔改",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [651] = {id=1017051,name="日晷",desc="-2攻击力",srcArea={14},targetArea={14},effect={attkAdd = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [652] = {id=1017351,name="黑矮星",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [653] = {id=1017451,name="十字星",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,damage=-99},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [654] = {id=1017851,name="提前发薪",desc="+4攻击力",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [655] = {id=1018051,name="特里格拉夫α",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [656] = {id=1018151,name="热力潮汐",desc="每当你的回合结束时（攻击开始之前），对双方全场机体造成1次1点伤害。",srcArea={14},targetArea={14},effect={skillAdd = 1018102},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [657] = {id=1018251,name="稳扎稳打",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [658] = {id=1018351,name="自我强化",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [659] = {id=1018352,name="自我强化",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [660] = {id=1018551,name="集成强化",desc="+2攻击，并获得自身集成能力。",srcArea={14},targetArea={14},effect={attkAdd = 2,stackcardSkillSelf = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [661] = {id=1018651,name="后继之力",desc="回合结束时，你抽2张牌。",srcArea={14},targetArea={14},effect={skillAdd = 1018602},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [662] = {id=1018951,name="临界改修",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [663] = {id=1019351,name="熔铸憎恶",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [664] = {id=1013351,name="薮猫-剑卫式",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,attkTargetMiss=1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [665] = {id=1019951,name="介错",desc="沉默",srcArea={14},targetArea={14},effect={disable=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [666] = {id=1020451,name="防护协议",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [667] = {id=1020452,name="防护协议",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone =2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [668] = {id=1021151,name="ACE-003 猎户座",desc="回路2：EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={2024},visibility=0,keywordList={},disable=1,showEffects={}},
    [669] = {id=1021152,name="ACE-003 猎户座",desc="回路3：你的战术伤害+2。",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2266},conditionListSelf={2025},visibility=0,keywordList={},disable=1,showEffects={}},
    [670] = {id=1021153,name="ACE-003 猎户座",desc="回路4：你的[恒星贯射]费用-2。",srcArea={14},targetArea={2,4,6},effect={costVal = -2},flag={},conditionList={2204},conditionListSelf={2026},visibility=0,keywordList={},disable=1,showEffects={}},
    [671] = {id=1021251,name="ACE-003α 激昂猎户座",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [672] = {id=1021252,name="ACE-003α 激昂猎户座",desc="你的费用3以上的卡费用减少1点",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={},conditionList={2129},conditionListSelf={2025},visibility=0,keywordList={},disable=1,showEffects={}},
    [673] = {id=1021351,name="ACE-003Ω 嗟怨猎户座",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [674] = {id=1021352,name="ACE-003Ω 嗟怨猎户座",desc="你的费用2以上的卡费用减少1点",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={},conditionList={2128},conditionListSelf={2026},visibility=0,keywordList={},disable=1,showEffects={}},
    [675] = {id=1022251,name="复仇无人机β",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [676] = {id=1022551,name="火力升级",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [677] = {id=1022552,name="火力升级",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [678] = {id=235251,name="积蓄能量",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [679] = {id=1022651,name="火力升级+",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [680] = {id=1022652,name="火力升级+",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [681] = {id=1022751,name="装甲升级",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [682] = {id=1022752,name="装甲升级",desc="受到伤害-1",srcArea={14},targetArea={14},effect={damage = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [683] = {id=1022851,name="装甲升级",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [684] = {id=1022852,name="装甲升级",desc="受到伤害-1",srcArea={14},targetArea={14},effect={damage = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [685] = {id=1022951,name="核心升级",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [686] = {id=1022952,name="核心升级",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [687] = {id=1023051,name="核心升级+",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [688] = {id=1023052,name="核心升级+",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [689] = {id=1023951,name="巨型模块",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [690] = {id=1024051,name="巨型模块+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [691] = {id=1024251,name="双翼模块+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [692] = {id=1024851,name="巨构",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [693] = {id=1024951,name="巨构+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [694] = {id=1024952,name="巨构+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [695] = {id=1025051,name="能源栉",desc="EPM+2。",srcArea={14},targetArea={8},effect={powerMax = 2},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [696] = {id=1025151,name="能源栉+",desc="EPM+2。",srcArea={14},targetArea={8},effect={powerMax = 2},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [697] = {id=1025152,name="能源栉+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [698] = {id=1025251,name="武装栉",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [699] = {id=1025351,name="武装栉+",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [700] = {id=1025352,name="武装栉+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [701] = {id=1025451,name="防御栉",desc="受到伤害-2",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [702] = {id=1025551,name="防御栉+",desc="受到伤害-2",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [703] = {id=1025552,name="防御栉+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [704] = {id=1025651,name="储能栉",desc="+1/+1",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone =1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [705] = {id=1025751,name="储能栉+",desc="+1/+1",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone =1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [706] = {id=1025752,name="储能栉+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [707] = {id=1025851,name="翼卫",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [708] = {id=1025951,name="翼卫+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [709] = {id=1026051,name="导引雷达",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [710] = {id=1026151,name="导引雷达+",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [711] = {id=1026251,name="构建仪",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [712] = {id=1026351,name="构建仪+",desc="+2/+1",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone =1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [713] = {id=1026451,name="国王卫",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [714] = {id=1026551,name="国王卫+",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [715] = {id=1026552,name="国王卫+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [716] = {id=1026651,name="皇后卫",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [717] = {id=1026751,name="皇后卫+",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [718] = {id=1026752,name="皇后卫+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [719] = {id=1026851,name="猎狼牙",desc="[贯穿]，+2攻击力",srcArea={14},targetArea={14},effect={tagAdd = 409,attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [720] = {id=1026951,name="猎狼牙+",desc="[贯穿]，+2攻击力",srcArea={14},targetArea={14},effect={tagAdd = 409,attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [721] = {id=1027051,name="构建器",desc="回合开始时获得覆膜",srcArea={14},targetArea={14},effect={skillAdd = 1027001},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [722] = {id=1027052,name="构建器",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [723] = {id=1027151,name="构建器+",desc="回合开始时获得覆膜，+2攻击力",srcArea={14},targetArea={14},effect={skillAdd = 1027101},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [724] = {id=1027152,name="构建器+",desc="[覆膜]，+2攻击力",srcArea={14},targetArea={14},effect={attkShield = 1,attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [725] = {id=1027251,name="潜航器",desc="无法被选为攻击目标",srcArea={14},targetArea={14},effect={attkTargetMiss=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [726] = {id=1027351,name="潜航器+",desc="无法被选为攻击目标",srcArea={14},targetArea={14},effect={attkTargetMiss=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [727] = {id=1027451,name="堡垒",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [728] = {id=1027452,name="堡垒",desc="[贯穿],[覆膜]",srcArea={14},targetArea={14},effect={tagAdd = 409,attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [729] = {id=1027551,name="昂扬堡垒",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [730] = {id=1027552,name="昂扬堡垒",desc="[贯穿],[覆膜]",srcArea={14},targetArea={14},effect={tagAdd = 409,attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [731] = {id=1027651,name="复仇堡垒",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [732] = {id=1027652,name="复仇堡垒",desc="[贯穿],[覆膜]",srcArea={14},targetArea={14},effect={tagAdd = 409,attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [733] = {id=1027751,name="串行总信道",desc="战术伤害增加3",srcArea={14},targetArea={2,4,6},effect={damageAdd = 3},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [734] = {id=1027851,name="串行总信道+",desc="战术伤害增加3",srcArea={14},targetArea={2,4,6},effect={damageAdd = 3},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [735] = {id=1028851,name="覆膜",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [736] = {id=1028951,name="覆膜+",desc="[覆膜]，+2/+2",srcArea={14},targetArea={14},effect={attkShield = 1,attkAdd = 2,hpAddDrone =2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [737] = {id=1029051,name="极限解构",desc="你的无人机牌费用减少99点",srcArea={8},targetArea={2,6},effect={costVal = -99},flag={removeTrigger={trigger=115,count=1}},conditionList={2091},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [738] = {id=1029052,name="极限解构",desc="你的下一张无人机获得消耗",srcArea={14},targetArea={14},effect={skillAdd = 1029002},flag={self=1,removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [739] = {id=1029053,name="极限解构",desc="消耗",srcArea={14},targetArea={14},effect={droneMove = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [740] = {id=1029151,name="极限解构+",desc="你的无人机牌费用减少99点",srcArea={8},targetArea={2,6},effect={costVal = -99},flag={removeTrigger={trigger=115,count=1}},conditionList={2091},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [741] = {id=1029152,name="极限解构+",desc="你的下一张无人机获得消耗",srcArea={14},targetArea={14},effect={skillAdd = 1029102},flag={self=1,removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [742] = {id=1029153,name="极限解构+",desc="消耗",srcArea={14},targetArea={14},effect={droneMove = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [743] = {id=1029251,name="恒星之威",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [744] = {id=1029252,name="恒星之威",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [745] = {id=1029253,name="恒星之威",desc="受到伤害-1",srcArea={14},targetArea={14},effect={damage = -1},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [746] = {id=1029351,name="恒星之威+",desc="+4攻击力",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [747] = {id=1029352,name="恒星之威+",desc="EPM+2。",srcArea={14},targetArea={8},effect={powerMax = 2},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [748] = {id=1029353,name="恒星之威+",desc="受到伤害-1",srcArea={14},targetArea={14},effect={damage = -1},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [749] = {id=1029451,name="电磁压制",desc="沉默",srcArea={14},targetArea={14},effect={disable=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [750] = {id=1029452,name="电磁压制",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [751] = {id=1029551,name="电磁压制+",desc="沉默",srcArea={14},targetArea={14},effect={disable=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [752] = {id=1029552,name="电磁压制+",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [753] = {id=1029651,name="力量解放",desc="+5攻击力",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [754] = {id=1029652,name="力量解放",desc="回合开始时，受到5伤害",srcArea={14},targetArea={14},effect={skillAdd = 1029602},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [755] = {id=1029751,name="力量解放",desc="+8攻击力",srcArea={14},targetArea={14},effect={attkAdd = 8},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [756] = {id=1029752,name="力量解放",desc="回合开始时，受到5伤害",srcArea={14},targetArea={14},effect={skillAdd = 1029702},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [757] = {id=1029851,name="电浆射击",desc="受到伤害+1",srcArea={14},targetArea={14},effect={damage = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [758] = {id=1029951,name="电浆射击+",desc="受到伤害+2",srcArea={14},targetArea={14},effect={damage = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [759] = {id=1030051,name="伤害吸收",desc="受到伤害时抽1张牌",srcArea={14},targetArea={14},effect={skillAdd = 1030002},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [760] = {id=1030151,name="伤害吸收+",desc="受到伤害时抽1张牌，并获得+1攻击力。",srcArea={14},targetArea={14},effect={skillAdd = 1030102},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [761] = {id=1030152,name="伤害吸收+",desc="+1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [762] = {id=1030851,name="驱雷势",desc="被摧毁时，对方抽两张牌。",srcArea={14},targetArea={14},effect={skillAdd = 1030802},flag={self=1,removeTrigger={trigger=119,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [763] = {id=1030951,name="策电势",desc="被摧毁时，对方抽两张牌。",srcArea={14},targetArea={14},effect={skillAdd = 1030902},flag={self=1,removeTrigger={trigger=119,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [764] = {id=1031051,name="剑舞势",desc="延缓",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [765] = {id=1031151,name="剑舞势+",desc="延缓",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [766] = {id=1031251,name="孪星势",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [767] = {id=1031351,name="孪星势+",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [768] = {id=1031651,name="奔袭势",desc="被摧毁时，对方[剑势]牌伤害增加1。",srcArea={14},targetArea={14},effect={skillAdd = 1031602},flag={self=1,removeTrigger={trigger=119,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [769] = {id=261752,name="振剑",desc="剑术伤害增加3",srcArea={14},targetArea={14},effect={stanceAdd = 3},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [770] = {id=1031652,name="奔袭势",desc="剑势伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2121},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [771] = {id=1031751,name="奔袭势+",desc="被摧毁时，对方[剑势]牌伤害增加1。",srcArea={14},targetArea={14},effect={skillAdd = 1031702},flag={self=1,removeTrigger={trigger=119,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [772] = {id=1031653,name="奔袭势",desc="剑势伤害增加1",srcArea={14},targetArea={14},effect={stanceAdd = 1},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [773] = {id=1031752,name="奔袭势+",desc="剑势伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2121},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [774] = {id=1032051,name="凿阵势",desc="延缓",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [775] = {id=1032151,name="凿阵势+",desc="延缓",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [776] = {id=1032451,name="舒展",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [777] = {id=1032551,name="舒展+",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [778] = {id=1032651,name="重整旗鼓",desc="+5攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [779] = {id=1032751,name="重整旗鼓+",desc="+5攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [780] = {id=1032752,name="重整旗鼓+",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,attkTargetMiss=1},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [781] = {id=1033051,name="疾驰折越",desc="延缓",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [782] = {id=1033851,name="疾驰锁定",desc="保留",srcArea={8},targetArea={2},effect={tagAdd = 302},flag={removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [783] = {id=1033951,name="疾驰锁定+",desc="保留",srcArea={8},targetArea={2},effect={tagAdd = 302},flag={removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [784] = {id=1034051,name="疾驰协议",desc="疾驰协议费用+1点",srcArea={8},targetArea={2,6},effect={costVal = 1},flag={},conditionList={2175},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [785] = {id=1034151,name="疾驰突袭",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [786] = {id=1034251,name="疾驰突袭+",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [787] = {id=1034351,name="疾驰湮灭",desc="+1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [788] = {id=1034451,name="疾驰湮灭",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [789] = {id=1034651,name="电磁弹射轨道",desc="无法攻击",srcArea={14},targetArea={14},effect={attkPause = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [790] = {id=1034751,name="电磁弹射轨道+",desc="无法攻击",srcArea={14},targetArea={14},effect={attkPause = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [791] = {id=1031753,name="奔袭势+",desc="剑势伤害增加1",srcArea={14},targetArea={14},effect={stanceAdd = 2},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [792] = {id=1034851,name="核心剑装“敛锋”",desc="剑势伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2121},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [793] = {id=1034852,name="核心剑装“敛锋”",desc="剑势伤害增加2",srcArea={14},targetArea={14},effect={stanceAdd = 2},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [794] = {id=1034951,name="核心剑装“敛锋”+",desc="剑势伤害增加3",srcArea={14},targetArea={2,4,6},effect={damageAdd = 3},flag={},conditionList={2121},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [795] = {id=1035051,name="附加剑装“碎星”",desc="+3攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [796] = {id=1035151,name="附加剑装“碎星”+",desc="+3攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [797] = {id=1035251,name="附加剑装“削月”",desc="+5攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [798] = {id=1035351,name="附加剑装“削月”+",desc="+5攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [799] = {id=1035451,name="附加剑装“斫日”",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [800] = {id=1035551,name="附加剑装“斫日”+",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [801] = {id=1036251,name="上级剑装“纸油”",desc="+3/+3。",srcArea={14},targetArea={14},effect={attkAdd = 3,hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [802] = {id=1036351,name="上级剑装“纸油”+",desc="+3/+3。",srcArea={14},targetArea={14},effect={attkAdd = 3,hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [803] = {id=1036352,name="上级剑装“纸油”+",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [804] = {id=1034952,name="核心剑装“敛锋”+",desc="剑术伤害增加3",srcArea={14},targetArea={14},effect={stanceAdd = 3},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [805] = {id=1036451,name="上级剑装“纳光”",desc="你的下一张[剑势]牌消耗减少3。",srcArea={8},targetArea={2},effect={costVal=-3},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2121}},count=1}},conditionList={2121},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [806] = {id=1036551,name="上级剑装“纳光”+",desc="你的下一张[剑势]牌消耗减少3。",srcArea={8},targetArea={2},effect={costVal=-3},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2121}},count=1}},conditionList={2121},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [807] = {id=1036851,name="剑幕",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone =4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [808] = {id=1036951,name="剑幕+",desc="+2生命值、[覆膜]",srcArea={14},targetArea={14},effect={hpAddDrone =4,attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [809] = {id=1037451,name="雾鸦侦察机α",desc="你的下一张无人机牌消耗减1。",srcArea={8},targetArea={2},effect={costVal=-2},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2064}},count=1}},conditionList={2064},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [810] = {id=1037551,name="雾鸦侦察机β",desc="你的下一张战术牌费用-2",srcArea={8},targetArea={2},effect={costVal=-2},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2087}},count=1}},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [811] = {id=1037851,name="利爪突击机α",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [812] = {id=1037951,name="利爪突击机β",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [813] = {id=1038551,name="电磁突击机β",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [814] = {id=1038651,name="减震支援机α",desc="手牌获得保留",srcArea={14},targetArea={2,4,6},effect={tagAdd = 302},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [815] = {id=1038751,name="减震支援机β",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [816] = {id=1038851,name="安防支援机α",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [817] = {id=1038951,name="安防支援机β",desc="+4攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={2180},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [818] = {id=1039151,name="增速支援机β",desc="变构。派出的回合，你的手牌获得[保留]。",srcArea={8},targetArea={2,4,6},effect={tagAdd = 302},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [819] = {id=1039551,name="UN剑诀·流云",desc="你的所有薮猫获得[回合结束时，抽1张牌]。",srcArea={14},targetArea={14},effect={skillAdd = 1039502},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [820] = {id=1039651,name="UN剑诀·散雾",desc="延缓",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [821] = {id=1039751,name="UN剑诀·听雷",desc="你的所有薮猫获得[当你的主将机体进行攻击时，此机体进行1次攻击]。",srcArea={14},targetArea={14},effect={skillAdd = 1039702},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [822] = {id=1040051,name="激励",desc="+1/+1。",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone =1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [823] = {id=1040351,name="重装入场",desc="若此次攻击破坏敌方机体，则僚机白矮星获得+4攻击。",srcArea={14},targetArea={14},effect={skillAdd = 1040302},flag={self=1,removeTrigger={trigger=129,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [824] = {id=1040352,name="重装入场",desc="+4攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [825] = {id=1040451,name="热炉强化",desc="+4攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [826] = {id=1040551,name="悖论溶解",desc="你的下一张无人机牌消耗减2。",srcArea={8},targetArea={2},effect={costVal=-2},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2064}},count=1}},conditionList={2064},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [827] = {id=1040851,name="连斩",desc="若将其破坏，则创造1张[连斩+]。",srcArea={14},targetArea={14},effect={skillAdd = 1040802},flag={self=1,removeTrigger={trigger=119,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [828] = {id=1041051,name="剑舞",desc="延缓",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [829] = {id=1404651,name="首发优势",desc="+1/+1。",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [830] = {id=1404951,name="细水长流",desc="EPM+1。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [831] = {id=1405151,name="爆发鼓舞",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [832] = {id=1405251,name="顺藤摸瓜",desc="受到的伤害+1。",srcArea={14},targetArea={14},effect={damage = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [833] = {id=1405451,name="闪击协议+",desc="战术牌获得[消耗]和[费用-1]。",srcArea={8},targetArea={2,6},effect={costVal=-2,stackMove=4},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [834] = {id=1405551,name="保护协议+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [835] = {id=1405552,name="保护协议+",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [836] = {id=1405651,name="孢子覆膜",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [837] = {id=1405751,name="闪击协议+",desc="你使用的第一张战术牌结算后进入废弃区。",srcArea={8},targetArea={2,6},effect={stackMove=4},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2087}},count=1}},conditionList={2087},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [838] = {id=1405851,name="古代协议",desc="你的手牌获得[保留]。",srcArea={8},targetArea={2},effect={tagAdd = 302},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [839] = {id=1405951,name="富氧虹吸装置",desc="战术牌获得[费用-3]。",srcArea={8},targetArea={2,6},effect={costVal=-3},flag={},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [840] = {id=1405952,name="富氧虹吸装置",desc="战术牌获得[费用++5]。",srcArea={8},targetArea={2,6},effect={costVal=5},flag={removeTrigger={trigger=7,triggerEx={},count=1}},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [841] = {id=1406351,name="战斗回忆",desc="+2攻击力。",srcArea={8},targetArea={14},effect={attkAdd = 2},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [842] = {id=1406551,name="闪击协议",desc="战术牌获得[消耗]和[费用-2]。",srcArea={8},targetArea={2,6},effect={costVal=-1,stackMove=4},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [843] = {id=1406651,name="保护协议",desc="[覆膜]、[延缓]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [844] = {id=1406652,name="保护协议",desc="[覆膜]、[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [845] = {id=1406751,name="防御姿态",desc="当你的主将处于[延缓]状态时，受到伤害减少2。",srcArea={8},targetArea={14},effect={damage = -2},flag={},conditionList={60,2138},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [846] = {id=1406851,name="逆转局势",desc="受到的伤害-1。",srcArea={14},targetArea={14},effect={damage = -1},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [847] = {id=1406951,name="熟能生巧",desc="+1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [848] = {id=1407151,name="引力舱室",desc="延缓",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [849] = {id=1041551,name="见招拆招",desc="反制敌方下一张战术牌。",srcArea={14},targetArea={14},effect={skillAdd = 1041502},flag={self=1,removeTrigger={trigger=111,triggerEx={srcTag={3},moveTarget=6,src=2}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [850] = {id=1041651,name="防御协议",desc="受到的伤害-2。",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={60},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [851] = {id=1041652,name="防御协议",desc="防御协议费用+1点",srcArea={8},targetArea={2,6},effect={costVal = 1},flag={},conditionList={2187},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [852] = {id=1041151,name="歌者卵",desc="你的主将获得+4攻击。",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [853] = {id=1041751,name="基础组件",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [854] = {id=1041851,name="基础组件+",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [855] = {id=1041951,name="尖锋无人机",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [856] = {id=1042051,name="尖锋无人机+",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [857] = {id=1042151,name="载重无人机",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [858] = {id=1042152,name="载重无人机",desc="+2/+2。",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [859] = {id=1042251,name="污染无人机",desc="离场时，创造1张[污染回路]。",srcArea={14},targetArea={14},effect={skillAdd = 1042202},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [860] = {id=1042351,name="污染无人机+",desc="离场时，创造1张[污染回路]。",srcArea={14},targetArea={14},effect={skillAdd = 1042302},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [861] = {id=1042451,name="污染回路",desc="对你的全部机体造成<attackValue value=2/>伤害]。",srcArea={14},targetArea={14},effect={skillAdd = 1042402},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [862] = {id=1042551,name="激励无人机",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [863] = {id=1042552,name="激励无人机",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [864] = {id=1042651,name="激励无人机+",desc="+1/+1。",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [865] = {id=1042652,name="激励无人机+",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [866] = {id=1042851,name="通讯无人机+",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [867] = {id=1042951,name="通讯无人机",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [868] = {id=1043051,name="通讯无人机+",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [869] = {id=1043151,name="挖掘无人机",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [870] = {id=1043251,name="挖掘无人机+",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [871] = {id=1043551,name="联结指令",desc="此无人机方向异能对自身生效",srcArea={14},targetArea={14},effect={dirSelf = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [872] = {id=1043651,name="联结指令",desc="此无人机方向异能对自身生效",srcArea={14},targetArea={14},effect={dirSelf = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [873] = {id=1043751,name="集成指令",desc="获得自身携带的集成能力。",srcArea={14},targetArea={14},effect={stackcardSkillSelf = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [874] = {id=1043851,name="集成指令+",desc="获得自身携带的集成能力。",srcArea={14},targetArea={14},effect={stackcardSkillSelf = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [875] = {id=1044251,name="对策指令+",desc="你的下一张[战术]指令牌费用-1。",srcArea={8},targetArea={2},effect={costVal=-1},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2188}},count=1}},conditionList={2188},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [876] = {id=1044351,name="精确指令",desc="手牌获得保留",srcArea={8},targetArea={2,4,6},effect={tagAdd = 302},flag={removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [877] = {id=1044451,name="精确指令+",desc="手牌获得保留",srcArea={8},targetArea={2,4,6},effect={tagAdd = 302},flag={removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [878] = {id=1044551,name="镇压指令",desc="-4攻击力",srcArea={14},targetArea={14},effect={attkAdd = -4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [879] = {id=1044651,name="镇压指令+",desc="-4攻击力",srcArea={14},targetArea={14},effect={attkAdd = -4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [880] = {id=1044751,name="强攻指令",desc="延缓",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [881] = {id=1044752,name="强攻指令",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={removeTrigger={trigger=7,count=1}},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [882] = {id=1044851,name="强攻指令+",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={removeTrigger={trigger=7,count=1}},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [883] = {id=1044951,name="集火指令",desc="+8攻击力",srcArea={14},targetArea={14},effect={attkAdd = 8},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [884] = {id=1045051,name="集火指令+",desc="+12攻击力",srcArea={14},targetArea={14},effect={attkAdd = 12},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [885] = {id=1045351,name="坚守指令",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [886] = {id=1045352,name="坚守指令",desc="坚守指令费用+1",srcArea={8},targetArea={2,6},effect={costVal = 1},flag={},conditionList={2191},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [887] = {id=1045451,name="坚守指令+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [888] = {id=1045452,name="坚守指令+",desc="坚守指令费用+1",srcArea={8},targetArea={2,6},effect={costVal = 1},flag={},conditionList={2191},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [889] = {id=1045551,name="扰乱指令",desc="延缓",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [890] = {id=1045651,name="扰乱指令+",desc="延缓",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [891] = {id=1045751,name="指令大师",desc="你的[指令]战术牌费用减少1。",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={},conditionList={2188},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [892] = {id=1045851,name="指令大师+",desc="你的[指令]战术牌费用减少1。",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={},conditionList={2188},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [893] = {id=1046151,name="底牌",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [894] = {id=1046251,name="底牌+",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [895] = {id=1046351,name="武装组件",desc="+2/+2。",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [896] = {id=1046451,name="武装组件+",desc="+3/+3。",srcArea={14},targetArea={14},effect={attkAdd = 3,hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [897] = {id=1046551,name="集成武装",desc="回合结束时，创造1张[集成武装]。",srcArea={14},targetArea={14},effect={skillAdd = 1046501},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [898] = {id=1046651,name="护盾武装",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [899] = {id=1046652,name="护盾武装",desc="[覆膜],+6生命值",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [900] = {id=1046653,name="护盾武装",desc="[覆膜],+6生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 6},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [901] = {id=1046751,name="护盾武装+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [902] = {id=1046752,name="护盾武装+",desc="[覆膜],+6生命值",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [903] = {id=1046753,name="护盾武装+",desc="[覆膜],+6生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 6},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [904] = {id=1046851,name="转运武装",desc="集成-武装：回合结束时，你抽1张牌。",srcArea={14},targetArea={14},effect={skillAdd = 1046802},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [905] = {id=1046951,name="转运武装+",desc="集成-武装：回合结束时，你抽2张牌。",srcArea={14},targetArea={14},effect={skillAdd = 1046902},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [906] = {id=210151,name="过热！",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [907] = {id=1048251,name="螺型无人机",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [908] = {id=1048351,name="螺型无人机+",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [909] = {id=1048651,name="蟹型无人机",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [910] = {id=1048751,name="协同引擎",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [911] = {id=1048851,name="协同锋刃",desc="集成-协同：回合结束时获得+3攻击。",srcArea={14},targetArea={14},effect={skillAdd = 1048802},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [912] = {id=1048852,name="协同锋刃",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [913] = {id=1048951,name="协同网络",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [914] = {id=1049051,name="协同装甲",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [915] = {id=1049052,name="协同装甲",desc="[覆膜]，+4生命值",srcArea={14},targetArea={14},effect={attkShield = 1,hpAddDrone = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [916] = {id=1049151,name="协同框架",desc="集成-协同：回合结束时，每有1点EP，获得+2/+0。",srcArea={14},targetArea={14},effect={skillAdd = 1049101},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [917] = {id=1049152,name="协同框架",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [918] = {id=1049251,name="协同链接",desc="集成-协同：此机体集成时，获得1EP。",srcArea={14},targetArea={14},effect={skillAdd = 1049201},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [919] = {id=1043351,name="整备指令",desc="你的能量上限+2。",srcArea={8},targetArea={8},effect={powerMax = 2},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [920] = {id=1043451,name="整备指令+",desc="你的能量上限+3。",srcArea={8},targetArea={8},effect={powerMax = 3},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [921] = {id=1049451,name="牵制射击",desc="反制敌方下一张牌。",srcArea={14},targetArea={14},effect={skillAdd = 1049402},flag={self=1,removeTrigger={trigger=111,triggerEx={countReset=1,moveTarget=6,src=2}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [922] = {id=1049551,name="蓄力疾驰",desc="保留",srcArea={8},targetArea={2},effect={tagAdd = 302},flag={removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [923] = {id=1050451,name="管理员权限",desc="获得自身携带的方向能力或集成能力。",srcArea={8},targetArea={14},effect={stackcardSkillSelf = 1,dirSelf=1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [924] = {id=1050452,name="管理员权限",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [925] = {id=1050851,name="牺牲",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,attkTargetMiss=1},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [926] = {id=1050951,name="大革命",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [927] = {id=1051151,name="导弹工厂",desc="僚机赝波在场时，每个回合开始时创造1张[红导弹]。",srcArea={14},targetArea={14},effect={skillAdd = 1051102},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [928] = {id=1051251,name="导弹改修",desc="导弹伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2149},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [929] = {id=1051551,name="协同锋刃",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [930] = {id=1051651,name="原型突击",desc="若此次攻击破坏敌方机体，则僚机白矮星获得+4攻击。",srcArea={14},targetArea={14},effect={skillAdd = 1051602},flag={self=1,removeTrigger={trigger=129,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [931] = {id=1051652,name="原型突击",desc="+4攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [932] = {id=1051951,name="阵地激励",desc="机体派出的回合获得+2攻击",srcArea={14},targetArea={14},effect={skillAdd = 1051902},flag={self=1,removeTrigger={trigger=129,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [933] = {id=1051952,name="阵地激励",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [934] = {id=1052051,name="坚固堡垒",desc="手牌获得保留",srcArea={14},targetArea={2,4,6},effect={tagAdd = 302},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [935] = {id=1052121,name="固有阵地",desc="本场战斗中，你的追猎者费用-1。",srcArea={8},targetArea={2,4,6},effect={costVal=-1},flag={},conditionList={2144},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [936] = {id=1052351,name="反击准备",desc="下一次敌方派出机体时，对该机体造成3伤害。",srcArea={14},targetArea={14},effect={skillAdd = 1052302},flag={self=1,removeTrigger={trigger=123,triggerEx={src=2}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [937] = {id=1052551,name="阵地守护",desc="你的无人机派出时获得+2装甲。",srcArea={14},targetArea={14},effect={skillAdd = 1052502},flag={self=1,removeTrigger={trigger=129,triggerEx={srcCondition={2016}}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [938] = {id=1052552,name="阵地守护",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [939] = {id=1052651,name="决战型作战核心",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [940] = {id=1052652,name="决战型作战核心",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [941] = {id=1052751,name="主管无人机",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2266},conditionListSelf={2024},visibility=6,keywordList={},disable=1,showEffects={}},
    [942] = {id=1052951,name="γ巨人",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [943] = {id=1053051,name="决战型作战核心",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [944] = {id=1053151,name="白矮星-鸣响",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [945] = {id=1053251,name="猎户座-狂热",desc="受到伤害-1.",srcArea={14},targetArea={14},effect={damage = -1},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [946] = {id=1053351,name="白鸟-渐隐",desc="+1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [947] = {id=1053451,name="猎户座-决斗",desc="受到伤害-1.",srcArea={14},targetArea={14},effect={damage = -1},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [948] = {id=1053551,name="伊米尔改-龙",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [949] = {id=1054551,name="矩阵派出+",desc="+1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [950] = {id=1054851,name="矩阵调色",desc="+1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [951] = {id=1054951,name="矩阵调色+",desc="+1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [952] = {id=1055251,name="矩阵炸弹",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [953] = {id=1055351,name="矩阵炸弹+",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [954] = {id=1056251,name="混沌矩阵",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [955] = {id=1056351,name="牵制指令",desc="-1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [956] = {id=1056352,name="牵制指令",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [957] = {id=1056451,name="牵制指令+",desc="-2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = -2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [958] = {id=1056452,name="牵制指令+",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [959] = {id=1056651,name="轨道射线+",desc="你的下1张[恒星贯射]能量消耗减少2。",srcArea={14},targetArea={2,4,6},effect={costVal = -2},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2204}},count=1}},conditionList={2204},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [960] = {id=1057651,name="元磁剑典·伏特零式",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [961] = {id=1058151,name="元磁剑典·伏特三式",desc="[电磁]牌伤害增加1。",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266,2227},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [962] = {id=1058851,name="元磁剑典·伏特三式+",desc="[电磁]牌伤害增加1。",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266,2227},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [963] = {id=1058951,name="电磁弹射轨道[new]",desc="无法攻击",srcArea={14},targetArea={14},effect={attkPause = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [964] = {id=1059051,name="电磁弹射轨道[new]+",desc="无法攻击",srcArea={14},targetArea={14},effect={attkPause = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [965] = {id=1059551,name="电磁掠影",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [966] = {id=1059651,name="电磁装置-幽波",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,attkTargetMiss=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [967] = {id=1059652,name="电磁装置-幽波",desc="-1生命值",srcArea={14},targetArea={14},effect={hpAddDrone = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [968] = {id=1059751,name="电磁装置-幽波+",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,attkTargetMiss=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [969] = {id=1059752,name="电磁装置-幽波+",desc="-1生命值",srcArea={14},targetArea={14},effect={hpAddDrone = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [970] = {id=1059851,name="电磁装置-\"夏洛\"",desc="电磁装置-\"夏洛\"消耗-1",srcArea={2},targetArea={2},effect={costVal = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [971] = {id=1059852,name="电磁装置-\"夏洛\"",desc="你的[电磁]牌能量消耗-1。",srcArea={14},targetArea={2,4,6},effect={costVal = -1},flag={},conditionList={2227},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [972] = {id=1059951,name="兵装-\"巨锤\"",desc="无法攻击",srcArea={14},targetArea={14},effect={attkPause = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [973] = {id=1060051,name="兵装-\"巨锤\"+",desc="无法攻击",srcArea={14},targetArea={14},effect={attkPause = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [974] = {id=1059952,name="兵装-\"巨锤\"",desc="-1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [975] = {id=1060052,name="兵装-\"巨锤\"+",desc="-1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [976] = {id=1060551,name="金属小刀",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [977] = {id=1060751,name="贯穿插件",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [978] = {id=1060851,name="贯穿插件+",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [979] = {id=1060951,name="残骸回收装甲",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [980] = {id=1061051,name="残骸回收装甲+",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [981] = {id=1061151,name="振剑-\"提神\"",desc="+5攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [982] = {id=1061251,name="振剑-\"提神\"+",desc="+5攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [983] = {id=1061351,name="振剑-\"驱煞\"",desc="+5+5",srcArea={14},targetArea={14},effect={attkAdd = 5,hpAddDrone = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [984] = {id=1061451,name="振剑-\"驱煞\"+",desc="+5+5",srcArea={14},targetArea={14},effect={attkAdd = 5,hpAddDrone = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [985] = {id=1062151,name="剑装-\"太空\"",desc="连击2",srcArea={14},targetArea={14},effect={attkTwice = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [986] = {id=1062152,name="剑装-\"太空\"",desc="延缓",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [987] = {id=1062651,name="空天机库",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [988] = {id=1062751,name="空天机库+",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [989] = {id=1063051,name="伴机计划",desc="<text_back type=2 content=离场时 />在所在格中派出1台[轻型战机]",srcArea={14},targetArea={14},effect={skillAdd = 1063002},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [990] = {id=1063151,name="伴机计划+",desc="<text_back type=2 content=离场时 />在所在格中派出1台[轻型战机]，你的所有[战机]获得+1/+0。",srcArea={14},targetArea={14},effect={skillAdd = 1063102},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [991] = {id=1063152,name="伴机计划+",desc="+1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [992] = {id=1063451,name="武装神机",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [993] = {id=1063452,name="武装神机",desc="本场战斗中，你每派出过1次[战机]机体，你的[武装神机]能量消耗减少1。",srcArea={14},targetArea={14},effect={skillAdd = 1063402},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [994] = {id=1063453,name="武装神机",desc="你的[武装神机]能量消耗减少1。",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={},conditionList={2237},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [995] = {id=1063551,name="武装神机+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [996] = {id=1063552,name="武装神机+",desc="本场战斗中，你每派出过1次[战机]机体，你的[武装神机]能量消耗减少1。",srcArea={14},targetArea={14},effect={skillAdd = 1063502},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [997] = {id=1063553,name="武装神机+",desc="你的[武装神机]能量消耗减少1。",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={},conditionList={2237},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [998] = {id=1063651,name="强机计划",desc="你的所有[战机]机体获得+1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={},conditionList={2235},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [999] = {id=1063751,name="强机计划+",desc="你的所有[战机]机体获得+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={},conditionList={2235},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1000] = {id=1063851,name="光学迷彩战机",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,attkTargetMiss=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1001] = {id=1063951,name="光学迷彩战机+",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,attkTargetMiss=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1002] = {id=1064251,name="预警侦察机",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={},conditionList={2235},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1003] = {id=1064351,name="预警侦察机+",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={},conditionList={2235},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1004] = {id=1064451,name="快速入场",desc="你的下1张[战机]牌能量消耗为0",srcArea={8},targetArea={2},effect={costVal=-99},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2235}},count=1}},conditionList={2235},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1005] = {id=1064551,name="快速入场+",desc="你的下1张[战机]牌能量消耗为0",srcArea={8},targetArea={2},effect={costVal=-99},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2235}},count=1}},conditionList={2235},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1006] = {id=1065051,name="手术战刀",desc="+4攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1007] = {id=1065151,name="手术战刀+",desc="+6攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 6},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1008] = {id=1065251,name="剪刀机动",desc="[全息]：无法被敌方的攻击和战术卡选为目标。",srcArea={14},targetArea={14},effect={noOtherChoose = 1,attkTargetMiss=1},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1009] = {id=1065351,name="剪刀机动+",desc="[全息]：无法被敌方的攻击和战术卡选为目标。",srcArea={14},targetArea={14},effect={noOtherChoose = 1,attkTargetMiss=1},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1010] = {id=1065352,name="剪刀机动+",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1011] = {id=1065551,name="凸面束镜",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1012] = {id=1065552,name="凸面束镜",desc="激光+1伤害",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [1013] = {id=1065651,name="充能激光",desc="激光+1伤害",srcArea={8},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1014] = {id=1065751,name="充能激光+",desc="激光+1伤害",srcArea={8},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1015] = {id=1065851,name="偏振透镜",desc="激光+1伤害",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [1016] = {id=1065852,name="偏振透镜",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1017] = {id=1065853,name="偏振透镜",desc="当你使用非[激光]牌时，将1张[激光射击]加入你的手牌。",srcArea={14},targetArea={14},effect={skillAdd = 1065801},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1018] = {id=1065951,name="激光聚焦",desc="下一张激光+2伤害",srcArea={8},targetArea={2,4,6},effect={damageAdd = 2},flag={removeTrigger={trigger=111,triggerEx={srcCondition={2265},moveSrc=6},count=1}},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1019] = {id=1066051,name="激光聚焦+",desc="下一张激光+4伤害",srcArea={8},targetArea={2,4,6},effect={damageAdd = 4},flag={removeTrigger={trigger=111,triggerEx={srcCondition={2265},moveSrc=6},count=1}},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1020] = {id=1066151,name="偏振透镜",desc="当你使用[激光]牌时，抽1张牌，此机体获得+1/+0。",srcArea={14},targetArea={14},effect={skillAdd = 1066102},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1021] = {id=1066152,name="偏振透镜",desc="+1攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1022] = {id=1066551,name="激光核心",desc="激光+1伤害",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [1023] = {id=1066552,name="激光核心",desc="当你使用[激光]牌时，此机体获得<text_back type=1 content=覆膜 />。",srcArea={14},targetArea={14},effect={skillAdd = 1066502},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1024] = {id=1066553,name="激光核心",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1025] = {id=1066651,name="怒火激光",desc="激光+1伤害",srcArea={8},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1026] = {id=1066652,name="怒火激光",desc="本场战斗中，你的[怒火激光]与[怒火激光+]能量消耗增加1。",srcArea={8},targetArea={2,4,6},effect={costVal=1},flag={},conditionList={2240},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1027] = {id=1066751,name="怒火激光+",desc="激光+1伤害",srcArea={8},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1028] = {id=1066752,name="怒火激光+",desc="本场战斗中，你的[怒火激光]与[怒火激光+]能量消耗增加1。",srcArea={8},targetArea={2,4,6},effect={costVal=1},flag={},conditionList={2240},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1029] = {id=1066851,name="激光导引",desc="激光+1伤害",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [1030] = {id=1066852,name="激光导引",desc="激光消耗为1",srcArea={14},targetArea={2,4,6},effect={costSet=1},flag={},conditionList={2238},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [1031] = {id=1066853,name="激光导引",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1032] = {id=1066951,name="重铸憎恶",desc="激光+1伤害",srcArea={8},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1033] = {id=1067051,name="重铸憎恶+",desc="激光+1伤害",srcArea={8},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1034] = {id=1019651,name="悖论坍缩",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1035] = {id=1068151,name="协同武装-\"奥格斯特\"",desc="+1/+3",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1036] = {id=1068251,name="协同武装-\"鲁道夫\"",desc="+3攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1037] = {id=1068351,name="协同武装-\"迈克尔\"",desc="当此机体被集成时，本回合中获得<text_back type=1 content=连击1 />。",srcArea={14},targetArea={14},effect={skillAdd = 1068301},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1038] = {id=1068352,name="协同武装-\"迈克尔\"",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1039] = {id=1070051,name="防御协议：命定的围城",desc="+1攻击力，[贯穿]",srcArea={14},targetArea={14},effect={attkAdd = 1,tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1040] = {id=1070351,name="防御中枢 埃阿斯",desc="阿克琉斯受到伤害-2",srcArea={14},targetArea={14},effect={damage = -2},flag={},conditionList={2248},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1041] = {id=1070451,name="攻击中枢 阿克琉斯",desc="此机体的攻击力为11-己方场上机体数。",srcArea={14},targetArea={14},effect={miscFunc={valueType = "targetCount", effectKey="attkAdd",targetId = 110,A=0,B=-1}},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1042] = {id=1070851,name="破阵武装 哈姆雷特",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={2245},visibility=0,keywordList={},disable=1,showEffects={}},
    [1043] = {id=1070852,name="破阵武装 哈姆雷特",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={2246},visibility=0,keywordList={},disable=1,showEffects={}},
    [1044] = {id=1070853,name="破阵武装 哈姆雷特",desc="受到伤害-8.",srcArea={14},targetArea={14},effect={damage = -8},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1045] = {id=1070854,name="破阵武装 哈姆雷特",desc="受到伤害+1.",srcArea={14},targetArea={14},effect={damage = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1046] = {id=1070951,name="附加武装 鬼魂",desc="+2攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1047] = {id=1071051,name="清理协议：未知的明天",desc="[贯穿]，连击1，+10攻击力",srcArea={14},targetArea={14},effect={tagAdd = 409,attkTwice = 1,attkAdd = 10},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1048] = {id=1070651,name="防御协议：王子的复仇",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,damage=-99},flag={removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1049] = {id=1071251,name="绝境绝景",desc="+3攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1050] = {id=1071351,name="冥河之水",desc="直到下个己方回合结束，受到伤害-2.",srcArea={14},targetArea={14},effect={damage = -2},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1051] = {id=1071451,name="奥德修斯之勇",desc="+3攻击力。",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1052] = {id=1071452,name="奥德修斯之勇",desc="无敌",srcArea={14},targetArea={14},effect={noOtherChoose = 1,damage=-99},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1053] = {id=1071551,name="脆弱之名",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1054] = {id=1071751,name="魔鬼之心",desc="离场时，对所有敌方机体造成1伤害",srcArea={14},targetArea={14},effect={skillAdd = 1071702},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1055] = {id=1071851,name="千人千相",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1056] = {id=1071852,name="千人千相",desc="+2/+2。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1057] = {id=1071853,name="千人千相",desc="[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1058] = {id=1072051,name="贬义叙述",desc="反制敌方下一张战术牌。",srcArea={14},targetArea={14},effect={skillAdd = 1072002},flag={self=1,removeTrigger={trigger=111,triggerEx={src=2,moveTarget=6,srcTag={3}}, count=4}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1059] = {id=1072151,name="契诃夫之枪",desc="五回合后对玩家造成30伤害。",srcArea={14},targetArea={14},effect={skillAdd = 1072102},flag={self=1,removeTrigger={trigger=4,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1060] = {id=1072152,name="契诃夫之枪",desc="四回合后对玩家造成30伤害。",srcArea={14},targetArea={14},effect={skillAdd = 1072103},flag={self=1,removeTrigger={trigger=4,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1061] = {id=1072153,name="契诃夫之枪",desc="三回合后对玩家造成30伤害。",srcArea={14},targetArea={14},effect={skillAdd = 1072104},flag={self=1,removeTrigger={trigger=4,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1062] = {id=1072154,name="契诃夫之枪",desc="二回合后对玩家造成30伤害。",srcArea={14},targetArea={14},effect={skillAdd = 1072105},flag={self=1,removeTrigger={trigger=4,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1063] = {id=1072155,name="契诃夫之枪",desc="一回合后对玩家造成30伤害。",srcArea={14},targetArea={14},effect={skillAdd = 1072106},flag={self=1,removeTrigger={trigger=4,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1064] = {id=1072251,name="高昂篇章",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1065] = {id=1072851,name="厄运",desc="你的其他卡牌费用+1",srcArea={2},targetArea={2},effect={costVal=1},flag={self=0},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1066] = {id=1410251,name="空城计",desc="[受到伤害-1]直到下个你的回合开始。",srcArea={14},targetArea={14},effect={damage = -1},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1067] = {id=1410351,name="倾泻火力",desc="战术伤害增加1",srcArea={8},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1068] = {id=1410451,name="强力弹丸",desc="+1攻击力",srcArea={8},targetArea={14},effect={attkAdd = 1},flag={},conditionList={2016},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1069] = {id=1409751,name="装甲损伤",desc="-10生命值",srcArea={8},targetArea={14},effect={hpAddDrone = -10},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1070] = {id=1409851,name="补充装甲+",desc="+20生命值",srcArea={8},targetArea={14},effect={hpAddDrone = 20},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1071] = {id=1409951,name="补充装甲",desc="+10生命值",srcArea={8},targetArea={14},effect={hpAddDrone = 10},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1072] = {id=1410551,name="绝处逢生",desc="+10攻击力",srcArea={8},targetArea={14},effect={attkAdd = 10},flag={},conditionList={60,2256},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1073] = {id=1410651,name="循环增幅算法",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1074] = {id=1411151,name="能量回收算法",desc="直到你的下个回合结束，你的EPM增加1。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={removeTrigger={trigger=7,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [1075] = {id=1411251,name="五轮之书",desc="对敌方全部机体造成5伤害。",srcArea={14},targetArea={14},effect={skillAdd = 1411202},flag={self=1,removeTrigger={trigger=4,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1076] = {id=1411252,name="五轮之书",desc="四回合后对玩家造成5伤害。",srcArea={14},targetArea={14},effect={skillAdd = 1411203},flag={self=1,removeTrigger={trigger=4,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1077] = {id=1411253,name="五轮之书",desc="三回合后对玩家造成5伤害。",srcArea={14},targetArea={14},effect={skillAdd = 1411204},flag={self=1,removeTrigger={trigger=4,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1078] = {id=1411254,name="五轮之书",desc="二回合后对玩家造成5伤害。",srcArea={14},targetArea={14},effect={skillAdd = 1411205},flag={self=1,removeTrigger={trigger=4,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1079] = {id=1411255,name="五轮之书",desc="一回合后对玩家造成5伤害。",srcArea={14},targetArea={14},effect={skillAdd = 1411206},flag={self=1,removeTrigger={trigger=4,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1080] = {id=1411451,name="不动如山",desc="手牌获得保留",srcArea={8},targetArea={2,4,6},effect={tagAdd = 302},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2087}},count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1081] = {id=1411651,name="七七七",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1082] = {id=1411751,name="基础升级",desc="你的[炮击][射击][振剑势]伤害增加2",srcArea={8},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2258},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1083] = {id=1411752,name="基础升级",desc="[高能炮击]伤害增加5。",srcArea={8},targetArea={2,4,6},effect={damageAdd = 5},flag={},conditionList={2259},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1084] = {id=1411951,name="乘胜追击",desc="+2攻击力",srcArea={8},targetArea={14},effect={attkAdd = 2},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1085] = {id=1021451,name="恒星贯射",desc="恒星贯射费用+1点",srcArea={8},targetArea={2,6},effect={costVal = 1},flag={},conditionList={2261},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1086] = {id=1030751,name="振剑式",desc="振剑式费用+1点",srcArea={8},targetArea={2,4,6},effect={costVal = 1},flag={},conditionList={2262},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1087] = {id=1030752,name="振剑式",desc="振剑式增加1",srcArea={8},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2262},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1088] = {id=1073751,name="爆破协议+",desc="对同列所有敌方机体造成5伤害",srcArea={14},targetArea={14},effect={skillAdd = 1073702},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1089] = {id=1074051,name="猎户座-巡猎",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [1090] = {id=1018451,name="伊米尔改-集约",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1091] = {id=1074251,name="伊米尔改-扩散",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1092] = {id=1074451,name="薮猫-强袭式",desc="连击2",srcArea={14},targetArea={14},effect={attkTwice = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1093] = {id=1050351,name="即刻逃逸",desc="手牌获得保留",srcArea={2},targetArea={2,4,6},effect={tagAdd = 302},flag={self=1,removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1094] = {id=1050251,name="猎户座-精准",desc="EPM+2。",srcArea={14},targetArea={8},effect={powerMax = 2},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_02"}},
    [1095] = {id=1074751,name="猎户座-刺神",desc="连击3。",srcArea={14},targetArea={14},effect={attkTwice = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1096] = {id=1050651,name="特里格拉夫β",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1097] = {id=1074951,name="白矮星-巡航",desc="手牌获得保留",srcArea={14},targetArea={2,4,6},effect={tagAdd = 302},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1098] = {id=1039451,name="薮猫-游侠式",desc="手牌获得保留",srcArea={8},targetArea={2,4,6},effect={tagAdd = 302},flag={removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1099] = {id=1075451,name="蓄能追猎",desc="你的[追猎者-哨戒]获得[当敌方机体被派出时，对其造成2伤害]。",srcArea={14},targetArea={14},effect={skillAdd = 1075402},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1100] = {id=710851,name="预警机“套娃”",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1101] = {id=710951,name="预警机“套娃”+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1102] = {id=1075551,name="中继引擎+",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1103] = {id=1032251,name="横扫势",desc="延缓。",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1104] = {id=1032351,name="横扫势+",desc="延缓。",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1105] = {id=1075751,name="十字星",desc="回路4：+5攻击力，连击1",srcArea={14},targetArea={14},effect={attkAdd = 5,attkTwice = 1},flag={self=1},conditionList={2052},conditionListSelf={2026},visibility=0,keywordList={},disable=1,showEffects={}},
    [1106] = {id=1075851,name="十字星-圣域模式",desc="回路4：+5攻击力，连击1",srcArea={14},targetArea={14},effect={attkAdd = 5,attkTwice = 1},flag={self=1},conditionList={2052},conditionListSelf={2026},visibility=0,keywordList={},disable=1,showEffects={}},
    [1107] = {id=2100051,name="ACE-003 猎户座",desc="回路2：[贯穿],+3生命值",srcArea={14},targetArea={14},effect={tagAdd = 409,hpAddDrone = 3},flag={},conditionList={0},conditionListSelf={2024},visibility=0,keywordList={},disable=1,showEffects={}},
    [1108] = {id=2100052,name="ACE-003 猎户座",desc="回路4：+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={2026},visibility=0,keywordList={},disable=1,showEffects={}},
    [1109] = {id=752251,name="自爆倒计时",desc="将在指定回合自爆",srcArea={14},targetArea={14},effect={boomAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1110] = {id=1075951,name="覆膜无人机",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1111] = {id=1076151,name="闪击无人机",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1112] = {id=1076551,name="质能提取+",desc="手牌获得保留",srcArea={8},targetArea={2,4,6},effect={tagAdd = 302},flag={removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1113] = {id=1076651,name="闪击无人机",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1114] = {id=1076751,name="闪击无人机+",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1115] = {id=1077251,name="闪击无人机",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1116] = {id=1077351,name="闪击无人机+",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1117] = {id=1077451,name="防御单元",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1118] = {id=1077452,name="防御单元",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1119] = {id=1077551,name="防御单元+",desc="+3攻击力",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1120] = {id=1077552,name="防御单元+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1121] = {id=1510051,name="老兵",desc="EPM+1。",srcArea={8},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [1122] = {id=1510052,name="老兵",desc="+2/+2",srcArea={8},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={targetCamp=1},conditionList={2016},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [1123] = {id=1510151,name="牺牲",desc="你的主将获得+4攻击",srcArea={8},targetArea={14},effect={attkAdd = 4},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [1124] = {id=1510152,name="牺牲",desc="每当敌方无人机离场时，敌方主将回复3CA。",srcArea={8},targetArea={14},effect={skillAdd = 1510101},flag={targetCamp=1},conditionList={2016},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1125] = {id=1510251,name="坍塌",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [1126] = {id=1510451,name="枭首",desc="+4/+4",srcArea={14},targetArea={14},effect={attkAdd = 4,hpAddDrone = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1127] = {id=1077851,name="圣域之锚",desc="不会成为敌方攻击、战术卡的目标",srcArea={14},targetArea={14},effect={noOtherChoose = 1,attkTargetMiss=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1128] = {id=1078351,name="护教军",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1129] = {id=1078352,name="护教军",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1130] = {id=1078551,name="重弩手",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1131] = {id=1078751,name="黑洞",desc="+1攻击力",srcArea={14},targetArea={14},effect={miscFunc={valueType = "targetCount", effectKey="attkAdd",targetId = 669,A=0,B=1}},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1132] = {id=1078752,name="黑洞",desc="不会成为敌方攻击的目标",srcArea={14},targetArea={14},effect={attkTargetMiss=1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1133] = {id=1078851,name="白洞",desc="不会成为敌方战术卡的目标",srcArea={14},targetArea={14},effect={noOtherChoose = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1134] = {id=1078951,name="衔尾蛇",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [1135] = {id=1078952,name="衔尾蛇",desc="直到本回合结束，获得[贯穿]",srcArea={14},targetArea={14},effect={tagAdd = 409},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1136] = {id=1079051,name="元气弹",desc="三回合后摧毁敌方所有机体。",srcArea={14},targetArea={14},effect={skillAdd = 1079002},flag={self=1,removeTrigger={trigger=2,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1137] = {id=1079052,name="元气弹",desc="二回合后摧毁敌方所有机体。",srcArea={14},targetArea={14},effect={skillAdd = 1079003},flag={self=1,removeTrigger={trigger=2,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1138] = {id=1079053,name="元气弹",desc="一回合后摧毁敌方所有机体。",srcArea={14},targetArea={14},effect={skillAdd = 1079004},flag={self=1,removeTrigger={trigger=2,triggerEx={}, count=2}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1139] = {id=1510951,name="异常损耗",desc="-4攻击力",srcArea={8},targetArea={14},effect={attkAdd = -4},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [1140] = {id=1511051,name="中枢磨损",desc="战术伤害-2",srcArea={8},targetArea={2,4,6},effect={damageAdd = -2},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [1141] = {id=1511151,name="缓启动",desc="[延缓]",srcArea={8},targetArea={14},effect={attkDelay = 1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [1142] = {id=1511351,name="副炮损伤",desc="-1攻击力",srcArea={14},targetArea={14},effect={attkAdd = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1143] = {id=1510351,name="守财",desc="连击1，贯穿",srcArea={8},targetArea={14},effect={tagAdd = 409,attkTwice = 1},flag={},conditionList={60},conditionListSelf={2285},visibility=6,keywordList={},disable=1,showEffects={}},
    [1144] = {id=1510352,name="守财",desc="连击1，贯穿",srcArea={8},targetArea={14},effect={tagAdd = 409,attkTwice = 1},flag={targetCamp=1},conditionList={60},conditionListSelf={2286},visibility=6,keywordList={},disable=1,showEffects={}},
    [1145] = {id=1079251,name="强化指令",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1146] = {id=1079351,name="强化指令+",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1147] = {id=1079451,name="威力投射器",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [1148] = {id=1079551,name="威力投射器+",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [1149] = {id=1079651,name="冲击型“鲨吻”",desc="+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1150] = {id=1079751,name="冲击型“鲨吻”+",desc="+3/+0",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1151] = {id=1079851,name="网络挖矿单元",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1152] = {id=1079852,name="网络挖矿单元",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1153] = {id=1080251,name="战术指令",desc="你的下一张战术牌消耗减2。",srcArea={8},targetArea={2},effect={costVal=-2},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2017}},count=1}},conditionList={2017},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1154] = {id=1080351,name="战术指令+",desc="你的下一张战术牌消耗减3。",srcArea={8},targetArea={2},effect={costVal=-3},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2017}},count=1}},conditionList={2017},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1155] = {id=1080651,name="倾泻指令",desc="直到本回合结束，你的战术体牌能量消耗减少1。",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2017},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1156] = {id=1080751,name="倾泻指令+",desc="直到本回合结束，你的战术体牌能量消耗减少1。",srcArea={8},targetArea={2,6},effect={costVal = -1},flag={removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2017},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1157] = {id=1072059,name="贬义叙述",desc="+4次反制",srcArea={14},targetArea={14},effect={negaAdd = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1158] = {id=1072058,name="贬义叙述",desc="-1次反制",srcArea={14},targetArea={14},effect={negaAdd = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1159] = {id=1080851,name="巨盾无人机",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1160] = {id=1080951,name="巨盾无人机+",desc="+3生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1161] = {id=1081051,name="破坏无人机",desc="+1生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1162] = {id=1081151,name="破坏无人机+",desc="+2生命值",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1163] = {id=1081451,name="情势递归核心",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1164] = {id=1081551,name="情势递归核心+",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1165] = {id=1081651,name="击掌奇袭",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1166] = {id=1081751,name="击掌奇袭+",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1167] = {id=1081851,name="杀戮掠夺",desc="若此无人机被破坏，敌方下一张牌消耗-2",srcArea={14},targetArea={14},effect={skillAdd = 1081802},flag={self=1,removeTrigger={trigger=119,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1168] = {id=1082251,name="士官无人机",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=0,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2016},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1169] = {id=1082351,name="士官无人机+",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=0,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={2016},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1170] = {id=1082751,name="螺型无人机β",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [1171] = {id=1082851,name="螺型无人机β+",desc="战术伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [1172] = {id=1083051,name="ACE-004 极境",desc="连击1",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1173] = {id=1083451,name="轨道射线+",desc="你的下1张[恒星贯射]能量消耗减少2。",srcArea={14},targetArea={2,4,6},effect={costVal = -2},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2204}},count=1}},conditionList={2204},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1174] = {id=1083751,name="幻影势",desc="+2攻击力",srcArea={8},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={2291},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1175] = {id=1083851,name="幻影势+",desc="+2攻击力",srcArea={8},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={2291},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1176] = {id=1083951,name="散华势",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1177] = {id=1084051,name="散华势+",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1178] = {id=1084251,name="疾驰幻影",desc="疾驰幻影费用+1点",srcArea={8},targetArea={2,6},effect={costVal = 1},flag={},conditionList={2292},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1179] = {id=1084551,name="剑意化形百式",desc="剑装牌获得保留",srcArea={8},targetArea={2,4,6},effect={tagAdd = 302},flag={},conditionList={2289},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1180] = {id=1084552,name="剑意化形百式",desc="剑装牌费用为1",srcArea={8},targetArea={2,4,6},effect={costSet = 1},flag={},conditionList={2289},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1181] = {id=1084751,name="剑意化形壹式",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1182] = {id=1084851,name="剑意化形壹式+",desc="+3/+3",srcArea={14},targetArea={14},effect={attkAdd = 3,hpAddDrone = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1183] = {id=1085151,name="剑意化形叁式",desc="每回合一次，当你使用战术牌时，抽一张剑势牌，获得+2/+2。",srcArea={14},targetArea={14},effect={attkAdd = 1,hpAddDrone = 2,skillAdd = 1085101},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1184] = {id=1085152,name="剑意化形叁式",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1185] = {id=1085251,name="剑意化形叁式+",desc="每回合一次，当你使用战术牌时，抽一张剑势牌，获得+2/+2。",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2,skillAdd = 1085201},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1186] = {id=1085252,name="剑意化形叁式+",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1187] = {id=1085351,name="匠·剑意化形壹式",desc="+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1188] = {id=1085451,name="匠·剑意化形壹式+",desc="+4/+4",srcArea={14},targetArea={14},effect={attkAdd = 4,hpAddDrone = 4},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1189] = {id=1085751,name="匠·剑意化形叁式",desc="你的下一张卡牌能量消耗-3",srcArea={8},targetArea={2},effect={costVal=-3},flag={removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1190] = {id=1085851,name="匠·剑意化形叁式+",desc="你的下一张卡牌能量消耗-3",srcArea={8},targetArea={2},effect={costVal=-3},flag={removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1191] = {id=1085951,name="化剑势",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1192] = {id=1086051,name="化剑势+",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1193] = {id=1086151,name="疾驰跃进",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1194] = {id=1086251,name="疾驰跃进+",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1195] = {id=1086351,name="FOX迷彩",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1196] = {id=1086352,name="FOX迷彩",desc="+10攻击力",srcArea={14},targetArea={14},effect={attkAdd = 10},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1197] = {id=1086451,name="XOF机兵",desc="+10攻击力",srcArea={14},targetArea={14},effect={attkAdd = 10},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1198] = {id=1800351,name="团队作战",desc="每个回合你派出的第一台僚机费用减少3",srcArea={8},targetArea={2},effect={costVal=-3},flag={removeTrigger={trigger=115,triggerEx={srcCondition={61}},count=1}},conditionList={61},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1199] = {id=1800651,name="钢铁洪流",desc="你的无人机获得[消耗]。每当你的机体消耗时，创造1张随机的1费无人机牌到你的手牌。",srcArea={14},targetArea={14},effect={droneMove = 4},flag={},conditionList={2016},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1200] = {id=1801051,name="保守主义",desc="战斗开始时，你的主将获得[受到伤害+3]。每当你的机体离场时，你的主将回复3CA。",srcArea={14},targetArea={14},effect={damage = 3},flag={},conditionList={60},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [1201] = {id=1801151,name="众矢之的",desc="直到本回合结束，受到的伤害增加1",srcArea={14},targetArea={14},effect={damage = 1},flag={self=1,removeTrigger={trigger=7,count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [1202] = {id=1800451,name="更强的无人机",desc="双方的无人机派出时获得1倍于原本装甲数的额外装甲和上限。",srcArea={14},targetArea={14},effect={miscFunc={valueType = "cardFieldValue", name = "configHp", effectKey="hpAddDrone",A=0,B=1}},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [1203] = {id=1100251,name="装甲无人机γ",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1204] = {id=1100351,name="装甲无人机γ",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1205] = {id=1100551,name="蓄力核心",desc="连击3。",srcArea={14},targetArea={14},effect={attkTwice = 3},flag={self=1},conditionList={0},conditionListSelf={2024},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1206] = {id=1100552,name="蓄力核心",desc="连击6。",srcArea={14},targetArea={14},effect={attkTwice = 6},flag={self=1},conditionList={0},conditionListSelf={2026},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1207] = {id=1101351,name="整备炮管",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1208] = {id=1101352,name="整备炮管",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [1209] = {id=1101251,name="穿甲子炮台β",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1210] = {id=1101152,name="穿甲子炮台α",desc="+0/+2",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1211] = {id=1101252,name="穿甲子炮台β",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1212] = {id=1101151,name="穿甲子炮台α",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1213] = {id=1101051,name="穿甲炮台",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1214] = {id=1032652,name="重整旗鼓",desc="直到你的下个回合开始，你的主将机体受到的伤害减少10。",srcArea={14},targetArea={14},effect={damage = -10},flag={self=1,removeTrigger={trigger=1,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_debuffhold_01"}},
    [1215] = {id=1101851,name="充能射击",desc="你的下一张战术牌费用-1",srcArea={8},targetArea={2},effect={costVal=-1},flag={removeTrigger={trigger=115,triggerEx={srcCondition={2087}},count=1}},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1216] = {id=1102051,name="废热回收模组",desc="此机体获得+0/+1。",srcArea={14},targetArea={14},effect={hpAddDrone = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1217] = {id=1102151,name="废热回收模组+",desc="此机体获得+0/+2。",srcArea={14},targetArea={14},effect={hpAddDrone = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1218] = {id=1102251,name="废热放出模组",desc="此机体获得+1/+0。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1219] = {id=1102351,name="废热放出模组+",desc="此机体获得+2/+0。",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1220] = {id=1102451,name="供能过载",desc="在你的下个回合开始时，失去1EP。",srcArea={14},targetArea={14},effect={skillAdd = 1102402},flag={self=1,removeTrigger={trigger=4,count=1,triggerEx={}}},conditionList={60},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1221] = {id=1102651,name="能源运输单元",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1222] = {id=1102652,name="能源运输单元",desc="此机体获得+0/-1。",srcArea={14},targetArea={14},effect={hpAddDrone = -1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1223] = {id=2100751,name="自我修复",desc="延缓自身1回合",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={},count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1224] = {id=1103351,name="CEF-101 日晷",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1225] = {id=1103551,name="废料处理机“饰带”",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1226] = {id=1103851,name="CEF-102 扫除者",desc="每当敌方无人机离场时，你的主将机体获得+1/+0。",srcArea={8},targetArea={14},effect={skillAdd = 1103801},flag={targetCamp=1},conditionList={2016},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1227] = {id=1103852,name="CEF-102 扫除者",desc="获得+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1228] = {id=1104751,name="通讯干扰模块",desc="你的无人机牌能量消耗增加1。",srcArea={14},targetArea={2,6},effect={costVal=1},flag={targetCamp=1},conditionList={2091},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1229] = {id=1104851,name="出力干扰模块",desc="你的战术牌能量消耗增加1。",srcArea={14},targetArea={2,6},effect={costVal=1},flag={targetCamp=1},conditionList={2087},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1230] = {id=1103651,name="UGM-46 干扰者",desc="每当回合结束时，你的主将获得+2/+0。",srcArea={14},targetArea={14},effect={skillAdd = 1103601},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1231] = {id=2100951,name="总攻号令",desc="",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [1232] = {id=2100952,name="",desc="",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1233] = {id=2101451,name="指挥总攻",desc="此机体获得+4/+0。",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1234] = {id=2101051,name="蓄力核心",desc="战术伤害增加3",srcArea={8},targetArea={2,4,6},effect={damageAdd = 3},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [1235] = {id=2100958,name="",desc="",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1236] = {id=245451,name="火力中枢",desc="此机体获得+5/+0。",srcArea={14},targetArea={14},effect={attkAdd = 5},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1237] = {id=2100953,name="",desc="",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={enemy=1,trigger={trigger=21,triggerEx={},count=-1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1238] = {id=2100960,name="",desc="",srcArea={14},targetArea={14},effect={},flag={enemy=1,trigger={trigger=20,triggerEx={},count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1239] = {id=2104051,name="能量补给舱",desc="主将攻击力+3",srcArea={14},targetArea={14},effect={attkAdd = 3},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1240] = {id=2104451,name="复制工蜂",desc="你的所有复制工蜂获得+1/+0。",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={},conditionList={2299},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1241] = {id=2104551,name="蜂群增幅塔",desc="攻击力在3以下的机体获得[连击2]",srcArea={14},targetArea={2,6,14},effect={attkTwice = 2},flag={},conditionList={2315},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1242] = {id=2104552,name="蜂群增幅塔",desc="[连击]2",srcArea={14},targetArea={14},effect={attkTwice = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1243] = {id=2104751,name="散射袭扰机",desc="每当你的机体攻击时，对敌方主将造成2伤害。",srcArea={14},targetArea={14},effect={skillAdd = 2104701},flag={},conditionList={2016},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1244] = {id=2103551,name="火力中继器",desc="+1攻击力",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1245] = {id=2103851,name="协击共振单元",desc="[延缓]",srcArea={14},targetArea={14},effect={attkDelay = 1},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1246] = {id=2105651,name="悖论模拟引擎",desc="你的EPM减少2",srcArea={14},targetArea={8},effect={powerMax = -2},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [1247] = {id=2105652,name="悖论模拟引擎",desc="你的所有卡牌能量消耗减少1",srcArea={14},targetArea={2},effect={costVal=-1},flag={},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1248] = {id=2105551,name="协同增幅单元",desc="你的协同牌能量消耗增加1",srcArea={14},targetArea={2},effect={costVal=1},flag={},conditionList={2301},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1249] = {id=2105552,name="协同增幅单元",desc="激光+2伤害",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2265},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [1250] = {id=2105451,name="指令统筹单元",desc="你的指令牌能量消耗增加1",srcArea={14},targetArea={2},effect={costVal=1},flag={},conditionList={2303},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1251] = {id=2105452,name="指令统筹单元",desc="你的所有武装无人机获得+2/+2。",srcArea={14},targetArea={14},effect={attkAdd = 2,hpAddDrone = 2},flag={},conditionList={2304},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [1252] = {id=2105251,name="武装觉醒",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [1253] = {id=2105252,name="武装觉醒",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_02"}},
    [1254] = {id=2106351,name="铁木",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1255] = {id=2106451,name="夏洛",desc="战术伤害增加1",srcArea={14},targetArea={2,4,6},effect={damageAdd = 1},flag={},conditionList={2266},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={"mecha_common_uav_buffhold_01"}},
    [1256] = {id=2106352,name="铁木",desc="获得[在你的回合开始时，对此机体造成1伤害。]",srcArea={14},targetArea={14},effect={skillAdd = 2106302},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1257] = {id=2106452,name="夏洛",desc="获得[在你的回合开始时，对此机体造成1伤害。]",srcArea={14},targetArea={14},effect={skillAdd = 2106402},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1258] = {id=2106951,name="邮差",desc="离场时，对所有敌方机体造成5伤害。",srcArea={14},targetArea={14},effect={skillAdd = 2106902},flag={},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1259] = {id=2108051,name="邮差",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1260] = {id=2108052,name="邮差",desc="你的所有机体获得覆膜",srcArea={14},targetArea={14},effect={skillAdd = 2108001},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=0,showEffects={}},
    [1261] = {id=2108053,name="邮差",desc="离场时，你的所有机体获得[覆膜]",srcArea={14},targetArea={14},effect={skillAdd = 2108002},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1262] = {id=2107051,name="掮客",desc="所有被搭乘的机体获得+2/+2",srcArea={14},targetArea={14},effect={skillAdd = 2107001},flag={self=1},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1263] = {id=2107052,name="掮客",desc="所有获得+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2, hpAddDrone = 2},flag={},conditionList={2310},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1264] = {id=2107151,name="掮客",desc="你的所有无人机获得+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={selfPlayer=1},conditionList={501},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
    [1265] = {id=2107251,name="掮客",desc="EPM+1。",srcArea={14},targetArea={8},effect={powerMax = 1},flag={},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=0,showEffects={}},
    [1266] = {id=2107351,name="掮客",desc="+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1267] = {id=2107352,name="掮客",desc="连击1。",srcArea={14},targetArea={14},effect={attkTwice = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1268] = {id=2107551,name="掮客",desc="<text_back type=2 content=集成 />此机体获得+1/+0",srcArea={14},targetArea={14},effect={skillAdd = 2107501},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1269] = {id=2107552,name="掮客",desc="+1/+0",srcArea={14},targetArea={14},effect={attkAdd = 1},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1270] = {id=2107652,name="掮客",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1271] = {id=2107751,name="掮客",desc="<text_back type=2 content=集成 />本回合中你的主将机体获得+2/+0",srcArea={14},targetArea={14},effect={skillAdd = 2107701},flag={self=1,removeTrigger={trigger=7,triggerEx={}, count=1}},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1272] = {id=2107752,name="掮客",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1273] = {id=2107851,name="奥斯陆",desc="+0/+10",srcArea={14},targetArea={14},effect={hpAddDrone = 10},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1274] = {id=2107852,name="奥斯陆",desc="覆膜",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1275] = {id=2107853,name="奥斯陆",desc="<text_back type=2 content=离场时 />对你的主将机体造成10伤害",srcArea={14},targetArea={14},effect={skillAdd = 2107801},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1276] = {id=2107951,name="希尔达",desc="<text_back type=2 content=离场时 />在所在格中派出1台[轻型战机]",srcArea={14},targetArea={14},effect={skillAdd = 2107901},flag={self=1},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1277] = {id=2108251,name="保险服务",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1278] = {id=2108551,name="邮差",desc="你的所有[标准无人机]获得+3/+3",srcArea={14},targetArea={14},effect={attkAdd = 3, hpAddDrone = 3},flag={},conditionList={2164},conditionListSelf={},visibility=6,keywordList={{}},disable=1,showEffects={}},
    [1279] = {id=2108651,name="邮差",desc="你的所有[重锤武装]、[重锤武装+]、[长矛武装]与[长矛武装+]获得+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2, hpAddDrone = 2},flag={},conditionList={2311},conditionListSelf={},visibility=6,keywordList={{}},disable=1,showEffects={}},
    [1280] = {id=2108751,name="邮差",desc="你的所有[影隼侦察机α]与[利爪突击机α]获得+2/+2",srcArea={14},targetArea={14},effect={attkAdd = 2, hpAddDrone = 2},flag={},conditionList={2312},conditionListSelf={},visibility=6,keywordList={{}},disable=1,showEffects={}},
    [1281] = {id=2108851,name="邮差",desc="你的[炮击]伤害增加3",srcArea={14},targetArea={2,4,6},effect={damageAdd = 3},flag={},conditionList={2163},conditionListSelf={},visibility=6,keywordList={{}},disable=1,showEffects={}},
    [1282] = {id=2108951,name="邮差",desc="你的[射击]与[射击+]伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2313},conditionListSelf={},visibility=6,keywordList={{}},disable=1,showEffects={}},
    [1283] = {id=2109051,name="邮差",desc="你的[振剑势]伤害增加2",srcArea={14},targetArea={2,4,6},effect={damageAdd = 2},flag={},conditionList={2262},conditionListSelf={},visibility=6,keywordList={{}},disable=1,showEffects={}},
    [1284] = {id=2103251,name="火力中继器",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1285] = {id=2103552,name="火力中继器",desc="+2攻击力",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1286] = {id=2104651,name="覆膜投射器",desc="[覆膜]",srcArea={14},targetArea={14},effect={attkShield = 1},flag={self=1},conditionList={0},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={"mecha_common_uav_buffhold_01"}},
    [1287] = {id=2107753,name="掮客",desc="+2/+0",srcArea={14},targetArea={14},effect={attkAdd = 2},flag={self=1,removeTrigger={trigger=7,triggerEx={},count=1}},conditionList={},conditionListSelf={},visibility=0,keywordList={},disable=1,showEffects={}},
    [1288] = {id=760153,name="数据干扰",desc="下一张牌消耗+3",srcArea={8},targetArea={2},effect={costVal=3},flag={removeTrigger={trigger=115,count=1}},conditionList={0},conditionListSelf={},visibility=6,keywordList={},disable=1,showEffects={}},
}
local config = {}
local config_loaded = {}
local config_languages = {}

local function config_load(index)
    if index == nil then return nil end
    if config_loaded[index] then return config[index] end
    local source = config_source[index]
    if source == nil then return nil end
    local rowLanguage = config_languages[index] or language
    local data = ConfigRowRuntime.Build(source,config_runtime_schema,"static_skill_def",rowLanguage)
    config[index] = data
    config_loaded[index] = true
    return data
end

function static_skill_def.config_index(index)
    return config_load(index)
end

function static_skill_def.config_set(index,data)
    config[index] = data
    config_loaded[index] = true
end

function static_skill_def.config_num()
    return config_num
end

local config_id =
{
    [104]=1,[105]=2,[106]=3,[992651]=4,[993251]=5,[200651]=6,[200751]=7,[201051]=8,[201651]=9,[201751]=10,[201851]=11,[201852]=12,[201853]=13,[201951]=14,[201952]=15,[201953]=16,[202151]=17,[202251]=18,[202252]=19,[203051]=20,[203151]=21,[203251]=22,[203351]=23,[203551]=24,[203751]=25,[203752]=26,[203951]=27,[204351]=28,[204451]=29,[204551]=30,[204651]=31,[204751]=32,[204951]=33,[205051]=34,[205351]=35,[205451]=36,[205551]=37,[206351]=38,[206751]=39,[207551]=40,[208051]=41,[208351]=42,[208551]=43,[208651]=44,[208751]=45,[208951]=46,[208952]=47,[209151]=48,[210551]=49,[210552]=50,[210553]=51,[210751]=52,[212351]=53,[300251]=54,[300351]=55,[300352]=56,[300451]=57,[300551]=58,[300651]=59,[301251]=60,[213951]=61,[214351]=62,[214551]=63,[217951]=64,[218051]=65,[214752]=66,[214852]=67,[214951]=68,[215051]=69,[215151]=70,[215551]=71,[215552]=72,[215651]=73,[215652]=74,[215951]=75,[215952]=76,[216052]=77,[216951]=78,[217051]=79,[217351]=80,[217451]=81,[217751]=82,[217851]=83,[217752]=84,[217852]=85,[218151]=86,[230451]=87,[230551]=88,[230751]=89,[230951]=90,[231051]=91,[231651]=92,[231951]=93,[232151]=94,[232152]=95,[232551]=96,[232651]=97,[232751]=98,[232851]=99,[233151]=100,[233351]=101,[233451]=102,[233551]=103,[233651]=104,[233751]=105,[234151]=106,[234152]=107,[234251]=108,[234351]=109,[234451]=110,[241451]=111,[241452]=112,[241551]=113,[241552]=114,[241751]=115,[241851]=116,[242051]=117,[242451]=118,[243051]=119,[243151]=120,[243451]=121,[243452]=122,[243453]=123,[244651]=124,[244751]=125,[244951]=126,[245051]=127,[245251]=128,[245551]=129,[235451]=130,[235452]=131,[235851]=132,[236251]=133,[236252]=134,[236351]=135,[236451]=136,[236551]=137,[236751]=138,[236851]=139,[236951]=140,[237151]=141,[237152]=142,[237153]=143,[237551]=144,[237851]=145,[238951]=146,[239051]=147,[239052]=148,[239151]=149,[239251]=150,[239351]=151,[240051]=152,[240451]=153,[243751]=154,[243752]=155,[243951]=156,[243952]=157,[244251]=158,[244252]=159,[244451]=160,[244452]=161,[400051]=162,[400151]=163,[400851]=164,[401151]=165,[401351]=166,[401352]=167,[401451]=168,[401452]=169,[401551]=170,[402051]=171,[402151]=172,[402251]=173,[402351]=174,[403051]=175,[403151]=176,[403152]=177,[403251]=178,[403252]=179,[403351]=180,[403451]=181,[403551]=182,[403552]=183,[403651]=184,[220352]=185,[220651]=186,[220751]=187,[220851]=188,[221151]=189,[221451]=190,[221551]=191,[221751]=192,[221752]=193,[221753]=194,[222251]=195,[222252]=196,[220151]=197,[220152]=198,[220153]=199,[220251]=200,[220351]=201,[220353]=202,[234851]=203,[234951]=204,[234852]=205,[234952]=206,[503551]=207,[503552]=208,[700051]=209,[700151]=210,[700351]=211,[700551]=212,[700651]=213,[700751]=214,[700851]=215,[701051]=216,[701151]=217,[701551]=218,[701552]=219,[701701]=220,[248151]=221,[700251]=222,[700451]=223,[710351]=224,[710451]=225,[710551]=226,[711351]=227,[711451]=228,[711452]=229,[711651]=230,[711751]=231,[712151]=232,[712251]=233,[750051]=234,[750151]=235,[750251]=236,[750351]=237,[750451]=238,[750452]=239,[750551]=240,[750552]=241,[750751]=242,[751051]=243,[751251]=244,[751351]=245,[751451]=246,[751551]=247,[751651]=248,[752151]=249,[752152]=250,[752153]=251,[752451]=252,[752452]=253,[752851]=254,[753351]=255,[753451]=256,[753951]=257,[754051]=258,[754351]=259,[755151]=260,[755251]=261,[756251]=262,[756351]=263,[756651]=264,[756751]=265,[756851]=266,[758051]=267,[758151]=268,[758351]=269,[758651]=270,[758751]=271,[758851]=272,[759351]=273,[759451]=274,[759551]=275,[759651]=276,[250751]=277,[250951]=278,[251151]=279,[251351]=280,[251551]=281,[251751]=282,[251951]=283,[252151]=284,[253951]=285,[254151]=286,[254551]=287,[255351]=288,[255751]=289,[255951]=290,[255952]=291,[256151]=292,[256351]=293,[256551]=294,[256552]=295,[256751]=296,[257551]=297,[257751]=298,[257951]=299,[258151]=300,[760151]=301,[760152]=302,[760351]=303,[760551]=304,[760751]=305,[761151]=306,[761351]=307,[761352]=308,[761551]=309,[762151]=310,[762351]=311,[762751]=312,[763151]=313,[763351]=314,[763551]=315,[258351]=316,[258551]=317,[258751]=318,[258752]=319,[761451]=320,[763251]=321,[763451]=322,[763651]=323,[759151]=324,[764351]=325,[764451]=326,[240851]=327,[242751]=328,[242851]=329,[1600051]=330,[1600151]=331,[1600251]=332,[1600252]=333,[1600351]=334,[1600352]=335,[1600451]=336,[1600452]=337,[1600651]=338,[800151]=339,[800351]=340,[800451]=341,[800751]=342,[800951]=343,[801051]=344,[801151]=345,[801351]=346,[801701]=347,[850051]=348,[850052]=349,[850251]=350,[850252]=351,[850451]=352,[850452]=353,[850651]=354,[850652]=355,[850653]=356,[850851]=357,[850852]=358,[850853]=359,[851051]=360,[851052]=361,[851053]=362,[851054]=363,[851251]=364,[851451]=365,[851651]=366,[851851]=367,[851852]=368,[852051]=369,[852251]=370,[852451]=371,[852651]=372,[852851]=373,[853051]=374,[853451]=375,[853452]=376,[853651]=377,[853851]=378,[854251]=379,[854451]=380,[854651]=381,[854851]=382,[855251]=383,[855252]=384,[855451]=385,[855452]=386,[855651]=387,[855652]=388,[855851]=389,[855852]=390,[856051]=391,[856251]=392,[856451]=393,[856651]=394,[857051]=395,[857251]=396,[857252]=397,[857253]=398,[857451]=399,[857452]=400,[857651]=401,[857652]=402,[857851]=403,[857852]=404,[858051]=405,[800152]=406,[403951]=407,[404451]=408,[404551]=409,[404552]=410,[404251]=411,[403751]=412,[403851]=413,[260151]=414,[260152]=415,[260351]=416,[260551]=417,[260751]=418,[260752]=419,[261351]=420,[260753]=421,[261751]=422,[263351]=423,[263551]=424,[264151]=425,[264351]=426,[264551]=427,[264751]=428,[265551]=429,[265552]=430,[265951]=431,[266151]=432,[266351]=433,[266551]=434,[266951]=435,[267151]=436,[267351]=437,[267551]=438,[268151]=439,[268351]=440,[268551]=441,[268951]=442,[269751]=443,[269951]=444,[270151]=445,[270152]=446,[270351]=447,[270551]=448,[270951]=449,[271751]=450,[272351]=451,[272352]=452,[272751]=453,[272951]=454,[272952]=455,[273151]=456,[273351]=457,[273551]=458,[273951]=459,[275051]=460,[275251]=461,[275451]=462,[275551]=463,[276151]=464,[276251]=465,[276651]=466,[276951]=467,[277051]=468,[277151]=469,[277152]=470,[277153]=471,[277251]=472,[277351]=473,[277551]=474,[277552]=475,[277751]=476,[277951]=477,[278101]=478,[278251]=479,[278351]=480,[278451]=481,[278851]=482,[278951]=483,[279151]=484,[279251]=485,[279351]=486,[279352]=487,[279751]=488,[279851]=489,[280151]=490,[280251]=491,[280252]=492,[1601251]=493,[1601351]=494,[1601352]=495,[1601451]=496,[1601651]=497,[1601652]=498,[1602251]=499,[1602252]=500,[1602351]=501,[1602352]=502,[1602551]=503,[1603051]=504,[1603151]=505,[1603152]=506,[1603251]=507,[1603252]=508,[1603253]=509,[1603351]=510,[1603451]=511,[1603452]=512,[1603551]=513,[1603651]=514,[1603751]=515,[1603752]=516,[1603851]=517,[1603852]=518,[1603853]=519,[1603854]=520,[280651]=521,[280851]=522,[280852]=523,[281051]=524,[281151]=525,[281251]=526,[1603951]=527,[1603952]=528,[233051]=529,[701851]=530,[233851]=531,[281351]=532,[281352]=533,[281451]=534,[281651]=535,[281652]=536,[281751]=537,[281951]=538,[281952]=539,[282051]=540,[282052]=541,[282251]=542,[282351]=543,[282451]=544,[282452]=545,[282551]=546,[1604051]=547,[281851]=548,[751552]=549,[992751]=550,[992752]=551,[1000051]=552,[1000151]=553,[1000251]=554,[1000451]=555,[1000751]=556,[1001051]=557,[1001151]=558,[1001251]=559,[1001351]=560,[1001451]=561,[1001352]=562,[1001651]=563,[1001951]=564,[1002151]=565,[1002451]=566,[1002851]=567,[1002951]=568,[1003051]=569,[1003651]=570,[1003851]=571,[1003951]=572,[1003952]=573,[1004251]=574,[1004851]=575,[1005151]=576,[1005551]=577,[1006151]=578,[1006251]=579,[1006351]=580,[1006551]=581,[1006651]=582,[1006851]=583,[1006852]=584,[1006951]=585,[1007051]=586,[1007151]=587,[1007451]=588,[1007551]=589,[1007651]=590,[1007951]=591,[1008051]=592,[1008151]=593,[1008152]=594,[1008251]=595,[1008551]=596,[1008651]=597,[1008851]=598,[1008951]=599,[1009051]=600,[1009151]=601,[1009251]=602,[1009451]=603,[1009551]=604,[1009651]=605,[1009751]=606,[1009851]=607,[1010051]=608,[1010151]=609,[1010251]=610,[1010351]=611,[1010451]=612,[1010551]=613,[1010651]=614,[1010951]=615,[1011151]=616,[1011251]=617,[1011451]=618,[1011551]=619,[1011651]=620,[1011851]=621,[1012151]=622,[1012351]=623,[1000351]=624,[1000752]=625,[1009951]=626,[1010452]=627,[1012551]=628,[1012651]=629,[1012652]=630,[1012851]=631,[1012951]=632,[1013151]=633,[1013251]=634,[1013451]=635,[1013551]=636,[1013851]=637,[1013852]=638,[1014151]=639,[1014251]=640,[1014351]=641,[1014651]=642,[1014652]=643,[1015551]=644,[1015951]=645,[1016151]=646,[1016351]=647,[1016451]=648,[1016751]=649,[1016851]=650,[1017051]=651,[1017351]=652,[1017451]=653,[1017851]=654,[1018051]=655,[1018151]=656,[1018251]=657,[1018351]=658,[1018352]=659,[1018551]=660,[1018651]=661,[1018951]=662,[1019351]=663,[1013351]=664,[1019951]=665,[1020451]=666,[1020452]=667,[1021151]=668,[1021152]=669,[1021153]=670,[1021251]=671,[1021252]=672,[1021351]=673,[1021352]=674,[1022251]=675,[1022551]=676,[1022552]=677,[235251]=678,[1022651]=679,[1022652]=680,[1022751]=681,[1022752]=682,[1022851]=683,[1022852]=684,[1022951]=685,[1022952]=686,[1023051]=687,[1023052]=688,[1023951]=689,[1024051]=690,[1024251]=691,[1024851]=692,[1024951]=693,[1024952]=694,[1025051]=695,[1025151]=696,[1025152]=697,[1025251]=698,[1025351]=699,[1025352]=700,[1025451]=701,[1025551]=702,[1025552]=703,[1025651]=704,[1025751]=705,[1025752]=706,[1025851]=707,[1025951]=708,[1026051]=709,[1026151]=710,[1026251]=711,[1026351]=712,[1026451]=713,[1026551]=714,[1026552]=715,[1026651]=716,[1026751]=717,[1026752]=718,[1026851]=719,[1026951]=720,[1027051]=721,[1027052]=722,[1027151]=723,[1027152]=724,[1027251]=725,[1027351]=726,[1027451]=727,[1027452]=728,[1027551]=729,[1027552]=730,[1027651]=731,[1027652]=732,[1027751]=733,[1027851]=734,[1028851]=735,[1028951]=736,[1029051]=737,[1029052]=738,[1029053]=739,[1029151]=740,[1029152]=741,[1029153]=742,[1029251]=743,[1029252]=744,[1029253]=745,[1029351]=746,[1029352]=747,[1029353]=748,[1029451]=749,[1029452]=750,[1029551]=751,[1029552]=752,[1029651]=753,[1029652]=754,[1029751]=755,[1029752]=756,[1029851]=757,[1029951]=758,[1030051]=759,[1030151]=760,[1030152]=761,[1030851]=762,[1030951]=763,[1031051]=764,[1031151]=765,[1031251]=766,[1031351]=767,[1031651]=768,[261752]=769,[1031652]=770,[1031751]=771,[1031653]=772,[1031752]=773,[1032051]=774,[1032151]=775,[1032451]=776,[1032551]=777,[1032651]=778,[1032751]=779,[1032752]=780,[1033051]=781,[1033851]=782,[1033951]=783,[1034051]=784,[1034151]=785,[1034251]=786,[1034351]=787,[1034451]=788,[1034651]=789,[1034751]=790,[1031753]=791,[1034851]=792,[1034852]=793,[1034951]=794,[1035051]=795,[1035151]=796,[1035251]=797,[1035351]=798,[1035451]=799,[1035551]=800,[1036251]=801,[1036351]=802,[1036352]=803,[1034952]=804,[1036451]=805,[1036551]=806,[1036851]=807,[1036951]=808,[1037451]=809,[1037551]=810,[1037851]=811,[1037951]=812,[1038551]=813,[1038651]=814,[1038751]=815,[1038851]=816,[1038951]=817,[1039151]=818,[1039551]=819,[1039651]=820,[1039751]=821,[1040051]=822,[1040351]=823,[1040352]=824,[1040451]=825,[1040551]=826,[1040851]=827,[1041051]=828,[1404651]=829,[1404951]=830,[1405151]=831,[1405251]=832,[1405451]=833,[1405551]=834,[1405552]=835,[1405651]=836,[1405751]=837,[1405851]=838,[1405951]=839,[1405952]=840,[1406351]=841,[1406551]=842,[1406651]=843,[1406652]=844,[1406751]=845,[1406851]=846,[1406951]=847,[1407151]=848,[1041551]=849,[1041651]=850,[1041652]=851,[1041151]=852,[1041751]=853,[1041851]=854,[1041951]=855,[1042051]=856,[1042151]=857,[1042152]=858,[1042251]=859,[1042351]=860,[1042451]=861,[1042551]=862,[1042552]=863,[1042651]=864,[1042652]=865,[1042851]=866,[1042951]=867,[1043051]=868,[1043151]=869,[1043251]=870,[1043551]=871,[1043651]=872,[1043751]=873,[1043851]=874,[1044251]=875,[1044351]=876,[1044451]=877,[1044551]=878,[1044651]=879,[1044751]=880,[1044752]=881,[1044851]=882,[1044951]=883,[1045051]=884,[1045351]=885,[1045352]=886,[1045451]=887,[1045452]=888,[1045551]=889,[1045651]=890,[1045751]=891,[1045851]=892,[1046151]=893,[1046251]=894,[1046351]=895,[1046451]=896,[1046551]=897,[1046651]=898,[1046652]=899,[1046653]=900,[1046751]=901,[1046752]=902,[1046753]=903,[1046851]=904,[1046951]=905,[210151]=906,[1048251]=907,[1048351]=908,[1048651]=909,[1048751]=910,[1048851]=911,[1048852]=912,[1048951]=913,[1049051]=914,[1049052]=915,[1049151]=916,[1049152]=917,[1049251]=918,[1043351]=919,[1043451]=920,[1049451]=921,[1049551]=922,[1050451]=923,[1050452]=924,[1050851]=925,[1050951]=926,[1051151]=927,[1051251]=928,[1051551]=929,[1051651]=930,[1051652]=931,[1051951]=932,[1051952]=933,[1052051]=934,[1052121]=935,[1052351]=936,[1052551]=937,[1052552]=938,[1052651]=939,[1052652]=940,[1052751]=941,[1052951]=942,[1053051]=943,[1053151]=944,[1053251]=945,[1053351]=946,[1053451]=947,[1053551]=948,[1054551]=949,[1054851]=950,[1054951]=951,[1055251]=952,[1055351]=953,[1056251]=954,[1056351]=955,[1056352]=956,[1056451]=957,[1056452]=958,[1056651]=959,[1057651]=960,[1058151]=961,[1058851]=962,[1058951]=963,[1059051]=964,[1059551]=965,[1059651]=966,[1059652]=967,[1059751]=968,[1059752]=969,[1059851]=970,[1059852]=971,[1059951]=972,[1060051]=973,[1059952]=974,[1060052]=975,[1060551]=976,[1060751]=977,[1060851]=978,[1060951]=979,[1061051]=980,[1061151]=981,[1061251]=982,[1061351]=983,[1061451]=984,[1062151]=985,[1062152]=986,[1062651]=987,[1062751]=988,[1063051]=989,[1063151]=990,[1063152]=991,[1063451]=992,[1063452]=993,[1063453]=994,[1063551]=995,[1063552]=996,[1063553]=997,[1063651]=998,[1063751]=999,[1063851]=1000,[1063951]=1001,[1064251]=1002,[1064351]=1003,[1064451]=1004,[1064551]=1005,[1065051]=1006,[1065151]=1007,[1065251]=1008,[1065351]=1009,[1065352]=1010,[1065551]=1011,[1065552]=1012,[1065651]=1013,[1065751]=1014,[1065851]=1015,[1065852]=1016,[1065853]=1017,[1065951]=1018,[1066051]=1019,[1066151]=1020,[1066152]=1021,[1066551]=1022,[1066552]=1023,[1066553]=1024,[1066651]=1025,[1066652]=1026,[1066751]=1027,[1066752]=1028,[1066851]=1029,[1066852]=1030,[1066853]=1031,[1066951]=1032,[1067051]=1033,[1019651]=1034,[1068151]=1035,[1068251]=1036,[1068351]=1037,[1068352]=1038,[1070051]=1039,[1070351]=1040,[1070451]=1041,[1070851]=1042,[1070852]=1043,[1070853]=1044,[1070854]=1045,[1070951]=1046,[1071051]=1047,[1070651]=1048,[1071251]=1049,[1071351]=1050,[1071451]=1051,[1071452]=1052,[1071551]=1053,[1071751]=1054,[1071851]=1055,[1071852]=1056,[1071853]=1057,[1072051]=1058,[1072151]=1059,[1072152]=1060,[1072153]=1061,[1072154]=1062,[1072155]=1063,[1072251]=1064,[1072851]=1065,[1410251]=1066,[1410351]=1067,[1410451]=1068,[1409751]=1069,[1409851]=1070,[1409951]=1071,[1410551]=1072,[1410651]=1073,[1411151]=1074,[1411251]=1075,[1411252]=1076,[1411253]=1077,[1411254]=1078,[1411255]=1079,[1411451]=1080,[1411651]=1081,[1411751]=1082,[1411752]=1083,[1411951]=1084,[1021451]=1085,[1030751]=1086,[1030752]=1087,[1073751]=1088,[1074051]=1089,[1018451]=1090,[1074251]=1091,[1074451]=1092,[1050351]=1093,[1050251]=1094,[1074751]=1095,[1050651]=1096,[1074951]=1097,[1039451]=1098,[1075451]=1099,[710851]=1100,[710951]=1101,[1075551]=1102,[1032251]=1103,[1032351]=1104,[1075751]=1105,[1075851]=1106,[2100051]=1107,[2100052]=1108,[752251]=1109,[1075951]=1110,[1076151]=1111,[1076551]=1112,[1076651]=1113,[1076751]=1114,[1077251]=1115,[1077351]=1116,[1077451]=1117,[1077452]=1118,[1077551]=1119,[1077552]=1120,[1510051]=1121,[1510052]=1122,[1510151]=1123,[1510152]=1124,[1510251]=1125,[1510451]=1126,[1077851]=1127,[1078351]=1128,[1078352]=1129,[1078551]=1130,[1078751]=1131,[1078752]=1132,[1078851]=1133,[1078951]=1134,[1078952]=1135,[1079051]=1136,[1079052]=1137,[1079053]=1138,[1510951]=1139,[1511051]=1140,[1511151]=1141,[1511351]=1142,[1510351]=1143,[1510352]=1144,[1079251]=1145,[1079351]=1146,[1079451]=1147,[1079551]=1148,[1079651]=1149,[1079751]=1150,[1079851]=1151,[1079852]=1152,[1080251]=1153,[1080351]=1154,[1080651]=1155,[1080751]=1156,[1072059]=1157,[1072058]=1158,[1080851]=1159,[1080951]=1160,[1081051]=1161,[1081151]=1162,[1081451]=1163,[1081551]=1164,[1081651]=1165,[1081751]=1166,[1081851]=1167,[1082251]=1168,[1082351]=1169,[1082751]=1170,[1082851]=1171,[1083051]=1172,[1083451]=1173,[1083751]=1174,[1083851]=1175,[1083951]=1176,[1084051]=1177,[1084251]=1178,[1084551]=1179,[1084552]=1180,[1084751]=1181,[1084851]=1182,[1085151]=1183,[1085152]=1184,[1085251]=1185,[1085252]=1186,[1085351]=1187,[1085451]=1188,[1085751]=1189,[1085851]=1190,[1085951]=1191,[1086051]=1192,[1086151]=1193,[1086251]=1194,[1086351]=1195,[1086352]=1196,[1086451]=1197,[1800351]=1198,[1800651]=1199,[1801051]=1200,[1801151]=1201,[1800451]=1202,[1100251]=1203,[1100351]=1204,[1100551]=1205,[1100552]=1206,[1101351]=1207,[1101352]=1208,[1101251]=1209,[1101152]=1210,[1101252]=1211,[1101151]=1212,[1101051]=1213,[1032652]=1214,[1101851]=1215,[1102051]=1216,[1102151]=1217,[1102251]=1218,[1102351]=1219,[1102451]=1220,[1102651]=1221,[1102652]=1222,[2100751]=1223,[1103351]=1224,[1103551]=1225,[1103851]=1226,[1103852]=1227,[1104751]=1228,[1104851]=1229,[1103651]=1230,[2100951]=1231,[2100952]=1232,[2101451]=1233,[2101051]=1234,[2100958]=1235,[245451]=1236,[2100953]=1237,[2100960]=1238,[2104051]=1239,[2104451]=1240,[2104551]=1241,[2104552]=1242,[2104751]=1243,[2103551]=1244,[2103851]=1245,[2105651]=1246,[2105652]=1247,[2105551]=1248,[2105552]=1249,[2105451]=1250,[2105452]=1251,[2105251]=1252,[2105252]=1253,[2106351]=1254,[2106451]=1255,[2106352]=1256,[2106452]=1257,[2106951]=1258,[2108051]=1259,[2108052]=1260,[2108053]=1261,[2107051]=1262,[2107052]=1263,[2107151]=1264,[2107251]=1265,[2107351]=1266,[2107352]=1267,[2107551]=1268,[2107552]=1269,[2107652]=1270,[2107751]=1271,[2107752]=1272,[2107851]=1273,[2107852]=1274,[2107853]=1275,[2107951]=1276,[2108251]=1277,[2108551]=1278,[2108651]=1279,[2108751]=1280,[2108851]=1281,[2108951]=1282,[2109051]=1283,[2103251]=1284,[2103552]=1285,[2104651]=1286,[2107753]=1287,[760153]=1288
}

function static_skill_def.config_id(key)
    local index = config_id[key]
    return static_skill_def.config_index(index)
end

local configSheets =
{
    ["config"] =
    {
        schema = config_schema,
        indexes =
        {
            { indexKey = "id", fields = {"id"}, fieldTypes = {"int"}, group = false },
        },
    },
}

local configSheetRuntimes =
{
    ["config"] =
    {
        getRows = function() return config_source end,
        getLanguages = function() return config_languages end,
        getSchema = function() return config_runtime_schema end,
        publish = function(rows,indexes,schema,languages)
            config_source = rows
            config_runtime_schema = schema or config_schema
            config_languages = languages or {}
            config = {}
            config_loaded = {}
            config_num = #rows
            config_id = indexes["id"] or {}
        end,
    },
}

local function BuildIndexKey(row,fields)
    if #fields == 1 then return row[fields[1]] end
    local values = {}
    for index,fieldName in ipairs(fields) do
        values[index] = tostring(row[fieldName])
    end
    return table.concat(values,"_")
end

local function BuildIndexKeyFromValue(value,fields)
    if #fields == 1 then return value end
    if type(value) ~= "table" or #value ~= #fields then return nil end
    local values = {}
    for index = 1,#fields do values[index] = tostring(value[index]) end
    return table.concat(values,"_")
end

local function ValidateRowsTable(rows)
    if type(rows) ~= "table" then return false,"配置行集合需要 table" end
    local count = 0
    for key in pairs(rows) do
        if type(key) ~= "number" or key < 1 or key % 1 ~= 0 then
            return false,string.format("配置行集合包含无效数组键[%s]",tostring(key))
        end
        count = count + 1
    end
    for index = 1,count do
        if rows[index] == nil then return false,string.format("配置行集合存在空洞[%s]",index) end
    end
    return true
end

local function GetIndexRule(info,installKey)
    local indexKey = nil
    if type(installKey) == "string" then
        indexKey = installKey
    elseif type(installKey) == "table" then
        local valid,err = ValidateRowsTable(installKey)
        if not valid then return nil,err end
        local fields = {}
        for index,fieldName in ipairs(installKey) do
            if type(fieldName) ~= "string" then return nil,string.format("installKey第%s项需要 string",index) end
            fields[index] = fieldName
        end
        indexKey = table.concat(fields,",")
    else
        return nil,string.format("installKey需要 string 或有序字段数组，实际为 %s",type(installKey))
    end
    for _,rule in ipairs(info.indexes) do
        if rule.indexKey == indexKey then return rule end
    end
    return nil,string.format("installKey未匹配现有查询索引[%s]",tostring(indexKey))
end

function static_skill_def.GetSheetInfo(sheetName)
    return configSheets[sheetName]
end

function static_skill_def.CaptureState(sheetName)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    return { rows = runtime.getRows(), languages = runtime.getLanguages(), schema = runtime.getSchema() }
end

function static_skill_def.RestoreState(sheetName,state)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    if type(state) ~= "table" or type(state.rows) ~= "table" or type(state.languages) ~= "table" or type(state.schema) ~= "table" then
        return false,"配置快照无效"
    end
    local indexes,indexErr = static_skill_def.BuildIndexes(sheetName,state.rows,true,state.schema)
    if indexes == nil then return false,indexErr end
    runtime.publish(state.rows,indexes,state.schema,state.languages)
    return true
end

function static_skill_def.ValidateRow(sheetName,row,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return false,schemaErr end
    return ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
end

function static_skill_def.BuildIndexes(sheetName,rows,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    local rowsValid,rowsErr = ValidateRowsTable(rows)
    if not rowsValid then return nil,rowsErr end
    local indexes = {}
    for _,rule in ipairs(info.indexes) do indexes[rule.indexKey] = {} end
    for index,row in ipairs(rows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",index,err) end
        for _,rule in ipairs(info.indexes) do
            local key = BuildIndexKey(row,rule.fields)
            local target = indexes[rule.indexKey]
            if rule.group then
                target[key] = target[key] or {}
                table.insert(target[key],index)
            else
                target[key] = index
            end
        end
    end
    return indexes
end

local function RemoveRowOwners(info,owners,row,rowIndex)
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local key = BuildIndexKey(row,rule.fields)
            local keyOwners = owners[rule.indexKey][key]
            if keyOwners ~= nil then
                for ownerIndex = #keyOwners,1,-1 do
                    if keyOwners[ownerIndex] == rowIndex then table.remove(keyOwners,ownerIndex) end
                end
                if #keyOwners == 0 then owners[rule.indexKey][key] = nil end
            end
        end
    end
end

local function ResolveNewRowConflicts(info,groupRule,rows,languages,newRowIndexes)
    local owners = {}
    local active = {}
    local isNew = {}
    local conflicts = {}
    for _,rowIndex in ipairs(newRowIndexes) do isNew[rowIndex] = true end
    for _,rule in ipairs(info.indexes) do if not rule.group then owners[rule.indexKey] = {} end end
    for rowIndex,row in ipairs(rows) do
        active[rowIndex] = true
        if not isNew[rowIndex] then
            for _,rule in ipairs(info.indexes) do
                if not rule.group then
                    local key = BuildIndexKey(row,rule.fields)
                    local keyOwners = owners[rule.indexKey][key] or {}
                    table.insert(keyOwners,rowIndex)
                    owners[rule.indexKey][key] = keyOwners
                end
            end
        end
    end
    for _,rowIndex in ipairs(newRowIndexes) do
        local row = rows[rowIndex]
        local removeIndexes = {}
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                local keyOwners = owners[rule.indexKey][key]
                if keyOwners ~= nil then
                    for _,oldIndex in ipairs(keyOwners) do
                        if active[oldIndex] then
                            removeIndexes[oldIndex] = true
                            table.insert(conflicts,{
                                indexKey = rule.indexKey,
                                key = key,
                                oldIndex = oldIndex,
                                newIndex = rowIndex,
                                oldGroupKey = BuildIndexKey(rows[oldIndex],groupRule.fields),
                                newGroupKey = BuildIndexKey(row,groupRule.fields),
                            })
                        end
                    end
                end
            end
        end
        for oldIndex in pairs(removeIndexes) do
            active[oldIndex] = false
            RemoveRowOwners(info,owners,rows[oldIndex],oldIndex)
        end
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                owners[rule.indexKey][key] = {rowIndex}
            end
        end
    end
    local result = {}
    local resultLanguages = {}
    for rowIndex,row in ipairs(rows) do
        if active[rowIndex] then
            table.insert(result,row)
            table.insert(resultLanguages,languages[rowIndex] or false)
        end
    end
    return result,resultLanguages,conflicts
end

local function CollectAppendConflicts(info,currentCount,rows)
    local conflicts = {}
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local latest = {}
            for rowIndex,row in ipairs(rows) do
                local key = BuildIndexKey(row,rule.fields)
                local oldIndex = latest[key]
                if rowIndex > currentCount and oldIndex ~= nil then
                    table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=oldIndex,newIndex=rowIndex})
                end
                latest[key] = rowIndex
            end
        end
    end
    return conflicts
end

function static_skill_def.ApplyBatch(sheetName,batch,allowUnknown,schemaOverride,rowLanguage)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local runtime = configSheetRuntimes[sheetName]
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    if type(batch) ~= "table" then return nil,"配置批次需要 table" end
    for key in pairs(batch) do
        if key ~= "installKey" and key ~= "installValue" and key ~= "operation" and key ~= "rows" then
            return nil,string.format("配置批次包含未知字段[%s]",tostring(key))
        end
    end
    local newRows = batch.rows
    local rowsValid,rowsErr = ValidateRowsTable(newRows)
    if not rowsValid then return nil,rowsErr end
    for rowIndex,row in ipairs(newRows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",rowIndex,err) end
    end
    local warnings = {}
    if #newRows == 0 and batch.installKey == nil then
        return { operation = "append", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} }
    end
    local currentRows = runtime.getRows()
    local currentLanguages = runtime.getLanguages()
    local candidateRows = {}
    local candidateLanguages = {}
    local newRowIndexes = {}
    if batch.installKey == nil then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"无 installKey 批次不能声明 installValue/operation" end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
        end
        local indexes,indexErr = static_skill_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        local conflicts = CollectAppendConflicts(info,#currentRows,candidateRows)
        if #conflicts > 0 then table.insert(warnings,string.format("无 installKey 追加产生 %s 个普通查询键冲突；后写结果生效",#conflicts)) end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "append", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    local rule,ruleErr = GetIndexRule(info,batch.installKey)
    if rule == nil then return nil,ruleErr end
    if not rule.group then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"普通 upsert 不能声明 installValue/operation" end
        if #newRows == 0 then return { operation = "upsert", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} } end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        local conflicts = {}
        for _,newRow in ipairs(newRows) do
            local key = BuildIndexKey(newRow,rule.fields)
            local matched = {}
            for rowIndex,oldRow in ipairs(candidateRows) do
                if BuildIndexKey(oldRow,rule.fields) == key then table.insert(matched,rowIndex) end
            end
            if #matched > 1 then return nil,string.format("安装身份歧义[index:%s][key:%s][rows:%s]",rule.indexKey,tostring(key),table.concat(matched,",")) end
            if #matched == 1 then
                table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=matched[1],newIndex=matched[1]})
                candidateRows[matched[1]] = newRow
                candidateLanguages[matched[1]] = rowLanguage or false
            else
                table.insert(candidateRows,newRow)
                table.insert(candidateLanguages,rowLanguage or false)
            end
        end
        local indexes,indexErr = static_skill_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "upsert", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    if batch.installValue == nil then return nil,"组批次缺少 installValue" end
    local groupKey = BuildIndexKeyFromValue(batch.installValue,rule.fields)
    if groupKey == nil then return nil,"installValue 与组查询字段不匹配" end
    local operation = batch.operation or "replace"
    if operation ~= "replace" and operation ~= "append" then return nil,string.format("无效组操作[%s]",tostring(operation)) end
    for rowIndex,row in ipairs(newRows) do
        local rowGroupKey = BuildIndexKey(row,rule.fields)
        if rowGroupKey ~= groupKey then return nil,string.format("组键不一致[目标:%s][第%s行:%s]",tostring(groupKey),rowIndex,tostring(rowGroupKey)) end
    end
    if operation == "append" and #newRows == 0 then return { operation = operation, groupKey = groupKey, rows = runtime.getRows(), warnings = {"空组 append 未修改配置"}, conflicts = {} } end
    local firstGroupIndex = nil
    local oldGroupCount = 0
    if operation == "replace" then
        for rowIndex,row in ipairs(currentRows) do
            if BuildIndexKey(row,rule.fields) == groupKey then
                oldGroupCount = oldGroupCount + 1
                if firstGroupIndex == nil then firstGroupIndex = #candidateRows + 1 end
            else
                table.insert(candidateRows,row)
                table.insert(candidateLanguages,currentLanguages[rowIndex] or false)
            end
        end
        local insertIndex = firstGroupIndex or (#candidateRows + 1)
        for offset,row in ipairs(newRows) do
            table.insert(candidateRows,insertIndex + offset - 1,row)
            table.insert(candidateLanguages,insertIndex + offset - 1,rowLanguage or false)
        end
        for offset = 1,#newRows do table.insert(newRowIndexes,insertIndex + offset - 1) end
    else
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
            table.insert(newRowIndexes,#candidateRows)
        end
    end
    if operation == "replace" and oldGroupCount == 0 and #newRows == 0 then table.insert(warnings,"清空不存在的组未修改配置") end
    local resultRows,resultLanguages,conflicts = ResolveNewRowConflicts(info,rule,candidateRows,candidateLanguages,newRowIndexes)
    local indexes,indexErr = static_skill_def.BuildIndexes(sheetName,resultRows,allowUnknown,schemaOverride)
    if indexes == nil then return nil,indexErr end
    runtime.publish(resultRows,indexes,schema,resultLanguages)
    return { operation = operation, groupKey = groupKey, rows = resultRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
end

local sheetFunc = 
{
    ["config"] = 
    {
        ["index"] = "config_index",
        ["@num"] = "config_num",
        ["@set"] = "config_set",
        ["id"] = "config_id",
    },
}

function static_skill_def.Get(sheetName,keyIndex,key)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return nil,1 end
    local funName = funcIndexs[keyIndex]
    if not funName then return nil,2 end
    return static_skill_def[funName](key),nil
end

function static_skill_def.Set(sheetName,index,data)
    if index == nil then return false end
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return false end
    local funName = funcIndexs["@set"]
    static_skill_def[funName](index,data)
    return true
end

function static_skill_def.GetNum(sheetName)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return 0 end
    local funName = funcIndexs["@num"]
    return static_skill_def[funName]()
end

return static_skill_def