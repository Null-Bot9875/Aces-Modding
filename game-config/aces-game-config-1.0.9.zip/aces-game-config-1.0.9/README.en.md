# Aces Configuration Reference 1.0.9

Game version: 1.0.9. Updated on 2026-10-23.

Includes Card, Enemy, Node, and related configuration. Lua files under data/ are references for existing IDs and structures; they cannot be installed by copying them into Mods/. See the repository LICENSE.md for usage terms.
