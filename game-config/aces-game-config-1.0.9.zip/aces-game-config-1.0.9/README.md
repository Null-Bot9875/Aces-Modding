# Aces 配置参考 1.0.9

游戏版本：1.0.9。更新日期：2026-10-23。

包含 Card、Enemy、Node 及其相关配置。data/ 下的 Lua 用于查询现有 ID 和配置结构，不能直接放进 Mods/ 安装。使用范围见仓库 LICENSE.md。
