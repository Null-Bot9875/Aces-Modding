local act_card_pool_def = {}
local ConfigRowRuntime = require("common/config/ConfigRowRuntime")

--base_pool
local base_pool_num = 1469
local base_pool_schema =
{
    ["cardId"] = { type = "int" },
    ["baseId"] = { type = "int" },
    ["poolId"] = { type = "int" },
    ["minBaseLevel"] = { type = "int" },
    ["maxBaseLevel"] = { type = "int" },
    ["limitActIds"] = { type = "list", item = { type = "int" } },
}
local base_pool_runtime_schema = base_pool_schema
local base_pool_source =
{
    [1] = {cardId=2010,baseId=501,poolId=51,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [2] = {cardId=2016,baseId=501,poolId=52,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [3] = {cardId=2018,baseId=501,poolId=53,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [4] = {cardId=2171,baseId=503,poolId=61,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [5] = {cardId=2133,baseId=503,poolId=62,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [6] = {cardId=2147,baseId=503,poolId=63,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [7] = {cardId=2131,baseId=503,poolId=64,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [8] = {cardId=2135,baseId=503,poolId=65,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [9] = {cardId=2000,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [10] = {cardId=2006,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [11] = {cardId=2010,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [12] = {cardId=2014,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [13] = {cardId=2016,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [14] = {cardId=2021,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [15] = {cardId=2023,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [16] = {cardId=2037,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [17] = {cardId=2039,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [18] = {cardId=2047,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [19] = {cardId=2053,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [20] = {cardId=7102,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [21] = {cardId=7112,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [22] = {cardId=7116,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [23] = {cardId=7118,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [24] = {cardId=7120,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [25] = {cardId=7543,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [26] = {cardId=7545,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [27] = {cardId=7549,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [28] = {cardId=7553,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [29] = {cardId=7527,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [30] = {cardId=7531,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [31] = {cardId=7535,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [32] = {cardId=7539,baseId=501,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [33] = {cardId=2127,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [34] = {cardId=2129,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [35] = {cardId=2131,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [36] = {cardId=2133,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [37] = {cardId=2135,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [38] = {cardId=2137,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [39] = {cardId=2139,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [40] = {cardId=2141,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [41] = {cardId=2143,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [42] = {cardId=2145,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [43] = {cardId=2147,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [44] = {cardId=2149,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [45] = {cardId=2151,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [46] = {cardId=2155,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [47] = {cardId=2157,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [48] = {cardId=2159,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [49] = {cardId=2161,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [50] = {cardId=2169,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [51] = {cardId=2171,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [52] = {cardId=2173,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [53] = {cardId=2175,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [54] = {cardId=2177,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [55] = {cardId=2179,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [56] = {cardId=2181,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [57] = {cardId=7587,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [58] = {cardId=7589,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [59] = {cardId=7591,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [60] = {cardId=7593,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [61] = {cardId=7595,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [62] = {cardId=7597,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [63] = {cardId=7599,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [64] = {cardId=7601,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [65] = {cardId=7603,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [66] = {cardId=7605,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [67] = {cardId=7607,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [68] = {cardId=7609,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [69] = {cardId=7611,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [70] = {cardId=7613,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [71] = {cardId=7615,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [72] = {cardId=7617,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [73] = {cardId=7619,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [74] = {cardId=7621,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [75] = {cardId=7623,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [76] = {cardId=7625,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [77] = {cardId=7627,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [78] = {cardId=7629,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [79] = {cardId=7631,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [80] = {cardId=7633,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [81] = {cardId=7635,baseId=503,poolId=721,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [82] = {cardId=2204,baseId=501,poolId=80,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [83] = {cardId=2208,baseId=501,poolId=81,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [84] = {cardId=2212,baseId=501,poolId=82,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [85] = {cardId=2216,baseId=501,poolId=83,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [86] = {cardId=2220,baseId=501,poolId=84,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [87] = {cardId=2204,baseId=503,poolId=80,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [88] = {cardId=2208,baseId=503,poolId=81,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [89] = {cardId=2212,baseId=503,poolId=82,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [90] = {cardId=2216,baseId=503,poolId=83,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [91] = {cardId=2220,baseId=503,poolId=84,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [92] = {cardId=2484,baseId=501,poolId=86,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [93] = {cardId=2484,baseId=503,poolId=86,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [94] = {cardId=2031,baseId=501,poolId=87,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [95] = {cardId=2031,baseId=503,poolId=87,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [96] = {cardId=2032,baseId=501,poolId=88,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [97] = {cardId=2032,baseId=503,poolId=88,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [98] = {cardId=7005,baseId=501,poolId=89,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [99] = {cardId=7005,baseId=503,poolId=89,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [100] = {cardId=7002,baseId=501,poolId=90,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [101] = {cardId=7002,baseId=503,poolId=90,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [102] = {cardId=7010,baseId=501,poolId=91,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [103] = {cardId=7010,baseId=503,poolId=91,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [104] = {cardId=7014,baseId=501,poolId=92,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [105] = {cardId=7014,baseId=503,poolId=92,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [106] = {cardId=7016,baseId=501,poolId=93,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [107] = {cardId=7016,baseId=503,poolId=93,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [108] = {cardId=10214,baseId=503,poolId=94,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [109] = {cardId=2480,baseId=501,poolId=95,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [110] = {cardId=2481,baseId=501,poolId=96,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [111] = {cardId=2482,baseId=501,poolId=97,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [112] = {cardId=2483,baseId=501,poolId=98,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [113] = {cardId=2484,baseId=501,poolId=99,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [114] = {cardId=2480,baseId=503,poolId=95,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [115] = {cardId=2481,baseId=503,poolId=96,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [116] = {cardId=2482,baseId=503,poolId=97,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [117] = {cardId=2483,baseId=503,poolId=98,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [118] = {cardId=2484,baseId=503,poolId=99,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [119] = {cardId=8500,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [120] = {cardId=8502,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [121] = {cardId=8504,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [122] = {cardId=8506,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [123] = {cardId=8508,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [124] = {cardId=8510,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [125] = {cardId=8512,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [126] = {cardId=8514,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [127] = {cardId=8522,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [128] = {cardId=8524,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [129] = {cardId=8526,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [130] = {cardId=8528,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [131] = {cardId=8530,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [132] = {cardId=8534,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [133] = {cardId=8536,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [134] = {cardId=8538,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [135] = {cardId=8540,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [136] = {cardId=8550,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [137] = {cardId=8554,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [138] = {cardId=8556,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [139] = {cardId=8558,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [140] = {cardId=8560,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [141] = {cardId=8562,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [142] = {cardId=8564,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [143] = {cardId=8568,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [144] = {cardId=8570,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [145] = {cardId=8572,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [146] = {cardId=8574,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [147] = {cardId=8576,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [148] = {cardId=8578,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [149] = {cardId=8580,baseId=503,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [150] = {cardId=10310,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [151] = {cardId=10312,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [152] = {cardId=10314,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [153] = {cardId=10316,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [154] = {cardId=10318,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [155] = {cardId=10320,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [156] = {cardId=10322,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [157] = {cardId=10324,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [158] = {cardId=10326,baseId=504,poolId=73,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [159] = {cardId=10328,baseId=504,poolId=73,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [160] = {cardId=10330,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [161] = {cardId=10332,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [162] = {cardId=10334,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [163] = {cardId=10336,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [164] = {cardId=10338,baseId=504,poolId=73,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [165] = {cardId=10340,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [166] = {cardId=10341,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [167] = {cardId=10343,baseId=504,poolId=73,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [168] = {cardId=10345,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [169] = {cardId=10346,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [170] = {cardId=10348,baseId=504,poolId=73,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [171] = {cardId=10350,baseId=504,poolId=73,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [172] = {cardId=10352,baseId=504,poolId=73,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [173] = {cardId=10354,baseId=504,poolId=73,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [174] = {cardId=10356,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [175] = {cardId=10358,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [176] = {cardId=10360,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [177] = {cardId=10362,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [178] = {cardId=10364,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [179] = {cardId=10366,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [180] = {cardId=10368,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [181] = {cardId=10370,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [182] = {cardId=10371,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [183] = {cardId=10372,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [184] = {cardId=10373,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [185] = {cardId=10374,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [186] = {cardId=10375,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [187] = {cardId=10376,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [188] = {cardId=10377,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [189] = {cardId=10378,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [190] = {cardId=10379,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [191] = {cardId=10380,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [192] = {cardId=10381,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [193] = {cardId=10382,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [194] = {cardId=10383,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [195] = {cardId=10384,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [196] = {cardId=10385,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [197] = {cardId=10386,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [198] = {cardId=10387,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [199] = {cardId=10388,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [200] = {cardId=10389,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [201] = {cardId=10390,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [202] = {cardId=10391,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [203] = {cardId=10392,baseId=504,poolId=73,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [204] = {cardId=10104,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [205] = {cardId=2741,baseId=504,poolId=111,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [206] = {cardId=2741,baseId=501,poolId=111,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [207] = {cardId=2741,baseId=503,poolId=111,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [208] = {cardId=2743,baseId=504,poolId=112,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [209] = {cardId=2743,baseId=501,poolId=112,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [210] = {cardId=2743,baseId=503,poolId=112,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [211] = {cardId=2745,baseId=504,poolId=113,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [212] = {cardId=2745,baseId=501,poolId=113,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [213] = {cardId=2745,baseId=503,poolId=113,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [214] = {cardId=8550,baseId=504,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [215] = {cardId=8554,baseId=504,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [216] = {cardId=8556,baseId=504,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [217] = {cardId=8558,baseId=504,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [218] = {cardId=8560,baseId=504,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [219] = {cardId=8562,baseId=504,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [220] = {cardId=8564,baseId=504,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [221] = {cardId=8550,baseId=501,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [222] = {cardId=8554,baseId=501,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [223] = {cardId=8556,baseId=501,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [224] = {cardId=8558,baseId=501,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [225] = {cardId=8560,baseId=501,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [226] = {cardId=8562,baseId=501,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [227] = {cardId=8564,baseId=501,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [228] = {cardId=8550,baseId=503,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [229] = {cardId=8554,baseId=503,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [230] = {cardId=8556,baseId=503,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [231] = {cardId=8558,baseId=503,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [232] = {cardId=8560,baseId=503,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [233] = {cardId=8562,baseId=503,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [234] = {cardId=8564,baseId=503,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [235] = {cardId=2747,baseId=504,poolId=115,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [236] = {cardId=2747,baseId=501,poolId=115,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [237] = {cardId=2747,baseId=503,poolId=115,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [238] = {cardId=8522,baseId=504,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [239] = {cardId=8524,baseId=504,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [240] = {cardId=8526,baseId=504,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [241] = {cardId=8528,baseId=504,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [242] = {cardId=8530,baseId=504,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [243] = {cardId=8534,baseId=504,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [244] = {cardId=8536,baseId=504,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [245] = {cardId=8540,baseId=504,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [246] = {cardId=8522,baseId=501,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [247] = {cardId=8524,baseId=501,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [248] = {cardId=8526,baseId=501,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [249] = {cardId=8528,baseId=501,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [250] = {cardId=8530,baseId=501,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [251] = {cardId=8534,baseId=501,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [252] = {cardId=8536,baseId=501,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [253] = {cardId=8540,baseId=501,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [254] = {cardId=8522,baseId=503,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [255] = {cardId=8524,baseId=503,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [256] = {cardId=8526,baseId=503,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [257] = {cardId=8528,baseId=503,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [258] = {cardId=8530,baseId=503,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [259] = {cardId=8534,baseId=503,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [260] = {cardId=8536,baseId=503,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [261] = {cardId=8540,baseId=503,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [262] = {cardId=8500,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [263] = {cardId=8502,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [264] = {cardId=8504,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [265] = {cardId=8506,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [266] = {cardId=8508,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [267] = {cardId=8510,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [268] = {cardId=8512,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [269] = {cardId=8514,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [270] = {cardId=8516,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [271] = {cardId=8518,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [272] = {cardId=8520,baseId=501,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [273] = {cardId=2004,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [274] = {cardId=2008,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [275] = {cardId=2016,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [276] = {cardId=2031,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [277] = {cardId=2033,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [278] = {cardId=2037,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [279] = {cardId=2039,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [280] = {cardId=7104,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [281] = {cardId=7112,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [282] = {cardId=7551,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [283] = {cardId=7553,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [284] = {cardId=7541,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [285] = {cardId=8520,baseId=501,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [286] = {cardId=2643,baseId=504,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [287] = {cardId=2645,baseId=504,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [288] = {cardId=2647,baseId=504,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [289] = {cardId=8522,baseId=504,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [290] = {cardId=8524,baseId=504,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [291] = {cardId=8528,baseId=504,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [292] = {cardId=8530,baseId=504,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [293] = {cardId=8534,baseId=504,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [294] = {cardId=8536,baseId=504,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [295] = {cardId=10050,baseId=501,poolId=122,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [296] = {cardId=10180,baseId=501,poolId=123,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [297] = {cardId=10050,baseId=503,poolId=122,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [298] = {cardId=10180,baseId=503,poolId=123,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [299] = {cardId=10050,baseId=504,poolId=122,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [300] = {cardId=10180,baseId=504,poolId=123,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [301] = {cardId=2000,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [302] = {cardId=2006,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [303] = {cardId=2010,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [304] = {cardId=2014,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [305] = {cardId=2016,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [306] = {cardId=2021,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [307] = {cardId=2023,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [308] = {cardId=2035,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [309] = {cardId=2037,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [310] = {cardId=2039,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [311] = {cardId=2047,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [312] = {cardId=2049,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [313] = {cardId=2051,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [314] = {cardId=2053,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [315] = {cardId=7100,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [316] = {cardId=7102,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [317] = {cardId=7104,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [318] = {cardId=7106,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [319] = {cardId=7108,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [320] = {cardId=7112,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [321] = {cardId=7116,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [322] = {cardId=7545,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [323] = {cardId=7547,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [324] = {cardId=7549,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [325] = {cardId=7551,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [326] = {cardId=7553,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [327] = {cardId=7527,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [328] = {cardId=7531,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [329] = {cardId=7533,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [330] = {cardId=7535,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [331] = {cardId=7537,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [332] = {cardId=7539,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [333] = {cardId=7541,baseId=501,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [334] = {cardId=2004,baseId=501,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [335] = {cardId=2008,baseId=501,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [336] = {cardId=2031,baseId=501,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [337] = {cardId=8500,baseId=501,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [338] = {cardId=8502,baseId=501,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [339] = {cardId=8504,baseId=501,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [340] = {cardId=8506,baseId=501,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [341] = {cardId=8508,baseId=501,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [342] = {cardId=8510,baseId=501,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [343] = {cardId=8512,baseId=501,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [344] = {cardId=2033,baseId=501,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [345] = {cardId=2042,baseId=501,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [346] = {cardId=2055,baseId=501,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [347] = {cardId=8514,baseId=501,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [348] = {cardId=8516,baseId=501,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [349] = {cardId=8518,baseId=501,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [350] = {cardId=8520,baseId=501,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [351] = {cardId=2127,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [352] = {cardId=10417,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [353] = {cardId=2161,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [354] = {cardId=10419,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [355] = {cardId=10421,baseId=503,poolId=72,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [356] = {cardId=10422,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [357] = {cardId=10425,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [358] = {cardId=10427,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [359] = {cardId=10429,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [360] = {cardId=10431,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [361] = {cardId=10433,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [362] = {cardId=10435,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [363] = {cardId=10437,baseId=503,poolId=72,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [364] = {cardId=10439,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [365] = {cardId=10441,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [366] = {cardId=10443,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [367] = {cardId=10445,baseId=503,poolId=72,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [368] = {cardId=10447,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [369] = {cardId=10449,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [370] = {cardId=10451,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [371] = {cardId=10453,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [372] = {cardId=10455,baseId=503,poolId=72,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [373] = {cardId=10457,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [374] = {cardId=10459,baseId=503,poolId=72,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [375] = {cardId=10461,baseId=503,poolId=72,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [376] = {cardId=7617,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [377] = {cardId=7619,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [378] = {cardId=7621,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [379] = {cardId=7623,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [380] = {cardId=7625,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [381] = {cardId=7627,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [382] = {cardId=7629,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [383] = {cardId=7631,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [384] = {cardId=10463,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [385] = {cardId=2155,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [386] = {cardId=2177,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [387] = {cardId=10411,baseId=501,poolId=130,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [388] = {cardId=10411,baseId=503,poolId=130,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [389] = {cardId=10411,baseId=504,poolId=130,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [390] = {cardId=10412,baseId=501,poolId=131,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [391] = {cardId=10412,baseId=503,poolId=131,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [392] = {cardId=10412,baseId=504,poolId=131,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [393] = {cardId=10413,baseId=501,poolId=132,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [394] = {cardId=10413,baseId=503,poolId=132,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [395] = {cardId=10413,baseId=504,poolId=132,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [396] = {cardId=10414,baseId=501,poolId=133,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [397] = {cardId=10414,baseId=503,poolId=133,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [398] = {cardId=10414,baseId=504,poolId=133,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [399] = {cardId=10308,baseId=504,poolId=134,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [400] = {cardId=10415,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [401] = {cardId=10416,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [402] = {cardId=10465,baseId=503,poolId=72,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [403] = {cardId=10466,baseId=503,poolId=72,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [404] = {cardId=10468,baseId=503,poolId=72,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [405] = {cardId=10470,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [406] = {cardId=10471,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [407] = {cardId=10473,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [408] = {cardId=10475,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [409] = {cardId=10477,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [410] = {cardId=10479,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [411] = {cardId=2135,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [412] = {cardId=7601,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [413] = {cardId=2061,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [414] = {cardId=10481,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [415] = {cardId=10482,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [416] = {cardId=10484,baseId=503,poolId=72,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [417] = {cardId=10487,baseId=503,poolId=72,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [418] = {cardId=10488,baseId=503,poolId=72,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [419] = {cardId=10489,baseId=503,poolId=72,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [420] = {cardId=10490,baseId=503,poolId=72,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [421] = {cardId=10491,baseId=503,poolId=72,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [422] = {cardId=10492,baseId=503,poolId=72,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [423] = {cardId=10570,baseId=504,poolId=73,minBaseLevel=3,maxBaseLevel=10,limitActIds={105106}},
    [424] = {cardId=10572,baseId=504,poolId=73,minBaseLevel=3,maxBaseLevel=10,limitActIds={105106}},
    [425] = {cardId=10574,baseId=504,poolId=73,minBaseLevel=3,maxBaseLevel=10,limitActIds={105106}},
    [426] = {cardId=10577,baseId=504,poolId=73,minBaseLevel=2,maxBaseLevel=10,limitActIds={105106}},
    [427] = {cardId=10579,baseId=504,poolId=73,minBaseLevel=2,maxBaseLevel=10,limitActIds={105106}},
    [428] = {cardId=10581,baseId=504,poolId=73,minBaseLevel=2,maxBaseLevel=10,limitActIds={105106}},
    [429] = {cardId=10589,baseId=504,poolId=73,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [430] = {cardId=10591,baseId=504,poolId=73,minBaseLevel=2,maxBaseLevel=10,limitActIds={105106}},
    [431] = {cardId=10593,baseId=504,poolId=73,minBaseLevel=2,maxBaseLevel=10,limitActIds={105106}},
    [432] = {cardId=10596,baseId=504,poolId=73,minBaseLevel=3,maxBaseLevel=10,limitActIds={105106}},
    [433] = {cardId=10598,baseId=504,poolId=73,minBaseLevel=3,maxBaseLevel=10,limitActIds={105106}},
    [434] = {cardId=10599,baseId=504,poolId=73,minBaseLevel=4,maxBaseLevel=10,limitActIds={106}},
    [435] = {cardId=10602,baseId=504,poolId=73,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [436] = {cardId=10605,baseId=504,poolId=73,minBaseLevel=4,maxBaseLevel=10,limitActIds={106}},
    [437] = {cardId=10607,baseId=504,poolId=73,minBaseLevel=4,maxBaseLevel=10,limitActIds={106}},
    [438] = {cardId=10609,baseId=504,poolId=73,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [439] = {cardId=10611,baseId=504,poolId=73,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [440] = {cardId=10613,baseId=504,poolId=73,minBaseLevel=4,maxBaseLevel=10,limitActIds={106}},
    [441] = {cardId=10615,baseId=504,poolId=73,minBaseLevel=4,maxBaseLevel=10,limitActIds={106}},
    [442] = {cardId=10618,baseId=504,poolId=73,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [443] = {cardId=7118,baseId=501,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [444] = {cardId=7120,baseId=501,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [445] = {cardId=7543,baseId=501,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [446] = {cardId=10542,baseId=501,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [447] = {cardId=10544,baseId=501,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [448] = {cardId=10546,baseId=501,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [449] = {cardId=10548,baseId=501,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [450] = {cardId=10550,baseId=501,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [451] = {cardId=10552,baseId=501,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [452] = {cardId=10554,baseId=501,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [453] = {cardId=10556,baseId=501,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [454] = {cardId=10558,baseId=501,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [455] = {cardId=10560,baseId=501,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [456] = {cardId=10561,baseId=501,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [457] = {cardId=10562,baseId=501,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [458] = {cardId=10563,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [459] = {cardId=10565,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [460] = {cardId=10567,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [461] = {cardId=10675,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [462] = {cardId=10677,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [463] = {cardId=10679,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [464] = {cardId=10681,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [465] = {cardId=10682,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [466] = {cardId=10683,baseId=503,poolId=72,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [467] = {cardId=10655,baseId=503,poolId=72,minBaseLevel=4,maxBaseLevel=10,limitActIds={106}},
    [468] = {cardId=10656,baseId=503,poolId=72,minBaseLevel=4,maxBaseLevel=10,limitActIds={106}},
    [469] = {cardId=10658,baseId=503,poolId=72,minBaseLevel=4,maxBaseLevel=10,limitActIds={106}},
    [470] = {cardId=10659,baseId=503,poolId=72,minBaseLevel=4,maxBaseLevel=10,limitActIds={106}},
    [471] = {cardId=10661,baseId=503,poolId=72,minBaseLevel=4,maxBaseLevel=10,limitActIds={106}},
    [472] = {cardId=10662,baseId=503,poolId=72,minBaseLevel=4,maxBaseLevel=10,limitActIds={106}},
    [473] = {cardId=10665,baseId=503,poolId=72,minBaseLevel=5,maxBaseLevel=10,limitActIds={106}},
    [474] = {cardId=10666,baseId=503,poolId=72,minBaseLevel=5,maxBaseLevel=10,limitActIds={106}},
    [475] = {cardId=10668,baseId=503,poolId=72,minBaseLevel=5,maxBaseLevel=10,limitActIds={106}},
    [476] = {cardId=10669,baseId=503,poolId=72,minBaseLevel=5,maxBaseLevel=10,limitActIds={106}},
    [477] = {cardId=10672,baseId=503,poolId=72,minBaseLevel=5,maxBaseLevel=10,limitActIds={106}},
    [478] = {cardId=8536,baseId=501,poolId=151,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [479] = {cardId=8536,baseId=503,poolId=151,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [480] = {cardId=8536,baseId=504,poolId=151,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [481] = {cardId=8540,baseId=501,poolId=152,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [482] = {cardId=8540,baseId=503,poolId=152,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [483] = {cardId=8540,baseId=504,poolId=152,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [484] = {cardId=2000,baseId=501,poolId=200,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [485] = {cardId=2161,baseId=503,poolId=200,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [486] = {cardId=10310,baseId=504,poolId=200,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [487] = {cardId=2037,baseId=501,poolId=201,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [488] = {cardId=10470,baseId=503,poolId=201,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [489] = {cardId=10348,baseId=504,poolId=201,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [490] = {cardId=2006,baseId=501,poolId=202,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [491] = {cardId=10433,baseId=503,poolId=202,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [492] = {cardId=10346,baseId=504,poolId=202,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [493] = {cardId=10542,baseId=501,poolId=203,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [494] = {cardId=10563,baseId=503,poolId=203,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [495] = {cardId=10591,baseId=504,poolId=203,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [496] = {cardId=10544,baseId=501,poolId=204,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [497] = {cardId=10675,baseId=503,poolId=204,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [498] = {cardId=10593,baseId=504,poolId=204,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [499] = {cardId=10546,baseId=501,poolId=205,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [500] = {cardId=10437,baseId=503,poolId=205,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [501] = {cardId=10589,baseId=504,poolId=205,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [502] = {cardId=10655,baseId=503,poolId=206,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [503] = {cardId=10310,baseId=504,poolId=206,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [504] = {cardId=10658,baseId=503,poolId=207,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [505] = {cardId=10618,baseId=504,poolId=207,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [506] = {cardId=10666,baseId=503,poolId=208,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [507] = {cardId=10615,baseId=504,poolId=208,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [508] = {cardId=8568,baseId=501,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [509] = {cardId=8570,baseId=501,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [510] = {cardId=8572,baseId=501,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [511] = {cardId=8574,baseId=501,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [512] = {cardId=8576,baseId=501,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [513] = {cardId=8578,baseId=501,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [514] = {cardId=8580,baseId=501,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [515] = {cardId=8570,baseId=503,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [516] = {cardId=8572,baseId=503,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [517] = {cardId=8574,baseId=503,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [518] = {cardId=8576,baseId=503,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [519] = {cardId=8578,baseId=503,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [520] = {cardId=8580,baseId=503,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [521] = {cardId=8570,baseId=504,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [522] = {cardId=8572,baseId=504,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [523] = {cardId=8574,baseId=504,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [524] = {cardId=8576,baseId=504,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [525] = {cardId=8578,baseId=504,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [526] = {cardId=8580,baseId=504,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [527] = {cardId=10728,baseId=501,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [528] = {cardId=10728,baseId=503,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [529] = {cardId=10728,baseId=504,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [530] = {cardId=10451,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [531] = {cardId=10453,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [532] = {cardId=10461,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [533] = {cardId=7631,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [534] = {cardId=7601,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [535] = {cardId=10479,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [536] = {cardId=2061,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [537] = {cardId=10320,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [538] = {cardId=10322,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [539] = {cardId=10340,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [540] = {cardId=10341,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [541] = {cardId=10104,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [542] = {cardId=10370,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [543] = {cardId=10384,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [544] = {cardId=10386,baseId=501,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [545] = {cardId=7531,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [546] = {cardId=2004,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [547] = {cardId=2031,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [548] = {cardId=2033,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [549] = {cardId=2037,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [550] = {cardId=2039,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [551] = {cardId=7545,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [552] = {cardId=7553,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [553] = {cardId=10320,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [554] = {cardId=10322,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [555] = {cardId=10340,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [556] = {cardId=10341,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [557] = {cardId=10104,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [558] = {cardId=10370,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [559] = {cardId=10384,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [560] = {cardId=10386,baseId=503,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [561] = {cardId=7531,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [562] = {cardId=2004,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [563] = {cardId=2031,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [564] = {cardId=2033,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [565] = {cardId=2037,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [566] = {cardId=2039,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [567] = {cardId=7545,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [568] = {cardId=7553,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [569] = {cardId=10451,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [570] = {cardId=10453,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [571] = {cardId=10461,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [572] = {cardId=7631,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [573] = {cardId=7601,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [574] = {cardId=10479,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [575] = {cardId=2061,baseId=504,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [576] = {cardId=8522,baseId=501,poolId=501,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [577] = {cardId=8522,baseId=503,poolId=501,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [578] = {cardId=8522,baseId=504,poolId=501,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [579] = {cardId=8524,baseId=501,poolId=502,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [580] = {cardId=8524,baseId=503,poolId=502,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [581] = {cardId=8524,baseId=504,poolId=502,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [582] = {cardId=8528,baseId=501,poolId=503,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [583] = {cardId=8528,baseId=503,poolId=503,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [584] = {cardId=8528,baseId=504,poolId=503,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [585] = {cardId=8526,baseId=501,poolId=504,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [586] = {cardId=8526,baseId=503,poolId=504,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [587] = {cardId=8526,baseId=504,poolId=504,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [588] = {cardId=8536,baseId=501,poolId=505,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [589] = {cardId=8536,baseId=503,poolId=505,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [590] = {cardId=8536,baseId=504,poolId=505,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [591] = {cardId=8530,baseId=501,poolId=506,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [592] = {cardId=8530,baseId=503,poolId=506,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [593] = {cardId=8530,baseId=504,poolId=506,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [594] = {cardId=2016,baseId=501,poolId=507,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [595] = {cardId=10422,baseId=503,poolId=507,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [596] = {cardId=10366,baseId=504,poolId=507,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [597] = {cardId=8546,baseId=501,poolId=508,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [598] = {cardId=8546,baseId=503,poolId=508,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [599] = {cardId=8546,baseId=504,poolId=508,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [600] = {cardId=8548,baseId=501,poolId=509,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [601] = {cardId=8548,baseId=503,poolId=509,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [602] = {cardId=8548,baseId=504,poolId=509,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [603] = {cardId=8552,baseId=501,poolId=510,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [604] = {cardId=8552,baseId=503,poolId=510,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [605] = {cardId=8552,baseId=504,poolId=510,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [606] = {cardId=8554,baseId=501,poolId=511,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [607] = {cardId=8554,baseId=503,poolId=511,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [608] = {cardId=8554,baseId=504,poolId=511,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [609] = {cardId=8556,baseId=501,poolId=512,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [610] = {cardId=8556,baseId=503,poolId=512,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [611] = {cardId=8556,baseId=504,poolId=512,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [612] = {cardId=8562,baseId=501,poolId=513,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [613] = {cardId=8562,baseId=503,poolId=513,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [614] = {cardId=8562,baseId=504,poolId=513,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [615] = {cardId=7551,baseId=501,poolId=514,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [616] = {cardId=10473,baseId=503,poolId=514,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [617] = {cardId=10334,baseId=504,poolId=514,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [618] = {cardId=8570,baseId=501,poolId=515,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [619] = {cardId=8570,baseId=503,poolId=515,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [620] = {cardId=8570,baseId=504,poolId=515,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [621] = {cardId=8572,baseId=501,poolId=516,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [622] = {cardId=8572,baseId=503,poolId=516,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [623] = {cardId=8572,baseId=504,poolId=516,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [624] = {cardId=8574,baseId=501,poolId=517,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [625] = {cardId=8574,baseId=503,poolId=517,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [626] = {cardId=8574,baseId=504,poolId=517,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [627] = {cardId=8576,baseId=501,poolId=518,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [628] = {cardId=8576,baseId=503,poolId=518,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [629] = {cardId=8576,baseId=504,poolId=518,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [630] = {cardId=8568,baseId=501,poolId=519,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [631] = {cardId=8568,baseId=503,poolId=519,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [632] = {cardId=8568,baseId=504,poolId=519,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [633] = {cardId=8580,baseId=501,poolId=520,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [634] = {cardId=8580,baseId=503,poolId=520,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [635] = {cardId=8580,baseId=504,poolId=520,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [636] = {cardId=2010,baseId=501,poolId=521,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [637] = {cardId=7601,baseId=503,poolId=521,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [638] = {cardId=10368,baseId=504,poolId=521,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [639] = {cardId=2010,baseId=1000,poolId=51,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [640] = {cardId=2016,baseId=1000,poolId=52,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [641] = {cardId=2018,baseId=1000,poolId=53,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [642] = {cardId=2000,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [643] = {cardId=2006,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [644] = {cardId=2010,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [645] = {cardId=2014,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [646] = {cardId=2016,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [647] = {cardId=2021,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [648] = {cardId=2023,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [649] = {cardId=2037,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [650] = {cardId=2039,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [651] = {cardId=2047,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [652] = {cardId=2053,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [653] = {cardId=7102,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [654] = {cardId=7112,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [655] = {cardId=7116,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [656] = {cardId=7118,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [657] = {cardId=7120,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [658] = {cardId=7543,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [659] = {cardId=7545,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [660] = {cardId=7549,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [661] = {cardId=7553,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [662] = {cardId=7527,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [663] = {cardId=7531,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [664] = {cardId=7535,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [665] = {cardId=7539,baseId=1000,poolId=1,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [666] = {cardId=2204,baseId=1000,poolId=80,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [667] = {cardId=2208,baseId=1000,poolId=81,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [668] = {cardId=2212,baseId=1000,poolId=82,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [669] = {cardId=2216,baseId=1000,poolId=83,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [670] = {cardId=2220,baseId=1000,poolId=84,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [671] = {cardId=2484,baseId=1000,poolId=86,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [672] = {cardId=2031,baseId=1000,poolId=87,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [673] = {cardId=2032,baseId=1000,poolId=88,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [674] = {cardId=7005,baseId=1000,poolId=89,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [675] = {cardId=7002,baseId=1000,poolId=90,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [676] = {cardId=7010,baseId=1000,poolId=91,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [677] = {cardId=7014,baseId=1000,poolId=92,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [678] = {cardId=7016,baseId=1000,poolId=93,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [679] = {cardId=2480,baseId=1000,poolId=95,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [680] = {cardId=2481,baseId=1000,poolId=96,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [681] = {cardId=2482,baseId=1000,poolId=97,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [682] = {cardId=2483,baseId=1000,poolId=98,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [683] = {cardId=2484,baseId=1000,poolId=99,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [684] = {cardId=8500,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [685] = {cardId=8502,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [686] = {cardId=8504,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [687] = {cardId=8506,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [688] = {cardId=8508,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [689] = {cardId=8510,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [690] = {cardId=8512,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [691] = {cardId=8514,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [692] = {cardId=2741,baseId=1000,poolId=111,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [693] = {cardId=2743,baseId=1000,poolId=112,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [694] = {cardId=2745,baseId=1000,poolId=113,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [695] = {cardId=8550,baseId=1000,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [696] = {cardId=8554,baseId=1000,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [697] = {cardId=8556,baseId=1000,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [698] = {cardId=8558,baseId=1000,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [699] = {cardId=8560,baseId=1000,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [700] = {cardId=8562,baseId=1000,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [701] = {cardId=8564,baseId=1000,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [702] = {cardId=2747,baseId=1000,poolId=115,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [703] = {cardId=8522,baseId=1000,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [704] = {cardId=8524,baseId=1000,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [705] = {cardId=8526,baseId=1000,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [706] = {cardId=8528,baseId=1000,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [707] = {cardId=8530,baseId=1000,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [708] = {cardId=8534,baseId=1000,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [709] = {cardId=8536,baseId=1000,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [710] = {cardId=8540,baseId=1000,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [711] = {cardId=8500,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [712] = {cardId=8502,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [713] = {cardId=8504,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [714] = {cardId=8506,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [715] = {cardId=8508,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [716] = {cardId=8510,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [717] = {cardId=8512,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [718] = {cardId=8514,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [719] = {cardId=8516,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [720] = {cardId=8518,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [721] = {cardId=8520,baseId=1000,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [722] = {cardId=2004,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [723] = {cardId=2008,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [724] = {cardId=2016,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [725] = {cardId=2031,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [726] = {cardId=2033,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [727] = {cardId=2037,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [728] = {cardId=2039,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [729] = {cardId=7104,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [730] = {cardId=7112,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [731] = {cardId=7551,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [732] = {cardId=7553,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [733] = {cardId=7541,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [734] = {cardId=8520,baseId=1000,poolId=120,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [735] = {cardId=10050,baseId=1000,poolId=122,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [736] = {cardId=10180,baseId=1000,poolId=123,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [737] = {cardId=2000,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [738] = {cardId=2006,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [739] = {cardId=2010,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [740] = {cardId=2014,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [741] = {cardId=2016,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [742] = {cardId=2021,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [743] = {cardId=2023,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [744] = {cardId=2035,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [745] = {cardId=2037,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [746] = {cardId=2039,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [747] = {cardId=2047,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [748] = {cardId=2049,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [749] = {cardId=2051,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [750] = {cardId=2053,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [751] = {cardId=7100,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [752] = {cardId=7102,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [753] = {cardId=7104,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [754] = {cardId=7106,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [755] = {cardId=7108,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [756] = {cardId=7112,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [757] = {cardId=7116,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [758] = {cardId=7545,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [759] = {cardId=7547,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [760] = {cardId=7549,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [761] = {cardId=7551,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [762] = {cardId=7553,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [763] = {cardId=7527,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [764] = {cardId=7531,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [765] = {cardId=7533,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [766] = {cardId=7535,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [767] = {cardId=7537,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [768] = {cardId=7539,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [769] = {cardId=7541,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [770] = {cardId=2004,baseId=1000,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={104105106}},
    [771] = {cardId=2008,baseId=1000,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={104105106}},
    [772] = {cardId=2031,baseId=1000,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={104105106}},
    [773] = {cardId=8500,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={104105106}},
    [774] = {cardId=8502,baseId=1000,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={104105106}},
    [775] = {cardId=8504,baseId=1000,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={104105106}},
    [776] = {cardId=8506,baseId=1000,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={104105106}},
    [777] = {cardId=8508,baseId=1000,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={104105106}},
    [778] = {cardId=8510,baseId=1000,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={104105106}},
    [779] = {cardId=8512,baseId=1000,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={104105106}},
    [780] = {cardId=2033,baseId=1000,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={104105106}},
    [781] = {cardId=2042,baseId=1000,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={104105106}},
    [782] = {cardId=2055,baseId=1000,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={104105106}},
    [783] = {cardId=8514,baseId=1000,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={104105106}},
    [784] = {cardId=8516,baseId=1000,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={104105106}},
    [785] = {cardId=8518,baseId=1000,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={104105106}},
    [786] = {cardId=8520,baseId=1000,poolId=70,minBaseLevel=5,maxBaseLevel=10,limitActIds={104105106}},
    [787] = {cardId=10411,baseId=1000,poolId=130,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [788] = {cardId=10412,baseId=1000,poolId=131,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [789] = {cardId=10413,baseId=1000,poolId=132,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [790] = {cardId=10414,baseId=1000,poolId=133,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [791] = {cardId=7118,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [792] = {cardId=7120,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [793] = {cardId=7543,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [794] = {cardId=8580,baseId=1000,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={104105106}},
    [795] = {cardId=8578,baseId=1000,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={104105106}},
    [796] = {cardId=8576,baseId=1000,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={104105106}},
    [797] = {cardId=8574,baseId=1000,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={104105106}},
    [798] = {cardId=8572,baseId=1000,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={104105106}},
    [799] = {cardId=8570,baseId=1000,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={104105106}},
    [800] = {cardId=8568,baseId=1000,poolId=70,minBaseLevel=3,maxBaseLevel=10,limitActIds={104105106}},
    [801] = {cardId=10542,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [802] = {cardId=10544,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [803] = {cardId=10546,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [804] = {cardId=10548,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [805] = {cardId=10550,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [806] = {cardId=10552,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [807] = {cardId=10554,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [808] = {cardId=10556,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [809] = {cardId=10558,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [810] = {cardId=10560,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [811] = {cardId=10561,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [812] = {cardId=10562,baseId=1000,poolId=70,minBaseLevel=1,maxBaseLevel=10,limitActIds={105106}},
    [813] = {cardId=8536,baseId=1000,poolId=151,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [814] = {cardId=8540,baseId=1000,poolId=152,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [815] = {cardId=2000,baseId=1000,poolId=200,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [816] = {cardId=2037,baseId=1000,poolId=201,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [817] = {cardId=2006,baseId=1000,poolId=202,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [818] = {cardId=10542,baseId=1000,poolId=203,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [819] = {cardId=10544,baseId=1000,poolId=204,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [820] = {cardId=10546,baseId=1000,poolId=205,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [821] = {cardId=8568,baseId=1000,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [822] = {cardId=8570,baseId=1000,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [823] = {cardId=8572,baseId=1000,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [824] = {cardId=8574,baseId=1000,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [825] = {cardId=8576,baseId=1000,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [826] = {cardId=8578,baseId=1000,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [827] = {cardId=8580,baseId=1000,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [828] = {cardId=10728,baseId=1000,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [829] = {cardId=10451,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [830] = {cardId=10453,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [831] = {cardId=10461,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [832] = {cardId=7631,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [833] = {cardId=7601,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [834] = {cardId=10479,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [835] = {cardId=2061,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [836] = {cardId=10320,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [837] = {cardId=10322,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [838] = {cardId=10340,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [839] = {cardId=10341,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [840] = {cardId=10104,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [841] = {cardId=10370,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [842] = {cardId=10384,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [843] = {cardId=10386,baseId=1000,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [844] = {cardId=8522,baseId=1000,poolId=501,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [845] = {cardId=8524,baseId=1000,poolId=502,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [846] = {cardId=8528,baseId=1000,poolId=503,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [847] = {cardId=8526,baseId=1000,poolId=504,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [848] = {cardId=8536,baseId=1000,poolId=505,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [849] = {cardId=8530,baseId=1000,poolId=506,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [850] = {cardId=2016,baseId=1000,poolId=507,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [851] = {cardId=8546,baseId=1000,poolId=508,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [852] = {cardId=8548,baseId=1000,poolId=509,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [853] = {cardId=8552,baseId=1000,poolId=510,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [854] = {cardId=8554,baseId=1000,poolId=511,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [855] = {cardId=8556,baseId=1000,poolId=512,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [856] = {cardId=8562,baseId=1000,poolId=513,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [857] = {cardId=7551,baseId=1000,poolId=514,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [858] = {cardId=8570,baseId=1000,poolId=515,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [859] = {cardId=8572,baseId=1000,poolId=516,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [860] = {cardId=8574,baseId=1000,poolId=517,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [861] = {cardId=8576,baseId=1000,poolId=518,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [862] = {cardId=8568,baseId=1000,poolId=519,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [863] = {cardId=8580,baseId=1000,poolId=520,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [864] = {cardId=2010,baseId=1000,poolId=521,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [865] = {cardId=8564,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [866] = {cardId=8562,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [867] = {cardId=8560,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [868] = {cardId=8558,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [869] = {cardId=8556,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [870] = {cardId=8554,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [871] = {cardId=8552,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [872] = {cardId=8550,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [873] = {cardId=8548,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [874] = {cardId=8546,baseId=1000,poolId=70,minBaseLevel=4,maxBaseLevel=10,limitActIds={104105106}},
    [875] = {cardId=8540,baseId=1000,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={104105106}},
    [876] = {cardId=8536,baseId=1000,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={104105106}},
    [877] = {cardId=8534,baseId=1000,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={104105106}},
    [878] = {cardId=8530,baseId=1000,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={104105106}},
    [879] = {cardId=8528,baseId=1000,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={104105106}},
    [880] = {cardId=8526,baseId=1000,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={104105106}},
    [881] = {cardId=8524,baseId=1000,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={104105106}},
    [882] = {cardId=8522,baseId=1000,poolId=70,minBaseLevel=2,maxBaseLevel=10,limitActIds={104105106}},
    [883] = {cardId=10050,baseId=501,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [884] = {cardId=10497,baseId=501,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [885] = {cardId=10176,baseId=501,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [886] = {cardId=10050,baseId=503,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [887] = {cardId=10497,baseId=503,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [888] = {cardId=10176,baseId=503,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [889] = {cardId=10050,baseId=504,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [890] = {cardId=10497,baseId=504,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [891] = {cardId=10176,baseId=504,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [892] = {cardId=10750,baseId=501,poolId=75,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [893] = {cardId=10180,baseId=501,poolId=75,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [894] = {cardId=10184,baseId=501,poolId=75,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [895] = {cardId=10750,baseId=503,poolId=75,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [896] = {cardId=10180,baseId=503,poolId=75,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [897] = {cardId=10184,baseId=503,poolId=75,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [898] = {cardId=10750,baseId=504,poolId=75,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [899] = {cardId=10180,baseId=504,poolId=75,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [900] = {cardId=10184,baseId=504,poolId=75,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [901] = {cardId=2204,baseId=501,poolId=76,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [902] = {cardId=2204,baseId=503,poolId=76,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [903] = {cardId=2204,baseId=504,poolId=76,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [904] = {cardId=2204,baseId=1000,poolId=76,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [905] = {cardId=10506,baseId=501,poolId=77,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [906] = {cardId=10506,baseId=503,poolId=77,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [907] = {cardId=10506,baseId=504,poolId=77,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [908] = {cardId=10506,baseId=1000,poolId=77,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [909] = {cardId=10045,baseId=501,poolId=78,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [910] = {cardId=10045,baseId=503,poolId=78,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [911] = {cardId=10045,baseId=504,poolId=78,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [912] = {cardId=10045,baseId=1000,poolId=78,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [913] = {cardId=2020,baseId=501,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [914] = {cardId=10123,baseId=501,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [915] = {cardId=10095,baseId=501,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [916] = {cardId=2020,baseId=503,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [917] = {cardId=10123,baseId=503,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [918] = {cardId=10095,baseId=503,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [919] = {cardId=2020,baseId=504,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [920] = {cardId=10123,baseId=504,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [921] = {cardId=10095,baseId=504,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [922] = {cardId=2020,baseId=1000,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [923] = {cardId=10123,baseId=1000,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [924] = {cardId=10095,baseId=1000,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [925] = {cardId=10136,baseId=501,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [926] = {cardId=10137,baseId=501,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [927] = {cardId=10144,baseId=501,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [928] = {cardId=10136,baseId=503,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [929] = {cardId=10137,baseId=503,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [930] = {cardId=10144,baseId=503,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [931] = {cardId=10136,baseId=504,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [932] = {cardId=10137,baseId=504,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [933] = {cardId=10144,baseId=504,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [934] = {cardId=10136,baseId=1000,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [935] = {cardId=10137,baseId=1000,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [936] = {cardId=10144,baseId=1000,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [937] = {cardId=10120,baseId=501,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [938] = {cardId=7566,baseId=501,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [939] = {cardId=10150,baseId=501,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [940] = {cardId=10120,baseId=503,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [941] = {cardId=7566,baseId=503,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [942] = {cardId=10150,baseId=503,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [943] = {cardId=10120,baseId=504,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [944] = {cardId=7566,baseId=504,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [945] = {cardId=10150,baseId=504,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [946] = {cardId=10120,baseId=1000,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [947] = {cardId=7566,baseId=1000,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [948] = {cardId=10150,baseId=1000,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [949] = {cardId=10050,baseId=501,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [950] = {cardId=10497,baseId=501,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [951] = {cardId=10184,baseId=501,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [952] = {cardId=10045,baseId=501,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [953] = {cardId=10394,baseId=501,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [954] = {cardId=10502,baseId=501,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [955] = {cardId=10180,baseId=501,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [956] = {cardId=10506,baseId=501,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [957] = {cardId=2204,baseId=501,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [958] = {cardId=10050,baseId=503,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [959] = {cardId=10497,baseId=503,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [960] = {cardId=10184,baseId=503,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [961] = {cardId=10045,baseId=503,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [962] = {cardId=10394,baseId=503,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [963] = {cardId=10502,baseId=503,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [964] = {cardId=10180,baseId=503,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [965] = {cardId=10506,baseId=503,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [966] = {cardId=2204,baseId=503,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [967] = {cardId=10050,baseId=504,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [968] = {cardId=10497,baseId=504,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [969] = {cardId=10184,baseId=504,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [970] = {cardId=10045,baseId=504,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [971] = {cardId=10394,baseId=504,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [972] = {cardId=10502,baseId=504,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [973] = {cardId=10180,baseId=504,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [974] = {cardId=10506,baseId=504,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [975] = {cardId=2204,baseId=504,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [976] = {cardId=10368,baseId=504,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [977] = {cardId=10326,baseId=504,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [978] = {cardId=10104,baseId=504,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [979] = {cardId=10415,baseId=504,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [980] = {cardId=10416,baseId=504,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [981] = {cardId=10453,baseId=503,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [982] = {cardId=10455,baseId=503,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [983] = {cardId=7102,baseId=501,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [984] = {cardId=7108,baseId=501,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [985] = {cardId=7112,baseId=501,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [986] = {cardId=2010,baseId=501,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [987] = {cardId=8580,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [988] = {cardId=8578,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [989] = {cardId=8576,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [990] = {cardId=8574,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [991] = {cardId=8572,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [992] = {cardId=8570,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [993] = {cardId=8568,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [994] = {cardId=8564,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [995] = {cardId=8562,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [996] = {cardId=8560,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [997] = {cardId=8558,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [998] = {cardId=8556,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [999] = {cardId=8554,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1000] = {cardId=8552,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1001] = {cardId=8550,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1002] = {cardId=8548,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1003] = {cardId=8546,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1004] = {cardId=8540,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1005] = {cardId=8536,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1006] = {cardId=8534,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1007] = {cardId=8530,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1008] = {cardId=8528,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1009] = {cardId=8526,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1010] = {cardId=8524,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1011] = {cardId=8522,baseId=-1,poolId=802,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1012] = {cardId=11029,baseId=-1,poolId=900,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1013] = {cardId=2061,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1014] = {cardId=2127,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1015] = {cardId=7627,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1016] = {cardId=10417,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1017] = {cardId=10422,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1018] = {cardId=10433,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1019] = {cardId=10439,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1020] = {cardId=10447,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1021] = {cardId=10449,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1022] = {cardId=10463,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1023] = {cardId=10465,baseId=503,poolId=10003,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1024] = {cardId=10471,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1025] = {cardId=10473,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1026] = {cardId=10475,baseId=503,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1027] = {cardId=10484,baseId=503,poolId=10003,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1028] = {cardId=10489,baseId=503,poolId=10003,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1029] = {cardId=10655,baseId=503,poolId=10003,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1030] = {cardId=10656,baseId=503,poolId=10003,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1031] = {cardId=10658,baseId=503,poolId=10003,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1032] = {cardId=10665,baseId=503,poolId=10003,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1033] = {cardId=10666,baseId=503,poolId=10003,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1034] = {cardId=10668,baseId=503,poolId=10003,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1035] = {cardId=2000,baseId=501,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1036] = {cardId=2010,baseId=501,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1037] = {cardId=2014,baseId=501,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1038] = {cardId=2021,baseId=501,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1039] = {cardId=2023,baseId=501,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1040] = {cardId=2037,baseId=501,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1041] = {cardId=2042,baseId=501,poolId=10003,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1042] = {cardId=2051,baseId=501,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1043] = {cardId=2053,baseId=501,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1044] = {cardId=7104,baseId=501,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1045] = {cardId=7543,baseId=501,poolId=10003,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1046] = {cardId=7547,baseId=501,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1047] = {cardId=8500,baseId=501,poolId=10003,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1048] = {cardId=8504,baseId=501,poolId=10003,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1049] = {cardId=8514,baseId=501,poolId=10003,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1050] = {cardId=10542,baseId=501,poolId=10003,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1051] = {cardId=10554,baseId=501,poolId=10003,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1052] = {cardId=10556,baseId=501,poolId=10003,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1053] = {cardId=10558,baseId=501,poolId=10003,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1054] = {cardId=10104,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1055] = {cardId=10314,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1056] = {cardId=10320,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1057] = {cardId=10324,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1058] = {cardId=10328,baseId=504,poolId=10003,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1059] = {cardId=10358,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1060] = {cardId=10366,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1061] = {cardId=10370,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1062] = {cardId=10371,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1063] = {cardId=10372,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1064] = {cardId=10373,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1065] = {cardId=10376,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1066] = {cardId=10377,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1067] = {cardId=10386,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1068] = {cardId=10387,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1069] = {cardId=10390,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1070] = {cardId=10391,baseId=504,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1071] = {cardId=10570,baseId=504,poolId=10003,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1072] = {cardId=10577,baseId=504,poolId=10003,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1073] = {cardId=10593,baseId=504,poolId=10003,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1074] = {cardId=10599,baseId=504,poolId=10003,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1075] = {cardId=10602,baseId=504,poolId=10003,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1076] = {cardId=10605,baseId=504,poolId=10003,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1077] = {cardId=10607,baseId=504,poolId=10003,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1078] = {cardId=10615,baseId=504,poolId=10003,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1079] = {cardId=10618,baseId=504,poolId=10003,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1080] = {cardId=2135,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1081] = {cardId=2161,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1082] = {cardId=7601,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1083] = {cardId=7617,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1084] = {cardId=7619,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1085] = {cardId=7621,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1086] = {cardId=7623,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1087] = {cardId=7625,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1088] = {cardId=7631,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1089] = {cardId=10421,baseId=503,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1090] = {cardId=10427,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1091] = {cardId=10429,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1092] = {cardId=10431,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1093] = {cardId=10441,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1094] = {cardId=10453,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1095] = {cardId=10459,baseId=503,poolId=10004,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1096] = {cardId=10461,baseId=503,poolId=10004,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1097] = {cardId=10470,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1098] = {cardId=10477,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1099] = {cardId=10479,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1100] = {cardId=10482,baseId=503,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1101] = {cardId=10487,baseId=503,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1102] = {cardId=10488,baseId=503,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1103] = {cardId=10490,baseId=503,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1104] = {cardId=10491,baseId=503,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1105] = {cardId=10492,baseId=503,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1106] = {cardId=10659,baseId=503,poolId=10004,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1107] = {cardId=10661,baseId=503,poolId=10004,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1108] = {cardId=10669,baseId=503,poolId=10004,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1109] = {cardId=2016,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1110] = {cardId=2031,baseId=501,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1111] = {cardId=2035,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1112] = {cardId=2039,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1113] = {cardId=2047,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1114] = {cardId=2049,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1115] = {cardId=2055,baseId=501,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1116] = {cardId=7100,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1117] = {cardId=7106,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1118] = {cardId=7116,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1119] = {cardId=7118,baseId=501,poolId=10004,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1120] = {cardId=7120,baseId=501,poolId=10004,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1121] = {cardId=7527,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1122] = {cardId=7531,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1123] = {cardId=7533,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1124] = {cardId=7535,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1125] = {cardId=7537,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1126] = {cardId=7545,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1127] = {cardId=7551,baseId=501,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1128] = {cardId=8502,baseId=501,poolId=10004,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1129] = {cardId=8506,baseId=501,poolId=10004,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1130] = {cardId=8508,baseId=501,poolId=10004,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1131] = {cardId=8516,baseId=501,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1132] = {cardId=8518,baseId=501,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1133] = {cardId=10544,baseId=501,poolId=10004,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1134] = {cardId=10548,baseId=501,poolId=10004,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1135] = {cardId=10550,baseId=501,poolId=10004,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1136] = {cardId=10552,baseId=501,poolId=10004,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1137] = {cardId=10560,baseId=501,poolId=10004,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1138] = {cardId=10561,baseId=501,poolId=10004,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1139] = {cardId=10310,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1140] = {cardId=10316,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1141] = {cardId=10318,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1142] = {cardId=10326,baseId=504,poolId=10004,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1143] = {cardId=10330,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1144] = {cardId=10332,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1145] = {cardId=10334,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1146] = {cardId=10336,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1147] = {cardId=10338,baseId=504,poolId=10004,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1148] = {cardId=10345,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1149] = {cardId=10346,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1150] = {cardId=10348,baseId=504,poolId=10004,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1151] = {cardId=10356,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1152] = {cardId=10374,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1153] = {cardId=10375,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1154] = {cardId=10378,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1155] = {cardId=10379,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1156] = {cardId=10380,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1157] = {cardId=10381,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1158] = {cardId=10384,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1159] = {cardId=10385,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1160] = {cardId=10388,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1161] = {cardId=10389,baseId=504,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1162] = {cardId=10392,baseId=504,poolId=10004,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1163] = {cardId=10572,baseId=504,poolId=10004,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1164] = {cardId=10579,baseId=504,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1165] = {cardId=10591,baseId=504,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1166] = {cardId=10596,baseId=504,poolId=10004,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1167] = {cardId=10609,baseId=504,poolId=10004,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1168] = {cardId=10611,baseId=504,poolId=10004,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1169] = {cardId=10613,baseId=504,poolId=10004,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1170] = {cardId=2155,baseId=503,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1171] = {cardId=2177,baseId=503,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1172] = {cardId=7629,baseId=503,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1173] = {cardId=10419,baseId=503,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1174] = {cardId=10425,baseId=503,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1175] = {cardId=10443,baseId=503,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1176] = {cardId=10451,baseId=503,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1177] = {cardId=10455,baseId=503,poolId=10005,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1178] = {cardId=10466,baseId=503,poolId=10005,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1179] = {cardId=10481,baseId=503,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1180] = {cardId=10662,baseId=503,poolId=10005,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1181] = {cardId=10672,baseId=503,poolId=10005,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1182] = {cardId=2004,baseId=501,poolId=10005,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1183] = {cardId=2006,baseId=501,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1184] = {cardId=2008,baseId=501,poolId=10005,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1185] = {cardId=2033,baseId=501,poolId=10005,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1186] = {cardId=7102,baseId=501,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1187] = {cardId=7108,baseId=501,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1188] = {cardId=7112,baseId=501,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1189] = {cardId=7539,baseId=501,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1190] = {cardId=7541,baseId=501,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1191] = {cardId=7549,baseId=501,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1192] = {cardId=7553,baseId=501,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1193] = {cardId=8510,baseId=501,poolId=10005,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1194] = {cardId=8512,baseId=501,poolId=10005,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1195] = {cardId=8520,baseId=501,poolId=10005,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1196] = {cardId=10546,baseId=501,poolId=10005,minBaseLevel=4,maxBaseLevel=10,limitActIds={-1}},
    [1197] = {cardId=10562,baseId=501,poolId=10005,minBaseLevel=5,maxBaseLevel=10,limitActIds={-1}},
    [1198] = {cardId=10312,baseId=504,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1199] = {cardId=10322,baseId=504,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1200] = {cardId=10340,baseId=504,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1201] = {cardId=10341,baseId=504,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1202] = {cardId=10343,baseId=504,poolId=10005,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1203] = {cardId=10350,baseId=504,poolId=10005,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1204] = {cardId=10352,baseId=504,poolId=10005,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1205] = {cardId=10354,baseId=504,poolId=10005,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1206] = {cardId=10360,baseId=504,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1207] = {cardId=10362,baseId=504,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1208] = {cardId=10364,baseId=504,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1209] = {cardId=10368,baseId=504,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1210] = {cardId=10382,baseId=504,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1211] = {cardId=10383,baseId=504,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1212] = {cardId=10415,baseId=504,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1213] = {cardId=10416,baseId=504,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1214] = {cardId=10574,baseId=504,poolId=10005,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1215] = {cardId=10581,baseId=504,poolId=10005,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1216] = {cardId=10598,baseId=504,poolId=10005,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1217] = {cardId=21054,baseId=503,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1218] = {cardId=21055,baseId=503,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1219] = {cardId=21056,baseId=503,poolId=10005,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1220] = {cardId=2204,baseId=501,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1221] = {cardId=2204,baseId=503,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1222] = {cardId=2204,baseId=504,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1223] = {cardId=11054,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1224] = {cardId=11055,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1225] = {cardId=11056,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1226] = {cardId=11057,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1227] = {cardId=11058,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1228] = {cardId=11060,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1229] = {cardId=11066,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1230] = {cardId=11068,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1231] = {cardId=11069,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1232] = {cardId=11070,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1233] = {cardId=11071,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1234] = {cardId=11072,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1235] = {cardId=11073,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1236] = {cardId=11074,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1237] = {cardId=11075,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1238] = {cardId=11076,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1239] = {cardId=11077,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1240] = {cardId=11078,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1241] = {cardId=11079,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1242] = {cardId=11080,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1243] = {cardId=11081,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1244] = {cardId=11084,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1245] = {cardId=11085,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1246] = {cardId=11086,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1247] = {cardId=11088,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1248] = {cardId=11089,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1249] = {cardId=11090,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1250] = {cardId=11091,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1251] = {cardId=11092,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1252] = {cardId=11093,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1253] = {cardId=11094,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1254] = {cardId=11095,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1255] = {cardId=11096,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1256] = {cardId=11097,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1257] = {cardId=11098,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1258] = {cardId=11099,baseId=505,poolId=71,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1259] = {cardId=11100,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1260] = {cardId=11101,baseId=505,poolId=71,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1261] = {cardId=11087,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1262] = {cardId=10050,baseId=505,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1263] = {cardId=10497,baseId=505,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1264] = {cardId=10176,baseId=505,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1265] = {cardId=2204,baseId=505,poolId=74,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1266] = {cardId=10750,baseId=505,poolId=75,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1267] = {cardId=10180,baseId=505,poolId=75,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1268] = {cardId=10184,baseId=505,poolId=75,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1269] = {cardId=2204,baseId=505,poolId=76,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1270] = {cardId=10506,baseId=505,poolId=77,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1271] = {cardId=10045,baseId=505,poolId=78,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1272] = {cardId=2204,baseId=505,poolId=80,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1273] = {cardId=2208,baseId=505,poolId=81,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1274] = {cardId=2212,baseId=505,poolId=82,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1275] = {cardId=2216,baseId=505,poolId=83,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1276] = {cardId=2220,baseId=505,poolId=84,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1277] = {cardId=2741,baseId=505,poolId=111,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1278] = {cardId=2743,baseId=505,poolId=112,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1279] = {cardId=2745,baseId=505,poolId=113,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1280] = {cardId=8550,baseId=505,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1281] = {cardId=8554,baseId=505,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1282] = {cardId=8556,baseId=505,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1283] = {cardId=8558,baseId=505,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1284] = {cardId=8560,baseId=505,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1285] = {cardId=8562,baseId=505,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1286] = {cardId=8564,baseId=505,poolId=114,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1287] = {cardId=2747,baseId=505,poolId=115,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1288] = {cardId=8522,baseId=505,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1289] = {cardId=8524,baseId=505,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1290] = {cardId=8526,baseId=505,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1291] = {cardId=8528,baseId=505,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1292] = {cardId=8530,baseId=505,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1293] = {cardId=8534,baseId=505,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1294] = {cardId=8536,baseId=505,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1295] = {cardId=8540,baseId=505,poolId=116,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1296] = {cardId=10050,baseId=505,poolId=122,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1297] = {cardId=10180,baseId=505,poolId=123,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1298] = {cardId=10411,baseId=505,poolId=130,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1299] = {cardId=10412,baseId=505,poolId=131,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1300] = {cardId=10413,baseId=505,poolId=132,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1301] = {cardId=10414,baseId=505,poolId=133,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1302] = {cardId=8536,baseId=505,poolId=151,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1303] = {cardId=8540,baseId=505,poolId=152,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1304] = {cardId=2020,baseId=505,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1305] = {cardId=10123,baseId=505,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1306] = {cardId=10095,baseId=505,poolId=220,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1307] = {cardId=10136,baseId=505,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1308] = {cardId=10137,baseId=505,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1309] = {cardId=10144,baseId=505,poolId=221,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1310] = {cardId=10728,baseId=505,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1311] = {cardId=10120,baseId=505,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1312] = {cardId=7566,baseId=505,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1313] = {cardId=10150,baseId=505,poolId=222,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1314] = {cardId=10050,baseId=505,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1315] = {cardId=10497,baseId=505,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1316] = {cardId=10184,baseId=505,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1317] = {cardId=10045,baseId=505,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1318] = {cardId=10394,baseId=505,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1319] = {cardId=10502,baseId=505,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1320] = {cardId=10180,baseId=505,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1321] = {cardId=10506,baseId=505,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1322] = {cardId=2204,baseId=505,poolId=300,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1323] = {cardId=8522,baseId=505,poolId=501,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1324] = {cardId=8524,baseId=505,poolId=502,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1325] = {cardId=8528,baseId=505,poolId=503,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1326] = {cardId=8526,baseId=505,poolId=504,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1327] = {cardId=8536,baseId=505,poolId=505,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1328] = {cardId=8530,baseId=505,poolId=506,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1329] = {cardId=8546,baseId=505,poolId=508,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1330] = {cardId=8548,baseId=505,poolId=509,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1331] = {cardId=8552,baseId=505,poolId=510,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1332] = {cardId=8554,baseId=505,poolId=511,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1333] = {cardId=8556,baseId=505,poolId=512,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1334] = {cardId=8562,baseId=505,poolId=513,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1335] = {cardId=8570,baseId=505,poolId=515,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1336] = {cardId=8572,baseId=505,poolId=516,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1337] = {cardId=8574,baseId=505,poolId=517,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1338] = {cardId=8576,baseId=505,poolId=518,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1339] = {cardId=8568,baseId=505,poolId=519,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1340] = {cardId=8580,baseId=505,poolId=520,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1341] = {cardId=2643,baseId=505,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1342] = {cardId=2645,baseId=505,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1343] = {cardId=2647,baseId=505,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1344] = {cardId=8522,baseId=505,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1345] = {cardId=8524,baseId=505,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1346] = {cardId=8528,baseId=505,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1347] = {cardId=8530,baseId=505,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1348] = {cardId=8534,baseId=505,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1349] = {cardId=8536,baseId=505,poolId=110,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1350] = {cardId=10308,baseId=505,poolId=134,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1351] = {cardId=10310,baseId=505,poolId=200,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1352] = {cardId=10348,baseId=505,poolId=201,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1353] = {cardId=10346,baseId=505,poolId=202,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1354] = {cardId=10591,baseId=505,poolId=203,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1355] = {cardId=10593,baseId=505,poolId=204,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1356] = {cardId=10589,baseId=505,poolId=205,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1357] = {cardId=10310,baseId=505,poolId=206,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1358] = {cardId=10618,baseId=505,poolId=207,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1359] = {cardId=10615,baseId=505,poolId=208,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1360] = {cardId=8570,baseId=505,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1361] = {cardId=8572,baseId=505,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1362] = {cardId=8574,baseId=505,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1363] = {cardId=8576,baseId=505,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1364] = {cardId=8578,baseId=505,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1365] = {cardId=8580,baseId=505,poolId=210,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1366] = {cardId=7531,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1367] = {cardId=2004,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1368] = {cardId=2031,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1369] = {cardId=2033,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1370] = {cardId=2037,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1371] = {cardId=2039,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1372] = {cardId=7545,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1373] = {cardId=7553,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1374] = {cardId=10451,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1375] = {cardId=10453,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1376] = {cardId=10461,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1377] = {cardId=7631,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1378] = {cardId=7601,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1379] = {cardId=10479,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1380] = {cardId=2061,baseId=505,poolId=212,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1381] = {cardId=10366,baseId=505,poolId=507,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1382] = {cardId=10334,baseId=505,poolId=514,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1383] = {cardId=10368,baseId=505,poolId=521,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1384] = {cardId=10368,baseId=505,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1385] = {cardId=10326,baseId=505,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1386] = {cardId=10104,baseId=505,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1387] = {cardId=10415,baseId=505,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1388] = {cardId=10416,baseId=505,poolId=801,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1389] = {cardId=11054,baseId=505,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1390] = {cardId=11055,baseId=505,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1391] = {cardId=11056,baseId=505,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1392] = {cardId=11066,baseId=505,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1393] = {cardId=11071,baseId=505,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1394] = {cardId=11073,baseId=505,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1395] = {cardId=11074,baseId=505,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1396] = {cardId=11076,baseId=505,poolId=10003,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1397] = {cardId=11079,baseId=505,poolId=10003,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1398] = {cardId=11080,baseId=505,poolId=10003,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1399] = {cardId=11088,baseId=505,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1400] = {cardId=11090,baseId=505,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1401] = {cardId=11096,baseId=505,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1402] = {cardId=11100,baseId=505,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1403] = {cardId=11057,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1404] = {cardId=11058,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1405] = {cardId=11069,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1406] = {cardId=11070,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1407] = {cardId=11072,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1408] = {cardId=11075,baseId=505,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1409] = {cardId=11077,baseId=505,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1410] = {cardId=11078,baseId=505,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1411] = {cardId=11081,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1412] = {cardId=11085,baseId=505,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1413] = {cardId=11086,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1414] = {cardId=11089,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1415] = {cardId=11091,baseId=505,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1416] = {cardId=11092,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1417] = {cardId=11093,baseId=505,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1418] = {cardId=11094,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1419] = {cardId=11097,baseId=505,poolId=10004,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1420] = {cardId=11098,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1421] = {cardId=11060,baseId=505,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1422] = {cardId=11084,baseId=505,poolId=10005,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1423] = {cardId=11095,baseId=505,poolId=10005,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1424] = {cardId=11099,baseId=505,poolId=10005,minBaseLevel=2,maxBaseLevel=10,limitActIds={-1}},
    [1425] = {cardId=11101,baseId=505,poolId=10005,minBaseLevel=3,maxBaseLevel=10,limitActIds={-1}},
    [1426] = {cardId=11087,baseId=505,poolId=10005,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1427] = {cardId=11060,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1428] = {cardId=11084,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1429] = {cardId=11087,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1430] = {cardId=11095,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1431] = {cardId=11099,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1432] = {cardId=11101,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1433] = {cardId=11105,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1434] = {cardId=11106,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1435] = {cardId=11114,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1436] = {cardId=11115,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1437] = {cardId=11116,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1438] = {cardId=11118,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1439] = {cardId=11121,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1440] = {cardId=11123,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1441] = {cardId=11124,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1442] = {cardId=11127,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1443] = {cardId=11130,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1444] = {cardId=11131,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1445] = {cardId=11134,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1446] = {cardId=11136,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1447] = {cardId=11137,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1448] = {cardId=11138,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1449] = {cardId=11139,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1450] = {cardId=11142,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1451] = {cardId=11143,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1452] = {cardId=10728,baseId=501,poolId=117,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1453] = {cardId=10728,baseId=503,poolId=117,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1454] = {cardId=10728,baseId=504,poolId=117,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1455] = {cardId=10728,baseId=1000,poolId=117,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1456] = {cardId=10728,baseId=505,poolId=117,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1457] = {cardId=11151,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1458] = {cardId=11151,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1459] = {cardId=11152,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1460] = {cardId=11152,baseId=505,poolId=10004,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1461] = {cardId=11150,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1462] = {cardId=11150,baseId=505,poolId=10003,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1463] = {cardId=11153,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1464] = {cardId=11154,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1465] = {cardId=11155,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1466] = {cardId=11156,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1467] = {cardId=11157,baseId=505,poolId=71,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1468] = {cardId=11158,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
    [1469] = {cardId=11159,baseId=505,poolId=135,minBaseLevel=1,maxBaseLevel=10,limitActIds={-1}},
}
local base_pool = {}
local base_pool_loaded = {}
local base_pool_languages = {}

local function base_pool_load(index)
    if index == nil then return nil end
    if base_pool_loaded[index] then return base_pool[index] end
    local source = base_pool_source[index]
    if source == nil then return nil end
    local rowLanguage = base_pool_languages[index] or nil
    local data = ConfigRowRuntime.Build(source,base_pool_runtime_schema,"act_card_pool_def",rowLanguage)
    base_pool[index] = data
    base_pool_loaded[index] = true
    return data
end

function act_card_pool_def.base_pool_index(index)
    return base_pool_load(index)
end

function act_card_pool_def.base_pool_set(index,data)
    base_pool[index] = data
    base_pool_loaded[index] = true
end

function act_card_pool_def.base_pool_num()
    return base_pool_num
end

local base_pool_baseId =
{
    [501]={1,2,3,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,82,83,84,85,86,92,94,96,98,100,102,104,106,109,110,111,112,113,119,120,121,122,123,124,125,126,206,209,212,221,222,223,224,225,226,227,236,246,247,248,249,250,251,252,253,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,295,296,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,387,390,393,396,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,478,481,484,487,490,493,496,499,508,509,510,511,512,513,514,527,530,531,532,533,534,535,536,537,538,539,540,541,542,543,544,576,579,582,585,588,591,594,597,600,603,606,609,612,615,618,621,624,627,630,633,636,883,884,885,892,893,894,901,905,909,913,914,915,925,926,927,937,938,939,949,950,951,952,953,954,955,956,957,983,984,985,986,1035,1036,1037,1038,1039,1040,1041,1042,1043,1044,1045,1046,1047,1048,1049,1050,1051,1052,1053,1109,1110,1111,1112,1113,1114,1115,1116,1117,1118,1119,1120,1121,1122,1123,1124,1125,1126,1127,1128,1129,1130,1131,1132,1133,1134,1135,1136,1137,1138,1182,1183,1184,1185,1186,1187,1188,1189,1190,1191,1192,1193,1194,1195,1196,1197,1220,1452},[503]={4,5,6,7,8,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,87,88,89,90,91,93,95,97,99,101,103,105,107,108,114,115,116,117,118,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,207,210,213,228,229,230,231,232,233,234,237,254,255,256,257,258,259,260,261,297,298,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,388,391,394,397,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,479,482,485,488,491,494,497,500,502,504,506,515,516,517,518,519,520,528,545,546,547,548,549,550,551,552,553,554,555,556,557,558,559,560,577,580,583,586,589,592,595,598,601,604,607,610,613,616,619,622,625,628,631,634,637,886,887,888,895,896,897,902,906,910,916,917,918,928,929,930,940,941,942,958,959,960,961,962,963,964,965,966,981,982,1013,1014,1015,1016,1017,1018,1019,1020,1021,1022,1023,1024,1025,1026,1027,1028,1029,1030,1031,1032,1033,1034,1080,1081,1082,1083,1084,1085,1086,1087,1088,1089,1090,1091,1092,1093,1094,1095,1096,1097,1098,1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1170,1171,1172,1173,1174,1175,1176,1177,1178,1179,1180,1181,1217,1218,1219,1221,1453},[504]={150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,208,211,214,215,216,217,218,219,220,235,238,239,240,241,242,243,244,245,286,287,288,289,290,291,292,293,294,299,300,389,392,395,398,399,400,401,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,480,483,486,489,492,495,498,501,503,505,507,521,522,523,524,525,526,529,561,562,563,564,565,566,567,568,569,570,571,572,573,574,575,578,581,584,587,590,593,596,599,602,605,608,611,614,617,620,623,626,629,632,635,638,889,890,891,898,899,900,903,907,911,919,920,921,931,932,933,943,944,945,967,968,969,970,971,972,973,974,975,976,977,978,979,980,1054,1055,1056,1057,1058,1059,1060,1061,1062,1063,1064,1065,1066,1067,1068,1069,1070,1071,1072,1073,1074,1075,1076,1077,1078,1079,1139,1140,1141,1142,1143,1144,1145,1146,1147,1148,1149,1150,1151,1152,1153,1154,1155,1156,1157,1158,1159,1160,1161,1162,1163,1164,1165,1166,1167,1168,1169,1198,1199,1200,1201,1202,1203,1204,1205,1206,1207,1208,1209,1210,1211,1212,1213,1214,1215,1216,1222,1454},[1000]={639,640,641,642,643,644,645,646,647,648,649,650,651,652,653,654,655,656,657,658,659,660,661,662,663,664,665,666,667,668,669,670,671,672,673,674,675,676,677,678,679,680,681,682,683,684,685,686,687,688,689,690,691,692,693,694,695,696,697,698,699,700,701,702,703,704,705,706,707,708,709,710,711,712,713,714,715,716,717,718,719,720,721,722,723,724,725,726,727,728,729,730,731,732,733,734,735,736,737,738,739,740,741,742,743,744,745,746,747,748,749,750,751,752,753,754,755,756,757,758,759,760,761,762,763,764,765,766,767,768,769,770,771,772,773,774,775,776,777,778,779,780,781,782,783,784,785,786,787,788,789,790,791,792,793,794,795,796,797,798,799,800,801,802,803,804,805,806,807,808,809,810,811,812,813,814,815,816,817,818,819,820,821,822,823,824,825,826,827,828,829,830,831,832,833,834,835,836,837,838,839,840,841,842,843,844,845,846,847,848,849,850,851,852,853,854,855,856,857,858,859,860,861,862,863,864,865,866,867,868,869,870,871,872,873,874,875,876,877,878,879,880,881,882,904,908,912,922,923,924,934,935,936,946,947,948,1455},[-1]={987,988,989,990,991,992,993,994,995,996,997,998,999,1000,1001,1002,1003,1004,1005,1006,1007,1008,1009,1010,1011,1012},[505]={1223,1224,1225,1226,1227,1228,1229,1230,1231,1232,1233,1234,1235,1236,1237,1238,1239,1240,1241,1242,1243,1244,1245,1246,1247,1248,1249,1250,1251,1252,1253,1254,1255,1256,1257,1258,1259,1260,1261,1262,1263,1264,1265,1266,1267,1268,1269,1270,1271,1272,1273,1274,1275,1276,1277,1278,1279,1280,1281,1282,1283,1284,1285,1286,1287,1288,1289,1290,1291,1292,1293,1294,1295,1296,1297,1298,1299,1300,1301,1302,1303,1304,1305,1306,1307,1308,1309,1310,1311,1312,1313,1314,1315,1316,1317,1318,1319,1320,1321,1322,1323,1324,1325,1326,1327,1328,1329,1330,1331,1332,1333,1334,1335,1336,1337,1338,1339,1340,1341,1342,1343,1344,1345,1346,1347,1348,1349,1350,1351,1352,1353,1354,1355,1356,1357,1358,1359,1360,1361,1362,1363,1364,1365,1366,1367,1368,1369,1370,1371,1372,1373,1374,1375,1376,1377,1378,1379,1380,1381,1382,1383,1384,1385,1386,1387,1388,1389,1390,1391,1392,1393,1394,1395,1396,1397,1398,1399,1400,1401,1402,1403,1404,1405,1406,1407,1408,1409,1410,1411,1412,1413,1414,1415,1416,1417,1418,1419,1420,1421,1422,1423,1424,1425,1426,1427,1428,1429,1430,1431,1432,1433,1434,1435,1436,1437,1438,1439,1440,1441,1442,1443,1444,1445,1446,1447,1448,1449,1450,1451,1456,1457,1458,1459,1460,1461,1462,1463,1464,1465,1466,1467,1468,1469}
}

local base_pool_baseId_data = {}
function act_card_pool_def.base_pool_baseId(key)
    if base_pool_baseId_data[key] then
        return base_pool_baseId_data[key]
    end
    local indexs = base_pool_baseId[key]
    local datas = {}
    if indexs == nil then return datas end
    for _,index in ipairs(indexs) do
        table.insert(datas,act_card_pool_def.base_pool_index(index))
    end
    base_pool_baseId_data[key] = datas
    return datas
end

local base_pool_poolId =
{
    [51]={1,639},[52]={2,640},[53]={3,641},[61]={4},[62]={5},[63]={6},[64]={7},[65]={8},[1]={9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,642,643,644,645,646,647,648,649,650,651,652,653,654,655,656,657,658,659,660,661,662,663,664,665},[721]={33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81},[80]={82,87,666,1272},[81]={83,88,667,1273},[82]={84,89,668,1274},[83]={85,90,669,1275},[84]={86,91,670,1276},[86]={92,93,671},[87]={94,95,672},[88]={96,97,673},[89]={98,99,674},[90]={100,101,675},[91]={102,103,676},[92]={104,105,677},[93]={106,107,678},[94]={108},[95]={109,114,679},[96]={110,115,680},[97]={111,116,681},[98]={112,117,682},[99]={113,118,683},[110]={119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,262,263,264,265,266,267,268,269,270,271,272,286,287,288,289,290,291,292,293,294,684,685,686,687,688,689,690,691,711,712,713,714,715,716,717,718,719,720,721,1341,1342,1343,1344,1345,1346,1347,1348,1349},[73]={150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,400,401,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442},[111]={205,206,207,692,1277},[112]={208,209,210,693,1278},[113]={211,212,213,694,1279},[114]={214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,695,696,697,698,699,700,701,1280,1281,1282,1283,1284,1285,1286},[115]={235,236,237,702,1287},[116]={238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,703,704,705,706,707,708,709,710,1288,1289,1290,1291,1292,1293,1294,1295},[120]={273,274,275,276,277,278,279,280,281,282,283,284,285,722,723,724,725,726,727,728,729,730,731,732,733,734},[122]={295,297,299,735,1296},[123]={296,298,300,736,1297},[70]={301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,737,738,739,740,741,742,743,744,745,746,747,748,749,750,751,752,753,754,755,756,757,758,759,760,761,762,763,764,765,766,767,768,769,770,771,772,773,774,775,776,777,778,779,780,781,782,783,784,785,786,791,792,793,794,795,796,797,798,799,800,801,802,803,804,805,806,807,808,809,810,811,812,865,866,867,868,869,870,871,872,873,874,875,876,877,878,879,880,881,882},[72]={351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477},[130]={387,388,389,787,1298},[131]={390,391,392,788,1299},[132]={393,394,395,789,1300},[133]={396,397,398,790,1301},[134]={399,1350},[151]={478,479,480,813,1302},[152]={481,482,483,814,1303},[200]={484,485,486,815,1351},[201]={487,488,489,816,1352},[202]={490,491,492,817,1353},[203]={493,494,495,818,1354},[204]={496,497,498,819,1355},[205]={499,500,501,820,1356},[206]={502,503,1357},[207]={504,505,1358},[208]={506,507,1359},[210]={508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,821,822,823,824,825,826,827,1360,1361,1362,1363,1364,1365},[222]={527,528,529,828,937,938,939,940,941,942,943,944,945,946,947,948,1310,1311,1312,1313},[212]={530,531,532,533,534,535,536,537,538,539,540,541,542,543,544,545,546,547,548,549,550,551,552,553,554,555,556,557,558,559,560,561,562,563,564,565,566,567,568,569,570,571,572,573,574,575,829,830,831,832,833,834,835,836,837,838,839,840,841,842,843,1366,1367,1368,1369,1370,1371,1372,1373,1374,1375,1376,1377,1378,1379,1380},[501]={576,577,578,844,1323},[502]={579,580,581,845,1324},[503]={582,583,584,846,1325},[504]={585,586,587,847,1326},[505]={588,589,590,848,1327},[506]={591,592,593,849,1328},[507]={594,595,596,850,1381},[508]={597,598,599,851,1329},[509]={600,601,602,852,1330},[510]={603,604,605,853,1331},[511]={606,607,608,854,1332},[512]={609,610,611,855,1333},[513]={612,613,614,856,1334},[514]={615,616,617,857,1382},[515]={618,619,620,858,1335},[516]={621,622,623,859,1336},[517]={624,625,626,860,1337},[518]={627,628,629,861,1338},[519]={630,631,632,862,1339},[520]={633,634,635,863,1340},[521]={636,637,638,864,1383},[74]={883,884,885,886,887,888,889,890,891,1220,1221,1222,1262,1263,1264,1265},[75]={892,893,894,895,896,897,898,899,900,1266,1267,1268},[76]={901,902,903,904,1269},[77]={905,906,907,908,1270},[78]={909,910,911,912,1271},[220]={913,914,915,916,917,918,919,920,921,922,923,924,1304,1305,1306},[221]={925,926,927,928,929,930,931,932,933,934,935,936,1307,1308,1309},[300]={949,950,951,952,953,954,955,956,957,958,959,960,961,962,963,964,965,966,967,968,969,970,971,972,973,974,975,1314,1315,1316,1317,1318,1319,1320,1321,1322},[801]={976,977,978,979,980,981,982,983,984,985,986,1384,1385,1386,1387,1388},[802]={987,988,989,990,991,992,993,994,995,996,997,998,999,1000,1001,1002,1003,1004,1005,1006,1007,1008,1009,1010,1011},[900]={1012},[10003]={1013,1014,1015,1016,1017,1018,1019,1020,1021,1022,1023,1024,1025,1026,1027,1028,1029,1030,1031,1032,1033,1034,1035,1036,1037,1038,1039,1040,1041,1042,1043,1044,1045,1046,1047,1048,1049,1050,1051,1052,1053,1054,1055,1056,1057,1058,1059,1060,1061,1062,1063,1064,1065,1066,1067,1068,1069,1070,1071,1072,1073,1074,1075,1076,1077,1078,1079,1389,1390,1391,1392,1393,1394,1395,1396,1397,1398,1399,1400,1401,1402,1462},[10004]={1080,1081,1082,1083,1084,1085,1086,1087,1088,1089,1090,1091,1092,1093,1094,1095,1096,1097,1098,1099,1100,1101,1102,1103,1104,1105,1106,1107,1108,1109,1110,1111,1112,1113,1114,1115,1116,1117,1118,1119,1120,1121,1122,1123,1124,1125,1126,1127,1128,1129,1130,1131,1132,1133,1134,1135,1136,1137,1138,1139,1140,1141,1142,1143,1144,1145,1146,1147,1148,1149,1150,1151,1152,1153,1154,1155,1156,1157,1158,1159,1160,1161,1162,1163,1164,1165,1166,1167,1168,1169,1403,1404,1405,1406,1407,1408,1409,1410,1411,1412,1413,1414,1415,1416,1417,1418,1419,1420,1458,1460},[10005]={1170,1171,1172,1173,1174,1175,1176,1177,1178,1179,1180,1181,1182,1183,1184,1185,1186,1187,1188,1189,1190,1191,1192,1193,1194,1195,1196,1197,1198,1199,1200,1201,1202,1203,1204,1205,1206,1207,1208,1209,1210,1211,1212,1213,1214,1215,1216,1217,1218,1219,1421,1422,1423,1424,1425,1426},[71]={1223,1224,1225,1226,1227,1228,1229,1230,1231,1232,1233,1234,1235,1236,1237,1238,1239,1240,1241,1242,1243,1244,1245,1246,1247,1248,1249,1250,1251,1252,1253,1254,1255,1256,1257,1258,1259,1260,1261,1457,1459,1461,1466,1467},[135]={1427,1428,1429,1430,1431,1432,1433,1434,1435,1436,1437,1438,1439,1440,1441,1442,1443,1444,1445,1446,1447,1448,1449,1450,1451,1463,1464,1465,1468,1469},[117]={1452,1453,1454,1455,1456}
}

local base_pool_poolId_data = {}
function act_card_pool_def.base_pool_poolId(key)
    if base_pool_poolId_data[key] then
        return base_pool_poolId_data[key]
    end
    local indexs = base_pool_poolId[key]
    local datas = {}
    if indexs == nil then return datas end
    for _,index in ipairs(indexs) do
        table.insert(datas,act_card_pool_def.base_pool_index(index))
    end
    base_pool_poolId_data[key] = datas
    return datas
end

--arm_pool
local arm_pool_num = 6
local arm_pool_schema =
{
    ["cardId"] = { type = "int" },
    ["armId"] = { type = "int" },
    ["poolId"] = { type = "int" },
    ["baseId"] = { type = "int" },
    ["minBaseLevel"] = { type = "int" },
    ["maxBaseLevel"] = { type = "int" },
}
local arm_pool_runtime_schema = arm_pool_schema
local arm_pool_source =
{
    [1] = {cardId=6064,armId=1101,poolId=1,baseId=103,minBaseLevel=1,maxBaseLevel=10},
    [2] = {cardId=6070,armId=1102,poolId=1,baseId=103,minBaseLevel=1,maxBaseLevel=10},
    [3] = {cardId=6070,armId=1103,poolId=1,baseId=103,minBaseLevel=1,maxBaseLevel=10},
    [4] = {cardId=6065,armId=1111,poolId=1,baseId=103,minBaseLevel=1,maxBaseLevel=10},
    [5] = {cardId=6074,armId=1112,poolId=1,baseId=103,minBaseLevel=1,maxBaseLevel=10},
    [6] = {cardId=6065,armId=1113,poolId=1,baseId=103,minBaseLevel=1,maxBaseLevel=10},
}
local arm_pool = {}
local arm_pool_loaded = {}
local arm_pool_languages = {}

local function arm_pool_load(index)
    if index == nil then return nil end
    if arm_pool_loaded[index] then return arm_pool[index] end
    local source = arm_pool_source[index]
    if source == nil then return nil end
    local rowLanguage = arm_pool_languages[index] or nil
    local data = ConfigRowRuntime.Build(source,arm_pool_runtime_schema,"act_card_pool_def",rowLanguage)
    arm_pool[index] = data
    arm_pool_loaded[index] = true
    return data
end

function act_card_pool_def.arm_pool_index(index)
    return arm_pool_load(index)
end

function act_card_pool_def.arm_pool_set(index,data)
    arm_pool[index] = data
    arm_pool_loaded[index] = true
end

function act_card_pool_def.arm_pool_num()
    return arm_pool_num
end

local arm_pool_armId =
{
    [1101]={1},[1102]={2},[1103]={3},[1111]={4},[1112]={5},[1113]={6}
}

local arm_pool_armId_data = {}
function act_card_pool_def.arm_pool_armId(key)
    if arm_pool_armId_data[key] then
        return arm_pool_armId_data[key]
    end
    local indexs = arm_pool_armId[key]
    local datas = {}
    if indexs == nil then return datas end
    for _,index in ipairs(indexs) do
        table.insert(datas,act_card_pool_def.arm_pool_index(index))
    end
    arm_pool_armId_data[key] = datas
    return datas
end

local arm_pool_poolId =
{
    [1]={1,2,3,4,5,6}
}

local arm_pool_poolId_data = {}
function act_card_pool_def.arm_pool_poolId(key)
    if arm_pool_poolId_data[key] then
        return arm_pool_poolId_data[key]
    end
    local indexs = arm_pool_poolId[key]
    local datas = {}
    if indexs == nil then return datas end
    for _,index in ipairs(indexs) do
        table.insert(datas,act_card_pool_def.arm_pool_index(index))
    end
    arm_pool_poolId_data[key] = datas
    return datas
end

--act_pool
local act_pool_num = 0
local act_pool_schema =
{
    ["cardId"] = { type = "int" },
    ["baseId"] = { type = "int" },
    ["actId"] = { type = "int" },
    ["poolId"] = { type = "int" },
    ["minActLevel"] = { type = "int" },
    ["maxActLevel"] = { type = "int" },
}
local act_pool_runtime_schema = act_pool_schema
local act_pool_source =
{
}
local act_pool = {}
local act_pool_loaded = {}
local act_pool_languages = {}

local function act_pool_load(index)
    if index == nil then return nil end
    if act_pool_loaded[index] then return act_pool[index] end
    local source = act_pool_source[index]
    if source == nil then return nil end
    local rowLanguage = act_pool_languages[index] or nil
    local data = ConfigRowRuntime.Build(source,act_pool_runtime_schema,"act_card_pool_def",rowLanguage)
    act_pool[index] = data
    act_pool_loaded[index] = true
    return data
end

function act_card_pool_def.act_pool_index(index)
    return act_pool_load(index)
end

function act_card_pool_def.act_pool_set(index,data)
    act_pool[index] = data
    act_pool_loaded[index] = true
end

function act_card_pool_def.act_pool_num()
    return act_pool_num
end

local act_pool_actId =
{
    
}

local act_pool_actId_data = {}
function act_card_pool_def.act_pool_actId(key)
    if act_pool_actId_data[key] then
        return act_pool_actId_data[key]
    end
    local indexs = act_pool_actId[key]
    local datas = {}
    if indexs == nil then return datas end
    for _,index in ipairs(indexs) do
        table.insert(datas,act_card_pool_def.act_pool_index(index))
    end
    act_pool_actId_data[key] = datas
    return datas
end

local act_pool_poolId =
{
    
}

local act_pool_poolId_data = {}
function act_card_pool_def.act_pool_poolId(key)
    if act_pool_poolId_data[key] then
        return act_pool_poolId_data[key]
    end
    local indexs = act_pool_poolId[key]
    local datas = {}
    if indexs == nil then return datas end
    for _,index in ipairs(indexs) do
        table.insert(datas,act_card_pool_def.act_pool_index(index))
    end
    act_pool_poolId_data[key] = datas
    return datas
end

local configSheets =
{
    ["base_pool"] =
    {
        schema = base_pool_schema,
        indexes =
        {
            { indexKey = "baseId", fields = {"baseId"}, fieldTypes = {"int"}, group = true },
            { indexKey = "poolId", fields = {"poolId"}, fieldTypes = {"int"}, group = true },
        },
    },
    ["arm_pool"] =
    {
        schema = arm_pool_schema,
        indexes =
        {
            { indexKey = "armId", fields = {"armId"}, fieldTypes = {"int"}, group = true },
            { indexKey = "poolId", fields = {"poolId"}, fieldTypes = {"int"}, group = true },
        },
    },
    ["act_pool"] =
    {
        schema = act_pool_schema,
        indexes =
        {
            { indexKey = "actId", fields = {"actId"}, fieldTypes = {"int"}, group = true },
            { indexKey = "poolId", fields = {"poolId"}, fieldTypes = {"int"}, group = true },
        },
    },
}

local configSheetRuntimes =
{
    ["base_pool"] =
    {
        getRows = function() return base_pool_source end,
        getLanguages = function() return base_pool_languages end,
        getSchema = function() return base_pool_runtime_schema end,
        publish = function(rows,indexes,schema,languages)
            base_pool_source = rows
            base_pool_runtime_schema = schema or base_pool_schema
            base_pool_languages = languages or {}
            base_pool = {}
            base_pool_loaded = {}
            base_pool_num = #rows
            base_pool_baseId = indexes["baseId"] or {}
            base_pool_baseId_data = {}
            base_pool_poolId = indexes["poolId"] or {}
            base_pool_poolId_data = {}
        end,
    },
    ["arm_pool"] =
    {
        getRows = function() return arm_pool_source end,
        getLanguages = function() return arm_pool_languages end,
        getSchema = function() return arm_pool_runtime_schema end,
        publish = function(rows,indexes,schema,languages)
            arm_pool_source = rows
            arm_pool_runtime_schema = schema or arm_pool_schema
            arm_pool_languages = languages or {}
            arm_pool = {}
            arm_pool_loaded = {}
            arm_pool_num = #rows
            arm_pool_armId = indexes["armId"] or {}
            arm_pool_armId_data = {}
            arm_pool_poolId = indexes["poolId"] or {}
            arm_pool_poolId_data = {}
        end,
    },
    ["act_pool"] =
    {
        getRows = function() return act_pool_source end,
        getLanguages = function() return act_pool_languages end,
        getSchema = function() return act_pool_runtime_schema end,
        publish = function(rows,indexes,schema,languages)
            act_pool_source = rows
            act_pool_runtime_schema = schema or act_pool_schema
            act_pool_languages = languages or {}
            act_pool = {}
            act_pool_loaded = {}
            act_pool_num = #rows
            act_pool_actId = indexes["actId"] or {}
            act_pool_actId_data = {}
            act_pool_poolId = indexes["poolId"] or {}
            act_pool_poolId_data = {}
        end,
    },
}

local function BuildIndexKey(row,fields)
    if #fields == 1 then return row[fields[1]] end
    local values = {}
    for index,fieldName in ipairs(fields) do
        values[index] = tostring(row[fieldName])
    end
    return table.concat(values,"_")
end

local function BuildIndexKeyFromValue(value,fields)
    if #fields == 1 then return value end
    if type(value) ~= "table" or #value ~= #fields then return nil end
    local values = {}
    for index = 1,#fields do values[index] = tostring(value[index]) end
    return table.concat(values,"_")
end

local function ValidateRowsTable(rows)
    if type(rows) ~= "table" then return false,"配置行集合需要 table" end
    local count = 0
    for key in pairs(rows) do
        if type(key) ~= "number" or key < 1 or key % 1 ~= 0 then
            return false,string.format("配置行集合包含无效数组键[%s]",tostring(key))
        end
        count = count + 1
    end
    for index = 1,count do
        if rows[index] == nil then return false,string.format("配置行集合存在空洞[%s]",index) end
    end
    return true
end

local function GetIndexRule(info,installKey)
    local indexKey = nil
    if type(installKey) == "string" then
        indexKey = installKey
    elseif type(installKey) == "table" then
        local valid,err = ValidateRowsTable(installKey)
        if not valid then return nil,err end
        local fields = {}
        for index,fieldName in ipairs(installKey) do
            if type(fieldName) ~= "string" then return nil,string.format("installKey第%s项需要 string",index) end
            fields[index] = fieldName
        end
        indexKey = table.concat(fields,",")
    else
        return nil,string.format("installKey需要 string 或有序字段数组，实际为 %s",type(installKey))
    end
    for _,rule in ipairs(info.indexes) do
        if rule.indexKey == indexKey then return rule end
    end
    return nil,string.format("installKey未匹配现有查询索引[%s]",tostring(indexKey))
end

function act_card_pool_def.GetSheetInfo(sheetName)
    return configSheets[sheetName]
end

function act_card_pool_def.CaptureState(sheetName)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    return { rows = runtime.getRows(), languages = runtime.getLanguages(), schema = runtime.getSchema() }
end

function act_card_pool_def.RestoreState(sheetName,state)
    local runtime = configSheetRuntimes[sheetName]
    if runtime == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    if type(state) ~= "table" or type(state.rows) ~= "table" or type(state.languages) ~= "table" or type(state.schema) ~= "table" then
        return false,"配置快照无效"
    end
    local indexes,indexErr = act_card_pool_def.BuildIndexes(sheetName,state.rows,true,state.schema)
    if indexes == nil then return false,indexErr end
    runtime.publish(state.rows,indexes,state.schema,state.languages)
    return true
end

function act_card_pool_def.ValidateRow(sheetName,row,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return false,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return false,schemaErr end
    return ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
end

function act_card_pool_def.BuildIndexes(sheetName,rows,allowUnknown,schemaOverride)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    local rowsValid,rowsErr = ValidateRowsTable(rows)
    if not rowsValid then return nil,rowsErr end
    local indexes = {}
    for _,rule in ipairs(info.indexes) do indexes[rule.indexKey] = {} end
    for index,row in ipairs(rows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",index,err) end
        for _,rule in ipairs(info.indexes) do
            local key = BuildIndexKey(row,rule.fields)
            local target = indexes[rule.indexKey]
            if rule.group then
                target[key] = target[key] or {}
                table.insert(target[key],index)
            else
                target[key] = index
            end
        end
    end
    return indexes
end

local function RemoveRowOwners(info,owners,row,rowIndex)
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local key = BuildIndexKey(row,rule.fields)
            local keyOwners = owners[rule.indexKey][key]
            if keyOwners ~= nil then
                for ownerIndex = #keyOwners,1,-1 do
                    if keyOwners[ownerIndex] == rowIndex then table.remove(keyOwners,ownerIndex) end
                end
                if #keyOwners == 0 then owners[rule.indexKey][key] = nil end
            end
        end
    end
end

local function ResolveNewRowConflicts(info,groupRule,rows,languages,newRowIndexes)
    local owners = {}
    local active = {}
    local isNew = {}
    local conflicts = {}
    for _,rowIndex in ipairs(newRowIndexes) do isNew[rowIndex] = true end
    for _,rule in ipairs(info.indexes) do if not rule.group then owners[rule.indexKey] = {} end end
    for rowIndex,row in ipairs(rows) do
        active[rowIndex] = true
        if not isNew[rowIndex] then
            for _,rule in ipairs(info.indexes) do
                if not rule.group then
                    local key = BuildIndexKey(row,rule.fields)
                    local keyOwners = owners[rule.indexKey][key] or {}
                    table.insert(keyOwners,rowIndex)
                    owners[rule.indexKey][key] = keyOwners
                end
            end
        end
    end
    for _,rowIndex in ipairs(newRowIndexes) do
        local row = rows[rowIndex]
        local removeIndexes = {}
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                local keyOwners = owners[rule.indexKey][key]
                if keyOwners ~= nil then
                    for _,oldIndex in ipairs(keyOwners) do
                        if active[oldIndex] then
                            removeIndexes[oldIndex] = true
                            table.insert(conflicts,{
                                indexKey = rule.indexKey,
                                key = key,
                                oldIndex = oldIndex,
                                newIndex = rowIndex,
                                oldGroupKey = BuildIndexKey(rows[oldIndex],groupRule.fields),
                                newGroupKey = BuildIndexKey(row,groupRule.fields),
                            })
                        end
                    end
                end
            end
        end
        for oldIndex in pairs(removeIndexes) do
            active[oldIndex] = false
            RemoveRowOwners(info,owners,rows[oldIndex],oldIndex)
        end
        for _,rule in ipairs(info.indexes) do
            if not rule.group then
                local key = BuildIndexKey(row,rule.fields)
                owners[rule.indexKey][key] = {rowIndex}
            end
        end
    end
    local result = {}
    local resultLanguages = {}
    for rowIndex,row in ipairs(rows) do
        if active[rowIndex] then
            table.insert(result,row)
            table.insert(resultLanguages,languages[rowIndex] or false)
        end
    end
    return result,resultLanguages,conflicts
end

local function CollectAppendConflicts(info,currentCount,rows)
    local conflicts = {}
    for _,rule in ipairs(info.indexes) do
        if not rule.group then
            local latest = {}
            for rowIndex,row in ipairs(rows) do
                local key = BuildIndexKey(row,rule.fields)
                local oldIndex = latest[key]
                if rowIndex > currentCount and oldIndex ~= nil then
                    table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=oldIndex,newIndex=rowIndex})
                end
                latest[key] = rowIndex
            end
        end
    end
    return conflicts
end

function act_card_pool_def.ApplyBatch(sheetName,batch,allowUnknown,schemaOverride,rowLanguage)
    local info = configSheets[sheetName]
    if info == nil then return nil,string.format("不存在配置 Sheet[%s]",tostring(sheetName)) end
    local runtime = configSheetRuntimes[sheetName]
    local schema,schemaErr = ConfigRowRuntime.MergeSchema(info.schema,schemaOverride)
    if schema == nil then return nil,schemaErr end
    if type(batch) ~= "table" then return nil,"配置批次需要 table" end
    for key in pairs(batch) do
        if key ~= "installKey" and key ~= "installValue" and key ~= "operation" and key ~= "rows" then
            return nil,string.format("配置批次包含未知字段[%s]",tostring(key))
        end
    end
    local newRows = batch.rows
    local rowsValid,rowsErr = ValidateRowsTable(newRows)
    if not rowsValid then return nil,rowsErr end
    for rowIndex,row in ipairs(newRows) do
        local valid,err = ConfigRowRuntime.Validate(row,schema,allowUnknown == true)
        if not valid then return nil,string.format("第%s行校验失败: %s",rowIndex,err) end
    end
    local warnings = {}
    if #newRows == 0 and batch.installKey == nil then
        return { operation = "append", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} }
    end
    local currentRows = runtime.getRows()
    local currentLanguages = runtime.getLanguages()
    local candidateRows = {}
    local candidateLanguages = {}
    local newRowIndexes = {}
    if batch.installKey == nil then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"无 installKey 批次不能声明 installValue/operation" end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
        end
        local indexes,indexErr = act_card_pool_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        local conflicts = CollectAppendConflicts(info,#currentRows,candidateRows)
        if #conflicts > 0 then table.insert(warnings,string.format("无 installKey 追加产生 %s 个普通查询键冲突；后写结果生效",#conflicts)) end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "append", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    local rule,ruleErr = GetIndexRule(info,batch.installKey)
    if rule == nil then return nil,ruleErr end
    if not rule.group then
        if batch.installValue ~= nil or batch.operation ~= nil then return nil,"普通 upsert 不能声明 installValue/operation" end
        if #newRows == 0 then return { operation = "upsert", rows = runtime.getRows(), warnings = {"空批次未修改配置"}, conflicts = {} } end
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        local conflicts = {}
        for _,newRow in ipairs(newRows) do
            local key = BuildIndexKey(newRow,rule.fields)
            local matched = {}
            for rowIndex,oldRow in ipairs(candidateRows) do
                if BuildIndexKey(oldRow,rule.fields) == key then table.insert(matched,rowIndex) end
            end
            if #matched > 1 then return nil,string.format("安装身份歧义[index:%s][key:%s][rows:%s]",rule.indexKey,tostring(key),table.concat(matched,",")) end
            if #matched == 1 then
                table.insert(conflicts,{indexKey=rule.indexKey,key=key,oldIndex=matched[1],newIndex=matched[1]})
                candidateRows[matched[1]] = newRow
                candidateLanguages[matched[1]] = rowLanguage or false
            else
                table.insert(candidateRows,newRow)
                table.insert(candidateLanguages,rowLanguage or false)
            end
        end
        local indexes,indexErr = act_card_pool_def.BuildIndexes(sheetName,candidateRows,allowUnknown,schemaOverride)
        if indexes == nil then return nil,indexErr end
        runtime.publish(candidateRows,indexes,schema,candidateLanguages)
        return { operation = "upsert", rows = candidateRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
    end
    if batch.installValue == nil then return nil,"组批次缺少 installValue" end
    local groupKey = BuildIndexKeyFromValue(batch.installValue,rule.fields)
    if groupKey == nil then return nil,"installValue 与组查询字段不匹配" end
    local operation = batch.operation or "replace"
    if operation ~= "replace" and operation ~= "append" then return nil,string.format("无效组操作[%s]",tostring(operation)) end
    for rowIndex,row in ipairs(newRows) do
        local rowGroupKey = BuildIndexKey(row,rule.fields)
        if rowGroupKey ~= groupKey then return nil,string.format("组键不一致[目标:%s][第%s行:%s]",tostring(groupKey),rowIndex,tostring(rowGroupKey)) end
    end
    if operation == "append" and #newRows == 0 then return { operation = operation, groupKey = groupKey, rows = runtime.getRows(), warnings = {"空组 append 未修改配置"}, conflicts = {} } end
    local firstGroupIndex = nil
    local oldGroupCount = 0
    if operation == "replace" then
        for rowIndex,row in ipairs(currentRows) do
            if BuildIndexKey(row,rule.fields) == groupKey then
                oldGroupCount = oldGroupCount + 1
                if firstGroupIndex == nil then firstGroupIndex = #candidateRows + 1 end
            else
                table.insert(candidateRows,row)
                table.insert(candidateLanguages,currentLanguages[rowIndex] or false)
            end
        end
        local insertIndex = firstGroupIndex or (#candidateRows + 1)
        for offset,row in ipairs(newRows) do
            table.insert(candidateRows,insertIndex + offset - 1,row)
            table.insert(candidateLanguages,insertIndex + offset - 1,rowLanguage or false)
        end
        for offset = 1,#newRows do table.insert(newRowIndexes,insertIndex + offset - 1) end
    else
        for index,row in ipairs(currentRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,currentLanguages[index] or false)
        end
        for _,row in ipairs(newRows) do
            table.insert(candidateRows,row)
            table.insert(candidateLanguages,rowLanguage or false)
            table.insert(newRowIndexes,#candidateRows)
        end
    end
    if operation == "replace" and oldGroupCount == 0 and #newRows == 0 then table.insert(warnings,"清空不存在的组未修改配置") end
    local resultRows,resultLanguages,conflicts = ResolveNewRowConflicts(info,rule,candidateRows,candidateLanguages,newRowIndexes)
    local indexes,indexErr = act_card_pool_def.BuildIndexes(sheetName,resultRows,allowUnknown,schemaOverride)
    if indexes == nil then return nil,indexErr end
    runtime.publish(resultRows,indexes,schema,resultLanguages)
    return { operation = operation, groupKey = groupKey, rows = resultRows, indexes = indexes, warnings = warnings, conflicts = conflicts }
end

local sheetFunc = 
{
    ["base_pool"] = 
    {
        ["index"] = "base_pool_index",
        ["@num"] = "base_pool_num",
        ["@set"] = "base_pool_set",
        ["baseId"] = "base_pool_baseId",
        ["poolId"] = "base_pool_poolId",
    },

    ["arm_pool"] = 
    {
        ["index"] = "arm_pool_index",
        ["@num"] = "arm_pool_num",
        ["@set"] = "arm_pool_set",
        ["armId"] = "arm_pool_armId",
        ["poolId"] = "arm_pool_poolId",
    },

    ["act_pool"] = 
    {
        ["index"] = "act_pool_index",
        ["@num"] = "act_pool_num",
        ["@set"] = "act_pool_set",
        ["actId"] = "act_pool_actId",
        ["poolId"] = "act_pool_poolId",
    },
}

function act_card_pool_def.Get(sheetName,keyIndex,key)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return nil,1 end
    local funName = funcIndexs[keyIndex]
    if not funName then return nil,2 end
    return act_card_pool_def[funName](key),nil
end

function act_card_pool_def.Set(sheetName,index,data)
    if index == nil then return false end
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return false end
    local funName = funcIndexs["@set"]
    act_card_pool_def[funName](index,data)
    return true
end

function act_card_pool_def.GetNum(sheetName)
    local funcIndexs = sheetFunc[sheetName]
    if not funcIndexs then return 0 end
    local funName = funcIndexs["@num"]
    return act_card_pool_def[funName]()
end

return act_card_pool_def