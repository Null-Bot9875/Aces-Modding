GameManager = SingleClass("GameManager")

function GameManager:__Init()
end

function GameManager:__Delete()

end

function GameManager:InitClass()
    if Language.Instance == nil then
        Language.New()
    end

    DevicesFpsManager.New()
    DevicesManager.New()

    DashboardManager.New()

    BitUtils.Init()
    EventManager.New()

    Network.InitGpbParser()
    self:InitNetwork()

    
    TouchManager.New()
    ViewStackManager.New()
    PoolManager.New()
    ViewManager.New()
    TimerManager.New()
    PreloadManager.New()
    ShaderManager.New()
    AudioManager.New()
    AnimManager.New()

    SdkManager.New()
    
    HotReload.New()
end

function GameManager:InitNetwork()
    local connType = nil
    if KvData.platform == KvData.PlatformType.WebGLPlayer then
        connType = NetworkDefine.ConnType.web
    else
        connType = NetworkDefine.ConnType.tcp
    end
    Network.Instance = Network.New(connType)
    Network.Instance:SetTick(2101,30,10)

    TimerManager.Instance = TimerManager.New()
end

function GameManager:ModuleSetup()
    for k,_ in pairs(ModuleMapping) do
        local facadeClass = GetClass(k)
        if facadeClass then
            local _ = facadeClass.New(facadeClass)
        else
            LogErrorf("无法找到模块入口[%s]",k)
        end
    end
    Facade.InitComplete()
end

function GameManager:Start()
    self:InitClass()

    self:InitSDK()
    self:ModuleSetup()

    DOTween.useSmoothDeltaTime = true

    EventManager.Instance:AddEvent(EventDefine.delay_preload_complete,self:ToFunc("DelayPreloadComplete"))

    -- AnimSoundHandler.SetSoundFunc(AudioManager.Instance,"OnPlayEffectAnim")
    AnimButton.SetSoundFunc(AudioManager.Instance,"OnPlayButtonClick")
    TransitionButton.SetSoundFunc(AudioManager.Instance,"OnPlayButtonClick")
    EffectButton.SetSoundFunc(AudioManager.Instance,"OnPlayButtonClick")
    AEEffectBehaviour.SetAnimEffectFunc(AnimManager.Instance,"OnEffectPlay")
    AEDelayChildPlayAnimBehaviour.SetAnimPlayFunc(AnimManager.Instance,"OnDelayAnimPlay")
    GaussianBlur.mainCamera = KvData.mainCamera
    GaussianBlur.SetEnable(true)
    -- 所有按钮的脚本，用于防止短期多次点击
    -- 注：这个操作和双击有冲突
    ClickCooldownButton.isEnabled = false
    ClickCooldownButton.cooldownSeconds = 0.1

    PreloadManager.Instance:SetComplete(self:ToFunc("OnPreloadComplete"))
    PreloadManager.Instance:Load()
end

function GameManager:OnPreloadComplete()
    local tex = PreloadManager.Instance:GetAsset(AssetPath.cursor)
    -- local tex = Resources.Load("cursor/1", typeof(Texture2D))
    Cursor.SetCursor(tex, Vector2.zero, CursorMode.Auto)

    -- 显示ui + default层
    local cullingMask = 0
    cullingMask = KvData.Layer.default
    cullingMask = cullingMask + BitUtils.LShift(1, KvData.Layer.ui)
    mod.MixedCtrl:SetUICameraCullingMask(cullingMask, "初始化UI相机")

    TimerManager.Instance:AddTimerByNextFrame(1,0,self:ToFunc("EnterComplete"))
end

function GameManager:DelayPreloadComplete()
    if KvData.platform == KvData.PlatformType.WebGLPlayer then
        LuaManager.Instance.luaUpdater:CheckoutFullLuaZip()
    end
end

function GameManager:EnterComplete()
    if KvData.jit then
        collectgarbage("setpause", 120)
        collectgarbage("setstepmul", 2000)
        if jit.opt then      
            jit.opt.start(3)                
        end
        jit.off()
    else
        collectgarbage("generational")
    end

    EventManager.Instance:SendEvent(EventDefine.preload_complete)
    StartWindow.Instance:CloseWindow()
    ViewManager.Instance:OpenWindow(LoginWindow)
end

function GameManager:Update()
    if not ACTIVE_MAIN_LOOP then
        return
    end
    local deltaTime = Time.deltaTime
    KvData.frameCount = Time.frameCount

    Network.Instance:Update()
	TimerManager.Instance:Update(deltaTime)
    TouchManager.Instance:Update(deltaTime)
    ViewStackManager.Instance:Update(deltaTime)


    DevicesFpsManager.Instance:Update()

    mod.BattleTickCtrl:Update(deltaTime)
    mod.MainuiCtrl:Update(deltaTime)
    mod.RoomCtrl:Update(deltaTime)
    -- mod.PveCtrl:Update(deltaTime)
    mod.GmCtrl:Update(deltaTime)
    mod.BattleFunCtrl:Update(deltaTime)
    mod.HotkeysCtrl:Update(deltaTime)

    mod.GuideCtrl:Update(deltaTime)
    mod.DialogueCtrl:Update(deltaTime)
end

function GameManager:LateUpdate()
    if not ACTIVE_MAIN_LOOP then
        return
    end
    local deltaTime = Time.deltaTime
    mod.BattleTickCtrl:LateUpdate(deltaTime)
end

function GameManager:InitSDK()
     --if BaseSetting.channel == "release" then
     --    BuglyAgent.ConfigDebugMode(true)
     --else
     --    --开启SDK的日志打印，发布版本请务必关闭
     --    BuglyAgent.ConfigDebugMode(false)
     --end

    -- if IS_DEBUG then
    --     local pocoObj = GameObject("Poco")
    --     pocoObj:AddComponent(PocoManager)
    --     GameObject.DontDestroyOnLoad(pocoObj)
    --     Log("初始化了Poco")
    -- end
end

--只有退出到登录的逻辑，切勿加入各平台sdk判定
function GameManager:ExitLogin()
    if not mod.LoginProxy:IsLogin() then
        Network.Instance:Disconnect()
        return
    end

    mod.LoginProxy:SetLogin(false)

    EventManager.Instance:Clean()
    TouchManager.Instance:Clean()
    ViewStackManager.Instance:Clean()
    AudioManager.Instance:Clean()

    ViewManager.Instance:CleanAllWindow()

    Network.Instance:Delete()
    self:InitNetwork()
    

    Facade.CleanModules()

    PoolManager.Instance:Clean()

    BaseCardItem.ClearDeferredRefreshState()


    if IS_EDITOR then
        for view,traceback in pairs(BaseView.debugViews) do
            Logf("退出登录,view未清理[%s][%s][创建堆栈:%s]",view.__className,tostring(view),traceback)
        end
    end

    self:ModuleSetup()

    ViewManager.Instance:OpenWindow(LoginWindow)

    EventManager.Instance:SendEvent(EventDefine.preload_complete)
    if PreloadManager.Instance:IsDelayLoaded() then
        EventManager.Instance:SendEvent(EventDefine.delay_preload_complete)
    end

    Cursor.visible = true
    Cursor.lockState = CursorLockMode.None
end


function GameManager:OnApplicationFocus(flag)
    EventManager.Instance:SendEvent(EventDefine.on_app_focus,flag)
end

function GameManager:OnApplicationQuit()
    Network.Instance:Close()
    mod.MixedCtrl:UploadTencentCOS()
end
