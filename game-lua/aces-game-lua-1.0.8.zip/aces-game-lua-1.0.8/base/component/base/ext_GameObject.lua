local base = xlua.getmetatable(GameObject)
local __baseindex = base.__index
local __extends = {}

--扩展

local typeCache = {}
function __extends.AddComponent(self,component)
	if not typeCache[component] then
		typeCache[component] = typeof(component)
	end
	return CustomUnityUtils.AddComponent(self,typeCache[component])
end

function __extends.GetComponent(self,component)
	if not typeCache[component] then
		typeCache[component] = typeof(component)
	end
	return CustomUnityUtils.GetComponent(self,typeCache[component])
end

function __extends.GetComponentInChildren(self,component)
	if not typeCache[component] then
		typeCache[component] = typeof(component)
	end
	return CustomUnityUtils.GetComponentInChildren(self,typeCache[component])
end


function __extends.GetComponentsInChildren(self,component,includeInactive)
	if not typeCache[component] then
		typeCache[component] = typeof(component)
	end
	return CustomUnityUtils.GetComponentsInChildren(self,typeCache[component],includeInactive or false)
end


-- function __extends.SetActive(self,active)
-- 	UnityUtils.SetActive(gameObject,active)
-- end

--
base.__index = function(t,k)
	if __extends[k] then
		return __extends[k]
	else
		return __baseindex(t,k)
	end
end
xlua.setmetatable(GameObject, base)