-- 扩展Unity Dropdown class 方法
local base = xlua.getmetatable(Dropdown)
local __baseindex = base.__index
local __extends = {}

function __extends.SetClick(self, cb, arg1,arg2,arg3)
	self.onValueChanged:RemoveAllListeners()
    if IS_EDITOR then
        LuaUtils.DropdownListener(self.onValueChanged,function(index) cb(index,arg1,arg2,arg3) end)
    else
        self.onValueChanged:AddListener(function(index) cb(index,arg1,arg2,arg3) end)
    end
end

base.__index = function(t,k)
	if __extends[k] then
		return __extends[k]
	else
		return __baseindex(t,k)
	end
end
xlua.setmetatable(Dropdown, base)