-- 扩展Unity TMP_Dropdown class 方法
local base = xlua.getmetatable(TMP_Dropdown)
local __baseindex = base.__index
local __extends = {}

function __extends.SetClick(self, cb, arg1,arg2,arg3)
	self.onValueChanged:RemoveAllListeners()
	self.onValueChanged:AddListener(function(index) cb(index,arg1,arg2,arg3) end)
end

function __extends.SetOptions(self, options)
	self:ClearOptions()
	local csOptions = CS.System.Collections.Generic.List(CS.System.String)()
	for _, v in ipairs(options) do
        csOptions:Add(tostring(v))
    end
	self:AddOptions(csOptions)
end

base.__index = function(t,k)
	if __extends[k] then
		return __extends[k]
	else
		return __baseindex(t,k)
	end
end
xlua.setmetatable(TMP_Dropdown, base)