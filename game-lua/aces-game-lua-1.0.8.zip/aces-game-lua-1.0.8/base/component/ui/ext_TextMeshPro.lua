local base = xlua.getmetatable(TextMeshProUGUI)
local __baseindex = base.__index
local __extends = {}

--扩展
function __extends.SetColor(self,r, g, b, a)
    UnityUtils.SetTextColor(self,r,g,b,a)
end

--
base.__index = function(t,k)
	if __extends[k] then
		return __extends[k]
	else
		return __baseindex(t,k)
	end
end
xlua.setmetatable(TextMeshProUGUI, base)
