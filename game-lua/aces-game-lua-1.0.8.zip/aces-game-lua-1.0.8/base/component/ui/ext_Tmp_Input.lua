local base = xlua.getmetatable(TMP_InputField)
local __baseindex = base.__index
local __extends = {}

--扩展
function __extends.SetSubmit(self,cb,arg1,arg2,arg3)
	self.onSubmit:RemoveAllListeners()
    self.onSubmit:AddListener(function(flag) cb(flag,arg1,arg2,arg3) end)
end

function __extends.SetEndEdit(self,cb,arg1,arg2,arg3)
	self.onEndEdit:RemoveAllListeners()
    self.onEndEdit:AddListener(function(flag) cb(flag,arg1,arg2,arg3) end)
end

function __extends.SetValueChanged(self, cb, args1,args2,args3)
	self.onValueChanged:RemoveAllListeners()
    self.onValueChanged:AddListener(function(flag) cb(flag,args1,args2,args3) end)
end
--
base.__index = function(t,k)
	if __extends[k] then
		return __extends[k]
	else
		return __baseindex(t,k)
	end
end
xlua.setmetatable(TMP_InputField, base)
