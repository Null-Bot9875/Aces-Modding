require "base/csharp_types"

require "utils/log"
require "mapping"

function DataReadOnly(data)
    for k,arg in pairs(data) do
        if type(arg) == "table" then
            DataReadOnly(arg)
            TableUtils.FieldReadOnly(arg)
        end
    end
end

-----------------------------------------------------------------------------
local parentG = {}
local __ClassLoaded = {}
local __CSTypes = {}
local __activeCS = true 
setmetatable(_G, parentG)
parentG.__index = function(t, k)
    local requireName = ClassToFile[k]
    if requireName and not __ClassLoaded[requireName] then
        __ClassLoaded[requireName] = true
        if require (ClassToFile[k]) then
            if IS_EDITOR and type(_G[k]) == "table" and _G[k].isStaticClass then
                DataReadOnly(_G[k])
                _G[k] = TableUtils.ReadOnly(_G[k])
            end
            return _G[k]
        else
            return false
        end
	else
		local csType = GetCSharp(k)
        if csType and __activeCS then
            _G[k] = csType
			__CSTypes[k] = csType
            return csType
        end
    end
end

-- 资源加载基础定义集中在启动层初始化，业务模块不再依赖隐式加载顺序。
require "common/asset_loader/AssetLoaderDefine"
require "common/asset_loader/AssetPath"

-- 玩家输入只能通过 GameInput 读取，控制台和回放共用同一门禁。
GameInput = require "common/touch/GameInput"

-- Config = Config or {}
-- local dataG = {}
-- local __Dataoaded = {}
-- setmetatable(Config, dataG)
-- dataG.__index = function(t, k)
--     local requireName = DataToFile[k]
--     if requireName and not __Dataoaded[requireName] then
--         __Dataoaded[requireName] = true
--         if require (DataToFile[k]) then
-- 			Config[k] = _G[k]
-- 			return Config[k]
--         else
--             return false
--         end
--     end
-- end

function RequireData(dataName)
	local requirePath = DataToFile[dataName]
	if not requirePath then return nil end
	if loadFiles[requirePath] then return loadFiles[requirePath] end
	local requireFile = require(requirePath)
    if not requireFile then return nil end
    loadFiles[requirePath] = requireFile
    return requireFile
end

function ActiveCSType(flag)
	__activeCS = flag
	for k,v in pairs(__CSTypes) do
		if flag then
			_G[k] = v
		else
			_G[k] = nil
			package.loaded[k] = nil
		end
	end
end

function GetClass(className)
	return _G[className]
end
-----------------------------------------------------------------------------


-- function TI18N(key,...)
--     local conf = Config.Get("text","tips","key",key)
--     if not conf then
--         LogErrorf("文本提示不存在对应Key值[%s]",key)
--         return key
--     end
--     if conf.isFormat then
--         return string.format(conf.text,...)
--     else
--         return conf.text
--     end
-- end

require "common/language/Language"

--require "base/component/ext_Component"
require "base/component/base/ext_Transform"
require "base/component/base/ext_GameObject"

require "base/component/ui/ext_Button"
require "base/component/ui/ext_Dropdown"
require "base/component/ui/ext_EventTrigger"
require "base/component/ui/ext_Image"
require "base/component/ui/ext_InputField"
require "base/component/ui/ext_RectTransform"
require "base/component/ui/ext_ScrollRect"
require "base/component/ui/ext_Slider"
require "base/component/ui/ext_Text"
require "base/component/ui/ext_TextMeshPro"
require "base/component/ui/ext_Tmp_Input"
require "base/component/ui/ext_Toggle"

require "base/component/ui/ext_TMPDropdown"

-- if CS.UnityEngine.Application.platform ~= CS.UnityEngine.RuntimePlatform.WebGLPlayer then
-- 	require "base/component/math/ext_Mathf"
-- 	require "base/component/math/ext_Vector2"
-- 	require "base/component/math/ext_Vector3"
-- 	require "base/component/math/ext_Vector4"
-- 	require "base/component/math/ext_Quaternion"
-- 	require "base/component/math/ext_Color"
-- 	require "base/component/math/ext_Ray"
-- 	require "base/component/math/ext_Bounds"
-- end


require "common/fixpoint/InitFixPoint"

--Socket = require "tolua/socket”
CJson = require "cjson"
ModRuntime = require "common/mod/ModRuntime"
---------------------------------------------------------------------------------------


-- if CS.UnityEngine.Application.platform == CS.UnityEngine.RuntimePlatform.WebGLPlayer then
-- 	local _ = _G["AssetPath"]
-- 	for k,v in pairs(ClassToFile) do
-- 		local _ = _G[k]
-- 	end

-- 	for k,v in pairs(DataToFile) do
-- 		local _ = Config[k]
-- 	end
-- end
