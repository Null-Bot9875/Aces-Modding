require "utils/DeleteCleanup"
local DeleteCleanup = _G.DeleteCleanup

BaseView = BaseClass("BaseView",BaseModule)
BaseView.debugViews = {}
BaseView.debugEvents = {}
BaseView.views = {}

BaseView.__transitionType = KvData.TransitionType.none

function BaseView:__Init()
    BaseView.views[self] = true

    self.__isCreate = true
    self.__canShow = true
    self.__firstShow = true

    self.gameObject = nil
    self.active = false
    self.viewType = nil
    self.assetList = {}
    self.assetScope = nil
    self.isDelete = false
    self.assetPath = nil
    self.iconLoaders = {}
    self.refreshParent = false
    self.extendViewList = {}
    self.animEffectListeners = nil
    self.animDelayPlayListeners = nil
    self.enableName = true
    self.effectInfos = {}
    self.timers = {}
    self:SuperFunc("__ExtendView",true)
    self:SuperFunc("__BindBeforeEvent",true)
    self:ExecuteExtendFun("__BindBeforeEvent",true)
    if IS_EDITOR then
        BaseView.debugViews[self] = debug.traceback()
        self.debug = BaseView.debugViews[self]
    end

    self.__fadeInDuration = 0.2
    self.__fadeOutDuration = 0.2
    self.transitionSeq = nil
    self.showCanvas = false

    self.nodeOrderOffset = {}
end

function BaseView:__Delete()
    if BaseView.views[self] then
        BaseView.views[self] = nil
    end
    
    --最后一步，开始删除预设了
    if not self.isDelete then LogError("base_view对象禁止直接调用Delete方法! ==> 改用(Destroy)") return end

    self:PushPool()
  
    if not BaseUtils.IsNull(self.gameObject) then
        if self.transform then
            self.transform:DOKill(true)
        end
        GameObject.Destroy(self.gameObject)
    end

    for img,_ in pairs(self.iconLoaders) do
        self:RemoveSprite(img)
    end

    self:RemoveAllEffect()

    AnimManager.Instance:RemoveEffectListener(self:GetInstanceId())

    for k,v in pairs(self.timers) do
        self:RemoveTimer(k)
    end

    self:RemoveAssetLoader()
    self:RemoveBeforeEvent()
    self.gameObject = nil

    self:CancelDebugDestroy()
    self:RemoveShowStopwatch()

    self:RemoveTransition()
    if IS_EDITOR then
        BaseView.debugViews[self] = nil
    end

    self.showCanvas = false
    
    -- Clear Lua-held managed shells on delete so leaked modules/views do not keep Unity objects alive.
    DeleteCleanup.ClearObjectReferences(self)
end

function BaseView:RemoveTransition()
    if self.transitionSeq then
        self.transitionSeq:Kill()
        self.transitionSeq = nil
    end
end

function BaseView:DebugDestroy()
    if IS_EDITOR then
        self.debugTimer = TimerManager.Instance:AddTimer(0,3,self:ToFunc("CheckDebug")) 
    end
end

function BaseView:CheckDebug()
    if BaseUtils.IsNull(self.gameObject) then
        LogErrorf("BaseView被异常删除[%s][创建堆栈:\n%s]",tostring(self.__className),self.debug)
    end
end

function BaseView:SetEnableName(flag)
    self.enableName = flag
end

---添加定时器
function BaseView:AddTimer(key,count,time,func)
    if self.timers[key] then
        assert(false,string.format("添加定时器失败,已存在相同key的定时器[key:%s]",tostring(key)))
    end
    self.timers[key] = TimerManager.Instance:AddTimer(count,time,func)
    self.timers[key]:SetComplete(self:ToFunc("OnTimerComplete"),key)
    return self.timers[key]
end

---添加唯一定时器, 同时只会存在一个同名定时器
---@param useOld boolean 使用现有定时器还是重新创建
function BaseView:AddUniqueTimer(key,count,time,func,useOld)
    if useOld and self.timers[key] then
        return self.timers[key]
    end
    self:RemoveTimer(key)
    return self:AddTimer(key,count,time,func)
end

function BaseView:OnTimerComplete(args,id)
    self:RemoveTimer(args)
end

function BaseView:RemoveTimer(key)
    if self.timers[key] then
        TimerManager.Instance:RemoveTimer(self.timers[key])
        self.timers[key] = nil
    end
end

function BaseView:HasTimer(key)
    return self.timers[key] ~= nil
end

function BaseView:CancelDebugDestroy()
    if self.debugTimer then
        TimerManager.Instance:RemoveTimer(self.debugTimer)
        self.debugTimer = nil
    end
end

function BaseView:Destroy()
    if self.isDelete then return end
    self.isDelete = true

    self:HideCommonHandle()
    self:RemoveLastingEvent()

    self:DeleteHandle()
end

function BaseView:DeleteHandle()
    for _,view in ipairs(self.extendViewList) do
        view:Delete()
    end
    self:Delete()
end

function BaseView:HideHandle()
    self:HideCommonHandle()
    self:SetActive(self.gameObject, false)
    self:RemoveAllEffect()
end

function BaseView:HideCommonHandle()
    if not self.active then return end
    self.__firstShow = true
    self.active = false
    self:RemoveEvent()
    self:SuperFunc("__Hide",false)
    self:ExecuteExtendFun("__Hide",false)

    EventManager.Instance:SendEvent(EventDefine.close_view,self.__className,self.viewType,self.transform)
    mod.GuideEventCtrl:Trigger(GuideDefine.Event.close_view,self.__className,self.viewType,self.transform)
end

function BaseView:SetObject(gameObject)
    self.gameObject = gameObject
    self:InitObject()
end

function BaseView:SetParent(parent,x,y,z)
    self.refreshParent = true
    self.parent = parent
    self.x = x
    self.y = y
    self.z = z
    if self:IsValid() then self:RefreshParent() end
end

function BaseView:RefreshParent()
    if not self.refreshParent then 
        return 
    end
    self.refreshParent = false

    if self.parent and BaseUtils.IsNull(self.parent) then
        LogErrorf("BaseView设置的父节点已经被删除了,但是没有调用(Hide、Destroy)函数[%s]",tostring(self.__className))
        return
    end

    self.transform:SetParent(self.parent,false)
    self.transform:SetAnchoredPosition3D(self.x or 0,self.y or 0,self.z or 0)
end

function BaseView:Show(args)
    if not args then
        args = {}
    end
    
    self.args = args
    if not self.__canShow then 
        self.__canShow = true 
    end

    self.showStopwatch = CS.System.Diagnostics.Stopwatch()
    self.showStopwatch:Start()
    if not self:ShowObject() then
        self:LoadAsset() 
    else
        EventManager.Instance:SendEvent(EventDefine.asset_loaded, self.__className)
    end
end

function BaseView:Hide()
    self:RemoveShowStopwatch()
    self:__BaseHide()

    if self:LoadAsseting() then 
        self.__canShow = false
        return
    end

    if not self.active then
        return
    end

    -- 使用实例的转场类型（会通过原型链找到子类定义的值）
    self:ExecuteTransitionOut(self.__transitionType, self:ToFunc("CloseComplete"))
end

function BaseView:CloseComplete()
    self:HideHandle()
end

function BaseView:RemoveShowStopwatch()
    if self.showStopwatch then
        self.showStopwatch:Stop()
        self.showStopwatch = nil
    end
end

function BaseView:ShowObject()
    if BaseUtils.IsNull(self.gameObject) or not TableUtils.IsEmpty(self.assetList) then 
        return false 
    end

    self:FirstCreate()
    if not self.__canShow then
        self.__canShow = true
        self:SetActive(self.gameObject, false)
        return false
    end

    local isFirstShow = self.__firstShow

    self:RepeatShow()
    self:FirstShow()

    if self.showStopwatch then
        self.showStopwatch:Stop()
        local runTime = self.showStopwatch.Elapsed.TotalMilliseconds
        self.showStopwatch = nil
        DashboardManager.Instance:Call(DashboardDefine.DashboardType.ui, "AddUIShowTime", self.__className, runTime)
    end

    if isFirstShow then
        -- 使用实例的转场类型（会通过原型链找到子类定义的值）
        self:ExecuteTransitionIn(self.__transitionType, self:ToFunc("ShowComplete"))
    end

    return true
end

-- 显示完成，触发回调
function BaseView:ShowComplete()
    self:__ShowComplete()
    EventManager.Instance:SendEvent(EventDefine.open_view, self.__className, self.viewType, self.transform)
    mod.GuideEventCtrl:Trigger(GuideDefine.Event.open_view, self.__className, self.viewType, self.transform, self.args)
end

function BaseView:FirstCreate()
    if not self.__isCreate then
        return 
    end
    self.__isCreate = false
    self:RefreshParent()
    self:CreateAction(self)

    self:DebugDestroy()
end

function BaseView:CreateAction(view)
    view:__BaseCreate()
    self:SuperFunc("__CacheObject",true)
    self:ExecuteExtendFun("__CacheObject",true)
    self:SuperFunc("__Create",true)
    self:ExecuteExtendFun("__Create",true)
    self:SuperFunc("__BindListener",true)
    self:ExecuteExtendFun("__BindListener",true)
    self:SuperFunc("__BindLastingEvent",true)
    self:ExecuteExtendFun("__BindLastingEvent",true)
end

function BaseView:IsActive()
    return self.active
end

function BaseView:PushPool()
    if self.poolKey and self:IsValid() then
        self:OnPushPool()
        PoolManager.Instance:Push(PoolType.object,self.poolKey,self.gameObject)
        self.gameObject = nil
    end
end

function BaseView:TablePushPool(table)
    if self[table] then
        for k, v in pairs(self[table]) do
            v:PushPool()
        end
    end
end

function BaseView:FirstShow()
    if not self.__firstShow then 
        return
    end
    self.__firstShow = false
    self:RefreshParent()
    self.active = true
    self:SetActive(self.gameObject, true)
    self:firstShowAction(self)
end

function BaseView:firstShowAction(view)
    view:__BaseShow()
    self:SuperFunc("__BindEvent",true)
    self:ExecuteExtendFun("__BindEvent",true)
    self:SuperFunc("__Show",true)
    self:ExecuteExtendFun("__Show",true)
    self:SuperFunc("__LastShow",true)
end

function BaseView:RepeatShow()
    if self.__firstShow then 
        return 
    end
    self:SuperFunc("__RepeatShow",true)
    self:ExecuteExtendFun("__RepeatShow",true)
end

function BaseView:LoadAsset()
    if self:LoadAsseting() then 
        return 
    end
    
    if not self.assetPath and not self.gameObject then
        assert(false, "UI资源路径为空,请调用SetAsset接口设置")
    elseif self.assetPath then
        table.insert(self.assetList,{file = self.assetPath, type = AssetType.Prefab})
    end

    if not self.assetList or #self.assetList<=0 then 
        self:AssetLoaded()
    else
        self.assetScope = AssetScope()
        self.assetLoader = AssetBatchLoader.New(self.assetScope)
        self.assetLoader:Load(self.assetList,self:ToFunc("AssetLoaded"))
    end
end

function BaseView:AssetLoaded()
    self.assetList = nil
    self.gameObject = self.gameObject or self.assetLoader:Instantiate(self.assetPath)
    if BaseUtils.IsNull(self.gameObject) then
        LogErrorf("BaseView资源加载失败[class:%s][file:%s]",tostring(self.__className),tostring(self.assetPath))
        self:RemoveAssetLoader()
        return
    end

    if self.assetScope then
        local scopeComponent = self.gameObject:AddComponent(AssetScopeComponent)
        scopeComponent:Adopt(self.assetScope)
        self.assetScope = nil
    end
    self:InitObject()
    self:InitAnim()

    self:ShowObject()
    self:RemoveAssetLoader()

    EventManager.Instance:SendEvent(EventDefine.asset_loaded, self.__className)
end

function BaseView:InitAnim()
    if self.animator and self.animFile then
        self.animator.runtimeAnimatorController = self:GetAsset(self.animFile)
    end
end

function BaseView:InitObject()
    if self.enableName then self.gameObject.name = self.__className end
    
    self.instanceId = self.gameObject:GetInstanceID()
    self.transform = self.gameObject.transform
    self.rectTrans = self.gameObject:GetComponent(RectTransform)
    self.animator = self.gameObject:GetComponent(Animator)
    if self.animator then
        self.animator.keepAnimatorStateOnDisable = true
    end
    self.rootCanvas = self.gameObject:GetComponent(Canvas)
    self.canvasGroup = self.gameObject:GetComponent(CanvasGroup)

    if self.showCanvas then
        self.rootCanvas.enabled = true
    end

    if self.sortingOrder then
        self:SetOrder(self.sortingOrder)
    end
end

function BaseView:SetAnim(animFile,anim)
    if self.animator and anim then
        self.animator.runtimeAnimatorController = anim
    end
end

function BaseView:GetInstanceId()
    return self.instanceId
end

function BaseView:PlayAnim(animName,layer,callback,args)
    if self.animator then
        self.animator:Play(animName,layer or -1,0)
        if callback then
            local time = BaseUtils.GetAnimatorClipTime(self.animator,animName)
            local timer = self:AddUniqueTimer("PlayAnim_"..animName,1,time,callback,false)
            if args then
                timer:SetArgs(args)
            end
        end
    end
end


function BaseView:GetAsset(file)
    if self.assetLoader then
        return self.assetLoader:GetAsset(file)
    end
end

function BaseView:RemoveAssetLoader()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function BaseView:SetViewType(viewType)
    self.viewType = viewType
end

function BaseView:SetAsset(file)
    if self.assetPath then
        assert(false, "禁止多次设置UI资源路径")
    end
    
    self.assetPath = file
    self.assetName =  IOUtils.GetFileName(file)
end

function BaseView:AddAsset(file,assetType)
    table.insert(self.assetList,{file = file, type = assetType})
end

function BaseView:SetAnimAsset(animFile)
    self.animFile = animFile
    self:AddAsset(self.animFile,AssetType.Object)
end

function BaseView:Find(path,component,transform)
    if not transform then transform = self.transform end
    if path then transform = transform:Find(path) end
    if not transform then return nil end
    return component and transform.gameObject:GetComponent(component) or transform
end

function BaseView:SetSprite(image,path,nativeSize,callBack)
    local iconLoader = self.iconLoaders[image] or IconLoader.Create()
    self.iconLoaders[image] = iconLoader
    iconLoader:LoadIcon(image,path,nativeSize,callBack)
end

function BaseView:RemoveSprite(image)
    if self.iconLoaders[image] then
        self.iconLoaders[image]:Delete()
        self.iconLoaders[image] = nil
    end
end

function BaseView:SetActive(gameObject,active)
    BaseUtils.SetActive(gameObject,active)
end

function BaseView:LoadAsseting()
    return not BaseUtils.IsNull(self.assetLoader) and self.assetLoader.isLoading
end

function BaseView:ExtendView(view)
    if not view then
        assert(false,"扩展类不存在")
    end

    local extendView = view.New(self)

    if extendView.module ~= self.module then
        assert(false,string.format("扩展类所属模块不一致[%s]",tostring(view.__className)))
    end

    self[view.__className] = extendView
    
    table.insert(self.extendViewList,extendView)
    return extendView
end

function BaseView:ExecuteExtendFun(fn,flag)
    for _,view in ipairs(self.extendViewList) do
        view:SuperFunc(fn,flag)
    end
end

function BaseView:Create()
    if not self.__isCreate or self:LoadAsseting() then 
        return 
    end

    if not BaseUtils.IsNull(self.gameObject) then
        return
    end

    self.__canShow = false
    self:LoadAsset()
end

function BaseView:SetTopLayer(canvas)
    canvas.sortingOrder = ViewManager.Instance:GetMaxOrderLayer()
end

function BaseView:SetOrder(order)
    if not order then
        order = ViewDefine.Layer[self.__className] or 0
    end

    self.sortingOrder = order
    if self.rootCanvas then
        self.rootCanvas.enabled = true
        self.rootCanvas.overrideSorting = true
        self.rootCanvas.sortingOrder = order
    end
    

    for _,effectInfo in pairs(self.effectInfos) do
        if effectInfo.orderOffset then
            effectInfo.effect:SetOrder(self.sortingOrder + effectInfo.orderOffset)
        end
    end

    for node,orderOffset in pairs(self.nodeOrderOffset) do
        local canvas = node:GetComponent(Canvas)
        if BaseUtils.IsNull(canvas) then
            canvas = node:AddComponent(Canvas)
            node:AddComponent(GraphicRaycaster)
            canvas.overrideSorting = true
            canvas.additionalShaderChannels = UIDefine.additionalShaderChannels
        end
        canvas.sortingOrder = order + orderOffset
    end

    self.showCanvas = true
end

function BaseView:AddNodeOrderOffset(obj,offset)
    self.nodeOrderOffset[obj] = offset
    local canvas = obj:GetComponent(Canvas)
    if BaseUtils.IsNull(canvas) then
        canvas = obj:AddComponent(Canvas)
        obj:AddComponent(GraphicRaycaster)
        canvas.overrideSorting = true
        canvas.additionalShaderChannels = UIDefine.additionalShaderChannels
    end

    canvas.sortingOrder = self:GetOrder() + offset
end

function BaseView:GetOrder()
    if not self.rootCanvas then
        return 0
    end
    return self.rootCanvas.sortingOrder
end

function BaseView:BindEvent(event,extendView)
    local view = extendView or self
    self:CheckEvent(event,view)
    local func = view:ToFunc(event.value)
    self.module:BindEvent(event,func)
    if not self.events then self.events = {} end
    table.insert(self.events,{event = event,func = func})
end

function BaseView:BindLastingEvent(event,extendView)
    local view = extendView or self
    self:CheckEvent(event,view)
    local func = view:ToFunc(event.value)
    self.module:BindEvent(event,func)
    if not self.lastingEvents then self.lastingEvents = {} end
    table.insert(self.lastingEvents,{event = event,func = func})
end

function BaseView:BindBeforeEvent(event,extendView)
    local view = extendView or self
    self:CheckEvent(event,view)
    local func = view:ToFunc(event.value)
    self.module:BindEvent(event,func)
    if not self.beforeEvents then self.beforeEvents = {} end
    table.insert(self.beforeEvents,{event = event,func = func})
end

function BaseView:AddAnimEffectListener(animName,func)
    if not self.animEffectListeners then self.animEffectListeners = {} end
    AnimManager.Instance:AddEffectListener(self:GetInstanceId(),animName,func)
    self.animEffectListeners[animName] = func
end

function BaseView:RemoveAnimEffectListener(animName)
    if self.animEffectListeners and self.animEffectListeners[animName] then
        AnimManager.Instance:RemoveEffectListener(self:GetInstanceId(),animName)
    end
end

function BaseView:AddAnimDelayPlayListener(animName,func)
    if not self.animDelayPlayListeners then self.animDelayPlayListeners = {} end
    AnimManager.Instance:AddDelayPlayListener(self:GetInstanceId(),animName,func)
    self.animDelayPlayListeners[animName] = func
end

function BaseView:RemoveAnimDelayPlayListener(animName)
    if self.animDelayPlayListeners and self.animDelayPlayListeners[animName] then
        AnimManager.Instance:RemoveDelayPlayListener(self:GetInstanceId(),animName)
    end
end

function BaseView:SetEffectOrder(key,orderOffset)
    local effectInfo = self.effectInfos[key]
    if effectInfo then
        effectInfo.effect:SetOrder(orderOffset)
    end 
end

function BaseView:AddEffect(key,setting,orderOffset)
    if not self.effectInfos[key] then
        if orderOffset then
            setting.order = (self:GetOrder() or 0) + orderOffset
        end

        local effect = UIEffect.New()
        effect:Init(setting)
        self.effectInfos[key] = {effect = effect,orderOffset = orderOffset}
    end
end

function BaseView:AddEffectByObj(key,effect,orderOffset)
    if not self.effectInfos[key] then
        if orderOffset then
            effect:SetOrder((self.sortingOrder or 0) + orderOffset)
        end
        self.effectInfos[key] = {effect = effect,orderOffset = orderOffset}
    end
end

function BaseView:PlayEffect(key)
    if self.effectInfos[key] then
        self.effectInfos[key].effect:Play()
    end
end

function BaseView:StopEffect(key)
    if self.effectInfos[key] then
        self.effectInfos[key].effect:Stop()
    end
end

function BaseView:RemoveEffect(key)
    if self.effectInfos[key] then
        self.effectInfos[key].effect:Delete()
        self.effectInfos[key]= nil
    end
end

function BaseView:GetEffect(key,isRemove)
    local effectInfo = self.effectInfos[key]
    if isRemove and effectInfo then
        self.effectInfos[key] = nil
    end
    return effectInfo and effectInfo.effect or nil
end

-- function BaseView:AddUniqueEffect(effect)
--     for uid, eff in pairs(self.effects) do
--         if effect.assetId == eff.assetId then
--             self:RemoveEffect(uid)
--         end
--     end
--     self:AddEffect(effect)
-- end

---加载UI特效
---@param setting table 设置
---@param unique boolean true代表相同ID的特效只能存在一个
---@return table UIEffect
-- function BaseView:LoadUIEffect(setting,unique)
--     local effect = UIEffect.New()
--     effect:Init(setting)
--     effect:Play()
--     if unique then
--         self:AddUniqueEffect(effect)
--     else
--         self:AddEffect(effect)
--     end
--     return effect
-- end

---加载UI特效
---@param data table 详见AnimManager:EffectPlay()
---@param unique boolean 是否允许加载多个相同ID的特效
---@return table UIEffect
-- function BaseView:LoadUIEffectByAnimData(data,unique)
--     local effectId = data.effectId
--     local nodePath = data.nodePath
--     local order = self:GetOrder() + KvData.EffectOrderAdd + data.order
--     local node = self:Find(nodePath)
--     if not node then
--         LogErrorAny("界面",self.__className,"找不到特效",effectId,'的挂载点,路径:',nodePath)
--     end
--     local effect = self:LoadUIEffect({
--         confId = data.effectId,
--         delayTime = data.beginTime,
--         lastTime = data.lastTime,
--         scale = data.scale,
--         pos = data.pos,
--         parent = node,
--         order = order,
--     },unique)
--     return effect
-- end

-- function BaseView:RemoveEffect(uid)
--     if self.effects[uid] then
--         self.effects[uid]:Delete()
--         self.effects[uid]= nil
--     end
-- end

function BaseView:RemoveAllEffect()
    for _,effectInfo in pairs(self.effectInfos) do
        effectInfo.effect:Delete()
    end
    self.effectInfos = {}
end

function BaseView:CheckEvent(event,view)
    if not self.module then
        assert(false, "BaseView添加事件失败[error:当前类缺失所属模块]")
    end
    
    if not event then
        assert(false, "BaseView添加事件失败[error:传入了空的事件]")
    end
    
    if not event._enum then
        assert(false, "BaseView添加事件失败[error:传入的不是事件]")
    end
    
    if not BaseView.debugEvents[event.value] then
        BaseView.debugEvents[event.value] = event.id
    elseif BaseView.debugEvents[event.value] ~= event.id then
        assert(false,string.format("同一模块重复定义了相同事件[模块:%s][事件:%s]",self.module.__className,event.value))
    end

    local class = _G[view.__className]

    if (not class.Event or event ~= class.Event[event.value])
        and (not self.module.Event or event ~= self.module.Event[event.value]) then
        assert(false, "禁止传入其它模块的事件")
    end

    if not view[event.value] then
        assert(false, string.format("BaseView添加事件失败[error:未实现事件回调函数(%s)]",event.value))
    end
end

function BaseView:RemoveEvent()
    if not self.module or not self.events or #self.events<=0 then return end
    for i,v in ipairs(self.events) do self.module:RemoveEvent(v.event,v.func) end
    self.events = nil
end

function BaseView:RemoveLastingEvent()
    if not self.module or not self.lastingEvents or #self.lastingEvents<=0 then return end
    for i,v in ipairs(self.lastingEvents) do self.module:RemoveEvent(v.event,v.func) end
    self.lastingEvents = nil
end

function BaseView:RemoveBeforeEvent()
    if not self.module or not self.beforeEvents or #self.beforeEvents<=0 then return end
    for i,v in ipairs(self.beforeEvents) do self.module:RemoveEvent(v.event,v.func) end
    self.beforeEvents = nil
end

function BaseView:IsValid()
    return self.gameObject ~= nil
end

function BaseView.ChangeLanguage()
    for view,_ in pairs(BaseView.views) do
        if view:IsActive() then
            view:SuperFunc("__ChangeLanguage",true)
            view:ExecuteExtendFun("__ChangeLanguage",true)
        end
    end
end

function BaseView:IsInited()
    return self.__isCreate ~= nil and self.__canShow == true and self:IsActive()
end

function BaseView:OnPushPool() end

-- anim
function BaseView:ExecuteTransitionIn(type,callback)
    if type == KvData.TransitionType.fade then
        if not self.canvasGroup then
            self.canvasGroup = self.gameObject:AddComponent(CanvasGroup)
        end
        self:RemoveTransition()

        self.canvasGroup.alpha = 0
        self.transitionSeq = DOTween.Sequence()
        self.transitionSeq:Append(self.canvasGroup:DOFade(1, self.__fadeInDuration))
        self.transitionSeq:AppendCallback(callback)
        self.transitionSeq:Play()
    end

    --
    if type == KvData.TransitionType.none or type == nil or type <= 10 then
        callback()
    end
end

function BaseView:ExecuteTransitionOut(type,callback)
    if type == KvData.TransitionType.fade then
        if not self.canvasGroup then
            self.canvasGroup = self.gameObject:AddComponent(CanvasGroup)
        end
        self:RemoveTransition()

        self.canvasGroup.alpha = 1
        self.transitionSeq = DOTween.Sequence()
        self.transitionSeq:Append(self.canvasGroup:DOFade(0, self.__fadeOutDuration))
        self.transitionSeq:AppendCallback(callback)
        self.transitionSeq:Play()
    end

    if type == KvData.TransitionType.none or type == nil or type <= 10 then
        callback()
    end
end

--[[
    BaseView 生命周期虚方法说明
    
    完整生命周期顺序：
    1. __ExtendView()      - 扩展视图初始化
    2. __CacheObject()     - 缓存GameObject引用
    3. __Create()          - 创建时初始化
    4. __BindListener()    - 绑定监听器
    5. __BindBeforeEvent() - 绑定前置事件
    6. __BindEvent()       - 绑定事件
    7. __BindLastingEvent()- 绑定持久事件
    8. __Show(args)        - 显示时调用（GameObject已SetActive(true)）
    9. __ShowComplete()    - 显示完成回调
--]]

function BaseView:__ExtendView() end
function BaseView:__CacheObject()
    local template = self:Find("template")
    if template and template.gameObject then
        template.gameObject:SetActive(false)
    end
end
function BaseView:__Create() end
function BaseView:__BindListener() end
function BaseView:__BindBeforeEvent() end
function BaseView:__BindEvent() end
function BaseView:__BindLastingEvent() end
function BaseView:__Show(args) end
function BaseView:__LastShow(args) end
function BaseView:__RepeatShow(args) end
function BaseView:__Hide() end

function BaseView:__BaseCreate() end
function BaseView:__BaseShow() end
function BaseView:__ShowComplete()end
function BaseView:__BaseHide() end
function BaseView:__ChangeLanguage() end
