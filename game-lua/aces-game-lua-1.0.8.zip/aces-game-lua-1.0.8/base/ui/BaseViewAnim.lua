BaseViewAnim = ExtendClass(BaseView)

function BaseViewAnim:InitViewAnim()
    
end