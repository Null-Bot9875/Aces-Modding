BaseWindow = BaseClass("BaseWindow",BaseView)
BaseWindow.isWindow = true
BaseWindow.__transitionType = KvData.TransitionType.fade
BaseWindow.__holdShow = false
BaseWindow.__canvasGroupHide = false
BaseWindow.__showMainui = false
-- 窗口打开时 ViewManager 会先 AddOrderLayer(__addOrderLayer) 再 SetOrderLayer；默认 2，子类可覆盖
BaseWindow.__addOrderLayer = 2

function BaseWindow:__Init()
    self.winName = self.__className
    self:SetViewType(UIDefine.ViewType.window)
    self.cacheMode = UIDefine.CacheMode.destroy
    self.assetPath = nil

    self.isTempHide = false

    self.orderLayer = 0

    self:CreateRoot()
end

function BaseWindow:__Delete()
    self:CleanGaussianTexture()
    GameObject.Destroy(self.rootObj)
    self.rootObj = nil
end

function BaseWindow:CreateRoot()
    self.rootObj = ViewManager.Instance:GetWindowParent()
    self.rootTrans = self.rootObj.transform
    self.rootObj.name = self.winName
    self.rootTrans.offsetMin = Vector2.zero
    self.rootTrans.offsetMax = Vector2.zero

    self.gaussianBlur = self.rootTrans:Find("gaussian_bg").gameObject:GetComponent(GaussianBlur)
end

function BaseWindow:SetCacheMode(mode)
    self.cacheMode = mode 
end

function BaseWindow:OnHotKeyCloseWindow()
    ViewManager.Instance:CloseWindowByName(self.winName)
    return true
end

-- 子类不要直接调用
function BaseWindow:CloseWindow(imm)
    self.isDeleteWindow = true
    if imm or self:LoadAsseting() then
        self:CloseComplete()
    else
        self:Hide()
    end
end

function BaseWindow:TempHideWindow()
    self.isTempHide = true
    if self.__canvasGroupHide then
        self:CanvasGroupHide()
    else
        self:SetActive(self.rootObj,false)
    end
end

function BaseWindow:TempShowWindow()
    self.isTempHide = false
    if self.__canvasGroupHide then
        self:CanvasGroupShow()
    else
        self:SetActive(self.rootObj,true)
    end
end

function BaseWindow:CanvasGroupHide()
    if not self.rootCanvasGroup then
        self.rootCanvasGroup = self.rootObj:GetComponent(CanvasGroup)
        if not self.rootCanvasGroup then
            self.rootCanvasGroup = self.rootObj:AddComponent(typeof(CanvasGroup))
        end
    end
    self.rootCanvasGroup.alpha = 0
    self.rootCanvasGroup.blocksRaycasts = false
    self.rootCanvasGroup.interactable = false
end

function BaseWindow:CanvasGroupShow()
    if not self.rootCanvasGroup then
        self.rootCanvasGroup = self.rootObj:GetComponent(CanvasGroup)
        if not self.rootCanvasGroup then
            self.rootCanvasGroup = self.rootObj:AddComponent(typeof(CanvasGroup))
        end
    end
    self.rootCanvasGroup.alpha = 1
    self.rootCanvasGroup.blocksRaycasts = true
    self.rootCanvasGroup.interactable = true
end

function BaseWindow:IsTempHide()
    return self.isTempHide
end

function BaseWindow:CloseComplete()
    self:CleanGaussianTexture()
    if self.cacheMode == UIDefine.CacheMode.hide then
        self:HideHandle()
    elseif self.cacheMode == UIDefine.CacheMode.destroy then
        self:Destroy()
        ViewManager.Instance:RemoveWindow(self.winName)
    end
    ViewManager.Instance:CloseComplete(self.winName)
end

function BaseWindow:SetParent(parent,x,y,z)
    self.refreshParent = true
    self.parent = self.rootTrans:Find("view")

    self.rootTrans:SetParent(parent,false)
end

function BaseWindow:SetOrderLayer(orderLayer)
    self.orderLayer = orderLayer
    if self.rootCanvas then
        self.rootCanvas.sortingOrder = self.orderLayer
    end
end

function BaseWindow:OnOpenParse(args)
    --if not self:isExistTab() then return end
    --local tabIndex = 1
    --if args ~= nil then tabIndex = args.tab or 1 end
    --self:getTab():onTabClick(tabIndex)
end

function BaseWindow:Gaussian()
    self.gaussianBlur:Render()
end

function BaseWindow:CleanGaussianTexture()
    if not self.__gaussian then
        return
    end

    if self.gaussianBlur and not BaseUtils.IsNull(self.gaussianBlur) then
        self.gaussianBlur:Clean()
    end
end

function BaseWindow:__BaseCreate()
    self:InitCreate()
end

function BaseWindow:InitCreate()
    -- self.rootCanvas = self:Find(nil,Canvas)
    self.rootCanvas.overrideSorting = true
    self.rootCanvas.sortingOrder = self.orderLayer

    if self.__adaptiveTop or self.__adaptiveBottom then
        ViewManager.Instance:Adaptive(self:Find("main",RectTransform),self.__adaptiveTop,self.__adaptiveBottom)
    end
end

function BaseWindow:__BaseShow()
    if self.__gaussian then
        self.gaussianBlur.gameObject:SetActive(true)
        self.gaussianBlur.transform:SetParent(self.transform)
        self.gaussianBlur.transform:SetAsFirstSibling()
    end

    self:OnOpenParse(self.args)
end

function BaseWindow:__BaseHide()
    assert(self.isDeleteWindow,string.format("window对象禁止直接调用Hide方法! ==> 改用(ViewManager.Instance:CloseWindow)",tostring(self.winName)))
end

function BaseWindow:__ShowComplete()
    ViewManager.Instance:OpenComplete(self)
end

function BaseWindow:SetWindowSize(width,height)
    UnityUtils.setSizeDelata(self.rectTrans,width,height)
end

function BaseWindow:OnCloseClick()
    ViewManager.Instance:CloseWindowByName(self.winName)
end
