-- 数据定义
UIDefine = UIDefine or {}


UIDefine.ViewType =
{
    window = 1, --窗体
    panel = 2, --面板
    item = 3, -- item
}

UIDefine.CacheMode =
{
    destroy = 1,--删除
    hide = 2,--隐藏
}

-- 转场配置
UIDefine.TransitionConfig = {
    fadeInDuration = 0.3,   -- 淡入时长
    fadeOutDuration = 0.2,  -- 淡出时长
    blackFadeDuration = 0.3, -- 叠黑转场的渐变时长
    -- 注意：叠黑转场的停留时长由资源加载时间自然决定，不需要固定配置
}

UIDefine.canvasRoot = nil
UIDefine.transBlackMask = nil  -- 全局黑色蒙层对象
UIDefine.transBlackMaskCanvasGroup = nil  -- 黑色蒙层的 CanvasGroup 组件
-- UIDefine.canvasTrans = nil
UIDefine.uiCamera = nil
UIDefine.additionalShaderChannels = nil

UIDefine.calcPosNode = nil
UIDefine.mixedTrans = nil

UIDefine.richTemplateParent = nil
UIDefine.cardDescTemplate = nil

UIDefine.eventSystem = nil