AnimDefine = SingleClass("AnimDefine")


AnimDefine.TweenLoopType =
{
    [0] = DG.Tweening.LoopType.Restart,
    [1] = DG.Tweening.LoopType.Yoyo,
    [2] = DG.Tweening.LoopType.Incremental
}

AnimDefine.TweenEase =
{
    [0] = DG.Tweening.Ease.Unset,
    [1] = DG.Tweening.Ease.Linear,
    [2] = DG.Tweening.Ease.InSine,
    [3] = DG.Tweening.Ease.OutSine,
    [4] = DG.Tweening.Ease.InOutSine,
    [5] = DG.Tweening.Ease.InQuad,
    [6] = DG.Tweening.Ease.OutQuad,
    [7] = DG.Tweening.Ease.InOutQuad,
    [8] = DG.Tweening.Ease.InCubic,
    [9] = DG.Tweening.Ease.OutCubic,
    [10] = DG.Tweening.Ease.InOutCubic,
    [11] = DG.Tweening.Ease.InQuart,
    [12] = DG.Tweening.Ease.OutQuart,
    [13] = DG.Tweening.Ease.InOutQuart,
    [14] = DG.Tweening.Ease.InQuint,
    [15] = DG.Tweening.Ease.OutQuint,
    [16] = DG.Tweening.Ease.InOutQuint,
    [17] = DG.Tweening.Ease.InExpo,
    [18] = DG.Tweening.Ease.OutExpo,
    [19] = DG.Tweening.Ease.InOutExpo,
    [20] = DG.Tweening.Ease.InCirc,
    [21] = DG.Tweening.Ease.OutCirc,
    [22] = DG.Tweening.Ease.InOutCirc,
    [23] = DG.Tweening.Ease.InElastic,
    [24] = DG.Tweening.Ease.OutElastic,
    [25] = DG.Tweening.Ease.InOutElastic,
    [26] = DG.Tweening.Ease.InBack,
    [27] = DG.Tweening.Ease.OutBack,
    [28] = DG.Tweening.Ease.InOutBack,
    [29] = DG.Tweening.Ease.InBounce,
    [30] = DG.Tweening.Ease.OutBounce,
    [31] = DG.Tweening.Ease.InOutBounce,
    [32] = DG.Tweening.Ease.Flash,
    [33] = DG.Tweening.Ease.InFlash,
    [34] = DG.Tweening.Ease.OutFlash,
    [35] = DG.Tweening.Ease.InOutFlash,
}

