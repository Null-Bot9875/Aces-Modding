MoveDOPathAnim = BaseClass("MoveDOPathAnim",AnimBaseTween)

-- 使用 DOTween 的 DOPath/DOLocalPath 进行路径移动
-- points: Vector3[]
-- options: { isLocal = false }
function MoveDOPathAnim:__Init(transform,points,totalTime,options)
    self.transform = transform
    self.points = points or {}
    self.totalTime = totalTime or 0.2
    self.options = options or {}
end

function MoveDOPathAnim:__Delete()
end

function MoveDOPathAnim:OnTween()
    if self.options.isLocal then
        return self.transform:DOLocalPath(self.points,self.totalTime)
    else
        return self.transform:DOPath(self.points,self.totalTime)
    end
end


