EffectAnim = BaseClass("EffectAnim",AnimBase)

function EffectAnim:__Init(setting,time)
    self.setting = setting
    self.time = time
    self.effect = nil
    self.doneTimer = nil
end

function EffectAnim:__Delete()
    self:RemoveTimer()
    self:RemoveEffect()
end

function EffectAnim:Play()
    self.effect = UIEffect.New()
    self.effect:Init(self.setting)
    self.effect:SetComplete(self:ToFunc("EffectDone"))
    self.effect:Play()

    self.doneTimer = TimerManager.Instance:AddTimer(1,self.time + 0.1,self:ToFunc("TimerDone"))
end

function EffectAnim:EffectDone()
    self:RemoveEffect()
    self:BaseComplete()
end

function EffectAnim:TimerDone()
    self.doneTimer = nil
    --self:RemoveEffect()
    self:BaseComplete()
end

function EffectAnim:Clean()
    self:RemoveEffect()
end

function EffectAnim:RemoveTimer()
    if self.doneTimer then
        TimerManager.Instance:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function EffectAnim:RemoveEffect()
    if self.effect then
        self.effect:Delete()
        self.effect = nil
    end
end