RotationAnim = BaseClass("RotationAnim",AnimBaseTween)

function RotationAnim:__Init(transform,toValue,time)
    self.transform = transform
    self.toValue = toValue
    self.time = time
end

function RotationAnim:__Delete()
    
end

function RotationAnim:OnTween()
    local tween = self.transform:DORotate(self.toValue,self.time)
    return tween
end

function RotationAnim.Create(root,animData,nodes,animNodes)
    local transform = AnimUtils.GetComponent(root,animData.path)
    local anim = RotationAnim.New(transform,animData.toValue,animData.time)
    return anim
end

function RotationAnim.GetRotationAngle(fromAngle, toAngle, isFarthest)
    if not isFarthest then
        local deltaZ = math.abs(toAngle - fromAngle)
        if deltaZ > 180 then
            if toAngle> fromAngle then
                toAngle = toAngle - 360
            else
                toAngle = toAngle + 360
            end
        end
    else
        local deltaZ = math.abs(toAngle - fromAngle)
        if deltaZ < 180 then
            if fromAngle > toAngle then
                toAngle = toAngle + 360
            else
                toAngle = toAngle - 360
            end
        end
    end

    return toAngle
end