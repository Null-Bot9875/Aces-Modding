RotationLocalXAnim = BaseClass("RotationLocalXAnim",AnimBaseTween)

function RotationLocalXAnim:__Init(transform,toX,time,isFarthest)
    self.transform = transform
    self.toX = toX
    self.time = time
    self.isFarthest = isFarthest or false
end

function RotationLocalXAnim:__Delete()
    
end

function RotationLocalXAnim:OnTween()
    local x = RotationAnim.GetRotationAngle(self.transform.rotation.eulerAngles.x, self.toX, self.isFarthest)
    local tween = DOTweenEx.DOLocalRotateX(self.transform,x,self.time)
    return tween
end

function RotationLocalXAnim.Create(root,animData,nodes,animNodes)
    local transform = AnimUtils.GetComponent(root,animData.path)
    local anim = RotationLocalXAnim.New(transform,animData.toX,animData.time)
    return anim
end