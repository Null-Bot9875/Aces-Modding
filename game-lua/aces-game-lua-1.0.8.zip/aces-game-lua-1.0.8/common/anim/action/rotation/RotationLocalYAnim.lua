RotationLocalYAnim = BaseClass("RotationLocalYAnim",AnimBaseTween)

function RotationLocalYAnim:__Init(transform,toY,time,isFarthest)
    self.transform = transform
    self.toY = toY
    self.time = time
    self.isFarthest = isFarthest or false
end

function RotationLocalYAnim:__Delete()
    
end

function RotationLocalYAnim:OnTween()
    local y = RotationAnim.GetRotationAngle(self.transform.rotation.eulerAngles.y, self.toY, self.isFarthest)
    local tween = DOTweenEx.DOLocalRotateY(self.transform,y,self.time)
    return tween
end

function RotationLocalYAnim.Create(root,animData,nodes,animNodes)
    local transform = AnimUtils.GetComponent(root,animData.path)
    local anim = RotationLocalYAnim.New(transform,animData.toY,animData.time)
    return anim
end