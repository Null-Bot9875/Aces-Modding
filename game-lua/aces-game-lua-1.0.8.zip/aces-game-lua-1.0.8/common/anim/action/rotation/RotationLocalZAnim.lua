RotationLocalZAnim = BaseClass("RotationLocalZAnim",AnimBaseTween)

function RotationLocalZAnim:__Init(transform,toZ,time,isFarthest)
    self.transform = transform
    self.toZ = toZ
    self.time = time
    self.isFarthest = isFarthest or false
end

function RotationLocalZAnim:__Delete()
    
end

function RotationLocalZAnim:OnTween()
    local z = RotationAnim.GetRotationAngle(self.transform.rotation.eulerAngles.z, self.toZ, self.isFarthest)
    local tween = DOTweenEx.DOLocalRotateZ(self.transform,z,self.time)
    return tween
end

function RotationLocalZAnim.Create(root,animData,nodes,animNodes)
    local transform = AnimUtils.GetComponent(root,animData.path)
    local anim = RotationLocalZAnim.New(transform,animData.toZ,animData.time)
    return anim
end