RotationXAnim = BaseClass("RotationXAnim",AnimBaseTween)

function RotationXAnim:__Init(transform,toX,time,isFarthest)
    self.transform = transform
    self.toX = toX
    self.time = time
    self.isFarthest = isFarthest or false
end

function RotationXAnim:__Delete()
    
end

function RotationXAnim:OnTween()
    local x = RotationAnim.GetRotationAngle(self.transform.rotation.eulerAngles.x, self.toX, self.isFarthest)
    local tween = DOTweenEx.DORotateX(self.transform,x,self.time)
    return tween
end

function RotationXAnim.Create(root,animData,nodes,animNodes)
    local transform = AnimUtils.GetComponent(root,animData.path)
    local anim = RotationXAnim.New(transform,animData.toX,animData.time)
    return anim
end