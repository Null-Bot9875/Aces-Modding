RotationZAnim = BaseClass("RotationZAnim",AnimBaseTween)

function RotationZAnim:__Init(transform,toZ,time, isFarthest)
    self.transform = transform
    self.toZ = toZ
    self.time = time
    self.isFarthest = isFarthest or false
end

function RotationZAnim:__Delete()
    
end

function RotationZAnim:OnTween()
    local z = RotationAnim.GetRotationAngle(self.transform.rotation.eulerAngles.z, self.toZ, self.isFarthest)
    local tween = DOTweenEx.DORotateZ(self.transform,z,self.time)
    return tween
end

function RotationZAnim.Create(root,animData,nodes,animNodes)
    local transform = AnimUtils.GetComponent(root,animData.path)
    local anim = RotationZAnim.New(transform,animData.toZ,animData.time)
    return anim
end