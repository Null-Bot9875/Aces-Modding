TweenAnimBase = BaseClass("TweenAnimBase",TweenBase)

function TweenAnimBase:__Init(...)
    self.tween = self:OnCreate(...)
    if not self:CheckValid("初始化失败") then
        return
    end
    self.tween:SetComplete(self:ToFunc("OnComplete"))
end

function TweenAnimBase:__Delete()
end

function TweenAnimBase:SetEase(ease)
    if not self:CheckValid("设置缓动曲线失败") then
        return
    end
    self.tween:SetEase(ease)
    return self
end

function TweenAnimBase:Play()
    if not self:CheckValid("播放动画失败") then
        return
    end
    if self.tween:Play() then
        self:OnPlay()
    end
end

function TweenAnimBase:Stop()
    if not self:CheckValid("停止动画失败") then
        return
    end
    if self.tween:Stop() then
        self:OnStop()
    end
end

function TweenAnimBase:Kill()
    if self.tween then
        self.tween:Kill()
        self.tween = nil
    end
end

function TweenAnimBase:IsFinish()
    if not self.tween then
        return false
    end
    return self.tween:IsFinish()
end

function TweenAnimBase:GetCurrentTime()
    if not self.tween then
        return 0
    end
    return self.tween:GetCurrentTime()
end

function TweenAnimBase:CheckValid(tips)
    if not self.tween then
        LogErrorAny(tips,"tween未创建 Class:",self.__className)
        return false
    end
    return true
end



--#region 虚方法

function TweenAnimBase:OnCreate(...)
    return nil
end

function TweenAnimBase:OnPlay()
    DOTweenUpdater.Instance:AddUpdateItem(self.tween)
end

function TweenAnimBase:OnStop()
    DOTweenUpdater.Instance:RemoveUpdateItem(self.tween)
end

function TweenAnimBase:OnComplete()
    DOTweenAnimFactory.PushAnim(self.tween)
    self:CallComplete()
    self.tween = nil
end

--#endregion