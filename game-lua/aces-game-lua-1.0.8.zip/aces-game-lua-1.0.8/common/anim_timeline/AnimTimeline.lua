AnimTimeline = BaseClass("AnimTimeline",LTimeline)

function AnimTimeline:__Init()
    self.timelineBehaviors = {}
    self.uid = 0
    self.updateTimer = TimerManager.Instance:AddTimer(0,0,self:ToFunc("OnUpdate"))
end

function AnimTimeline:__Delete()
    self.timelineBehaviors = {}
    if self.updateTimer then
        TimerManager.Instance:RemoveTimer(self.updateTimer)
        self.updateTimer = nil
    end
end

function AnimTimeline:OnInit(conf,args)
    local nodes = {}

    for _, v in ipairs(conf) do
        local class  = _G[v.type]

        if class then
            local node = {}

            local uid = v.uid

            if not uid or uid == "" then
                uid = self:GetTimelineNodeUid()
            end

            local timelineBehavior = class.New()
            timelineBehavior:Init(uid,v,args)
            node.behavior = timelineBehavior
            node.time = v.time
            table.insert(nodes,node)
            if args.inDatas then
                for k, v in pairs(args.inDatas) do
                    timelineBehavior:SetInData(k,v)
                end
            end

            self.timelineBehaviors[uid] = timelineBehavior
        else
            LogError("创建动画行为异常，未知的动画行为类型[行为类型:%s]",tostring(v.type))
        end
    end
    self:SetNodes(nodes)
end

function AnimTimeline:GetTimelineNodeUid()
    self.uid = self.uid + 1
    return self.uid
end

function AnimTimeline:GetTimelineNode(uid)
    return self.timelineBehaviors[uid]
end

function AnimTimeline:OnStart()
end

function AnimTimeline:OnAbort()
end

function AnimTimeline:OnFinish()
end

function AnimTimeline:OnUpdate()
    self:Update(Time.deltaTime)
end


function AnimTimeline.Create(confName,args)
    local animDatas = Config.GetLua(confName)
    if not animDatas then
        LogErrorf("不存在动画配置文件[%s]",confName)
        return
    end

    local animTimeline = AnimTimeline.New()
    animTimeline:Init(animDatas,args)

    return animTimeline
end