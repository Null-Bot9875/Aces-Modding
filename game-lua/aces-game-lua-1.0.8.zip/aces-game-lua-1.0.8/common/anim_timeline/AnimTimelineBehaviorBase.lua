AnimTimelineBehaviorBase = BaseClass("AnimTimelineBehaviorBase")

function AnimTimelineBehaviorBase:__Init()
    self.gameObject = nil
    self.uid = nil
    self.conf = nil
    self.args = nil
    self.onComplete = nil
    self.onHookComplete = nil
    self.inData = {}
end

function AnimTimelineBehaviorBase:__Delete()
end

function AnimTimelineBehaviorBase:Init(uid,conf,args,...)
    self.uid = uid
    self.conf = conf
    self.args = args
    self:OnInit(...)
end

function AnimTimelineBehaviorBase:Start()
    self:OnStart()
end

function AnimTimelineBehaviorBase:SetInData(key,val)
    self.inData[key] = val
end

function AnimTimelineBehaviorBase:GetInData(key)
    return self.inData[key]
end

function AnimTimelineBehaviorBase:GetConfData(key)
    if self.inData[key] ~= nil then
        return self.inData[key]
    else
        return self.conf[key]
    end
end

function AnimTimelineBehaviorBase:Update(deltaTime)
    self:OnUpdate(deltaTime)
end

function AnimTimelineBehaviorBase:SetComplete(onComplete)
    self.onComplete = onComplete
end

function AnimTimelineBehaviorBase:SetHookComplete(onComplete)
    self.onHookComplete = onComplete
end

function AnimTimelineBehaviorBase:TimelineDone(...)
    if self.onHookComplete then
        self.onHookComplete(self,...)
    end
    if self.onComplete then
        self.onComplete(self,...)
    end
end

function AnimTimelineBehaviorBase:GetNode(type)
    local gameObject = self.inData.targetObj or self.args.targetObj
    if not gameObject then
        local trans = self.args.rootTrans:Find(self.conf.nodePath)
        if trans then
            gameObject = self.args.rootTrans:Find(self.conf.nodePath).gameObject
        end
    end

    if not gameObject then
        return nil
    end

    return type and gameObject:GetComponent(type) or gameObject
end

-- 虚函数
function AnimTimelineBehaviorBase:OnInit(...)
end
function AnimTimelineBehaviorBase:OnStart()
end
function AnimTimelineBehaviorBase:OnUpdate(deltaTime)
end
function AnimTimelineBehaviorBase:OnDestroy()
end