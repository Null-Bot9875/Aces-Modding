AnimTimelineDefine = StaticClass("AnimTimelineDefine")


-- AnimTimelineDefine.TimelineIndex =
-- {
--     ["AnimTimelineDefine"]    = { class = "MaskViewTimeline" },
-- }