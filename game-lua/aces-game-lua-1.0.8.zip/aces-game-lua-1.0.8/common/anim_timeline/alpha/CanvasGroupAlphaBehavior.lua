CanvasGroupAlphaBehavior = BaseClass("CanvasGroupAlphaBehavior",AnimTimelineBehaviorBase)

function CanvasGroupAlphaBehavior:__Init()
    self.anim = nil
end

function CanvasGroupAlphaBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end

    local canvasGroup = self:GetNode(CanvasGroup)
    if canvasGroup then
        canvasGroup.blocksRaycasts = true
    end
end

function CanvasGroupAlphaBehavior:OnInit()
end

function CanvasGroupAlphaBehavior:OnStart()
    local canvasGroup = self:GetNode(CanvasGroup)
    if canvasGroup then
        canvasGroup.blocksRaycasts = false
        self.anim = ToCanvasGroupAlphaAnim.New(canvasGroup,self:GetConfData("toAlpha"),self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function CanvasGroupAlphaBehavior:AnimDone()
    local canvasGroup = self:GetNode(CanvasGroup)
    if canvasGroup then
        canvasGroup.blocksRaycasts = true
    end

    self:TimelineDone()
end

