ImageColorBehavior = BaseClass("ImageColorBehavior",AnimTimelineBehaviorBase)

function ImageColorBehavior:__Init()
    self.anim = nil
end

function ImageColorBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function ImageColorBehavior:OnInit()
end

function ImageColorBehavior:OnStart()
    local image = self:GetNode(Image)
    if image then
        self.anim = ToImageColorAnim.New(image,Color(self:GetConfData("toColorR"),self:GetConfData("toColorG"),self:GetConfData("toColorB"),self:GetConfData("toColorA")),self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function ImageColorBehavior:AnimDone()
    self:TimelineDone()
end

