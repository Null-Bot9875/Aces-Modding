ImageFillAmountBehavior = BaseClass("ImageFillAmountBehavior",AnimTimelineBehaviorBase)

function ImageFillAmountBehavior:__Init()
    self.anim = nil
end

function ImageFillAmountBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function ImageFillAmountBehavior:OnInit()
end

function ImageFillAmountBehavior:OnStart()
    local image = self:GetNode(Image)
    if image then
        self.anim = FillAmountAnim.New(image,self:GetConfData("toFillAmount"),self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function ImageFillAmountBehavior:AnimDone()
    self:TimelineDone()
end

