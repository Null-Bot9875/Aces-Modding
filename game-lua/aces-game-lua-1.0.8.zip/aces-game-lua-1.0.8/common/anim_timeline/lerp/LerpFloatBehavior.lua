LerpFloatBehavior = BaseClass("LerpFloatBehavior",AnimTimelineBehaviorBase)

function LerpFloatBehavior:__Init()
    self.callBack = nil
    self.anim = nil
end

function LerpFloatBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function LerpFloatBehavior:OnInit()
end

function LerpFloatBehavior:OnStart()
    self.callBack = self:GetConfData("callBack")
    if self.callBack  then
        self.anim = ToFloatValueAnim.New(self:GetConfData("fromVal"),self:GetConfData("toVal"),self.conf.duration,self:ToFunc("OnValue"))
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function LerpFloatBehavior:OnValue(val)
    self.callBack(val)
end

function LerpFloatBehavior:AnimDone()
    self:TimelineDone()
end

