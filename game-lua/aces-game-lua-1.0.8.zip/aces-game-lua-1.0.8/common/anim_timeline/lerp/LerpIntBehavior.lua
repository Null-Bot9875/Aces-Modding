LerpIntBehavior = BaseClass("LerpIntBehavior",AnimTimelineBehaviorBase)

function LerpIntBehavior:__Init()
    self.callBack = nil
    self.anim = nil
end

function LerpIntBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function LerpIntBehavior:OnInit()
end

function LerpIntBehavior:OnStart()
    self.callBack = self:GetConfData("callBack")
    if self.callBack  then
        self.anim = ToIntValueAnim.New(self:GetConfData("fromVal"),self:GetConfData("toVal"),self.conf.duration,self:ToFunc("OnValue"))
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function LerpIntBehavior:OnValue(val)
    self.callBack(val)
end

function LerpIntBehavior:AnimDone()
    self:TimelineDone()
end

