ActiveNodeBehavior = BaseClass("ActiveNodeBehavior",AnimTimelineBehaviorBase)

function ActiveNodeBehavior:__Init()
end

function ActiveNodeBehavior:__Delete()
end

function ActiveNodeBehavior:OnInit()
end

function ActiveNodeBehavior:OnStart()
    local targetObj = self:GetNode()
    if targetObj then
        targetObj:SetActive(self.conf.toFlag)
    end

    self:AnimDone()

end

function ActiveNodeBehavior:AnimDone()
    self:TimelineDone()
end

