CallBackBehavior = BaseClass("CallBackBehavior",AnimTimelineBehaviorBase)

function CallBackBehavior:__Init()
end

function CallBackBehavior:__Delete()
end

function CallBackBehavior:OnInit()
end

function CallBackBehavior:OnStart()
    local callBack = self:GetInData("callBack")
    if callBack then
        callBack()
    end
    self:AnimDone()
end

function CallBackBehavior:AnimDone()
    self:TimelineDone()
end

