InitStateBehavior = BaseClass("InitStateBehavior",AnimTimelineBehaviorBase)

function InitStateBehavior:__Init()
end

function InitStateBehavior:__Delete()
end

function InitStateBehavior:OnInit()
end

function InitStateBehavior:OnStart()
    local targetObj = self:GetNode()
    if not targetObj then
        self:AnimDone()
        return
    end

    if self.conf.isInitActive then
        targetObj:SetActive(self.conf.initActive)
    end

    if self.conf.isInitPos then
        local rectTrans = targetObj:GetComponent(RectTransform)
        local targetPosObj = self:GetInData("targetPosObj")
        if targetPosObj then
            rectTrans.transform:SetPosition(targetPosObj.transform.position.x,targetPosObj.transform.position.y,targetPosObj.transform.position.z)
        else
            rectTrans.anchoredPosition = Vector2(self:GetConfData("initPosX"),self:GetConfData("initPosY"))
        end
    end

    if self.conf.isInitRotate then
        local trans = targetObj.transform
        trans.localEulerAngles = Vector3(self.conf.initRotateX, self.conf.initRotateY,self.conf.initRotateZ)
    end

    if self.conf.isInitScale then
        local trans = targetObj.transform
        trans.localScale = Vector3(self.conf.initScaleX, self.conf.initScaleY,self.conf.initScaleZ)
    end

    if self.conf.isInitCanvasGroupAlpha then
        local canvasGroup = targetObj:GetComponent(CanvasGroup)
        canvasGroup.alpha = self.conf.initCanvasGroupAlpha
    end

    if self.conf.isInitImageColor then
        local image = targetObj:GetComponent(Image)
        image.color = Color(self:GetConfData("initImageColorR"),self:GetConfData("initImageColorG"),self:GetConfData("initImageColorB"),self:GetConfData("initImageColorA"))
    end

    if self.conf.isInitTextColor then
        local text = targetObj:GetComponent(TextMeshProUGUI)
        text.color = Color(self:GetConfData("initTextColorR"),self:GetConfData("initTextColorG"),self:GetConfData("initTextColorB"),self:GetConfData("initTextColorA"))
    end

    self:AnimDone()
end

function InitStateBehavior:AnimDone()
    self:TimelineDone()
end

