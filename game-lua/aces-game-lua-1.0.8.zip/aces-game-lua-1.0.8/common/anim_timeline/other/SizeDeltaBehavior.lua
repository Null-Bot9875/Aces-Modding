SizeDeltaBehavior = BaseClass("SizeDeltaBehavior",AnimTimelineBehaviorBase)

function SizeDeltaBehavior:__Init()
    self.anim = nil
end

function SizeDeltaBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function SizeDeltaBehavior:OnInit()
end

function SizeDeltaBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = ToSizeDeltaAnim.New(rectTrans,Vector2(self:GetConfData("toSizeX"),self:GetConfData("toSizeY")), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function SizeDeltaBehavior:AnimDone()
    self:TimelineDone()
end

