UIEffectBehaviour = BaseClass("UIEffectBehaviour",AnimTimelineBehaviorBase)

function UIEffectBehaviour:__Init()
    self.parentNode = nil
    self.anim = nil
end

function UIEffectBehaviour:__Delete()
    self.parent = nil

    if self.anim then
        self.anim:Delete()
        self.anim = nil
    end
end

function UIEffectBehaviour:OnInit()
end

function UIEffectBehaviour:OnStart()
    self.parentNode = self:GetNode()
    local order = self.args.order
    if not order then
        local canvas = self.args.rootTrans.gameObject:GetComponent(Canvas)
        if canvas then
            order = canvas.sortingOrder
        end
    end

    if not order then
        LogErrorf("播放UI特效失败，UI特效层级为空")
        self:AnimDone()
        return
    end

    local setting = {}
    setting.assetId = self.conf.assetId
    setting.parent = self.parentNode.transform
    setting.pos = {x = self.conf.pos.x,y = self.conf.pos.y}
    setting.rotate = {x = self.conf.rotate.x,y = self.conf.rotate.y,z = self.conf.rotate.z}
    setting.scale = self.conf.scale * 1000
    setting.order = order + self.conf.offsetOrder


    self.anim =  EffectAnim.New(setting,self.conf.duration)
    self.anim:SetComplete(self:ToFunc("AnimDone"))
    self.anim:Play()
end

function UIEffectBehaviour:AnimDone()
   -- Log("UI特效播放完成了")
    self:TimelineDone()
end

