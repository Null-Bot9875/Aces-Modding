MoveAnchor3DBehavior = BaseClass("MoveAnchor3DBehavior",AnimTimelineBehaviorBase)

function MoveAnchor3DBehavior:__Init()
    self.anim = nil
end

function MoveAnchor3DBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function MoveAnchor3DBehavior:OnInit()
end

function MoveAnchor3DBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = MoveAnchor3dAnim.New(rectTrans, Vector3(self:GetConfData("toPosX"),self:GetConfData("toPosY"),self:GetConfData("toPosZ")), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function MoveAnchor3DBehavior:AnimDone()
    self:TimelineDone()
end

