MoveAnchorBehavior = BaseClass("MoveAnchorBehavior",AnimTimelineBehaviorBase)

function MoveAnchorBehavior:__Init()
    self.anim = nil
end

function MoveAnchorBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function MoveAnchorBehavior:OnInit()
end

function MoveAnchorBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = MoveAnchorAnim.New(rectTrans,Vector2(self:GetConfData("toPosX"),self:GetConfData("toPosY")), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function MoveAnchorBehavior:AnimDone()
    self:TimelineDone()
end

