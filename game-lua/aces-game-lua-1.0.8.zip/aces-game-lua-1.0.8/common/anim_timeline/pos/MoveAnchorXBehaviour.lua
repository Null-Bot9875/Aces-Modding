MoveAnchorXBehaviour = BaseClass("MoveAnchorXBehaviour",AnimTimelineBehaviorBase)

function MoveAnchorXBehaviour:__Init()
    self.anim = nil
end

function MoveAnchorXBehaviour:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function MoveAnchorXBehaviour:OnInit()
end

function MoveAnchorXBehaviour:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = MoveAnchorXAnim.New(rectTrans, self:GetConfData("toPosX"), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function MoveAnchorXBehaviour:AnimDone()
    self:TimelineDone()
end

