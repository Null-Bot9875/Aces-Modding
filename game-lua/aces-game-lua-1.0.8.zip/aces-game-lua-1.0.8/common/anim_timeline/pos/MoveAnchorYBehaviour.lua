MoveAnchorYBehaviour = BaseClass("MoveAnchorYBehaviour",AnimTimelineBehaviorBase)

function MoveAnchorYBehaviour:__Init()
    self.anim = nil
end

function MoveAnchorYBehaviour:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function MoveAnchorYBehaviour:OnInit()
end

function MoveAnchorYBehaviour:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = MoveAnchorYAnim.New(rectTrans, self:GetConfData("toPosY"), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function MoveAnchorYBehaviour:AnimDone()
    self:TimelineDone()
end

