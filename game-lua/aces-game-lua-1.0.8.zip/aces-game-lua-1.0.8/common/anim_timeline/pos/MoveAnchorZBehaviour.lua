MoveAnchorZBehaviour = BaseClass("MoveAnchorZBehaviour",AnimTimelineBehaviorBase)

function MoveAnchorZBehaviour:__Init()
    self.anim = nil
end

function MoveAnchorZBehaviour:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function MoveAnchorZBehaviour:OnInit()
end

function MoveAnchorZBehaviour:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = MoveAnchor3dZAnim.New(rectTrans,self:GetConfData("toPosZ"), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function MoveAnchorZBehaviour:AnimDone()
    self:TimelineDone()
end

