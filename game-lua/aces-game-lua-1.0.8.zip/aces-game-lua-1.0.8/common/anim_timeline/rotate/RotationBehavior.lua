RotationBehavior = BaseClass("RotationBehavior",AnimTimelineBehaviorBase)

function RotationBehavior:__Init()
    self.anim = nil
end

function RotationBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function RotationBehavior:OnInit()
end

function RotationBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = RotationAnim.New(rectTrans, Vector3(self:GetConfData("toAngleX"),self:GetConfData("toAngleY"),self:GetConfData("toAngleZ")), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function RotationBehavior:AnimDone()
    self:TimelineDone()
end

