RotationLocalBehavior = BaseClass("RotationLocalBehavior",AnimTimelineBehaviorBase)

function RotationLocalBehavior:__Init()
    self.anim = nil
end

function RotationLocalBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function RotationLocalBehavior:OnInit()
end

function RotationLocalBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = RotationLocalAnim.New(rectTrans, Vector3(self:GetConfData("toAngleX"),self:GetConfData("toAngleY"),self:GetConfData("toAngleZ")), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function RotationLocalBehavior:AnimDone()
    self:TimelineDone()
end

