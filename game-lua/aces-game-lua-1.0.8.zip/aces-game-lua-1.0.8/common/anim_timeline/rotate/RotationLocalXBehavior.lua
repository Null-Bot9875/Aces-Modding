RotationLocalXBehavior = BaseClass("RotationLocalXBehavior",AnimTimelineBehaviorBase)

function RotationLocalXBehavior:__Init()
    self.anim = nil
end

function RotationLocalXBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function RotationLocalXBehavior:OnInit()
end

function RotationLocalXBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = RotationLocalXAnim.New(rectTrans,self:GetConfData("toAngleX"), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function RotationLocalXBehavior:AnimDone()
    self:TimelineDone()
end