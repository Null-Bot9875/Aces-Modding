RotationLocalYBehavior = BaseClass("RotationLocalYBehavior",AnimTimelineBehaviorBase)

function RotationLocalYBehavior:__Init()
    self.anim = nil
end

function RotationLocalYBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function RotationLocalYBehavior:OnInit()
end

function RotationLocalYBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = RotationLocalYAnim.New(rectTrans,self:GetConfData("toAngleY"), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function RotationLocalYBehavior:AnimDone()
    self:TimelineDone()
end