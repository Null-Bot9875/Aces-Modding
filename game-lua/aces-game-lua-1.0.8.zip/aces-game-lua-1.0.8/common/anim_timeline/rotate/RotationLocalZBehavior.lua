RotationLocalZBehavior = BaseClass("RotationLocalZBehavior",AnimTimelineBehaviorBase)

function RotationLocalZBehavior:__Init()
    self.anim = nil
end

function RotationLocalZBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function RotationLocalZBehavior:OnInit()
end

function RotationLocalZBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = RotationLocalZAnim.New(rectTrans,self:GetConfData("toAngleZ"), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function RotationLocalZBehavior:AnimDone()
    self:TimelineDone()
end