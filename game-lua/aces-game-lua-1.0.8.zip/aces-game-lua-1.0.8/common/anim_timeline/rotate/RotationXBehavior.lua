RotationXBehavior = BaseClass("RotationXBehavior",AnimTimelineBehaviorBase)

function RotationXBehavior:__Init()
    self.anim = nil
end

function RotationXBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function RotationXBehavior:OnInit()
end

function RotationXBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = RotationXAnim.New(rectTrans,self:GetConfData("toAngleX"), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function RotationXBehavior:AnimDone()
    self:TimelineDone()
end