RotationYBehavior = BaseClass("RotationYBehavior",AnimTimelineBehaviorBase)

function RotationYBehavior:__Init()
    self.anim = nil
end

function RotationYBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function RotationYBehavior:OnInit()
end

function RotationYBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = RotationYAnim.New(rectTrans,self:GetConfData("toAngleY"), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function RotationYBehavior:AnimDone()
    self:TimelineDone()
end