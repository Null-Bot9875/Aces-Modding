RotationZBehavior = BaseClass("RotationZBehavior",AnimTimelineBehaviorBase)

function RotationZBehavior:__Init()
    self.anim = nil
end

function RotationZBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function RotationZBehavior:OnInit()
end

function RotationZBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = RotationZAnim.New(rectTrans,self:GetConfData("toAngleZ"), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function RotationZBehavior:AnimDone()
    self:TimelineDone()
end