ScaleBehavior = BaseClass("ScaleBehavior",AnimTimelineBehaviorBase)

function ScaleBehavior:__Init()
    self.anim = nil
end

function ScaleBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function ScaleBehavior:OnInit()
end

function ScaleBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = ScaleAnim.New(rectTrans, Vector3(self:GetConfData("toScaleX"),self:GetConfData("toScaleY"),self:GetConfData("toScaleZ")), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function ScaleBehavior:AnimDone()
    self:TimelineDone()
end

