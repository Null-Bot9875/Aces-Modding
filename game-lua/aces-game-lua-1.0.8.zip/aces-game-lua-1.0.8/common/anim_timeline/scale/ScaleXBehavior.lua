ScaleXBehavior = BaseClass("ScaleXBehavior",AnimTimelineBehaviorBase)

function ScaleXBehavior:__Init()
    self.anim = nil
end

function ScaleXBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function ScaleXBehavior:OnInit()
end

function ScaleXBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = ScaleXAnim.New(rectTrans, self:GetConfData("toScaleX"), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function ScaleXBehavior:AnimDone()
    self:TimelineDone()
end

