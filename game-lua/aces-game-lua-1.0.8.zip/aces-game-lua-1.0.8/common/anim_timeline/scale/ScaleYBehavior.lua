ScaleYBehavior = BaseClass("ScaleYBehavior",AnimTimelineBehaviorBase)

function ScaleYBehavior:__Init()
    self.anim = nil
end

function ScaleYBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function ScaleYBehavior:OnInit()
end

function ScaleYBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = ScaleYAnim.New(rectTrans, self:GetConfData("toScaleY"), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function ScaleYBehavior:AnimDone()
    self:TimelineDone()
end

