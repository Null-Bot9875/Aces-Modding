ScaleZBehavior = BaseClass("ScaleZBehavior",AnimTimelineBehaviorBase)

function ScaleZBehavior:__Init()
    self.anim = nil
end

function ScaleZBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function ScaleZBehavior:OnInit()
end

function ScaleZBehavior:OnStart()
    local rectTrans = self:GetNode(RectTransform)
    if rectTrans then
        self.anim = ScaleZAnim.New(rectTrans, self:GetConfData("toScaleZ"), self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function ScaleZBehavior:AnimDone()
    self:TimelineDone()
end

