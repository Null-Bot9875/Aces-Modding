TextColorBehavior = BaseClass("TextColorBehavior",AnimTimelineBehaviorBase)

function TextColorBehavior:__Init()
    self.anim = nil
end

function TextColorBehavior:__Delete()
    if self.anim then
        self.anim:Destroy()
        self.anim = nil
    end
end

function TextColorBehavior:OnInit()
end

function TextColorBehavior:OnStart()
    local text = self:GetNode(TextMeshProUGUI)
    if text then
        self.anim = ToTextColorAnim.New(text,Color(self:GetConfData("toColorR"),self:GetConfData("toColorG"),self:GetConfData("toColorB"),self:GetConfData("toColorA")),self.conf.duration)
        self.anim:SetLoop(self.conf.loopNum, AnimDefine.TweenLoopType[self.conf.loopType])
        self.anim:SetEase(AnimDefine.TweenEase[self.conf.ease])
        self.anim:SetComplete(self:ToFunc("AnimDone"))
        self.anim:Play()
    else
        self:AnimDone()
    end
end

function TextColorBehavior:AnimDone()
    self:TimelineDone()
end

