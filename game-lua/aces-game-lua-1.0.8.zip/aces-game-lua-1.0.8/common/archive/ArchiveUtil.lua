ArchiveUtil = StaticClass("ArchiveManager")
-- 不用require读取不到
local serpent = require("common/archive/serpent")

-- 存档
function ArchiveUtil.SaveData(data, fileName)
    local path = string.format("%s/%s.lua", Application.persistentDataPath, fileName)
    local file = io.open(path, "w")
    file:write("return " .. serpent.block(data))
    file:close()
end

-- 读档
function ArchiveUtil.LoadData(fileName)
    local path = string.format("%s/%s.lua", Application.persistentDataPath, fileName)
    local file = io.open(path, "r")
    if file then
        local lua = file:read("*all")
        file:close()
        local chunk = load(lua)
        local data = chunk()
        --Log(serpent.block(data))
        return data
    end
end
