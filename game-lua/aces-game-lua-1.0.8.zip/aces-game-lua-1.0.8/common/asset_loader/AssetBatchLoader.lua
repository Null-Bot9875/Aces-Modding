AssetBatchLoader = BaseClass("AssetBatchLoader")
local EOperationStatus = CS.YooAsset.EOperationStatus

function AssetBatchLoader:__Init(scope)
    assert(scope, "AssetBatchLoader必须传入AssetScope")
    assert(not scope.IsDisposed, "AssetBatchLoader禁止使用已释放的AssetScope")

    self.scope = scope
    self.delFlag = false
    self.loadStarted = false
    self.loadAssets = {}
    self.assetIndexs = {}
    self.assetFlagFiles = {}
    self.handleInfos = {}
    self.assetCompletedFunc = self:ToFunc("OnAssetCompleted")
    self.isLoading = false
    self.isCancel = false
    self.hasError = false
    self.loadBeginTime = 0.0
    self.loadNum = 0
    self.loadCompleteNum = 0
    self.onComplete = nil
    self.onAssetComplete = nil
    self.args = nil
    self.callbackTimer = nil
    self.pendingAssetCompletes = {}
    self.completePending = false
end

function AssetBatchLoader:__Delete()
    if not self.delFlag then
        assert(false, "切勿直接调用Delete删除资源加载器,需要改用Destroy")
    end
end

function AssetBatchLoader:Load(assetList,onComplete,args)
    assert(not self.loadStarted, "AssetBatchLoader每个实例只允许调用一次Load")
    assert(onComplete, "非法资源加载回调")

    self.loadStarted = true
    self.isLoading = true
    self.args = args
    self.onComplete = onComplete
    self.loadBeginTime = Time.time

    for _,v in ipairs(assetList) do
        assert(v.file and v.file ~= "", "资源路径为空")
        assert(v.type, string.format("资源类型为空[%s]",tostring(v.file)))

        if not self.assetIndexs[v.file] then
            local loadInfo = {
                asset = nil,
                error = nil,
                file = v.file,
                handle = nil,
                priority = v.priority or AssetPriority.Low,
                status = nil,
                type = v.type,
            }
            table.insert(self.loadAssets,loadInfo)
            self.assetIndexs[v.file] = #self.loadAssets

            if v.flag then
                self.assetFlagFiles[v.flag] = v.file
            end
        end
    end

    self.loadNum = #self.loadAssets
    if self.loadNum <= 0 then
        self.isLoading = false
        self.completePending = true
        self:ScheduleCallbacks()
        return
    end

    for _,loadInfo in ipairs(self.loadAssets) do
        self:StartLoad(loadInfo)
    end
end

function AssetBatchLoader:StartLoad(loadInfo)
    local handle = AssetLoader.Instance:LoadAssetAsync(loadInfo.file,loadInfo.type,loadInfo.priority)
    self.scope:Add(handle)
    loadInfo.handle = handle
    self.handleInfos[handle] = loadInfo
    handle:Completed("+",self.assetCompletedFunc)
end

function AssetBatchLoader:OnAssetCompleted(handle)
    handle:Completed("-",self.assetCompletedFunc)

    local loadInfo = self.handleInfos[handle]
    self.handleInfos[handle] = nil
    if not loadInfo then
        return
    end

    loadInfo.status = handle.Status
    loadInfo.error = handle.Error
    if handle.Status == EOperationStatus.Succeeded then
        loadInfo.asset = handle.AssetObject
    else
        self.hasError = true
        loadInfo.asset = nil
        LogErrorf("AssetBatchLoader加载失败[file:%s][error:%s]",loadInfo.file,tostring(loadInfo.error))
        self.scope:Release(handle)
        loadInfo.handle = nil
    end

    self.loadCompleteNum = self.loadCompleteNum + 1
    if not self.isCancel and self.onAssetComplete then
        table.insert(self.pendingAssetCompletes,loadInfo)
        self:ScheduleCallbacks()
    end

    if self.loadCompleteNum < self.loadNum then
        return
    end

    self.isLoading = false
    if not self.isCancel then
        self.completePending = true
        self:ScheduleCallbacks()
    end
end

-- YooAsset 对已完成的 handle 会在注册 Completed 时立即回调。
-- 统一延迟业务回调，避免 Load 调用栈重入尚未完成的业务初始化流程。
function AssetBatchLoader:ScheduleCallbacks()
    if self.delFlag or self.callbackTimer then
        return
    end
    if not self.completePending and #self.pendingAssetCompletes <= 0 then
        return
    end

    self.callbackTimer = TimerManager.Instance:AddTimerByNextFrame(1,0,self:ToFunc("DispatchCallbacks"))
end

function AssetBatchLoader:DispatchCallbacks()
    self.callbackTimer = nil
    if self.delFlag or self.isCancel then
        return
    end

    local pendingAssetCompletes = self.pendingAssetCompletes
    self.pendingAssetCompletes = {}
    for _,loadInfo in ipairs(pendingAssetCompletes) do
        if self.onAssetComplete then
            self.onAssetComplete(loadInfo.file,loadInfo)
        end
        if self.delFlag or self.isCancel then
            return
        end
    end

    if self.completePending then
        self.completePending = false
        self:LoadComplete()
    end
end

function AssetBatchLoader:LoadComplete()
    if not self.onComplete then
        return
    end

    local onComplete = self.onComplete
    self.onComplete = nil
    onComplete(self.args,self.hasError,self.loadAssets)
end

function AssetBatchLoader:GetLoadInfo(file)
    local index = self.assetIndexs[file]
    return index and self.loadAssets[index] or nil
end

function AssetBatchLoader:GetAsset(file)
    if self.isLoading then
        LogErrorf("资源正在加载中[%s]",tostring(file))
        return nil
    end

    local loadInfo = self:GetLoadInfo(file)
    if not loadInfo then
        LogErrorf("资源不存在[%s]",tostring(file))
        return nil
    end

    return loadInfo.asset,loadInfo.type
end

function AssetBatchLoader:Instantiate(file,parent,instantiateInWorldSpace)
    local loadInfo = self:GetLoadInfo(file)
    if not loadInfo or not loadInfo.asset then
        LogErrorf("Prefab不存在[%s]",tostring(file))
        return nil
    end
    if loadInfo.type ~= AssetType.Prefab then
        LogErrorf("资源不是Prefab[%s]",tostring(file))
        return nil
    end

    if instantiateInWorldSpace == nil then
        return GameObject.Instantiate(loadInfo.asset,parent)
    end
    return GameObject.Instantiate(loadInfo.asset,parent,instantiateInWorldSpace)
end

function AssetBatchLoader:GetAssetByIndex(index)
    local loadInfo = self.loadAssets[index]
    if not loadInfo then
        LogErrorf("不存在index索引资源[%s]",tostring(index))
        return nil
    end
    return self:GetAsset(loadInfo.file),loadInfo.file
end

function AssetBatchLoader:GetAssetByFlag(flag)
    local file = self.assetFlagFiles[flag]
    if not file then
        LogErrorf("不存在flag索引资源[%s]",tostring(flag))
        return nil
    end
    return self:GetAsset(file),file
end

function AssetBatchLoader:GetFile(index)
    return self.loadAssets[index].file
end

function AssetBatchLoader:HasFile(file)
    return self.assetIndexs[file] ~= nil
end

function AssetBatchLoader:HasError()
    return self.hasError
end

function AssetBatchLoader:GetProgress()
    if self.loadNum == 0 then
        return 1
    end
    return self.loadCompleteNum / self.loadNum
end

function AssetBatchLoader:IsComplete()
    return self.loadStarted and self.loadCompleteNum >= self.loadNum
end

function AssetBatchLoader:Destroy()
    if self.delFlag then
        return
    end

    self.isCancel = true
    if self.callbackTimer then
        TimerManager.Instance:RemoveTimer(self.callbackTimer)
        self.callbackTimer = nil
    end
    for handle,_ in pairs(self.handleInfos) do
        if handle.IsValid then
            handle:Completed("-",self.assetCompletedFunc)
        end
    end

    self.handleInfos = {}
    self.pendingAssetCompletes = {}
    self.completePending = false
    self.onComplete = nil
    self.onAssetComplete = nil
    self.scope = nil
    self.isLoading = false
    self.delFlag = true
    self:Delete()
end
