AssetLoaderDefine = StaticClass("AssetLoaderDefine")

-- 资源类型
AssetType =
{
    Prefab = typeof(GameObject),
    Object = typeof(Object),
    Sprite = typeof(Sprite),
    AudioClip = typeof(AudioClip),
    Texture2D = typeof(Texture2D),
    VideoClip = typeof(VideoClip),
    Mat = typeof(Material)
}

AssetPriority = 
{
    Low = 0,
    Medium = 500,
    High = 1000,
}
