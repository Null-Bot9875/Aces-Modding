AssetPath = SingleClass("AssetPath")

AssetPath.uiTexPathCache = {}

AssetPath.shader = "shader"

AssetPath.cursor = "mixed/cursor/512.png"
AssetPath.cursorEye = "mixed/cursor/eye.png"
AssetPath.commonAtlas1 = "ui/texture/common1"

-- AssetPath.font1 = "font/source_han_serif_medium.ttc"
-- AssetPath.font2 = "font/digital.ttf"

AssetPath.pv1 = "video/pv_1.mp4"

-- Prefab
AssetPath.windowParent = "ui/mixed/window_parent.prefab"
AssetPath.adaptiveHeightMask = "ui/mixed/adaptive_height_mask.prefab"
AssetPath.panelParent = "ui/mixed/panel_parent.prefab"
AssetPath.uiunitTemplate = "ui/mixed/ui_unit_template.prefab"

AssetPath.choiceDescTemplate = "ui/prefab/rich_text/choice_desc_template.prefab"
AssetPath.cardDescTemplate = "ui/prefab/rich_text/card_desc_template.prefab"


AssetPath.simpleBattlePropItem = "ui/prefab/pve_rogue/simple_battle_prop_item.prefab"
AssetPath.simpleChipItem = "ui/prefab/pve_rogue/simple_chip_item.prefab"
AssetPath.simpleCardItem = "ui/prefab/pve_rogue/simple_card_item.prefab"
AssetPath.simpleHeroItem = "ui/prefab/pve_rogue/simple_hero_item.prefab"
-- AssetPath.abilityCard = "ui/prefab/common/ability_card_item.prefab"
AssetPath.detailCardView = "ui/prefab/common/card_detail_view.prefab"
AssetPath.propItem = "ui/prefab/prop/prop_item.prefab"
AssetPath.propCardItem = "ui/prefab/prop/prop_card_item.prefab"
AssetPath.propMechaItem = "ui/prefab/prop/prop_mecha_item.prefab"
AssetPath.propDetailView = "ui/prefab/bag/prop_detail_view.prefab"
AssetPath.rogueNodeItem = "ui/prefab/pve_rogue/pve_rogue_node_item.prefab"
AssetPath.heroItem = "ui/prefab/pve_rogue/hero_item.prefab"
AssetPath.playerInfo = "ui/prefab/common/player_info.prefab"
-- AssetPath.rogueBattlePropCardItem = "ui/prefab/pve_rogue/pve_rogue_battle_prop_item.prefab"

-- card
AssetPath.battlePropCardItem = "ui/prefab/card/prop_card_item.prefab"
AssetPath.rogueChipCardItem = "ui/prefab/card/chip_card_item.prefab"
AssetPath.tacticCard = "ui/prefab/card/tactic_card_item.prefab"
AssetPath.deviceCard = "ui/prefab/card/device_card_item.prefab"
AssetPath.deviceDroneCard = "ui/prefab/card/device_drone_card_item.prefab"
AssetPath.mechaCard = "ui/prefab/card/mecha_card_item.prefab"
AssetPath.heroCard = "ui/prefab/card/new_hero_card_item.prefab"

AssetPath.rt_ui_object = "ui/mixed/rt_ui_object.prefab"
-- AssetPath.armItem = "ui/prefab/arm/arm_item.prefab"

AssetPath.guideView = "ui/prefab/guide/guide_view.prefab"

AssetPath.horizontaPageContainer = "ui/prefab/common/horizontal_page_container.prefab"
AssetPath.template = "ui/mixed/template.prefab"


AssetPath.rogueResultCamera = "ui/prefab/pve_rogue/pve_rogue_result_window_camera.prefab"
AssetPath.cardCustomUnlockNotifyView = "ui/prefab/pve_rogue/card_custom_unlock_notify_view.prefab"

AssetPath.matchuiSceneNode = "ui/mixed/matchui_scene_node.prefab"
AssetPath.matchuiScene = "scene/match/match.prefab"

AssetPath.descriptionTipsView = "ui/prefab/common/description_tips_view.prefab"
AssetPath.cardDetailTipsView = "ui/prefab/common/card_detail_tips_view.prefab"

AssetPath.guidePicWindow = "ui/prefab/guide/guide_picture_window.prefab"


AssetPath.Matholographic06 = "effect/prefab/mat_holographic_06.prefab"
AssetPath.Matholographic07 = "effect/prefab/mat_holographic_07.prefab"
AssetPath.Matholographic08 = "effect/prefab/mat_holographic_08.prefab"

AssetPath.matMechaScan01 = "effect/prefab/mat_mechascan_01.prefab"
AssetPath.matMechaScan02 = "effect/prefab/mat_mechascan_02.prefab"
AssetPath.matMechaScan03 = "effect/prefab/mat_mechascan_03.prefab"
AssetPath.matMechaScan04 = "effect/prefab/mat_mechascan_04.prefab"

AssetPath.timelinePreloadMats = "effect/prefab/timeline_preload_mats.prefab"

AssetPath.commonButton1 = "ui/prefab/common/common_button_1.prefab"
AssetPath.commonButton2 = "ui/prefab/common/common_button_2.prefab"
AssetPath.commonButton3 = "ui/prefab/common/common_button_3.prefab"
AssetPath.commonButton4 = "ui/prefab/common/common_button_4.prefab"
AssetPath.commonButton5 = "ui/prefab/common/common_button_5.prefab"
AssetPath.commonButton6 = "ui/prefab/common/common_button_6.prefab"

AssetPath.cardKeywordView = "ui/prefab/common/card_keyword_view.prefab"

-- AssetPath.enemyMechaDetail = "ui/prefab/battle/pvp_mecha_enemy_detail_panel.prefab"
-- AssetPath.selfMehcaDetail = "ui/prefab/battle/pvp_mecha_self_detail_panel.prefab"

function AssetPath.GetAchievementIcon(iconId)
    return string.format("ui/icon/achievement/%s.png", iconId)
end

function AssetPath.GetPv(pvPath)
    return string.format("mixed/story/%s.prefab", pvPath)
end

function AssetPath.GetAudioByBgm(audioId)
    return string.format("sound/bgm/%s.wav", audioId)
end

function AssetPath.GetAudioByUI(audioId)
    return string.format("sound/ui/%s.wav", audioId)
end

function AssetPath.GetAudioByCommom(audioId)
    return string.format("audio/common/%s.ogg", audioId)
end

function AssetPath.GetAudioByCarrier(audioId)
    return string.format("sound/carrier/%s.wav", audioId)
end

function AssetPath.GetAudioByScene(audioId)
    return string.format("sound/battle/%s.wav", audioId)
end

-- function AssetPath.GetBattleItemIcon(iconId)
--     return string.format("ui/icon/item/%s.png", iconId)
-- end

function AssetPath.GetTile(iconId)
    return string.format("ui/icon/tiles/%s.png", iconId)
end

function AssetPath.GetCardIcon(iconId)
    if type(iconId) == "string" and string.sub(iconId, 1, 6) == "mod://" then
        return iconId
    end
    return string.format("ui/icon/card/%s.png", iconId)
end

-- 从卡牌 id（card_def 的 cardId）映射到资源 id（assetId）；不存在或无 assetId 时返回 nil
function AssetPath.GetCardAssetId(cardId)
    local conf = Config.Get("card_def", "config", "cardId", cardId)
    if not conf or not conf.assetId then
        return nil
    end
    return conf.assetId
end

-- 从卡牌 id 直接得到卡牌图标路径；不存在时返回 nil
function AssetPath.GetCardIconByCardId(cardId)
    local assetId = AssetPath.GetCardAssetId(cardId)
    if not assetId then
        return nil
    end
    return AssetPath.GetCardIcon(assetId)
end

function AssetPath.GetActionChain(iconId)
    return string.format("ui/icon/action_chain/%s.png", iconId)
end

function AssetPath.GetActionChainBlur(iconId)
    return string.format("ui/icon/action_chain/%s_blur.png", iconId)    
end

function AssetPath.GetCardSquareIcon(assetId)
    if type(assetId) == "string" and string.sub(assetId, 1, 6) == "mod://" then
        return assetId
    end
    return string.format("ui/icon/card_square_icon/%s.png", assetId)
end

-- function AssetPath.GetStaticIcon(assetId)
--     return string.format("ui/icon/static_icon/%s.png", assetId)
-- end

function AssetPath.GetMechaIcon(assetId)
    return string.format("ui/icon/mecha/main_mecha/%s.png", assetId)
end

function AssetPath.GetMechaIconImage(assetId)
    return string.format("ui/icon/mecha/mecha_image/%s.png", assetId)
end

function AssetPath.GetMechaIconDeckInfo(assetId)
    return string.format("ui/icon/mecha/mecha_in_deck_info/%s.png", assetId)
end

function AssetPath.GetMechaIconByReconstruction(assetId)
    return string.format("ui/icon/mecha/mecha_reconstruction/%s.png", assetId)
end


function AssetPath.GetPveChallengeSmallMechaIcon(assetId)
    return string.format("ui/icon/mecha/pve_challenge_small_mecha/%s.png", assetId)
end


function AssetPath.GetOptionExtraBg(assetId)
    return string.format("ui/icon/option_extra_bg/%s.png", assetId)
end


-- function AssetPath.GetCardDeckRareIcon(assetId)
--     return string.format("ui/texture/card_deck/card_deck_select_window/%s.png", assetId)
-- end

-- function AssetPath.GetMechaIconSelect(assetId)
--     return string.format("ui/icon/mecha/mecha_in_select/%s.png", assetId)
-- end

function AssetPath.GetMechaInfoIcon(assetId)
    return string.format("ui/icon/mecha/mecha_info_icon/%s.png", assetId)
end

function AssetPath.GetMechaIconInSelect(assetId)
    return string.format("ui/icon/mecha/square_mecha/%s.png", assetId)
end

function AssetPath.GetMechaIconInEdit(assetId)
    return string.format("ui/icon/mecha/mecha_in_edit/%s.png", assetId)
end

function AssetPath.GetMechaIconInPveRogueResult(assetId)
    return string.format("ui/icon/mecha/mecha_in_pve_rogue_result/%s.png", assetId)
end

function AssetPath.GetKeywordIcon(assetId)
    return string.format("ui/icon/keyword/%s.png", assetId)
end

function AssetPath.GetDeviceTokenIcon(assetId)
    return string.format("ui/icon/token/%s.png", assetId)
end

function AssetPath.GetBattleSkillIcon(camp, assetId)
    if camp == BattleDefine.Camp.self then
        return string.format("ui/icon/battle_skill/%s_self.png", assetId)
    else
        return string.format("ui/icon/battle_skill/%s_enemy.png", assetId)
    end
end

function AssetPath.GetEPTitleIcon(assetId)
    return string.format("ui/icon/ep_title/%s.png", assetId)
end

function AssetPath.GetEventNodeBack(assetId)
    return string.format("ui/icon/event_node_back/%s.png", assetId)
end

function AssetPath.GetActBack(assetId)
    return string.format("ui/icon/act/%s.png", assetId)
end

function AssetPath.GetDeviceActiveBack(colorType)
    return string.format("ui/icon/card_color/device_active_back/%s.png", colorType)
end

function AssetPath.GetMechaBattleIcon(assetId)
    return string.format("ui/icon/mecha/mecha_in_battle_info/%s.png", assetId)
end

function AssetPath.GetRareIcon(rareType)
    return string.format("ui/icon/rare_icon/rare_%s.png", rareType)
end


function AssetPath.GetCardDeckRareIcon(assetId)
    return string.format("ui/icon/card_deck/%s.png", assetId)
end

function AssetPath.GetDeckRareBack(rareType)
    return string.format("ui/icon/rare_back/deck_back_%s.png", rareType)
end

function AssetPath.GetDeckEditRareBack(rareType)
    return string.format("ui/icon/rare_back/deck_edit_%s.png", rareType)
    
end

function AssetPath.GetDeckRareFrame(rareType)
    return string.format("ui/icon/rare_back/deck_frame_%s.png", rareType)
end

function AssetPath.GetDeviceFrameColor(colorType)
    return string.format("ui/icon/card_color/device_frame_color/%s.png", colorType)
end

function AssetPath.GetEditCardDetailColor(colorType)
    return string.format("ui/icon/card_color/card_edit_detail_color/%s.png", colorType)    
end

function AssetPath.GetGuideIcon(assetId)
    return string.format("ui/icon/guide/%s.png", assetId)
end

function AssetPath.GetGuideTexture(assetId)
    return string.format("ui/single/guide/%s.png", assetId)
end

function AssetPath.GetCardTextColor(colorType)
    return string.format("ui/icon/card_color/card_text_color/color_%s.png", colorType)
end

function AssetPath.GetTacticFrameColor(colorType)
    return string.format("ui/icon/card_color/tactic_frame_color/%s.png", colorType)
end

function AssetPath.GetDeviceCardBackColor(colorType)
    return string.format("ui/icon/color_device/back_%s.png", colorType)
end

function AssetPath.GetDeviceCardBackSRColor(colorType)
    return string.format("ui/icon/color_device/back_sr_%s.png", colorType)
end

function AssetPath.GetTacitcCardBottomColor(colorType)
    return string.format("ui/icon/color_tactic/bottom_%s.png", colorType)
end

function AssetPath.GetTacitcCardFrame(colorType)
    return string.format("ui/icon/color_tactic/frame_%s.png", colorType)
end 

function AssetPath.GetTacitcCardIconColor(colorType)
    return string.format("ui/icon/color_tactic/icon_back_%s.png", colorType)
end 

function AssetPath.GetCardIconColor(colorType)
    return string.format("ui/icon/card_color/card_icon_color/%s.png", colorType)
end

function AssetPath.GetDeviceCardIconColor(colorType)
    return string.format("ui/icon/card_color/device_icon_color/%s.png", colorType)
end

function AssetPath.GetCardRoughItemColor(colorType)
    return string.format("ui/icon/card_color/card_rough_item/color_%s.png", colorType)
end

function AssetPath.GetLongColor(colorType)
    return string.format("ui/icon/card_color/long_color/color_%s.png", colorType)
end

function AssetPath.GetEditLongCardRareBack(rareType)
    return string.format("ui/icon/rare_back/long_back_%s.png", rareType)
    
end

function AssetPath.GetDeviceTopItemIcon(assetId)
    return string.format("ui/icon/top_item_device/%s.png", assetId)
end

-- function AssetPath.GetAttrTopItemIcon(assetId)
--     return string.format("ui/icon/top_item_buff/%s.png", assetId)
-- end

-- function AssetPath.GetStaticTopItemIcon(assetId)
--     return string.format("ui/icon/top_item_buff/%s.png", assetId)
-- end

function AssetPath.GetEventOptionIcon(assetId)
    return string.format("ui/icon/pve_option/%s.png", assetId)
end

function AssetPath.GetBattleIcon(assetId)
    return string.format("ui/icon/battle/%s.png", assetId)
end

function AssetPath.GetCardBack(rareType)
    return string.format("ui/icon/rare_back/back_%s.png", rareType)
end

function AssetPath.GetDeviceCardBack(rareType)
    return string.format("ui/icon/rare_back/back_device_%s.png", rareType)
end

function AssetPath.GetSquareCardBack(rareType)
    return string.format("ui/icon/rare_back/back_square_%s.png", rareType)
end

function AssetPath.GetHeadIconPath(headId)
    return string.format("ui/icon/head/head_%s.png", headId)
end

function AssetPath.GetHeroHeadIconPath(assetId)
    return string.format("ui/icon/hero_head_icon/%s.png", assetId)
end

function AssetPath.GetPveChallengeActIconPath(assetId)
    return string.format("ui/icon/pve_challenge_bg/challenge_act_%s.png", assetId)
end


function AssetPath.GetBaseChallengePath(assetId)
    return string.format("ui/texture/pve_base_challenge_window/%s.png", assetId)
end

function AssetPath.GetPveRogueMapNodeIconPath(assetId)
    return string.format("ui/single/pve_rogue/%s.png", assetId)
end


function AssetPath.GetPropIcon(itemId)
    local itemCfg = Config.Get("item_def", "config", "id", itemId)
    if not itemCfg then
        LogError(string.format("not exist item_def, id : %s", itemId))
        return
    end
    return string.format("ui/icon/prop/%s.png", itemCfg.assetId)
end

function AssetPath.GetPropQuailityIcon(quality)
    return string.format("ui/texture/prop/quality_bg_%s.png", quality)
end

function AssetPath.GetPropQuailityDiIcon(quality)
    return string.format("ui/texture/prop/quality_di_%s.png", quality)
end

function AssetPath.GetPropQuailityLineIcon(quality)
    return string.format("ui/texture/prop/quality_line_%s.png", quality)
end

function AssetPath.GetShopItem(id)
    return string.format("ui/icon/shop_item/%s.png", id)
end

function AssetPath.GetMechaDetailIcon(assetId)
    return string.format("ui/icon/mecha/battle_mecha_detail/%s.png", assetId)
end

function AssetPath.GetCardShowBack(camp)
    local campStr = camp == BattleDefine.Camp.self and "self" or "enemy"
    return string.format("ui/icon/battle/card_show_back_%s.png", campStr)    
end

function AssetPath.GetMechaInSelectMecha(assetId)
    return string.format("ui/icon/mecha/mecha_in_select_mecha/%s.png", assetId)    
end

function AssetPath.GetMechaByStatement(assetId)
    return string.format("ui/icon/mecha/battle_mecha_statement/%s.png", assetId)    
end

function AssetPath.GetCardSquareColor(colorType)
    return string.format("ui/icon/card_color/card_square_color/color_%s.png", colorType)    
end

function AssetPath.GetCardSquareColor1(colorType)
    return string.format("ui/icon/card_color/card_square_color1/color_%s.png", colorType)    
end

function AssetPath.GetCardItemInEditColor(colorType)
    return string.format("ui/icon/card_color/card_item_in_edit/%s.png", colorType)    
end

function AssetPath.GetBattleRecordHeadIcon(assetId)
    return string.format("ui/icon/battle_record_head_icon/%s.png", assetId)    
end

function AssetPath.GetPropQuailityIcon2(assetId)
    return string.format("ui/icon/prop_quality/%s.png", assetId)    
end

function AssetPath.GetRankIcon(assetId)
    return string.format("ui/icon/rank_icon/%s.png", assetId)
end

function AssetPath.GetRankBackIcon(assetId)
    return string.format("ui/icon/rank_icon_back/%s.png", assetId)
end

function AssetPath.GetDialogQualityLineIcon(quality)
    return string.format("ui/icon/dialog_up_quality/dialog_up_line_%s.png", quality)
end

function AssetPath.GetDialogQualityLightIcon(quality)
    return string.format("ui/icon/dialog_up_quality/dialog_guang_%s.png", quality)
end

function AssetPath.GetCardDeviceColorSprite(type)
    return string.format("ui/icon/card_color/card_base_tactic/%s.png", type)
end

function AssetPath.GetDailyMechaIcon(type)
    return string.format("ui/icon/mecha/pve_daily_challenge_mecha/%s.png", type)
end

function AssetPath.GetLogMechaIcon(assetId)
    return string.format("ui/icon/mecha/log_mecha/%s.png", assetId)
end

function AssetPath.GetSystemHelpIcon(assetId)
    return string.format("ui/icon/system_help/%s.png", assetId)
end

function AssetPath.GetCheckinWeeklyIcon(assetId)
    return string.format("ui/icon/check_in_weekly/%s.png", assetId)
end


function AssetPath.GetPveRogueSelectRewardIcon(assetId)
    return string.format("ui/texture/pve_rogue/pve_rogue_select_reward_list_window/%s.png", assetId) 
end

function AssetPath.GetPveRogueLineSprite(assetId)
    return string.format("ui/texture/pve_rogue/pve_rogue_map_window/%s.png", assetId)     
end

function AssetPath.GetArmSprite(assetId)
    return string.format("ui/texture/arm/%s.png", assetId)     
end

function AssetPath.GetArmIcon(assetId)
    return string.format("ui/icon/arm/%s.png", assetId)     
end

function AssetPath.GetSimpleCardBackColor(colorType)
    return string.format("ui/texture/card/card_common/kuang_%s.png", colorType)
end

function AssetPath.GetCardSmallIcon(assetId)
    return string.format("ui/icon/card_small/%s.png", assetId)
end

function AssetPath.GetArmItemIcon(assetId)
    return string.format("ui/icon/arm_item/%s.png", assetId)
end


function AssetPath.GetArmItemIcon2(assetId)
    return string.format("ui/icon/arm_item2/%s.png", assetId)
end

function AssetPath.GetPveRogueShopSprite(assetId)
    return string.format("ui/texture/pve_rogue/pve_rogue_shop_window/%s.png", assetId)
end

function AssetPath.GetSimpleCardTexture(assetId)
    return string.format("ui/texture/simple_card_item/%s.png", assetId)
end


function AssetPath.GetBattleLoadBgPath(assetId)
    return string.format("ui/single/mecha_logo/%s.png", assetId)
end

function UITex(path)
    if not AssetPath.uiTexPathCache[path] then
        AssetPath.uiTexPathCache[path] = "ui/texture/" .. path .. ".png"
    end
    return AssetPath.uiTexPathCache[path]
end

function AssetPath.GetChanlleMechaIcon(assetId)
    return string.format("ui/icon/pve/%s.png", assetId)
end

function AssetPath.GetRichtextIcon(assetId)
    return string.format("ui/icon/rich_text/%s.png", assetId)    
end

function AssetPath.GetItemIconPath(assetId)
    return string.format("ui/icon/chip_icon/%s.png", assetId)    
end

function AssetPath.GetChipTexturePath(assetId)
    return string.format("ui/texture/chip/%s.png", assetId)    
end


function AssetPath.GetBattleItemTexurePath(assetId)
    return string.format("ui/texture/pve_rogue/battle_prop_item/%s.png", assetId)    
end
function AssetPath.GetBattleItemIconPath(assetId)
    return string.format("ui/icon/battle_item_icon/%s.png", assetId)    
end

function AssetPath.GetBattleItemRewardIconPath(assetId)
    return string.format("ui/icon/battle_item_reward/%s.png", assetId)    
end

function AssetPath.GetChipRewardIconPath(assetId)
    return string.format("ui/icon/chip_reward/%s.png", assetId)    
end

-- color 1.绿色 2. 红色 4.蓝色 8.白色 16.黄色
function AssetPath.GetPropCardBackColor1(colorType)
    return string.format("ui/icon/card_color/prop_color/prop_color_1_%s.png", colorType)
end

function AssetPath.GetPropCardBackColor2(colorType)
    return string.format("ui/icon/card_color/prop_color/prop_color_2_%s.png", colorType)
end

function AssetPath.GetPropCardBackColor3(colorType)
    return string.format("ui/icon/card_color/prop_color/prop_color_3_%s.png", colorType)
end

function AssetPath.GetChipCardBackColor1(colorType)
    return string.format("ui/icon/card_color/chip_color/chip_back_color_1_%s.png", colorType)
end

function AssetPath.GetChipCardBackColor2(colorType)
    return string.format("ui/icon/card_color/chip_color/chip_back_color_2_%s.png", colorType)
end

function AssetPath.GetChipCardBackColor3(colorType)
    return string.format("ui/icon/card_color/chip_color/chip_back_color_3_%s.png", colorType)
end

function AssetPath.GetDeviceCardBottomColor(colorType)
    return string.format("ui/icon/card_color/device_color/device_color_bottom_%s.png", colorType)
end

function AssetPath.GetDeviceCardTopColor(colorType)
    return string.format("ui/icon/card_color/device_color/device_color_top_%s.png", colorType)
end

function AssetPath.GetDeviceStackColor(colorType)
    return string.format("ui/icon/card_color/device_color/device_stack_color_top_%s.png", colorType)
end

function AssetPath.GetMechaCardTopColor(colorType)
    return string.format("ui/icon/card_color/mecha_color/mecha_color_top_%s.png", colorType)
end

-- TODO 先用这个临时路径下的图片
function AssetPath.GetBattleMainIcon(assetId)
    -- return string.format("ui/icon/mecha/battle_mecha_card_pool_reset/%s.png", assetId)
    return string.format("ui/icon/mecha/battle_main/%s.png", assetId)
end

function AssetPath.GetTacticCardTopColor(colorType)
    return string.format("ui/icon/card_color/tactic_color/tactic_top_color_%s.png", colorType)
end

function AssetPath.GetTacticCardBottomColor(colorType)
    return string.format("ui/icon/card_color/tactic_color/tactic_bottom_color_%s.png", colorType)
end

function AssetPath.GetTacticCardIconBack(colorType)
    return string.format("ui/icon/card_color/tactic_color/tactic_icon_back_%s.png", colorType)
end

function AssetPath.GetActInnerIconPath(index)
    return string.format("ui/icon/battle_main_act_item/icon%s_inner.png", index)
end

function AssetPath.GetActGridIconPath(index)
    return string.format("ui/icon/battle_main_act_item/icon%s_grid.png", index)
end

function AssetPath.GetHeroCampBack1(camp)
    return string.format("ui/icon/hero_camp/back_1_camp_%s.png", camp)
end

function AssetPath.GetHeroCampBack2(camp)
    return string.format("ui/icon/hero_camp/back_2_camp_%s.png", camp)
end

function AssetPath.GetOptionIconPath(assetId)
    return string.format("ui/icon/pve_rogue_option_icon/%s.png", assetId)
end

function AssetPath.GetHeroIconPath(assetId)
    return string.format("ui/icon/hero_icon/%s.png", assetId)
end

function AssetPath.GetBattleDeviceTopHeroIcon(assetId)
    return string.format("ui/icon/battle_device_top_hero/%s.png", assetId)
end

function AssetPath.GetDeviceStackIcon(assetId)
    return string.format("ui/icon/device_stack_icon/%s.png", assetId)
end

function AssetPath.GetRogueNodeIcon(assetId)
    return string.format("ui/texture/pve_rogue/new_pve_rogue_map_window/%s.png", assetId)
end

-- 获取 Rogue 节点的渐变色贴图
function AssetPath.GetRogueNodeGradient(assetId)
    return string.format("ui/texture/pve_rogue/new_pve_rogue_map_window/%s.png", assetId)
end
--图集映射
----------------------------------------------
AssetPath.cardBackSprite = UITex("common1/card/1")

-- 类型(颜色 1.白色 2.红色 3.绿色 4.蓝色 5.黄色
AssetPath.ArmIcon =
{
    [1] = UITex("battle/main/arm_8"),
    [2] = UITex("battle/main/arm_2"),
    [3] = UITex("battle/main/arm_1"),
    [4] = UITex("battle/main/arm_4"),
    [5] = UITex("battle/main/arm_16"),
}

AssetPath.GetBuffBackIcon = 
{
    [BattleDefine.Camp.self] = 
    {
        [BattleDefine.Camp.self] = UITex("battle/buff/self_back_src_self_1"),
        [BattleDefine.Camp.enemy] = UITex("battle/buff/self_back_src_enemy_1"),
    },
    [BattleDefine.Camp.enemy] = 
    {
        [BattleDefine.Camp.self] = UITex("battle/buff/enemy_back_src_self_1"),
        [BattleDefine.Camp.enemy] = UITex("battle/buff/enemy_back_src_enemy_1"),
    },
}

AssetPath.DeviceIcon =
{
    [KvData.DeviceType.none]     = UITex("battle/new_main/device_icon_8"),
    [KvData.DeviceType.engine]   = UITex("battle/new_main/device_icon_1"),
    [KvData.DeviceType.armor]    = UITex("battle/new_main/device_icon_2"),
    [KvData.DeviceType.frame]    = UITex("battle/new_main/device_icon_3"),
    [KvData.DeviceType.weapon]   = UITex("battle/new_main/device_icon_4"),
    [KvData.DeviceType.extra]    = UITex("battle/new_main/device_icon_5"),
    [KvData.DeviceType.carrier1] = UITex("battle/new_main/device_icon_6"),
    [KvData.DeviceType.carrier2] = UITex("battle/new_main/device_icon_7"),
    [KvData.DeviceType.mode] = UITex("battle/new_main/device_icon_10"),
    [KvData.DeviceType.ultimate] = UITex("battle/new_main/device_icon_11"),
}

AssetPath.RichTextIcon =
{
    [RichTextDefine.Element.attack] = UITex("rich_text/card/0"),
    [RichTextDefine.Element.start] = UITex("rich_text/card/3"),
    [RichTextDefine.Element.fastStart] = UITex("rich_text/card/2"),
    [RichTextDefine.Element.energy] = UITex("rich_text/card/1"),
    [RichTextDefine.Element.token] =
    {
        ["101"] = UITex("rich_text/card/101"),
        ["102"] = UITex("rich_text/card/102"),
        ["103"] = UITex("rich_text/card/103"),
        ["104"] = UITex("rich_text/card/104"),
        ["105"] = UITex("rich_text/card/105"),
        ["106"] = UITex("rich_text/card/106"),
        ["107"] = UITex("rich_text/card/107"),
    },
    [RichTextDefine.Element.lastingEffect] =  UITex("rich_text/card/108"),
    [RichTextDefine.Element.hp] =  UITex("rich_text/card/9"),
}

AssetPath.SimpleCardType =
{
    [KvData.DeviceType.engine]  = UITex("pve/card_rough_item/icon_engine_1"),
    [KvData.DeviceType.armor]   = UITex("pve/card_rough_item/icon_armor_2"),
    [KvData.DeviceType.frame]   = UITex("pve/card_rough_item/icon_frame_3"),
    [KvData.DeviceType.weapon]  = UITex("pve/card_rough_item/icon_weapon_4"),
    [KvData.DeviceType.extra]   = UITex("pve/card_rough_item/icon_extra_5"),
    [KvData.DeviceType.carrier1] = UITex("pve/card_rough_item/icon_carrier1_6"),
    [KvData.DeviceType.carrier2] = UITex("pve/card_rough_item/icon_carrier2_7"),
    [KvData.DeviceType.mode] = UITex("pve/card_rough_item/icon_mode_8"),
    [KvData.DeviceType.ultimate] = UITex("pve/card_rough_item/icon_ultimate_9"),
}

AssetPath.EffectColor =
{
    [BattleDefine.CardType.green]        = "green",  -- 绿色
    [BattleDefine.CardType.red]          ="red",  -- 红色
    [BattleDefine.CardType.blue]         = "blue",  -- 蓝色
    [BattleDefine.CardType.white]        = "white",  -- 白色
    [BattleDefine.CardType.yellow]       = "yellow", -- 黄色
    [BattleDefine.CardType.green_red]    = "green",  -- 绿红
    [BattleDefine.CardType.green_blue]   = "green",  -- 绿蓝
    [BattleDefine.CardType.green_white]  = "green",  -- 绿白
    [BattleDefine.CardType.green_yellow] = "green", -- 绿黄
    [BattleDefine.CardType.red_blue]     = "red",  -- 红蓝
    [BattleDefine.CardType.red_white]    = "red", -- 红白
    [BattleDefine.CardType.red_yellow]   = "red", -- 红黄
    [BattleDefine.CardType.blue_white]   = "blue", -- 蓝白
    [BattleDefine.CardType.blue_yellow]  = "blue", -- 蓝黄
    [BattleDefine.CardType.white_yellow] = "white", -- 白黄
}

AssetPath.HandCardSelectedEffectColor =
{
    [BattleDefine.CardType.green]        = "green",  -- 绿色
    [BattleDefine.CardType.red]          ="red",  -- 红色
    [BattleDefine.CardType.blue]         = "blue",  -- 蓝色
    [BattleDefine.CardType.white]        = "white",  -- 白色
    [BattleDefine.CardType.red_white]    = "redwhite", -- 红白
    [BattleDefine.CardType.red_blue]     = "redblue",  -- 红蓝
    [BattleDefine.CardType.green_red]    = "redgreen",  -- 绿红
    [BattleDefine.CardType.blue_white]   = "bluewhite", -- 蓝白
    [BattleDefine.CardType.green_blue]   = "bluegreen",  -- 绿蓝
    [BattleDefine.CardType.green_white]  = "greenwhite",  -- 绿白
}

AssetPath.HandCardSelectedEffectColor =
{
    [BattleDefine.CardType.green]        = "green",  -- 绿色
    [BattleDefine.CardType.red]          ="red",  -- 红色
    [BattleDefine.CardType.blue]         = "blue",  -- 蓝色
    [BattleDefine.CardType.white]        = "white",  -- 白色
    [BattleDefine.CardType.red_white]    = "redwhite", -- 红白
    [BattleDefine.CardType.red_blue]     = "redblue",  -- 红蓝
    [BattleDefine.CardType.green_red]    = "redgreen",  -- 绿红
    [BattleDefine.CardType.blue_white]   = "bluewhite", -- 蓝白
    [BattleDefine.CardType.green_blue]   = "bluegreen",  -- 绿蓝
    [BattleDefine.CardType.green_white]  = "greenwhite",  -- 绿白
}

AssetPath.WeeklyDayIcon = 
{
    [1] = UITex("check_in/check_in_weekly_reward_window/01"),
    [2] = UITex("check_in/check_in_weekly_reward_window/02"),
    [3] = UITex("check_in/check_in_weekly_reward_window/03"),
    [4] = UITex("check_in/check_in_weekly_reward_window/04"),
    [5] = UITex("check_in/check_in_weekly_reward_window/05"),
    [6] = UITex("check_in/check_in_weekly_reward_window/06"),
}

AssetPath.LibraryTypeImage = 
{
    [1] = UITex("battle/new_main/hg_102"),
    [2] = UITex("battle/new_main/hg_19"),
}
