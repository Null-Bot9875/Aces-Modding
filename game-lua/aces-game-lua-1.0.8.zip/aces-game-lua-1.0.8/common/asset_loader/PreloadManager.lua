PreloadManager = SingleClass("PreloadManager")

function PreloadManager:__Init()
    self.assetScope = AssetScope()
    self.assetLoader = nil
    self.delayAssetLoader = nil
    self.preloadAssets = {}
    self.delayPreloadAssets = {}
    self.delayLoaded = false
    self.preloadObjs = {}
    self.onComplete = nil
    self:InitPreloadAssets()
end

function PreloadManager:__Delete()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
    if self.delayAssetLoader then
        self.delayAssetLoader:Destroy()
        self.delayAssetLoader = nil
    end
    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function PreloadManager:InitPreloadAssets()
    table.insert(self.preloadAssets,{file = "ui/prefab/login/login_window_1.prefab", type = AssetType.Object})
    table.insert(self.preloadAssets,{file = "ui/prefab/pve_rogue/pve_rogue_store_window.prefab", type = AssetType.Object})
    table.insert(self.preloadAssets,{file = "ui/prefab/pve_rogue/new_pve_rogue_choice_window.prefab", type = AssetType.Object})
    table.insert(self.preloadAssets,{file = "ui/prefab/pve_rogue/pve_rogue_map_window.prefab", type = AssetType.Object})
    table.insert(self.preloadAssets,{file = "ui/prefab/battle/battle_load_window.prefab", type = AssetType.Object})

    -- 新手引导的资源
    table.insert(self.preloadAssets,{file = "ui/prefab/guide/small_guide_tips_view.prefab", type = AssetType.Object})
    table.insert(self.preloadAssets,{file = "ui/prefab/guide/guide_tips_view.prefab", type = AssetType.Object})

    table.insert(self.preloadAssets,{file = "ui/prefab/guide/guide_mask_view.prefab", type = AssetType.Object})
    table.insert(self.preloadAssets,{file = "effect/prefab/ui_playerguide_quadframe_01.prefab", type = AssetType.Object})
    table.insert(self.preloadAssets,{file = "effect/prefab/ui_playerguide_hand_01.prefab", type = AssetType.Object})
    table.insert(self.preloadAssets,{file = "effect/prefab/ui_playerguide_clicktip_01.prefab", type = AssetType.Object})
    table.insert(self.preloadAssets,{file = "effect/prefab/ui_battle_card_can_use_playguide.prefab", type = AssetType.Object})
    table.insert(self.preloadAssets,{file = "effect/prefab/ui_playerguide_clicktip_04.prefab", type = AssetType.Object})

    -- 预加载机甲模型及贴图（tm31r, ace_1_s10, ace_3）
    -- tm31r 模型和贴图
    -- table.insert(self.preloadAssets,{file = "unit/mecha/tm31r/tm31r.prefab", type = AssetType.Prefab})
    -- table.insert(self.preloadAssets,{file = "unit/mecha/tm31r/tm31r.controller", type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = "unit/mecha/tm31r/texture/engine_albedo_1.tga", type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = "unit/mecha/tm31r/texture/track_albedo_1.tga", type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = "unit/mecha/tm31r/texture/wing_albedo_1.tga", type = AssetType.Object})

    -- ace_1_s10 模型和贴图
    -- table.insert(self.preloadAssets,{file = "unit/mecha/ace_1_s10/ace_1_s10.prefab", type = AssetType.Prefab})
    -- table.insert(self.preloadAssets,{file = "unit/mecha/ace_1_s10/ace_1_s10.controller", type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = "unit/mecha/ace_1_s10/texture/engine_albedo_1.tga", type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = "unit/mecha/ace_1_s10/texture/track_albedo_1.tga", type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = "unit/mecha/ace_1_s10/texture/wing_albedo_1.tga", type = AssetType.Object})

    -- ace_3 模型和贴图
    -- table.insert(self.preloadAssets,{file = "unit/mecha/ace_3/ace_3.prefab", type = AssetType.Prefab})
    -- table.insert(self.preloadAssets,{file = "unit/mecha/ace_3/ace_3.controller", type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = "unit/mecha/ace_3/texture/engine_albedo_1.tga", type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = "unit/mecha/ace_3/texture/track_albedo_1.tga", type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = "unit/mecha/ace_3/texture/wing_albedo_1.tga", type = AssetType.Object})

    
    table.insert(self.preloadAssets,{file = AssetPath.cursor, type = AssetType.Texture2D})
    table.insert(self.preloadAssets,{file = AssetPath.cursorEye, type = AssetType.Texture2D})
    table.insert(self.preloadAssets,{file = AssetPath.windowParent, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.panelParent, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.uiunitTemplate, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.cardDescTemplate, type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = AssetPath.choiceDescTemplate, type = AssetType.Object})

    table.insert(self.preloadAssets,{file = AssetPath.tacticCard, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.deviceCard, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.deviceDroneCard, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.mechaCard, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.heroCard, type = AssetType.Object})

    -- table.insert(self.preloadAssets,{file = AssetPath.armItem, type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = AssetPath.abilityCard, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.detailCardView, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.rt_ui_object, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.guideView, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.propItem, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.propCardItem, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.propMechaItem, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.propDetailView, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.rogueNodeItem, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.heroItem, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.horizontaPageContainer, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.template, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.adaptiveHeightMask, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.playerInfo, type = AssetType.Object})

    table.insert(self.preloadAssets,{file = AssetPath.simpleCardItem, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.simpleChipItem, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.simpleHeroItem, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.simpleBattlePropItem, type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = AssetPath.enemyMechaDetail, type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = AssetPath.selfMehcaDetail, type = AssetType.Object})


    -- table.insert(self.preloadAssets,{file = AssetPath.pv1, type = AssetType.VideoClip})
    -- table.insert(self.preloadAssets,{file = AssetPath.matchuiScene, type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = AssetPath.matchuiSceneNode, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.descriptionTipsView, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.cardDetailTipsView, type = AssetType.Object})

    table.insert(self.preloadAssets,{file = AssetPath.rogueChipCardItem, type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = AssetPath.rogueBattlePropCardItem, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.battlePropCardItem, type = AssetType.Object})

    table.insert(self.preloadAssets,{file = AssetPath.commonButton1, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.commonButton2, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.commonButton3, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.commonButton4, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.commonButton5, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.commonButton6, type = AssetType.Object})

    table.insert(self.preloadAssets,{file = AssetPath.cardKeywordView, type = AssetType.Object})
    
    
    
    -- table.insert(self.preloadAssets,{file = AssetPath.Matholographic06, type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = AssetPath.Matholographic07, type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = AssetPath.Matholographic08, type = AssetType.Object})

    
    -- table.insert(self.preloadAssets,{file = AssetPath.matMechaScan01, type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = AssetPath.matMechaScan02, type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = AssetPath.matMechaScan03, type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = AssetPath.matMechaScan04, type = AssetType.Object})


    table.insert(self.preloadAssets,{file = AssetPath.timelinePreloadMats, type = AssetType.Object})
    -- table.insert(self.preloadAssets,{file = AssetPath.guidePicWindow, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.rogueResultCamera, type = AssetType.Object})
    table.insert(self.preloadAssets,{file = AssetPath.cardCustomUnlockNotifyView, type = AssetType.Object})
end

function PreloadManager:Load()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    self.assetLoader.onAssetComplete = self:ToFunc("OnAssetsComplete")
    self.assetLoader:Load(self.preloadAssets,self:ToFunc("OnComplete"))
    self:UpdateProgress()
end

function PreloadManager:DelayLoad()
    self.delayAssetLoader = AssetBatchLoader.New(self.assetScope)
    self.delayAssetLoader:Load(self.delayPreloadAssets,self:ToFunc("DelayComplete"))
end

function PreloadManager:UpdateProgress()
    local progress = self.assetLoader:GetProgress()
    -- StartWindow.Instance:SetState(string.format("预加载资源:%s%s(不消耗流量)",math.ceil( progress * 100 ),"%"))
    StartWindow.Instance:SetState(TI18N("app_pre_loading_progress",math.ceil( progress * 100 ),"%"))
    StartWindow.Instance:SetProgress(progress)
end

function PreloadManager:OnAssetsComplete(file)
    self:UpdateProgress()
end

function PreloadManager:SetComplete(cb)
    self.onComplete = cb
end

function PreloadManager:OnComplete()
    self:UpdateProgress()
    if self.onComplete then
        self.onComplete()
    end

    self:DelayLoad()
end

function PreloadManager:DelayComplete()
    self.delayLoaded = true
    EventManager.Instance:SendEvent(EventDefine.delay_preload_complete)
end

function PreloadManager:IsDelayLoaded()
    return self.delayLoaded
end

function PreloadManager:GetAsset(file)
    if not self.preloadObjs[file] then
        local assetLoader = self.assetLoader:HasFile(file) and self.assetLoader or self.delayAssetLoader
        local obj = assetLoader:GetAsset(file)
        self.preloadObjs[file] = obj
    end
    return self.preloadObjs[file]
end
