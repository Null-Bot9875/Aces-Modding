ArmTpose = BaseClass("ArmTpose")
ArmTpose.NOT_CLEAR = true

function ArmTpose:__Init()
    self.callBack = nil
    self.assetLoader = nil
    self.assetScope = nil
    self.loaded = false
    self.autoReleaser = nil
    self.setting = nil
    self.poolKey = nil
    self.isComplete = false
    self.materials = nil
end

function ArmTpose:__Delete()
    self:RemoveLoader()
    self:ReleasePendingScope()
    if self.gameObject then
        GameObject.Destroy(self.gameObject)
        self.gameObject = nil
    end

end

function ArmTpose:Load(setting,callBack)
    self.setting = setting
    self.callBack = callBack

    if self.setting.gameObject then
        self:OnLoaded()
    else
        self.modelFile = string.format("unit/arm/%s/%s.prefab",setting.modelId,setting.modelId)
        if setting.texture ~= "" then
            self.skinPath = string.format("unit/arm/%s/texture/%s.tga",setting.modelId,setting.texture)
        end
        

        local assetList = {}
        table.insert(assetList, {file = self.modelFile,type = AssetType.Prefab})
        if self.skinPath then
            table.insert(assetList, {file = self.skinPath,type = AssetType.Object})
        end
    
        self.assetScope = AssetScope()
        self.assetLoader = AssetBatchLoader.New(self.assetScope)
        self.assetLoader:Load(assetList,self:ToFunc("OnLoaded"))
    end
end


function ArmTpose:OnLoaded(_,hasError)
    if self:CancelBuildTpose() then
        return
    end
    if hasError then
        self:RemoveLoader()
        self:ReleasePendingScope()
        return
    end
    
    self:BuildModel()
    self:BuildSkin()
    self:AdoptScope()
   -- self:BuildAnim()

    self:RemoveLoader()

    self.isComplete = true
    self:TposeComplete()
end

function ArmTpose:BuildModel()
    self.gameObject = self.setting.gameObject or self.assetLoader:Instantiate(self.modelFile)
    self.gameObject:SetActive(true)
    self.transform = self.gameObject.transform
    self.renderer = self.gameObject:GetComponentInChildren(Renderer)
    self.mat = self.renderer.material
    --self.materials = self.renderer.materials

    --self.renderer.receiveShadows = false

    -- if KvData.platform == KvData.PlatformType.WebGLPlayer then
    --     self.renderer.shadowCastingMode = ShadowCastingMode.Off
    -- else
    --     self.renderer.shadowCastingMode = ShadowCastingMode.On
    -- end

    -- local matcap = PreloadManager.Instance:GetAsset(AssetPath.model_matcap)
    -- self.mat:SetTexture("_MatcapTex",matcap)
    -- self.mat:SetFloat("_OutLineWidth",0.0035)
    -- self.mat:SetColor("_OutLineColor",Color(0,0,0,0x50/0xFF))
    -- self.mat:SetFloat("_AddIns",1.0)
-- self.mat:SetColor("_Color",Color(0,0,0,1))
end

function ArmTpose:BuildSkin()
    if not self.skinPath then
        return
    end
    self.skinTex = self.assetLoader:GetAsset(self.skinPath)
    self.mat.mainTexture = self.skinTex
end

function ArmTpose:TposeComplete()
    if self.callBack then
        self.callBack(self.setting.args)
    end
end

function ArmTpose:IsComplete()
    return self.isComplete
end

function ArmTpose:CancelBuildTpose()
    if not self.isCancel then return false end
    self:RemoveLoader()
    self:Delete()
    return true
end

function ArmTpose:RemoveLoader()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function ArmTpose:OnReset()
end

function ArmTpose.GetSetting(config,args)
    local setting = {}
    setting.modelId = config.modelId
    setting.skinId = config.skinId
    setting.animId = config.animId
    setting.args = args
    return setting
end

function ArmTpose:AdoptScope()
    if self.assetScope and self.gameObject then
        self.gameObject:AddComponent(AssetScopeComponent):Adopt(self.assetScope)
        self.assetScope = nil
    end
end

function ArmTpose:ReleasePendingScope()
    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end
