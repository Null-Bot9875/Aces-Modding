DeviceTpose = BaseClass("DeviceTpose")
DeviceTpose.NOT_CLEAR = true

function DeviceTpose:__Init()
    self.callBack = nil
    self.assetLoader = nil
    self.assetScope = nil
    self.loaded = false
    self.autoReleaser = nil
    self.setting = nil
    self.poolKey = nil
    self.isComplete = false
    self.materials = nil
end

function DeviceTpose:__Delete()
    self:RemoveLoader()
    self:ReleasePendingScope()
    if self.gameObject then
        GameObject.Destroy(self.gameObject)
        self.gameObject = nil
    end

end

function DeviceTpose:Load(setting,callBack)
    self.setting = setting
    self.callBack = callBack

    if self.setting.gameObject then
        self:OnLoaded()
    else
        self.modelFile = string.format("unit/mecha/%s/%s.prefab",setting.modelId,setting.modelId)
        self.animFile = string.format("unit/mecha/%s/%s.controller",setting.modelId,setting.animId)

        local assetList = {}
        table.insert(assetList, {file = self.modelFile,type = AssetType.Prefab})
        table.insert(assetList, {file = self.animFile,type = AssetType.Object})
    
        self.assetScope = AssetScope()
        self.assetLoader = AssetBatchLoader.New(self.assetScope)
        self.assetLoader:Load(assetList,self:ToFunc("OnLoaded"))
    end
end


function DeviceTpose:OnLoaded(_,hasError)
    if self:CancelBuildTpose() then
        return
    end
    if hasError then
        self:RemoveLoader()
        self:ReleasePendingScope()
        return
    end
    
    self:BuildModel()
    if self.assetLoader then
        self:BuildSkin()
        self:BuildAnim()
        self:AdoptScope()
    else
        self.animator = self.gameObject:GetComponentInChildren(Animator)
    end

    self:RemoveLoader()

    self.isComplete = true
    self:TposeComplete()
end

function DeviceTpose:BuildModel()
    self.gameObject = self.setting.gameObject or self.assetLoader:Instantiate(self.modelFile)
    self.gameObject:SetActive(true)
    self.transform = self.gameObject.transform
    --self.renderer = self.gameObject:GetComponentInChildren(Renderer)
    --self.mat = self.renderer.material
    --self.materials = self.renderer.materials

    --self.renderer.receiveShadows = false

    -- if KvData.platform == KvData.PlatformType.WebGLPlayer then
    --     self.renderer.shadowCastingMode = ShadowCastingMode.Off
    -- else
    --     self.renderer.shadowCastingMode = ShadowCastingMode.On
    -- end

    -- local matcap = PreloadManager.Instance:GetAsset(AssetPath.model_matcap)
    -- self.mat:SetTexture("_MatcapTex",matcap)
    -- self.mat:SetFloat("_OutLineWidth",0.0035)
    -- self.mat:SetColor("_OutLineColor",Color(0,0,0,0x50/0xFF))
    -- self.mat:SetFloat("_AddIns",1.0)
-- self.mat:SetColor("_Color",Color(0,0,0,1))
end

function DeviceTpose:BuildSkin()
    -- self.engineTexFile =  string.format("unit/mecha/%s/texture/engine_%s_albedo.tga",setting.modelId,setting.texIndex)
    -- self.trackTexFile =  string.format("unit/mecha/%s/texture/track_%s_albedo.tga",setting.modelId,setting.texIndex)
    -- self.wingTexFile =  string.format("unit/mecha/%s/texture/wing_%s_albedo.tga",setting.modelId,setting.texIndex)


    --self.normalTex = self.assetLoader:GetAsset(self.normalFile)


    --self.renderer = self.gameObject:GetComponentInChildren(Renderer)
    --self.mat = self.renderer.material


    -- self.mat:SetTexture("_BaseMap",self.skinTex)
    -- self.mat:SetTexture("_MaskMap",self.maskTex)
    --self.mat:SetTexture("_BumpTex",self.normalTex)


    --local unitCubemapTex = PreloadManager.Instance:GetAsset(AssetPath.unit_cubemap)
    --self.mat:SetTexture("_CustomCubemap",unitCubemapTex)
end

function DeviceTpose:BuildAnim()
    self.animCtrl = self.assetLoader:GetAsset(self.animFile)

    self.animator = self.gameObject:GetComponentInChildren(Animator)
    self.animator.runtimeAnimatorController = self.animCtrl
end

function DeviceTpose:TposeComplete()
    if self.callBack then
        self.callBack(self.setting.args)
    end
end

function DeviceTpose:IsComplete()
    return self.isComplete
end

function DeviceTpose:CancelBuildTpose()
    if not self.isCancel then return false end
    self:RemoveLoader()
    self:Delete()
    return true
end

function DeviceTpose:RemoveLoader()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function DeviceTpose:OnReset()
end

function DeviceTpose.GetSetting(config,args)
    local setting = {}
    setting.modelId = config.modelId
    setting.skinId = config.skinId
    setting.animId = config.animId
    setting.args = args
    return setting
end

function DeviceTpose:AdoptScope()
    if self.assetScope and self.gameObject then
        self.gameObject:AddComponent(AssetScopeComponent):Adopt(self.assetScope)
        self.assetScope = nil
    end
end

function DeviceTpose:ReleasePendingScope()
    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end
