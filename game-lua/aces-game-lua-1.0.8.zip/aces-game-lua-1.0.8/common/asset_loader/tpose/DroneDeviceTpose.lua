DroneDeviceTpose = BaseClass("DroneDeviceTpose")
DroneDeviceTpose.NOT_CLEAR = true

function DroneDeviceTpose:__Init()
    self.callBack = nil
    self.assetLoader = nil
    self.assetScope = nil
    self.loaded = false
    self.autoReleaser = nil
    self.setting = nil
    self.poolKey = nil
    self.isComplete = false
    self.materials = nil

    self.extraMaterials = {}
    self.ownedMaterials = {}
    self.ownedMaterialList = {}
end

function DroneDeviceTpose:__Delete()
    self:RemoveLoader()
    self:ReleasePendingScope()
    self:ClearOwnedMaterials()

    if self.gameObject then
        GameObject.Destroy(self.gameObject)
        self.gameObject = nil
    end

end

function DroneDeviceTpose:Load(setting, callBack)
    self.setting = setting
    self.callBack = callBack

    if self.setting.gameObject then
        self:OnLoaded()
    else
        self.modelFile = string.format("unit/mecha/%s/%s.prefab", setting.modelId, setting.modelId)

        self.animFile = string.format("unit/mecha/%s/%s.controller", setting.modelId, setting.animId)
        if not AssetLoader.Instance:IsLocationValid(self.animFile) then
            self.animFile = "unit/mecha/common/common.controller"
        end

        local assetList = {}
        table.insert(assetList, { file = self.modelFile, type = AssetType.Prefab })
        table.insert(assetList, { file = self.animFile, type = AssetType.Object })

        self.assetScope = AssetScope()
        self.assetLoader = AssetBatchLoader.New(self.assetScope)
        self.assetLoader:Load(assetList, self:ToFunc("OnLoaded"))
    end
end

function DroneDeviceTpose:OnLoaded(_,hasError)
    if self:CancelBuildTpose() then
        return
    end
    if hasError then
        self:RemoveLoader()
        self:ReleasePendingScope()
        return
    end

    self:BuildModel()
    if self.assetLoader then
        self:BuildAnim()
        self:AdoptScope()
    else
        self.animator = self.gameObject:GetComponentInChildren(Animator)
    end

    for i = 1, #self.extraMaterials do
        self:AddMaterial(self.extraMaterials[i])
    end

    self:RemoveLoader()

    self.isComplete = true
    self:TposeComplete()
end

function DroneDeviceTpose:BuildModel()
    self.gameObject = self.setting.gameObject or self.assetLoader:Instantiate(self.modelFile)
    self.gameObject:SetActive(true)
    self.transform = self.gameObject.transform
end

function DroneDeviceTpose:BuildAnim()
    self.animCtrl = self.assetLoader:GetAsset(self.animFile)

    self.animator = self.gameObject:GetComponentInChildren(Animator)
    self.animator.runtimeAnimatorController = self.animCtrl
end

function DroneDeviceTpose:AdoptScope()
    if self.assetScope and self.gameObject then
        self.gameObject:AddComponent(AssetScopeComponent):Adopt(self.assetScope)
        self.assetScope = nil
    end
end

function DroneDeviceTpose:ReleasePendingScope()
    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function DroneDeviceTpose:GetAnimator()
    return self.animator
end

function DroneDeviceTpose:TrackOwnedMaterial(mat)
    if not mat or self.ownedMaterials[mat] then
        return
    end

    self.ownedMaterials[mat] = true
    table.insert(self.ownedMaterialList, mat)
end

function DroneDeviceTpose:DestroyOwnedMaterial(mat)
    if not mat or not self.ownedMaterials[mat] then
        return
    end

    self.ownedMaterials[mat] = nil
    if not BaseUtils.IsNull(mat) then
        GameObject.Destroy(mat)
    end
end

function DroneDeviceTpose:ClearOwnedMaterials()
    for _, mat in ipairs(self.ownedMaterialList) do
        self:DestroyOwnedMaterial(mat)
    end

    self.ownedMaterials = {}
    self.ownedMaterialList = {}
end

function DroneDeviceTpose:TposeComplete()
    if self.callBack then
        self.callBack(self.setting.args)
    end
end

function DroneDeviceTpose:IsComplete()
    return self.isComplete
end

function DroneDeviceTpose:CancelBuildTpose()
    if not self.isCancel then return false end
    self:RemoveLoader()
    self:Delete()
    return true
end

function DroneDeviceTpose:RemoveLoader()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function DroneDeviceTpose:OnReset()
end

function DroneDeviceTpose.GetSetting(config, args)
    local setting = {}
    setting.modelId = config.modelId
    setting.skinId = config.skinId
    setting.animId = config.animId
    setting.args = args
    return setting
end

function DroneDeviceTpose:ReplaceMat(mat)
    local renderers = self.gameObject:GetComponentsInChildren(SkinnedMeshRenderer)
    for i = 0, renderers.Length - 1 do
        local renderer = renderers[i]
        local sharedMaterials = renderer.sharedMaterials
        local newMaterials = CS.System.Array.CreateInstance(typeof(CS.UnityEngine.Material), sharedMaterials.Length)
        for j = 0, sharedMaterials.Length - 1 do
            newMaterials[j] = mat
        end
        renderer.sharedMaterials = newMaterials
    end
end

function DroneDeviceTpose:AddMaterial(mat)
    if not mat then
        return
    end

    if not self.gameObject then
        return
    end

    local isAdd = false
    for i = 1, #self.extraMaterials do
        if self.extraMaterials[i].name == mat.name then
            isAdd = true
            break
        end
    end

    if not isAdd then
        table.insert(self.extraMaterials, mat)
    end

    if isAdd then
        return
    end

    local renderers = self.gameObject:GetComponentsInChildren(SkinnedMeshRenderer)
    for i = 0, renderers.Length - 1 do
        local renderer = renderers[i]
        local sharedMaterials = renderer.sharedMaterials
        local newMaterials = CS.System.Array.CreateInstance(typeof(CS.UnityEngine.Material), sharedMaterials.Length + 1)
        for j = 0, sharedMaterials.Length - 1 do
            newMaterials[j] = sharedMaterials[j]
        end

        local materialInstance = Material.Instantiate(mat)
        materialInstance.name = mat.name
        self:TrackOwnedMaterial(materialInstance)
        newMaterials[sharedMaterials.Length] = materialInstance
        renderer.sharedMaterials = newMaterials
    end
end

function DroneDeviceTpose:RemoveMaterial(name)
    local isExist = false
    for i = 1, #self.extraMaterials do
        if self.extraMaterials[i].name == name then
            isExist = true
            table.remove(self.extraMaterials, i)
            break
        end
    end

    if not isExist then
        return
    end

    if not self.gameObject then
        return
    end

    local renderers = self.gameObject:GetComponentsInChildren(SkinnedMeshRenderer)
    for i = 0, renderers.Length - 1 do
        local renderer = renderers[i]
        local sharedMaterials = renderer.sharedMaterials
        local keptMaterials = {}
        for j = 0, sharedMaterials.Length - 1 do
            local material = sharedMaterials[j]
            if material and UnityUtils.GetMatBaseName(material) == name and self.ownedMaterials[material] then
                self:DestroyOwnedMaterial(material)
            else
                table.insert(keptMaterials, material)
            end
        end

        local newMaterials = CS.System.Array.CreateInstance(typeof(CS.UnityEngine.Material), #keptMaterials)
        for j = 1, #keptMaterials do
            newMaterials[j - 1] = keptMaterials[j]
        end
        renderer.sharedMaterials = newMaterials
    end
end
