UnitTpose = BaseClass("UnitTpose")
UnitTpose.NOT_CLEAR = true

function UnitTpose:__Init()
    self.callBack = nil
    self.assetLoader = nil
    self.assetScope = nil
    self.loaded = false
    self.autoReleaser = nil
    self.setting = nil
    self.poolKey = nil
    self.isComplete = false
    self.materials = nil

    self.rendererMats = {}
    self.rendererMatMap = {}
    self.armTposeInfos = {}
end

function UnitTpose:__Delete()
    self:RemoveLoader()
    self:ReleasePendingScope()
    self:ClearRendererMaterials()

    if self.gameObject then
        GameObject.Destroy(self.gameObject)
        self.gameObject = nil
    end

    self:RemoveArmLoader()
end

function UnitTpose:Load(setting,callBack)
    self.setting = setting
    self.callBack = callBack

    if self.setting.gameObject then
        self:OnModelLoaded()
    else
        self.modelFile = string.format("unit/mecha/%s/%s.prefab",setting.modelId,setting.modelId)

        self.engineTexFile =  string.format("unit/mecha/%s/texture/engine_albedo_%s.tga",setting.modelId,setting.texIndex)
        if not AssetLoader.Instance:IsLocationValid(self.engineTexFile) then
            self.engineTexFile = nil
        end

        self.trackTexFile =  string.format("unit/mecha/%s/texture/track_albedo_%s.tga",setting.modelId,setting.texIndex)
        if not AssetLoader.Instance:IsLocationValid(self.trackTexFile) then
            self.trackTexFile = nil
        end

        self.wingTexFile =  string.format("unit/mecha/%s/texture/wing_albedo_%s.tga",setting.modelId,setting.texIndex)
        if not AssetLoader.Instance:IsLocationValid(self.wingTexFile) then
            self.wingTexFile = nil
        end

        self.animFile = string.format("unit/mecha/%s/%s.controller",setting.modelId,setting.animId)


        --self.skinFile = string.format("unit/%s/%s_albedo.tga",setting.modelId,setting.skinId)
        --self.maskFile = string.format("unit/%s/%s_mask.tga",setting.modelId,setting.skinId)
    
        local assetList = {}
        table.insert(assetList, {file = self.modelFile,type = AssetType.Prefab})

        if self.engineTexFile then
            table.insert(assetList, {file = self.engineTexFile,type = AssetType.Object})
        end

        if self.trackTexFile then
            table.insert(assetList, {file = self.trackTexFile,type = AssetType.Object})
        end

        if self.wingTexFile then
            table.insert(assetList, {file = self.wingTexFile,type = AssetType.Object})
        end

        table.insert(assetList, {file = self.animFile,type = AssetType.Object})
        --table.insert(assetList, {file = self.skinFile,type = AssetType.Object})
        --table.insert(assetList, {file = self.maskFile,type = AssetType.Object})
    
        self.assetScope = AssetScope()
        self.assetLoader = AssetBatchLoader.New(self.assetScope)
        self.assetLoader:Load(assetList,self:ToFunc("OnModelLoaded"))
        -- LogError(string.format("预加载机甲模型及贴图: %s frame: %d", self.modelFile, Time.frameCount))
    end
end


function UnitTpose:OnModelLoaded(_,hasError)
    -- LogError(string.format("预加载机甲模型及贴图完成: %s frame: %d", self.modelFile, Time.frameCount))
    if self:CancelBuildTpose() then
        return
    end
    if hasError then
        self:RemoveLoader()
        self:ReleasePendingScope()
        return
    end
    
    self:BuildModel()
    if self.assetLoader then
        self:BuildSkin()
        self:BuildAnim()
        self:AdoptScope()
    else
        self.animator = self.gameObject:GetComponentInChildren(Animator)
    end
    self:RemoveLoader()

    self:OnComplete()
end


function UnitTpose:OnComplete()
    --self:InitOutline()
    self.isComplete = true
    self:TposeComplete()
end


-- function UnitTpose:InitOutline()
--     for _,v in ipairs(self.rendererMats) do
--         v:SetFloat("_RenderOutline",0)
--         v:SetFloat("_OutlineUseReplaceColor",1)
--         v:SetColor("_OutlineReplaceColor",Color(1,1,0,1))

--         v:SetFloat("_OutlineWidth",32)
--         v:SetFloat("_OutlineWidthExtraMultiplier",2)

--         v:SetFloat("_OutlineBaseZOffset",1)
--     end
-- end

-- function UnitTpose:SetOutline(flag)
--     for _,v in ipairs(self.rendererMats) do
--         v:SetFloat("_RenderOutline",flag and 1 or 0)
--     end
-- end

function UnitTpose:BuildModel()
    self.gameObject = self.setting.gameObject or self.assetLoader:Instantiate(self.modelFile)
    self.gameObject:SetActive(true)
    self.transform = self.gameObject.transform
    --self.renderer = self.gameObject:GetComponentInChildren(Renderer)
    --self.mat = self.renderer.material
    --self.materials = self.renderer.materials

    --self.renderer.receiveShadows = false

    -- if KvData.platform == KvData.PlatformType.WebGLPlayer then
    --     self.renderer.shadowCastingMode = ShadowCastingMode.Off
    -- else
    --     self.renderer.shadowCastingMode = ShadowCastingMode.On
    -- end

    -- local matcap = PreloadManager.Instance:GetAsset(AssetPath.model_matcap)
    -- self.mat:SetTexture("_MatcapTex",matcap)
    -- self.mat:SetFloat("_OutLineWidth",0.0035)
    -- self.mat:SetColor("_OutLineColor",Color(0,0,0,0x50/0xFF))
    -- self.mat:SetFloat("_AddIns",1.0)
-- self.mat:SetColor("_Color",Color(0,0,0,1))

end

function UnitTpose:BuildSkin()
    -- self.engineTexFile =  string.format("unit/mecha/%s/texture/engine_%s_albedo.tga",setting.modelId,setting.texIndex)
    -- self.trackTexFile =  string.format("unit/mecha/%s/texture/track_%s_albedo.tga",setting.modelId,setting.texIndex)
    -- self.wingTexFile =  string.format("unit/mecha/%s/texture/wing_%s_albedo.tga",setting.modelId,setting.texIndex)

    if self.engineTexFile then
        self.engineTex = self.assetLoader:GetAsset(self.engineTexFile)
        local engineRenderer = self.transform:Find("engine").gameObject:GetComponent(Renderer)
        self:GetOrCreateRendererMaterial(engineRenderer):SetTexture("_BaseMap",self.engineTex)
    end
    

    if self.trackTexFile then
        self.trackTex = self.assetLoader:GetAsset(self.trackTexFile)

        local trackRenderer = self.transform:Find("track").gameObject:GetComponent(Renderer)
        self:GetOrCreateRendererMaterial(trackRenderer):SetTexture("_BaseMap",self.trackTex)
    end

    if self.wingTexFile then
        self.wingTex = self.assetLoader:GetAsset(self.wingTexFile)

        local wingRenderer = self.transform:Find("wing").gameObject:GetComponent(Renderer)
        self:GetOrCreateRendererMaterial(wingRenderer):SetTexture("_BaseMap",self.wingTex)
    end
   

    --self.normalTex = self.assetLoader:GetAsset(self.normalFile)


    --self.renderer = self.gameObject:GetComponentInChildren(Renderer)
    --self.mat = self.renderer.material
    


    -- self.mat:SetTexture("_BaseMap",self.skinTex)
    -- self.mat:SetTexture("_MaskMap",self.maskTex)
    --self.mat:SetTexture("_BumpTex",self.normalTex)


    --local unitCubemapTex = PreloadManager.Instance:GetAsset(AssetPath.unit_cubemap)
    --self.mat:SetTexture("_CustomCubemap",unitCubemapTex)
end

function UnitTpose:BuildAnim()
    self.animCtrl = self.assetLoader:GetAsset(self.animFile)

    self.animator = self.gameObject:GetComponentInChildren(Animator)
    self.animator.runtimeAnimatorController = self.animCtrl
end

function UnitTpose:AdoptScope()
    if self.assetScope and self.gameObject then
        self.gameObject:AddComponent(AssetScopeComponent):Adopt(self.assetScope)
        self.assetScope = nil
    end
end

function UnitTpose:ReleasePendingScope()
    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function UnitTpose:GetAnimator()
    return self.animator    
end

function UnitTpose:GetOrCreateRendererMaterial(renderer)
    if not renderer then
        return nil
    end

    local mat = self.rendererMatMap[renderer]
    if mat and not BaseUtils.IsNull(mat) then
        return mat
    end

    mat = renderer.material
    self.rendererMatMap[renderer] = mat
    table.insert(self.rendererMats, mat)
    return mat
end

function UnitTpose:ClearRendererMaterials()
    for _, mat in pairs(self.rendererMatMap) do
        if mat and not BaseUtils.IsNull(mat) then
            GameObject.Destroy(mat)
        end
    end

    self.rendererMatMap = {}
    self.rendererMats = {}
end

function UnitTpose:ActiveOutline(flag)
    if not self.gameObject then
        return
    end

    local renderers = self.gameObject:GetComponentsInChildren(Renderer)
    for i = 0, renderers.Length - 1 do
        local mat = self:GetOrCreateRendererMaterial(renderers[i])
        if mat then
            mat:SetFloat("_RenderOutline",flag and 1 or 0)
        end
    end
end

function UnitTpose:TposeComplete()
    if self.callBack then
        self.callBack(self.setting.args)
    end
end

function UnitTpose:IsComplete()
    return self.isComplete
end

function UnitTpose:CancelBuildTpose()
    if not self.isCancel then return false end
    self:RemoveLoader()
    self:Delete()
    return true
end

function UnitTpose:RemoveLoader()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function UnitTpose:RemoveArmLoader()
    for _, v in pairs(self.armTposeInfos) do
        for _,info in pairs(v) do
            if info.tpose then
                info.tpose:Delete()
                info.tpose = nil
            end
        end
    end
end

function UnitTpose:OnReset()
end

function UnitTpose.GetSetting(config,args)
    local setting = {}
    setting.modelId = config.modelId
    setting.skinId = config.skinId
    setting.animId = config.animId
    setting.args = args
    return setting
end
