AudioManager = SingleClass("AudioManager")

function AudioManager:__Init()
    self.uid = 0
    self.audioPlays = {}
    self.assetScope = AssetScope()
    self.audioClips = {}
    self.audioLoaders = {}
    self.audioLoadCallbacks = {}

    self.OnPlayButtonClick = self:ToFunc("PlayButtonClick")

    self.onHookBgm = nil

    self:InitAudio()
end

function AudioManager:__Delete()
    for _,audioPlay in pairs(self.audioPlays) do
        audioPlay:Delete()
    end
    self.audioPlays = nil

    for _,loader in pairs(self.audioLoaders) do
        loader:Destroy()
    end
    self.audioLoaders = nil
    self.audioLoadCallbacks = nil
    self.audioClips = nil

    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end

    if not BaseUtils.IsNull(self.audioParent) then
        GameObject.Destroy(self.audioParent)
        self.audioParent = nil
    end
end

function AudioManager:Clean()
    for _,v in pairs(self.audioPlays) do
        v:StopAll()
    end
end

function AudioManager:InitAudio()
    self.audioParent =  GameObject("Audio")
    self.audioParent.transform:SetLocalPosition(0,0,0)
    GameObject.DontDestroyOnLoad(self.audioParent)

    for k,v in pairs(AudioDefine.AudioType) do
        local audioType = k
        local setting = AudioDefine.AudioPlaySetting[audioType]
        local audioPlay = AudioPlay.New(self.audioParent,audioType,self)
        audioPlay:SetSingle(setting.single)
        audioPlay:SetLoop(setting.loop)
        audioPlay:SetSameDispose(setting.sameDispose)
        audioPlay:SetMaxSameAudioCount(setting.maxSameAudioCount)
        audioPlay:SetVolume(setting.volume)
        self.audioPlays[k] = audioPlay
    end
end

function AudioManager:LoadAudio(file,callback,args)
    local clip = self.audioClips[file]
    if clip then
        callback(args,clip)
        return
    end

    if not self.audioLoadCallbacks[file] then
        self.audioLoadCallbacks[file] = {}
    end
    table.insert(self.audioLoadCallbacks[file],{callback = callback,args = args})

    if self.audioLoaders[file] then
        return
    end

    local loader = AssetBatchLoader.New(self.assetScope)
    self.audioLoaders[file] = loader
    loader:Load({{file = file,type = AssetType.AudioClip}},self:ToFunc("OnAudioLoaded"),file)
end

function AudioManager:OnAudioLoaded(file)
    local loader = self.audioLoaders[file]
    if not loader then
        return
    end

    local clip = loader:GetAsset(file)
    loader:Destroy()
    self.audioLoaders[file] = nil
    if clip then
        self.audioClips[file] = clip
    end

    local callbacks = self.audioLoadCallbacks[file] or {}
    self.audioLoadCallbacks[file] = nil
    for _,callbackInfo in ipairs(callbacks) do
        callbackInfo.callback(callbackInfo.args,clip)
    end
end

function AudioManager:SetHookBgm(onHookBgm)
    self.onHookBgm = onHookBgm
end

function AudioManager:PlayBgm(audioId,delayTime,isLoop)
    if not audioId then
        return
    end
    if KvData.platform == KvData.PlatformType.WebGLPlayer then
        return
    end

    if self.onHookBgm then
        local newAudioId = self.onHookBgm(audioId)
        if newAudioId then
            audioId = newAudioId
        end
    end

    local uid = self:GetUid()
    local file = AssetPath.GetAudioByBgm(audioId)

    local audioPlay = self.audioPlays[AudioDefine.AudioType.bgm]
    audioPlay:Play(uid,audioId,file,delayTime,isLoop)
end

-- 异步获取 BGM 时长（秒），用于 intro 等需精确时长场景；callback(durationSec)
function AudioManager:GetBgmDuration(audioId, callback)
    if not audioId or not callback then
        return
    end
    if KvData.platform == KvData.PlatformType.WebGLPlayer then
        return
    end
    if self.onHookBgm then
        local newAudioId = self.onHookBgm(audioId)
        if newAudioId then
            audioId = newAudioId
        end
    end
    local file = AssetPath.GetAudioByBgm(audioId)
    self:LoadAudio(file,self:ToFunc("OnBgmDurationLoaded"),callback)
end

function AudioManager:OnBgmDurationLoaded(callback,clip)
    if not clip then
        return
    end
    local durationSec = clip.length
    if durationSec then
        callback(durationSec)
    end
end

function AudioManager:StopBgm()
    local audioPlay = self.audioPlays[AudioDefine.AudioType.bgm]
    audioPlay:StopAll()
end

function AudioManager:PlayUI(audioId,delayTime,isLoop)
    if not audioId or tostring(audioId) == "0" then
        return
    end
    if KvData.platform == KvData.PlatformType.WebGLPlayer then
        return
    end

    local uid = self:GetUid()
    local file = AssetPath.GetAudioByUI(audioId)

    local audioPlay = self.audioPlays[AudioDefine.AudioType.ui]
    audioPlay:Play(uid,audioId,file,delayTime,isLoop)
end

function AudioManager:StopUI(audioId)
    if not audioId or tostring(audioId) == "0" then
        return 
    end
    local audioPlay = self.audioPlays[AudioDefine.AudioType.ui]
    audioPlay:Stop(audioId)
end

function AudioManager:OnPlayEffectAnim(audioId)
    self:PlayUI(audioId)
end

function AudioManager:PlayButtonClick(audioId,type)
    if audioId == "" and (not type or type == "") then
        return
    end

    if audioId == "" and type == "click_btn" then
        audioId = "click"
    elseif audioId == "" and type == "hover_btn" then
         audioId = "hover_enter"
    end

    self:PlayUI(audioId)
end

function AudioManager:PlayCarrier(audioId)
    if not audioId then
        return
    end
    if KvData.platform == KvData.PlatformType.WebGLPlayer then
        return
    end

    local uid = self:GetUid()
    local file = AssetPath.GetAudioByCarrier(audioId)

    local audioPlay = self.audioPlays[AudioDefine.AudioType.skill]
    audioPlay:Play(uid,audioId,file)

    return uid
end

function AudioManager:StopCarrier(audioUid)
    local audioPlay = self.audioPlays[AudioDefine.AudioType.skill]
    audioPlay:StopByUid(audioUid)
end

function AudioManager:PlayScene(audioId)
    if not audioId then
        return
    end

    local uid = self:GetUid()
    local file = AssetPath.GetAudioByScene(audioId)

    local audioPlay = self.audioPlays[AudioDefine.AudioType.scene]
    audioPlay:Play(uid,audioId,file)
end

function AudioManager:GetUid()
    self.uid = self.uid + 1
    return self.uid
end

function AudioManager:SetMute(audioType,flag)
    if audioType then
        self.audioPlays[audioType]:SetMute(flag)
    else
        for _,v in pairs(self.audioPlays) do
            v:SetMute(flag)
        end
    end
end

function AudioManager:SetVolume(audioType,volume)
    if audioType then
        self.audioPlays[audioType]:SetVolume(volume)
    else
        for _,v in pairs(self.audioPlays) do
            v:SetVolume(volume)
        end
    end
end
