AudioPlay = BaseClass("AudioPlay")

function AudioPlay:__Init(parent,audioType,audioManager)
    self.audioManager = audioManager
    self.audioType = audioType
    self.single = false
    self.loop = false
    --self.sleepVolume = sleepVolume

    self.isMute = false
    self.volume = 1

    self.audioPlays = List.New()
    self.audioPool = {} --音源组件池

    self.sameDispose = AudioDefine.SameDispose.ignore

    self.gameObject = GameObject(self.audioType)
    self.gameObject.transform:SetParent(parent.transform)
    self.gameObject.transform:SetLocalPosition(0,0,0)

    self.maxSameAudioCount = -1
end

function AudioPlay:__Delete()
    self:StopAll()
    self.audioManager = nil
    self.audioPool = nil
end

function AudioPlay:SetSingle(single)
    self.single = single
end

function AudioPlay:SetLoop(flag)
    self.loop = flag
end

-- function AudioPlay:SetSleepVolume(value)
--     self.sleepVolume = value
-- end

function AudioPlay:SetSameDispose(sameDispose)
    self.sameDispose = sameDispose
end

function AudioPlay:SetMaxSameAudioCount(maxSameAudioCount)
    self.maxSameAudioCount = maxSameAudioCount
end

function AudioPlay:Play(uid,audioId,file,delayTime,isLoop)
    if not file or file == "" or not AssetLoader.Instance:IsLocationValid(file) then
        LogErrorf("音频资源不存在, audioId=%s, file=%s", tostring(audioId), tostring(file))
        return
    end

    local flag = self:HasAudio(audioId)
    if flag and self.sameDispose == AudioDefine.SameDispose.ignore then
        return
    end

    if flag and not self.single and self.sameDispose == AudioDefine.SameDispose.replace then
        self:Stop(audioId)
    end

    if flag and self.sameDispose == AudioDefine.SameDispose.overlay and self.maxSameAudioCount ~= -1 then
        if self:GetAudioCount(audioId) >= self.maxSameAudioCount then
            return
        end
    end

    if self.single then
        self:StopAll()
    end

    local audioInfo = table.remove(self.audioPool) or {}
    audioInfo.uid = uid
    audioInfo.audioId = audioId
    audioInfo.file = file
    audioInfo.timer = nil
    audioInfo.delayTime = delayTime
    audioInfo.isLoop = isLoop ~= nil and isLoop or self.loop

    if not audioInfo.audioSource then
        audioInfo.audioSource = self:CreateAudioSource()
    end

    audioInfo.audioSource.loop = audioInfo.isLoop

    audioInfo.audioSource.volume = self.volume
    audioInfo.audioSource.mute = self.isMute

    self.audioPlays:Push(audioInfo,audioInfo.uid)

    self.audioManager:LoadAudio(audioInfo.file,self:ToFunc("AudioLoaded"),audioInfo.uid)
end


function AudioPlay:AudioLoaded(uid,clip)
    local iter = self.audioPlays:GetIterByIndex(uid)
    if iter then
        local audioInfo = iter.value
        if not clip then
            LogErrorf("音频资源加载失败, audioId=%s, file=%s", tostring(audioInfo.audioId), tostring(audioInfo.file))
            table.insert(self.audioPool, audioInfo)
            self.audioPlays:Remove(iter)
            return
        end

        audioInfo.audioSource.clip = clip
        -- 真正播放前按当前静音/音量状态设置组件，避免异步回调时状态已变化
        audioInfo.audioSource.volume = self.volume
        audioInfo.audioSource.mute = self.isMute

        if audioInfo.delayTime then
            audioInfo.audioSource:PlayDelayed(audioInfo.delayTime)
        else
            audioInfo.audioSource:Play()
        end

        if not  audioInfo.isLoop then
            audioInfo.timer = TimerManager.Instance:AddTimerByNextFrame(1,audioInfo.audioSource.clip.length, self:ToFunc("OnPlayed"))
            audioInfo.timer:SetArgs(uid)
        end
    end
end

function AudioPlay:CreateAudioSource()
    local audioSource = self.gameObject:AddComponent(AudioSource)
    audioSource.playOnAwake = false
    audioSource.loop = self.loop
    -- 新组件创建时即按当前静音/音量设置，避免首次播放未应用设置
    audioSource.volume = self.volume
    audioSource.mute = self.isMute
    return audioSource
end

function AudioPlay:HasAudio(audioId)
    for iter in self.audioPlays:Items() do
        if iter.value.audioId == audioId then
            return true
        end
    end
    return false
end

function AudioPlay:GetAudioCount(audioId)
    local count = 0
    for iter in self.audioPlays:Items() do
        if iter.value.audioId == audioId then
            count = count + 1
        end
    end
    return count
end

function AudioPlay:Stop(audioId)
    for iter in self.audioPlays:Items() do
        local audioInfo = iter.value
        if audioInfo.audioId == audioId then
            self:ClearAudio(audioInfo)
            self.audioPlays:Remove(iter)
        end
    end
end

function AudioPlay:StopAll()
    for iter in self.audioPlays:Items() do
        self:ClearAudio(iter.value)
    end
    self.audioPlays:Clear()
end

function AudioPlay:StopByUid(uid)
    local iter = self.audioPlays:GetIterByIndex(uid)
    if iter then
        self:ClearAudio(iter.value)
        self.audioPlays:Remove(iter)
    end
end

function AudioPlay:ClearAudio(audioInfo)
    if audioInfo.timer then
        TimerManager.Instance:RemoveTimer(audioInfo.timer)
        audioInfo.timer = nil
    end

    audioInfo.audioSource.clip = nil
    audioInfo.audioSource:Stop()
    
    table.insert(self.audioPool,audioInfo)
end

function AudioPlay:Pause()
    for _, audio in pairs(self.audioList) do 
        audio:Pause() 
    end
end

function AudioPlay:UnPause()
    for _, audio in pairs(self.audioList) do 
        audio:UnPause() 
    end
end

-- 音量
function AudioPlay:SetVolume(volume)
    self.volume = volume
    for iter in self.audioPlays:Items() do
        iter.value.audioSource.volume = volume
    end
end

-- 静音
function AudioPlay:SetMute(flag)
    self.isMute = flag
    for iter in self.audioPlays:Items() do
        iter.value.audioSource.mute = self.isMute
    end
end

--是否静音
function AudioPlay:IsMute()
    return self.isMute
end

function AudioPlay:ResetVolume()
    for audio in self.audioList:Items() do
        audio.value.volume = self.volume
    end
end

-- function AudioPlay:OnSleep()
--     if self.sleepVolume > self.volume then return end
--     for audio in self.audioList:Items() do
--         if audio.playing then audio.value.volume = self.sleepVolume end
--     end
-- end

--播放结束
function AudioPlay:OnPlayed(uid)
    self:StopByUid(uid)
end
