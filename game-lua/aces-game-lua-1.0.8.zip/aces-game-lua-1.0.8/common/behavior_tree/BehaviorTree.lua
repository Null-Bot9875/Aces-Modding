BehaviorTree = BaseClass("BehaviorTree")

function BehaviorTree:__Init()
    self.id = 0
    self.nodeMap = {}
    self.nodes = {}
    self.rootNode = nil
    self.sharedData = nil

    self.enable = false
    self.paused = false
    
    self.cacheData = {}
    self.args = nil
    --self.inputData = nil
    self.callBack = nil
    self.gameObject = nil
end

function BehaviorTree:__Delete()
    for _,nodeId in ipairs(self.nodes) do
        self.nodeMap[nodeId]:Delete()
	end
end

function BehaviorTree:Init(id,nodes,...)
    self.id = id
    self.nodes = nodes
    self:OnInit(...)
end

function BehaviorTree:SetArgs(args)
    self.args = args
end

function BehaviorTree:SetCacheData(key,data)
	self.cacheData[key] = data
end

function BehaviorTree:GetCacheData(key)
	return self.cacheData[key]
end

function BehaviorTree:SetGameObject(gameObject)
    self.gameObject = gameObject
end

function BehaviorTree:IsEnable()
    return self.isEnable
end

function BehaviorTree:Start()
    if self.enable then
        return
    end

    self.enable = true
    --self.inputData  = data.inputData
    --self.cbInfo = data.cbInfo
end

function BehaviorTree:Pause(paused)
    self.paused = paused
    for _,nodeId in ipairs(self.nodes) do
        self.nodeMap[nodeId]:Pause()
	end
end

function BehaviorTree:Restart()
    for _,nodeId in ipairs(self.nodes) do
        self.nodeMap[nodeId]:Restart()
	end
end

function BehaviorTree:Abort()

end

function BehaviorTree:Update(deltaTime)
    if not self.enable or self.paused then
        return
    end

	local status = self.rootNode:Update(deltaTime)
	if status ~= BTTaskStatus.Success and status ~= BTTaskStatus.Failure then
        return
    end

    for _,nodeId in ipairs(self.nodes) do
        self.nodeMap[nodeId]:Complete()
	end

    self.enable = false

    if self.cbInfo then
        self.cbInfo.callBack(self.cbInfo.args)
    end
end

function BehaviorTree:Stop()
    self.enable = false
    self.paused = false
    for _,nodeId in ipairs(self.nodes) do
        self.nodeMap[nodeId]:Stop()
	end
end

function BehaviorTree:Create()
    for _,nodeId in ipairs(self.nodes) do
        self.nodeMap[nodeId]:Create()
	end
    self:OnCreate()
end


--创建行为树完成
function BehaviorTree:OnInit(...)
end

function BehaviorTree:OnCreate()
end