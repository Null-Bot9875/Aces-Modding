BTUtils = StaticClass("BTUtils")

function BTUtils.Create(btType,config,...)
    local bt = btType.New()
    bt:Init(config.id,config.nodes,...)
	
	for i,nodeId in ipairs(bt.nodes) do
        local nodeInfo = config.nodeMap[nodeId]
        if not nodeInfo then
            assert(false, string.format("行为树创建异常,节点不存在[行为树Id:%s][节点Id:%s]",bt.id,nodeId))
        end

		local nodeClass = _G[nodeInfo.class]
        if not nodeClass then
            assert(false, string.format("行为树创建异常,节点类型不存在[行为树Id:%s][节点id:%s][class:%s]",bt.id,nodeId,nodeInfo.class))
        end

		local runNode= nodeClass.New()
		runNode.id = nodeId
		runNode.owner = bt
        runNode:SetParams(nodeInfo.params)

        if runNode:CanHasChild() then
            assert(nodeInfo.childs, string.format("行为树创建异常,节点不应该存在子节点属性[行为树Id:%s][节点Id:%s]",bt.id,nodeId))
        end

		runNode:OnAwake()

		bt.nodeMap[runNode.id] = runNode
	end

	bt.rootNode = bt.nodeMap[config.rootNode]
    if not bt.rootNode then
        assert(false, string.format("行为树创建异常,根节点不存在[行为树Id:%s][根节点Id:%s]",bt.id,tostring(config.rootNode)))
    end

    for i,nodeId in ipairs(bt.nodes) do
        local nodeInfo = config.nodeMap[nodeId]
        local runNode = bt.nodeMap[nodeId]
        if runNode:CanHasChild() then
            for _,childNodeId in ipairs(nodeInfo.childs) do
                local childNode = bt.nodeMap[childNodeId]
                if childNode then
                    runNode:AddChild(childNode)
                else
                    assert(false,string.format("行为树创建异常,子节点不存在[行为树Id:%s][节点Id:%s][子节点Id:%s]",bt.id,runNode.id,childNodeId))
                end
            end
        end
    end

    bt.sharedData = config.sharedData

    bt:Create()

	return bt
end
