Config = {}

local confs = {}
local confFiles = {}
local modInstallContext = nil

local function Traceback(errorMessage)
	return debug.traceback(tostring(errorMessage), 2)
end

local function RaiseModStartupFailure(info, message)
	error({
		__modStartupFailure = true,
		modId = tostring(info.id),
		stage = "config_install",
		message = tostring(message),
	}, 0)
end

local function loadConfig(confName)
	if type(confName) ~= "string" or confName == "" then
		LogErrorf(string.format("Config.Get 传入非法 confName[%s] 调用栈:\n%s", tostring(confName), debug.traceback()))
		return nil
	end

	local requireFile = DataToFile[confName]
	if not requireFile then
		LogErrorf(string.format("不存在的配置表[配置表:%s] 调用栈:\n%s", confName, debug.traceback()))
		return nil
	end

	local conf = require(requireFile)
	confs[confName] = conf
    table.insert(confFiles,requireFile)
	return conf
end

function Config.Init()

end

function Config.Unload()
    for _,file in ipairs(confFiles) do
        package.loaded[file] = nil
    end
    confs = {}
    confFiles = {}
end


function Config.Get(confName,sheetName,keyIndex,key,dontShowError)
	local conf = confs[confName] or loadConfig(confName)
	if not conf then return end

	local confData,errCode = conf.Get(sheetName,keyIndex,key)
	
	if not errCode then
		return confData
	end

	if dontShowError ~= true then
		if errCode == ConfigDefine.Error.not_sheet then 
			LogErrorf("不存在的Sheet[配置表:%s][sheet:%s]",confName,sheetName) 
		end
	
		if errCode == ConfigDefine.Error.not_index then
			LogErrorf("不存在的键值索引[配置表:%s][sheet:%s][索引:(%s)][key:%s]",confName,sheetName,keyIndex,key) 
		end
	end
end

function Config.Getf(confName,sheetName,keyIndex,...)
	local key = table.concat({...}, "_")
	return Config.Get(confName,sheetName,keyIndex,key),key
end

function Config.GetLua(confName)
	local conf = confs[confName] or loadConfig(confName)
	return conf
end

function Config.HasConf(confName)
	return DataToFile[confName] ~= nil
end

local function BuildIndexKey(row, fields)
	if #fields == 1 then return row[fields[1]] end
	local values = {}
	for index, fieldName in ipairs(fields) do
		values[index] = tostring(row[fieldName])
	end
	return table.concat(values, "_")
end

local function GetInstallIndexKey(installKey)
	if type(installKey) == "string" then return installKey end
	if type(installKey) ~= "table" then return nil end
	return table.concat(installKey, ",")
end

local function GetIndexRule(sheetInfo, installKey)
	local indexKey = GetInstallIndexKey(installKey)
	if indexKey == nil then return nil end
	for _, rule in ipairs(sheetInfo.indexes or {}) do
		if rule.indexKey == indexKey then return rule end
	end
	return nil
end

local function FormatSources(value)
	if type(value) ~= "table" then return tostring(value or "none") end
	local unique = {}
	local values = {}
	for _, source in ipairs(value) do
		if not unique[source] then
			unique[source] = true
			values[#values + 1] = source
		end
	end
	return #values > 0 and table.concat(values, "|") or "none"
end

local function BuildOwners(module, sheetName, rows, rowSources)
	local sheetInfo = module.GetSheetInfo(sheetName)
	local owners = {}
	for _, rule in ipairs(sheetInfo.indexes or {}) do owners[rule.indexKey] = {} end
	for _, row in ipairs(rows) do
		local source = rowSources[row] or "Core"
		for _, rule in ipairs(sheetInfo.indexes or {}) do
			local key = BuildIndexKey(row, rule.fields)
			if rule.group then
				local values = owners[rule.indexKey][key] or {}
				values[#values + 1] = source
				owners[rule.indexKey][key] = values
			else
				owners[rule.indexKey][key] = source
			end
		end
	end
	return owners
end

local function BuildModLanguage(info)
	local translations = {}
	if type(info.languageJson) == "string" and info.languageJson ~= "" then
		local success, value = pcall(CJson.decode, info.languageJson)
		if success and type(value) == "table" then
			local valid = true
			for key, text in pairs(value) do
				if type(key) ~= "string" or type(text) ~= "string" then
					valid = false
					break
				end
			end
			if valid then
				translations = value
			else
				LogModError(info.id, "CLIENT", "[file:language/language.csv] 运行时 JSON 只能包含 string -> string；整份译文回退原文")
			end
		else
			LogModError(info.id, "CLIENT", "[file:language/language.csv] 运行时 JSON 解析失败；整份译文回退原文: ", value)
		end
	end
	return {
		GetConfigText = function(_, _, hash, sourceText)
			local languageManager = rawget(_G, "LanguageManager")
			local currentLanguage = languageManager and languageManager.Instance and languageManager.Instance.Language
			if type(info.language) == "string" and info.language ~= ""
				and type(currentLanguage) == "string" and currentLanguage ~= info.language then
				return sourceText
			end
			return translations[hash] or sourceText
		end,
	}
end

local function RestoreSnapshots(snapshots)
	for index = #snapshots, 1, -1 do
		local snapshot = snapshots[index]
		local restored, restoreError = snapshot.module.RestoreState(snapshot.sheetName, snapshot.state)
		assert(restored, string.format(
			"MOD 配置事务回滚失败[configName:%s][sheetName:%s]: %s",
			snapshot.configName,
			snapshot.sheetName,
			tostring(restoreError)))
	end
end

local function CaptureSnapshot(target, targetByKey, configName, sheetName, module)
	local key = configName .. "\n" .. sheetName
	if targetByKey[key] then return end
	local state, stateError = module.CaptureState(sheetName)
	assert(state ~= nil, string.format(
		"无法创建 MOD 配置事务快照[configName:%s][sheetName:%s]: %s",
		configName,
		sheetName,
		tostring(stateError)))
	local snapshot = {
		configName = configName,
		sheetName = sheetName,
		module = module,
		state = state,
	}
	target[#target + 1] = snapshot
	targetByKey[key] = snapshot
end

local function LogUnknownFields(info, descriptor, batch, module)
	local sheetInfo = module.GetSheetInfo(descriptor.sheetName)
	local schema = sheetInfo.schema
	for rowIndex, row in ipairs(batch.rows) do
		for fieldName in pairs(row) do
			if schema[fieldName] == nil then
				LogModError(info.id, "CLIENT", string.format(
					"MOD 配置包含未知字段；字段保留但不获得 Schema、索引或 i18n 语义[path:%s][configName:%s][sheetName:%s][field:rows[%s].%s]",
					descriptor.path,
					descriptor.configName,
					descriptor.sheetName,
					rowIndex,
					tostring(fieldName)))
			end
		end
	end
end

local function BuildAuthoringContext(info, descriptor)
	return {
		modId = info.id,
		path = descriptor.path,
		logError = function(message) LogModError(info.id, "CLIENT", message) end,
	}
end

local function LoadModBatches(host, info, authoring)
	local pending = {}
	for _, descriptor in ipairs(info.configBatches or {}) do
		assert(type(descriptor) == "table"
			and type(descriptor.path) == "string"
			and type(descriptor.modulePath) == "string"
			and type(descriptor.configName) == "string"
			and type(descriptor.sheetName) == "string",
			"MOD 配置批次描述无效[id:" .. tostring(info.id) .. "]")
		local sourceLabel = tostring(info.id) .. ":" .. descriptor.path
		local success, batch = xpcall(function()
			return host:ExecuteConfigBatch(info, descriptor.modulePath)
		end, Traceback)
		assert(success, string.format("MOD 配置 Lua 执行失败[source:%s]: %s", sourceLabel, tostring(batch)))
		local normalized, normalizeError, schemaOverride = authoring.Normalize(
			descriptor.configName,
			descriptor.sheetName,
			batch,
			BuildAuthoringContext(info, descriptor))
		assert(normalized ~= nil, string.format(
			"MOD 作者配置规范化失败[source:%s]: %s",
			sourceLabel,
			tostring(normalizeError)))
		pending[#pending + 1] = {
			descriptor = descriptor,
			batch = normalized,
			schemaOverride = schemaOverride,
			sourceLabel = sourceLabel,
			hasAuthorAdapter = authoring.HasAdapter(descriptor.configName, descriptor.sheetName),
		}
	end
	return pending
end

local function LogBatchWarnings(info, pending, oldOwners, newOwners, result, oldGroupSources)
	for _, warning in ipairs(result.warnings or {}) do
		LogMod(info.id, "CLIENT", "WARNING", string.format(
			"MOD 配置安装警告[source:%s]: %s",
			pending.sourceLabel,
			tostring(warning)))
	end
	for _, conflict in ipairs(result.conflicts or {}) do
		local oldSource = oldOwners[conflict.indexKey] and oldOwners[conflict.indexKey][conflict.key]
		local finalSource = newOwners[conflict.indexKey] and newOwners[conflict.indexKey][conflict.key]
		LogMod(info.id, "CLIENT", "WARNING", string.format(
			"MOD 配置冲突[configName:%s][sheetName:%s][index:%s][key:%s][oldSource:%s][newSource:%s][finalSource:%s]",
			pending.descriptor.configName,
			pending.descriptor.sheetName,
			tostring(conflict.indexKey),
			tostring(conflict.key),
			FormatSources(oldSource or pending.sourceLabel),
			pending.sourceLabel,
			FormatSources(finalSource)))
	end
	if oldGroupSources ~= nil then
		local installKey = GetInstallIndexKey(pending.batch.installKey)
		local groupKey = result.groupKey
		local finalSource = newOwners[installKey] and newOwners[installKey][groupKey]
		LogMod(info.id, "CLIENT", "WARNING", string.format(
			"MOD 配置组冲突[configName:%s][sheetName:%s][index:%s][key:%s][oldSource:%s][newSource:%s][finalSource:%s]",
			pending.descriptor.configName,
			pending.descriptor.sheetName,
			tostring(installKey),
			tostring(groupKey),
			FormatSources(oldGroupSources),
			pending.sourceLabel,
			FormatSources(finalSource)))
	end
end

local function ApplyModBatches(info, pendingBatches, language, rowSources, globalSnapshots, globalByKey)
	local modSnapshots = {}
	local modByKey = {}
	local success, installError = xpcall(function()
		for _, pending in ipairs(pendingBatches) do
			local descriptor = pending.descriptor
			local module = Config.GetLua(descriptor.configName)
			assert(module ~= nil, "不存在目标配置 module[" .. descriptor.configName .. "]")
			assert(type(module.GetSheetInfo) == "function"
				and type(module.ApplyBatch) == "function"
				and type(module.CaptureState) == "function"
				and type(module.RestoreState) == "function",
				"目标配置 module 缺少统一安装接口[" .. descriptor.configName .. "]")
			local sheetInfo = module.GetSheetInfo(descriptor.sheetName)
			assert(sheetInfo ~= nil, string.format(
				"不存在目标配置 Sheet[configName:%s][sheetName:%s]",
				descriptor.configName,
				descriptor.sheetName))
			CaptureSnapshot(globalSnapshots, globalByKey, descriptor.configName, descriptor.sheetName, module)
			CaptureSnapshot(modSnapshots, modByKey, descriptor.configName, descriptor.sheetName, module)
			if not pending.hasAuthorAdapter then
				LogUnknownFields(info, descriptor, pending.batch, module)
			end

			local currentState = module.CaptureState(descriptor.sheetName)
			local oldOwners = BuildOwners(module, descriptor.sheetName, currentState.rows, rowSources)
			local oldGroupSources = nil
			local installRule = GetIndexRule(sheetInfo, pending.batch.installKey)
			if installRule and installRule.group and pending.batch.installValue ~= nil then
				local groupKey = #installRule.fields == 1
					and pending.batch.installValue
					or table.concat(pending.batch.installValue, "_")
				oldGroupSources = oldOwners[installRule.indexKey][groupKey]
			end
			for _, row in ipairs(pending.batch.rows) do rowSources[row] = pending.sourceLabel end

			local result, applyError = module.ApplyBatch(
				descriptor.sheetName,
				pending.batch,
				true,
				pending.schemaOverride,
				language)
			assert(result ~= nil, string.format(
				"MOD 配置批次安装失败[source:%s]: %s",
				pending.sourceLabel,
				tostring(applyError)))
			local newOwners = BuildOwners(module, descriptor.sheetName, result.rows, rowSources)
			LogBatchWarnings(info, pending, oldOwners, newOwners, result, oldGroupSources)
		end
	end, Traceback)
	if not success then
		RestoreSnapshots(modSnapshots)
		return false, installError
	end
	return true
end

function Config.InstallMods(host, mods, authoring)
	assert(host ~= nil, "MOD 配置安装缺少 ModHost")
	assert(type(mods) == "table", "MOD 配置安装清单需要 table")
	assert(type(authoring) == "table" and type(authoring.Normalize) == "function", "MOD 配置安装缺少作者适配层")
	local globalSnapshots = {}
	local globalByKey = {}
	local rowSources = {}
	local preparedMods = {}
	for _, info in ipairs(mods) do
		local language = BuildModLanguage(info)
		local success, pendingOrError = xpcall(function()
			return LoadModBatches(host, info, authoring)
		end, Traceback)
		if not success then
			RestoreSnapshots(globalSnapshots)
			RaiseModStartupFailure(
				info,
				string.format("MOD 配置事务失败[id:%s]: %s", tostring(info.id), tostring(pendingOrError)))
		end
		local installed, installError = ApplyModBatches(
			info,
			pendingOrError,
			language,
			rowSources,
			globalSnapshots,
			globalByKey)
		if not installed then
			RestoreSnapshots(globalSnapshots)
			RaiseModStartupFailure(
				info,
				string.format("MOD 配置事务失败[id:%s]: %s", tostring(info.id), tostring(installError)))
		end
		preparedMods[#preparedMods + 1] = {
			info = info,
			pendingBatches = pendingOrError,
		}
	end
	modInstallContext = {
		preparedMods = preparedMods,
	}
	return true
end

function Config.ReinstallMods(refreshedMods)
	if modInstallContext == nil then return true end
	local refreshedById = {}
	if type(refreshedMods) == "table" then
		for _, info in ipairs(refreshedMods) do
			if type(info) == "table" and type(info.id) == "string" then
				refreshedById[info.id] = info
			end
		end
	end
	local globalSnapshots = {}
	local globalByKey = {}
	local rowSources = {}
	for _, prepared in ipairs(modInstallContext.preparedMods) do
		local info = refreshedById[prepared.info.id] or prepared.info
		local installed, installError = ApplyModBatches(
			info,
			prepared.pendingBatches,
			BuildModLanguage(info),
			rowSources,
			globalSnapshots,
			globalByKey)
		if not installed then
			RestoreSnapshots(globalSnapshots)
			error(string.format("MOD 配置重装事务失败[id:%s]: %s", tostring(info.id), tostring(installError)), 2)
		end
	end
	return true
end

function Config.Set(confName,sheetName,index,data)
	local conf = confs[confName] or loadConfig(confName)
	if not conf then return false end
	return conf.Set(sheetName,index,data)
end

function Config.GetNum(confName,sheetName)
	local conf = confs[confName] or loadConfig(confName)
	if not conf then return 0 end
	return conf.GetNum(sheetName)
end
