local ConfigRowRuntime = {}

local function IsModId(value)
    if type(value) ~= "string" or value == "" then return false end
    if string.sub(value, 1, 1) == "." or string.sub(value, -1) == "." then return false end
    if string.find(value, "..", 1, true) then return false end
    for segment in string.gmatch(value, "[^.]+") do
        if not string.match(segment, "^[a-z0-9]+$") then return false end
    end
    return string.find(value, ".", 1, true) ~= nil
end

local function IsModAssetRef(value)
    if type(value) ~= "string" or string.sub(value, 1, 6) ~= "mod://" then
        return false
    end
    local modId, relativePath = string.match(value, "^mod://([^/]+)/(.+)$")
    if not modId or not IsModId(modId) then
        return false
    end
    if string.find(relativePath, "\\", 1, true)
        or string.find(relativePath, "//", 1, true)
        or string.find(relativePath, "[%z\1-\31]")
        or string.find(relativePath, "[<>:\"|%?%*]")
        or string.lower(string.sub(relativePath, -4)) ~= ".png" then
        return false
    end
    for segment in string.gmatch(relativePath, "[^/]+") do
        if segment == "." or segment == ".." then return false end
    end
    return true
end

local function ValidateValue(value, schema, path)
    local valueType = type(value)
    local schemaType = schema.type
    if schemaType == "int" then
        if valueType ~= "number" or value % 1 ~= 0 then
            return false, string.format("%s 需要 int，实际为 %s", path, valueType)
        end
    elseif schemaType == "float" then
        if valueType ~= "number" then
            return false, string.format("%s 需要 float，实际为 %s", path, valueType)
        end
    elseif schemaType == "string" then
        if valueType ~= "string" then
            return false, string.format("%s 需要 string，实际为 %s", path, valueType)
        end
    elseif schemaType == "bool" then
        if valueType ~= "boolean" then
            return false, string.format("%s 需要 bool，实际为 %s", path, valueType)
        end
    elseif schemaType == "list" then
        if valueType ~= "table" then
            return false, string.format("%s 需要 list，实际为 %s", path, valueType)
        end
        for index, item in ipairs(value) do
            local valid, err = ValidateValue(item, schema.item, string.format("%s[%s]", path, index))
            if not valid then return false, err end
        end
    elseif schemaType == "dict" then
        if valueType ~= "table" then
            return false, string.format("%s 需要 dict，实际为 %s", path, valueType)
        end
        for key, item in pairs(value) do
            local validKey, keyErr = ValidateValue(key, schema.key, string.format("%s.key", path))
            if not validKey then return false, keyErr end
            local validValue, valueErr = ValidateValue(item, schema.value, string.format("%s[%s]", path, key))
            if not validValue then return false, valueErr end
        end
    elseif schemaType == "asset_ref" then
        local isInteger = valueType == "number" and value % 1 == 0
        if not isInteger and not IsModAssetRef(value) then
            return false, string.format("%s 需要 int 或规范化 mod:// PNG URI，实际为 %s", path, valueType)
        end
    elseif schemaType ~= "mix" and schemaType ~= "lua" then
        return false, string.format("%s 存在未知 Schema 类型[%s]", path, tostring(schemaType))
    end
    return true
end

function ConfigRowRuntime.MergeSchema(baseSchema, schemaOverride)
    if schemaOverride == nil then return baseSchema end
    if type(baseSchema) ~= "table" or type(schemaOverride) ~= "table" then
        return nil, "Schema override 需要 table"
    end
    local result = {}
    for fieldName, fieldSchema in pairs(baseSchema) do result[fieldName] = fieldSchema end
    for fieldName, fieldSchema in pairs(schemaOverride) do
        if baseSchema[fieldName] == nil then
            return nil, string.format("Schema override 包含未知字段[%s]", tostring(fieldName))
        end
        if type(fieldSchema) ~= "table" or fieldSchema.type == nil then
            return nil, string.format("Schema override 字段无效[%s]", tostring(fieldName))
        end
        result[fieldName] = fieldSchema
    end
    return result
end

local function TranslateMix(value, configName, language)
    if type(value) == "string" then
        local hash = IOUtils.GetMD5ByStringLen(value)
        return language:GetConfigText(configName, hash, value)
    end
    if type(value) ~= "table" then return value end
    for key, item in pairs(value) do
        value[key] = TranslateMix(item, configName, language)
    end
    return value
end

local function TranslateValue(value, schema, configName, language)
    if schema.type == "string" and schema.i18n then
        local hash = IOUtils.GetMD5ByStringLen(value)
        return language:GetConfigText(configName, hash, value)
    elseif schema.type == "list" then
        for index, item in ipairs(value) do
            value[index] = TranslateValue(item, schema.item, configName, language)
        end
    elseif schema.type == "dict" then
        for key, item in pairs(value) do
            value[key] = TranslateValue(item, schema.value, configName, language)
        end
    elseif schema.type == "mix" and schema.i18n then
        return TranslateMix(value, configName, language)
    end
    return value
end

local function TranslateBySchema(data, schema, configName, language)
    for fieldName, fieldSchema in pairs(schema) do
        data[fieldName] = TranslateValue(data[fieldName], fieldSchema, configName, language)
    end
end

function ConfigRowRuntime.Validate(source, schema, allowUnknown)
    if type(source) ~= "table" then
        return false, string.format("配置行需要 table，实际为 %s", type(source))
    end
    if type(schema) ~= "table" then
        return false, string.format("配置 Schema 需要 table，实际为 %s", type(schema))
    end
    for fieldName, fieldSchema in pairs(schema) do
        if source[fieldName] == nil then
            return false, string.format("配置行缺少字段[%s]", fieldName)
        end
        local valid, err = ValidateValue(source[fieldName], fieldSchema, fieldName)
        if not valid then return false, err end
    end
    for fieldName in pairs(source) do
        if schema[fieldName] == nil and not allowUnknown then
            return false, string.format("配置行包含未知字段[%s]", tostring(fieldName))
        end
    end
    return true
end

function ConfigRowRuntime.Build(source, schema, configName, language)
    -- 作者层已在发布前按目标 Sheet 决定是否允许扩展字段。运行时 Build 只负责
    -- 深拷贝与 i18n；保留扩展字段，避免一次合法安装在首次查询时再次失败。
    local valid, err = ConfigRowRuntime.Validate(source, schema, true)
    assert(valid, string.format("配置行校验失败[%s]: %s", tostring(configName), tostring(err)))
    local data = TableUtils.DeepCopy(source)
    if language ~= nil then
        TranslateBySchema(data, schema, configName, language)
    end
    return data
end

return ConfigRowRuntime
