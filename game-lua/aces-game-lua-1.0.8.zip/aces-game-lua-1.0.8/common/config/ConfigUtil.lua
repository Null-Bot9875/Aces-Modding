ConfigUtil = StaticClass("ConfigUtil")

---通过ItemId获取UnitData数据
---@param itemId any
---@return unknown
function ConfigUtil.GetUnitDataByItemId(itemId)
    local itemConfig = Config.ItemData.data_item_info[itemId]
    if not itemConfig then
        assert(false, string.format("无法找到ItemData[%s]", tostring(itemId)))
    end
    local unitConfig = Config.UnitData.data_unit_info[itemConfig.item_attr]
    return unitConfig
end

---获取卡牌拥有数量/上限/百分比
---@param unit_id any
---@return integer ownedAmount
---@return integer maxAmount
---@return integer percent
function ConfigUtil.GetUnitItemOwnedAmount(unit_id)
    local unitData = mod.CollectionProxy:GetDataById(unit_id)
    local level = unitData.level
    local ownedAmount = unitData.count
    local maxAmount = 0
    local percent = 1
    local key = string.format("%s_%s", tostring(unit_id), tostring(level + 1))
    local nextLevInfo = Config.UnitData.data_unit_lev_info[key]
    if nextLevInfo then
        maxAmount = nextLevInfo.lv_up_count
        if maxAmount > 0 then
            percent = MathUtils.Clamp(ownedAmount / maxAmount, 0, 1)
        end
    end
    return ownedAmount, maxAmount, percent
end

-- 获取机甲的设备卡牌id
function ConfigUtil.GetMechaDeviceConf(baseId, type)
    local index = nil
    local conf = Config.Get("card_base_def", "config", "baseId", baseId)
    for i, v in ipairs(conf.slotTypes) do
        if v == type then
            index = i
            break
        end
    end

    local cardId = conf.initCards[index]
    if cardId == 0 then
        return nil
    end

    -- local modeId2 = nil
    -- if type == KvData.DeviceType.mode and cardId ~= 0 then
    --     local cardConf = Config.Get("card_def", "config", "cardId", cardId)
    --     for i, v in ipairs(cardConf.extend.linkCards) do
    --         if v.type == 2 then
    --             modeId2 = v.id
    --             break
    --         end
    --     end
    -- end

    return cardId, modeId2
end

-- 获取机甲的颜色
function ConfigUtil.GetMechaColorType(baseId)
    local conf = Config.Get("card_base_def", "config", "baseId", baseId)
    local color = 0
    local colorList = {}
    for v, _ in ipairs(conf.cardTypeLimit) do
        color = color | BattleDefine.CardTypeMap[v]
        table.insert(colorList, v)
    end

    return color, colorList
end

-- 获取卡牌的颜色
function ConfigUtil.GetCardColorType(cardId)
    local conf = Config.Get("card_def", "config", "cardId", cardId)
    local cardType = 0
    for _, v in ipairs(conf.type) do
        cardType = cardType | BattleDefine.CardTypeMap[v]
    end

    return cardType, conf.type
end

-- 获取卡牌的费用
function ConfigUtil.GetCardCost(cardId)
    if cardId == 0 then
        return 0
    end

    local conf = Config.Get("card_def", "config", "cardId", cardId)
    if not conf then
        LogError("无法找到[%s]卡牌配置", tostring(cardId))
        return 0
    end

    local energyNum = 0
    if conf.costEffect and conf.costEffect ~= 0 then
        local effectConf = Config.Get("battle_effect_def", "config", "effectId", conf.costEffect)
        if not effectConf then
            LogError("无法找到[%s]卡牌费用效果配置[%s]", tostring(cardId), tostring(conf.costEffect))
            return 0
        end

        if effectConf.event == BattleDefine.EffectType.energy then
            energyNum = math.abs(effectConf.value)
        end
    end

    return energyNum
end



function ConfigUtil.GetRewardId(rewardId)
    local num = Config.GetNum("act_reward_def", "config")
    local baseId = mod.PveRogueProxy:GetBaseId()

    for i = 1, num do
        local conf = Config.Get("act_reward_def", "config", "index", i)
        if conf.rewardId == rewardId and baseId == conf.baseId then
            return conf.replaceRewardId
        end
    end

    -- local actRewardCfg = Config.Get("act_reward_def","config","rewardId", rewardId)
    -- if actRewardCfg and actRewardCfg.replaceRewardId then
    --     return actRewardCfg.replaceRewardId
    -- end

    return rewardId
end