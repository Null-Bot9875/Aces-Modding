DashboardDefine = StaticClass("DashboardDefine")

DashboardDefine.DashboardType =
{
    base_info = {title = "基础信息"},
    ui = "ui",
    battle = "battle"
}

DashboardDefine.DashboardInfo =
{
    [DashboardDefine.DashboardType.ui] = {title = "UI",class = "UIDashboard"},
    [DashboardDefine.DashboardType.battle] = {title = "Battle",class = "BattleDashboard"}
}

DashboardDefine.isRun = true