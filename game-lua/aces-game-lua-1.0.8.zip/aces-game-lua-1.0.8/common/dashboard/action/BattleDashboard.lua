BattleDashboard = BaseClass("BattleDashboard")

function BattleDashboard:__Init()
    self.baseInfo = {}

    self.frameInfo = {}
    self.frameInfo.loginInfo = {}
    self.frameInfo.renderInfo = {}
end

function BattleDashboard:__Delete()

end

function BattleDashboard:NewBattle()

end

function BattleDashboard:AddLogicFrameTime(frame,time)
    
end

function BattleDashboard:AddRenderFrameTime(frame,time)

end