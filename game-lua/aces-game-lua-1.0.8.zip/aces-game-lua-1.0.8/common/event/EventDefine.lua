EventDefine = EventDefine or Enum.New(
	"init_role_data_complete",
	"change_role_exp",

	"enter_battle",
	"over_battle",
	"preload_complete",
	"delay_preload_complete",
	"pre_enter_battle",

	"init_data_complete",
	"reconnet_init_data_complete",

	"exit_battle",
	"enter_login",
	"enter_mainui",
	"active_mainui",
	"active_mainui_top",
	"active_mainui_bottom",
	"on_mainui_active",
	"after_mainui_active",

	"update_role_info",
	"update_open_func",
	"ep_id_changed",

	"refresh_role_item",

	"on_func_unlock",
	"on_func_lock",

	"change_remind",
	"update_battlepass_info",

    "open_view",
    "close_view",
	
	"open_window",
	"open_window_complete",
	"close_window",

	"temp_show_window",
	"temp_hide_window",
	
	"asset_loaded",

	"on_actor_change",

    --引导
    "ready_use_card",
    "cancel_card_ob_start",
    "cancel_use_item",
	"start_drag_card",
	"on_hover_hand_card",
	"on_horver_exit_hand_card",
    "slot_setup_card",

	-- 发送卡牌使用
	"send_use_card_msg",

    "attack_play_done",
    "remove_stack_done",
	"hide_guide_mask_view",
    "show_guide_mask_view",

	"show_guide_tips_view",
	"hide_guide_tips_view",

    "select_pow_discard_card",

	"hand_card_ob_start",

    "battle_result",

	"on_app_focus",

	-- UI相机
	"ui_camera_disabled",

	--背包
	"on_prop_delete_handle",  --手動刪除
	"on_prop_delete",  --刪除
	"on_prop_update", --物品更新


	--卡组
	"on_sel_card_group_update", --卡组更新
	"on_card_group_add", -- 添加卡组
	"on_card_group_delete", -- 删除卡组
	

	--选择机体目标
	"on_select_mecha_begin",
    "on_mecha_selected",
    "on_mecha_cancel_select",
    "on_select_mecha_end",
	"on_auto_select_mecha",
	"on_auto_select_mecha_end",


	-- "device_tpose_load_finish",

    "update_mecha",
	"attack_play_finish",


    "get_arm_reward",
	"begin_dialogue",
	"finish_dialogue",

	"setter_change_quality",

	"dirty_words_filter_done",

	"condition_tips_anim_done",

	"room_chat_notify",

	-- BGM 场景事件
	"login_displayed",
	"mainui_displayed",
	"ep_map_opened",
	"battle_entered",
	"battle_bgm_phase_changed",
	"settlement_showed",
	"returned_from_settlement_to_mainui",

	-- 玩家个人信息
	"player_profile_update",
	"achievement_unlock"
)