LanguageDefine = StaticClass("LanguageDefine")

LanguageDefine.languages =
{
    {type = "none",text = "",area="cn"},
    {type = "zh_cn",text = "简体中文",area="cn"},
    {type = "zh_tw",text = "繁體中文",area="tw"},
    {type = "en_us",text = "English",area="en"},
    {type = "ja_jp",text = "日本語",area="jp"},
    {type = "de_de",text = "Deutsch",area="de"},
    {type = "ko_kr",text = "한국어",area="kr"},
    {type = "ru_ru",text = "Русский",area="ru"},
    {type = "fr_fr",text = "Français",area="fr"},
    {type = "pt_br",text = "Português",area="pt"},
    -- {type = "vi_vn",text = "Tiếng Việt",area="vn"},
    {type = "es_es",text = "Español",area="es"}, -- 西班牙语
}

LanguageDefine.language =
{
    none = "none",
    zh_cn = "zh_cn",
    zh_tw = "zh_tw",
    en_us = "en_us",
    ja_jp = "ja_jp",
    ko_kr = "ko_kr",
    ru_ru = "ru_ru",
    fr_fr = "fr_fr",
    pt_br = "pt_br",
    pt_br = "es_es",
}

LanguageDefine.kokrLanguage = LanguageDefine.languages[7].type
LanguageDefine.devLanguage = LanguageDefine.languages[2].type
LanguageDefine.noneLanguage = LanguageDefine.languages[1].type


LanguageDefine.CheckState =
{
    normal = 0,
    update = 1,
    error = 2,
}