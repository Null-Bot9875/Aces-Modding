local ModConfigAuthoring = {}

local CARD_REQUIRED_FIELDS = {
    "cardId",
    "name",
    "rare",
    "type",
    "tagMap",
    "targetIds",
    "costEffect",
    "skillList",
}

local CARD_DEFAULTS = {
    tag = {},
    descLua = {},
    extraCost = {},
    staticList = {},
    attkSkill = 0,
    dir = 0,
    dirSkillList = {},
    areaSkillList = {},
    hp = 0,
    useConditions = { 0 },
    stackcard = {},
    stackcardSkill = {},
    extend = {},
    limitBaseIds = {},
    upgrade = 0,
    slotType = { 0 },
    initCard = 0,
    pvpReplace = 0,
    assetId = 10001,
    mainType = 1,
    mainTag = {},
    subTag = {},
    iconId = 0,
    deviceStackIcon = {},
    keywordList = {},
}

local EFFECT_DEFAULTS = {
    desc = "",
    extend = {},
    playResultType = 0,
    customResultType = "",
    dontUseCardTimeline = false,
    markTarget = "",
}

local SKILL_DEFAULTS = {
    tag = "",
    desc = "",
    tagMap = {},
    targetIds = { 0 },
    useConditions = { 0 },
    costEffect = 0,
    extraCost = {},
    icon = "",
    triggerEx = {},
    stack = 1,
    srcCardId = 0,
    extend = {},
    visibility = 0,
    keywordList = {},
    playResultType = 0,
}

local STATIC_SKILL_DEFAULTS = {
    desc = "",
    flag = {},
    conditionList = {},
    conditionListSelf = {},
    flavorText = "",
    visibility = 0,
    keywordList = {},
    disable = 1,
    showEffects = {},
}

local CARD_SCHEMA_OVERRIDE = {
    assetId = { type = "asset_ref" },
}

local CARD_FIELDS = {
    cardId = true,
    name = true,
    tag = true,
    descLua = true,
    targetIds = true,
    costEffect = true,
    extraCost = true,
    skillList = true,
    staticList = true,
    attkSkill = true,
    dir = true,
    dirSkillList = true,
    areaSkillList = true,
    hp = true,
    useConditions = true,
    stackcard = true,
    stackcardSkill = true,
    extend = true,
    tagMap = true,
    limitBaseIds = true,
    upgrade = true,
    slotType = true,
    initCard = true,
    pvpReplace = true,
    assetId = true,
    mainType = true,
    type = true,
    mainTag = true,
    subTag = true,
    iconId = true,
    rare = true,
    deviceStackIcon = true,
    keywordList = true,
}

local function IsModId(value)
    if type(value) ~= "string" or value == "" then return false end
    if string.sub(value, 1, 1) == "." or string.sub(value, -1) == "." then return false end
    if string.find(value, "..", 1, true) then return false end
    for segment in string.gmatch(value, "[^.]+") do
        if not string.match(segment, "^[a-z0-9]+$") then return false end
    end
    return string.find(value, ".", 1, true) ~= nil
end

local function CopyDefault(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for key, item in pairs(value) do result[key] = CopyDefault(item) end
    return result
end

local function GetLocation(context, fieldPath)
    return string.format(
        "[modId:%s][path:%s][configName:card_def][sheetName:config][field:%s]",
        tostring(context.modId),
        tostring(context.path),
        tostring(fieldPath)
    )
end

local function LogUnknownField(context, fieldPath)
    local message = string.format("MOD Card 包含未知字段%s；字段将保留但不获得 Schema、索引或 i18n 语义", GetLocation(context, fieldPath))
    if context.logError ~= nil then
        context.logError(message)
    elseif LogError ~= nil then
        LogError(message)
    end
end

local function NormalizeModAssetPath(value, context)
    if not IsModId(context.modId) then
        return nil, string.format("MOD Card 图片缺少合法 modId%s", GetLocation(context, "assetId"))
    end
    if value == ""
        or string.sub(value, 1, 1) == "/"
        or string.sub(value, 1, 1) == "\\"
        or string.match(value, "^%a:[/\\]")
        or string.sub(value, 1, 6) == "mod://" then
        return nil, string.format("MOD Card assetId 必须是本 MOD assets 下的相对 PNG 路径%s", GetLocation(context, "assetId"))
    end
    local normalized = string.gsub(value, "\\", "/")
    if string.find(normalized, "//", 1, true)
        or string.find(normalized, "[%z\1-\31]")
        or string.find(normalized, "[<>:\"|%?%*]")
        or string.lower(string.sub(normalized, -4)) ~= ".png" then
        return nil, string.format("MOD Card assetId 需要合法 .png 相对路径%s", GetLocation(context, "assetId"))
    end
    for segment in string.gmatch(normalized, "[^/]+") do
        if segment == "." or segment == ".." then
            return nil, string.format("MOD Card assetId 不能越过 assets 目录%s", GetLocation(context, "assetId"))
        end
    end
    return "mod://" .. context.modId .. "/" .. normalized
end

local function ValidateCardAuthorTypes(row, context, assetProvided)
    if type(row.name) ~= "string" then
        return false, string.format("MOD Card name 必须是 string%s", GetLocation(context, "name"))
    end
    if type(row.rare) ~= "number" or row.rare % 1 ~= 0 then
        return false, string.format("MOD Card rare 必须是 int%s", GetLocation(context, "rare"))
    end
    if type(row.type) ~= "table" then
        return false, string.format("MOD Card type 必须是 list%s", GetLocation(context, "type"))
    end
    if type(row.tagMap) ~= "table" then
        return false, string.format("MOD Card tagMap 必须是 dict%s", GetLocation(context, "tagMap"))
    end
    if type(row.targetIds) ~= "table" then
        return false, string.format("MOD Card targetIds 必须是 list%s", GetLocation(context, "targetIds"))
    end
    if type(row.costEffect) ~= "number" or row.costEffect % 1 ~= 0 then
        return false, string.format("MOD Card costEffect 必须是 int%s", GetLocation(context, "costEffect"))
    end
    if type(row.skillList) ~= "table" then
        return false, string.format("MOD Card skillList 必须是 list%s", GetLocation(context, "skillList"))
    end
    if assetProvided then
        local assetType = type(row.assetId)
        if assetType ~= "string" and (assetType ~= "number" or row.assetId % 1 ~= 0) then
            return false, string.format("MOD Card assetId 必须是 int 或相对 PNG 路径%s", GetLocation(context, "assetId"))
        end
    end
    return true
end

local function NormalizeCardRow(source, context)
    if type(source) ~= "table" then
        return nil, string.format("MOD Card row 需要 table%s", GetLocation(context, "row"))
    end
    for _, fieldName in ipairs(CARD_REQUIRED_FIELDS) do
        if source[fieldName] == nil then
            return nil, string.format("MOD Card 缺少必填字段%s", GetLocation(context, fieldName))
        end
    end
    if type(source.cardId) ~= "number" or source.cardId % 1 ~= 0 or source.cardId <= 0 then
        return nil, string.format("MOD Card cardId 必须是正整数%s[value:%s]", GetLocation(context, "cardId"), tostring(source.cardId))
    end
    local assetProvided = source.assetId ~= nil
    local result = source
    for fieldName, defaultValue in pairs(CARD_DEFAULTS) do
        if result[fieldName] == nil then result[fieldName] = CopyDefault(defaultValue) end
    end
    for fieldName in pairs(result) do
        if not CARD_FIELDS[fieldName] then LogUnknownField(context, fieldName) end
    end
    local valid, err = ValidateCardAuthorTypes(result, context, assetProvided)
    if not valid then return nil, err end
    if assetProvided and type(result.assetId) == "string" then
        result.assetId, err = NormalizeModAssetPath(result.assetId, context)
        if result.assetId == nil then return nil, err end
    end
    return result
end

local function NormalizeEffectBatch(batch)
    if type(batch) ~= "table" or type(batch.rows) ~= "table" then
        return nil, "MOD Effect 批次需要包含 rows table"
    end
    local result = {}
    for key, value in pairs(batch) do result[key] = value end
    result.rows = {}
    for rowIndex, source in ipairs(batch.rows) do
        if type(source) ~= "table" then
            return nil, string.format("第%s行: MOD Effect row 需要 table", rowIndex)
        end
        for fieldName, defaultValue in pairs(EFFECT_DEFAULTS) do
            if source[fieldName] == nil then source[fieldName] = CopyDefault(defaultValue) end
        end
        result.rows[rowIndex] = source
    end
    return result
end

local function NormalizeSkillBatch(batch)
    if type(batch) ~= "table" or type(batch.rows) ~= "table" then
        return nil, "MOD Skill 批次需要包含 rows table"
    end
    local result = {}
    for key, value in pairs(batch) do result[key] = value end
    result.rows = {}
    for rowIndex, source in ipairs(batch.rows) do
        if type(source) ~= "table" then
            return nil, string.format("第%s行: MOD Skill row 需要 table", rowIndex)
        end
        for fieldName, defaultValue in pairs(SKILL_DEFAULTS) do
            if source[fieldName] == nil then source[fieldName] = CopyDefault(defaultValue) end
        end
        result.rows[rowIndex] = source
    end
    return result
end

local function NormalizeStaticSkillBatch(batch)
    if type(batch) ~= "table" or type(batch.rows) ~= "table" then
        return nil, "MOD Static Skill 批次需要包含 rows table"
    end
    local result = {}
    for key, value in pairs(batch) do result[key] = value end
    result.rows = {}
    for rowIndex, source in ipairs(batch.rows) do
        if type(source) ~= "table" then
            return nil, string.format("第%s行: MOD Static Skill row 需要 table", rowIndex)
        end
        for fieldName, defaultValue in pairs(STATIC_SKILL_DEFAULTS) do
            if source[fieldName] == nil then source[fieldName] = CopyDefault(defaultValue) end
        end
        result.rows[rowIndex] = source
    end
    return result
end

function ModConfigAuthoring.HasAdapter(configName, sheetName)
    return sheetName == "config"
        and (configName == "card_def"
            or configName == "battle_effect_def"
            or configName == "battle_skill_def"
            or configName == "static_skill_def")
end

function ModConfigAuthoring.Normalize(configName, sheetName, batch, context)
    if not ModConfigAuthoring.HasAdapter(configName, sheetName) then return batch end
    if configName == "battle_effect_def" then return NormalizeEffectBatch(batch) end
    if configName == "battle_skill_def" then return NormalizeSkillBatch(batch) end
    if configName == "static_skill_def" then return NormalizeStaticSkillBatch(batch) end
    if type(batch) ~= "table" or type(batch.rows) ~= "table" then
        return nil, "MOD Card 批次需要包含 rows table"
    end
    context = context or {}
    local result = {}
    for key, value in pairs(batch) do result[key] = value end
    result.rows = {}
    for rowIndex, source in ipairs(batch.rows) do
        local rowContext = {
            modId = context.modId,
            path = context.path,
            logError = context.logError,
        }
        local row, err = NormalizeCardRow(source, rowContext)
        if row == nil then return nil, string.format("第%s行: %s", rowIndex, tostring(err)) end
        result.rows[rowIndex] = row
    end
    return result, nil, CARD_SCHEMA_OVERRIDE
end

return ModConfigAuthoring
