local rawRequire = require
local rawLoad = load

ModHost = BaseClass("ModHost")

local function Traceback(errorMessage)
    return debug.traceback(tostring(errorMessage), 2)
end

local function NormalizeModulePath(moduleName)
    assert(type(moduleName) == "string" and moduleName ~= "", "require 模块名不能为空")
    local path = moduleName:gsub("\\", "/")
    path = path:gsub("%.lua$", ""):gsub("%.", "/")
    assert(path:sub(1, 1) ~= "/" and not path:find("..", 1, true), "非法 Mod 模块路径: " .. moduleName)
    assert(path:match("^[a-zA-Z0-9_/%-]+$"), "非法 Mod 模块名: " .. moduleName)
    return path
end

local function NormalizeConfigModulePath(moduleName)
    assert(type(moduleName) == "string" and moduleName ~= "", "配置批次模块路径不能为空")
    local path = moduleName:gsub("\\", "/"):gsub("%.lua$", "")
    assert(path:sub(1, 1) ~= "/" and not path:find("//", 1, true), "非法 MOD 配置批次路径: " .. moduleName)
    assert(not path:find("[%z\1-\31]"), "非法 MOD 配置批次路径: " .. moduleName)
    local parts = {}
    for part in path:gmatch("[^/]+") do
        assert(part ~= "." and part ~= "..", "非法 MOD 配置批次路径: " .. moduleName)
        parts[#parts + 1] = part
    end
    assert(#parts == 4
        and parts[1] == "config"
        and parts[2]:match("^[a-zA-Z0-9_]+$")
        and parts[3]:match("^[a-zA-Z0-9_]+$"),
        "MOD 配置批次路径必须使用 config/<module>/<sheet>/<file>: " .. moduleName)
    return path
end

local function BuildInfoProxy(info)
    local values = {
        id = info.id,
        name = info.name,
        author = info.author,
        version = info.version,
        description = info.description,
    }
    return setmetatable({}, {
        __index = values,
        __newindex = function()
            error("Mod Controller Info 是只读数据", 2)
        end,
        __pairs = function()
            return pairs(values)
        end,
        __metatable = false,
    })
end

function ModHost:__Init(environment, baseEnv, mods)
    self.environment = environment
    self.baseEnv = baseEnv
    self.mods = mods
    self.modById = {}
    self.controllers = {}
    self.controllerContexts = setmetatable({}, { __mode = "k" })
    self.stoppedUpdateControllers = setmetatable({}, { __mode = "k" })
    self.loadedModules = {}
    self.loadedCoreModules = {}
    self.ready = false
    self.readyFrame = nil
    for _, info in ipairs(mods) do
        self.modById[info.id] = info
    end
end

function ModHost:__Delete()
    self:Unload()
end

function ModHost:CreateController(context)
    local host = self
    local controllerValues = {
        Info = BuildInfoProxy(context),
    }
    local controller = setmetatable({}, {
        __index = controllerValues,
        __newindex = function(target, key, value)
            if key == "Info" then
                error("Mod Controller Info 不允许替换", 2)
            end
            rawset(target, key, value)
        end,
    })
    self.controllerContexts[controller] = context

    function controller:Log(...)
        LogMod(context.id, host.environment, "INFO", ...)
    end
    function controller:LogWarning(...)
        LogMod(context.id, host.environment, "WARNING", ...)
    end
    function controller:LogError(...)
        LogModError(context.id, host.environment, ...)
    end

    return controller
end

function ModHost:BuildFileEnv(context, coreModule)
    local host = self
    local fileEnv = {
        _G = false,
    }
    fileEnv._G = fileEnv
    if context then
        local modApi = {}
        function modApi.CreateController()
            return host:CreateController(context)
        end
        fileEnv.Mod = modApi
    end
    if coreModule then
        fileEnv.require = function(name)
            return host:RequireCore(name)
        end
    else
        fileEnv.require = function(name)
            return host:Require(context, name)
        end
    end
    setmetatable(fileEnv, { __index = self.baseEnv })
    return fileEnv
end

function ModHost:LoadSource(cacheKey, chunkName, context, coreModule)
    local source = CS.ModLuaBridge.GetLuaSourceText(cacheKey)
    if source == nil then
        error("Lua 模块不存在: " .. cacheKey, 2)
    end
    local fileEnv = self:BuildFileEnv(context, coreModule)
    local chunk, loadError = rawLoad(source, "@" .. chunkName, "t", fileEnv)
    if not chunk then
        error(loadError, 2)
    end
    return chunk
end

function ModHost:Require(context, moduleName)
    local separator = moduleName:find(":", 1, true)
    if separator then
        local prefix = moduleName:sub(1, separator - 1)
        local targetModule = moduleName:sub(separator + 1)
        if prefix == "core" then
            return self:RequireCore(targetModule)
        end
        local targetContext = self.modById[prefix:lower()]
        assert(targetContext, "目标 Mod 未启用或不存在: " .. prefix)
        return self:RequireModModule(targetContext, targetModule)
    end
    return self:RequireModModule(context, moduleName)
end

function ModHost:RequireCore(moduleName)
    if self.environment == "CLIENT" then
        return rawRequire(NormalizeModulePath(moduleName))
    end

    local modulePath = NormalizeModulePath(moduleName)
    local cacheKey = "core:" .. modulePath
    if self.loadedCoreModules[cacheKey] ~= nil then
        return self.loadedCoreModules[cacheKey]
    end

    self.loadedCoreModules[cacheKey] = true
    local ok, result = xpcall(function()
        local chunk = self:LoadSource(
            modulePath,
            "core/" .. modulePath .. ".lua",
            nil,
            true)
        return chunk()
    end, Traceback)
    if not ok then
        self.loadedCoreModules[cacheKey] = nil
        error(result, 2)
    end
    if result == nil then
        result = true
    end
    self.loadedCoreModules[cacheKey] = result
    return result
end

function ModHost:RequireModModulePath(context, modulePath)
    assert(context, "Mod require 缺少当前 Mod 上下文")
    local cacheKey = context.id .. ":" .. modulePath
    if self.loadedModules[cacheKey] ~= nil then
        return self.loadedModules[cacheKey]
    end

    self.loadedModules[cacheKey] = true
    local sourceKey = "__mods/" .. context.id .. "/" .. modulePath
    local chunkName = "Mods/" .. context.folder .. "/" .. modulePath .. ".lua"
    local ok, result = xpcall(function()
        local chunk = self:LoadSource(sourceKey, chunkName, context, false)
        return chunk()
    end, Traceback)
    if not ok then
        self.loadedModules[cacheKey] = nil
        error(result, 2)
    end
    if result == nil then
        result = true
    end
    self.loadedModules[cacheKey] = result
    return result
end

function ModHost:RequireModModule(context, moduleName)
    return self:RequireModModulePath(context, NormalizeModulePath(moduleName))
end

function ModHost:ExecuteConfigBatch(context, modulePath)
    assert(context, "Mod require 缺少当前 Mod 上下文")
    local normalizedPath = NormalizeConfigModulePath(modulePath)
    local cacheKey = context.id .. ":" .. normalizedPath
    local cached = self.loadedModules[cacheKey]
    if cached ~= nil then
        if type(cached) ~= "table" then
            self.loadedModules[cacheKey] = nil
            error(string.format(
                "MOD 配置批次必须返回 table[id:%s][path:%s]",
                tostring(context.id),
                tostring(modulePath)), 2)
        end
        return cached
    end

    self.loadedModules[cacheKey] = true
    local sourceKey = "__mods/" .. context.id .. "/" .. normalizedPath
    local chunkName = "Mods/" .. context.folder .. "/" .. normalizedPath .. ".lua"
    local ok, result = xpcall(function()
        local chunk = self:LoadSource(sourceKey, chunkName, context, false)
        local batch = chunk()
        if type(batch) ~= "table" then
            error(string.format(
                "MOD 配置批次必须返回 table[id:%s][path:%s]",
                tostring(context.id),
                tostring(modulePath)), 2)
        end
        return batch
    end, Traceback)
    if not ok then
        self.loadedModules[cacheKey] = nil
        error(result, 2)
    end
    self.loadedModules[cacheKey] = result
    return result
end

function ModHost:CallController(controller, methodName, ...)
    local callback = controller[methodName]
    if type(callback) ~= "function" then
        return true
    end
    local context = self.controllerContexts[controller]
    local args = { ... }
    local ok, errorMessage = xpcall(function()
        callback(controller, table.unpack(args))
    end, Traceback)
    if not ok then
        LogModError(context.id, self.environment, errorMessage)
        return false, errorMessage
    end
    return true
end

function ModHost:Start(entryPath)
    for _, context in ipairs(self.mods) do
        local sourceKey = "__mods/" .. context.id .. "/" .. entryPath
        local chunkName = "Mods/" .. context.folder .. "/" .. entryPath .. ".lua"
        local ok, result = xpcall(function()
            local chunk = self:LoadSource(sourceKey, chunkName, context, false)
            return chunk()
        end, Traceback)
        if not ok then
            LogModError(context.id, self.environment, result)
            return false, {
                __modStartupFailure = true,
                modId = context.id,
                stage = "entry_load",
                message = result,
            }
        elseif type(result) ~= "table" or self.controllerContexts[result] ~= context then
            local message = chunkName .. " 必须返回 Mod.CreateController() 创建的对象"
            LogModError(context.id, self.environment, message)
            return false, {
                __modStartupFailure = true,
                modId = context.id,
                stage = "entry_contract",
                message = message,
            }
        else
            local isOk, errorMessage = self:CallController(result, "OnLoad")
            if isOk then
                self.controllers[#self.controllers + 1] = result
            else
                self:CallController(result, "OnUnload")
                return false, {
                    __modStartupFailure = true,
                    modId = context.id,
                    stage = "on_load",
                    message = errorMessage,
                }
            end
        end
    end
    return true
end

function ModHost:GameReady()
    if self.ready then
        return
    end
    for _, controller in ipairs(self.controllers) do
        self:CallController(controller, "OnGameReady")
    end
    self.ready = true
    self.readyFrame = Time.frameCount
end

function ModHost:UpdateController(controller, deltaTime)
    if self.stoppedUpdateControllers[controller] then
        return
    end
    local isOk = self:CallController(controller, "OnUpdate", deltaTime)
    if not isOk then
        self.stoppedUpdateControllers[controller] = true
    end
end

function ModHost:Update(deltaTime)
    if not self.ready or Time.frameCount <= self.readyFrame then
        return
    end
    for _, controller in ipairs(self.controllers) do
        self:UpdateController(controller, deltaTime)
    end
end

function ModHost:UpdateWithoutGameReady(deltaTime)
    for _, controller in ipairs(self.controllers) do
        self:UpdateController(controller, deltaTime)
    end
end

function ModHost:Unload()
    for index = #self.controllers, 1, -1 do
        self:CallController(self.controllers[index], "OnUnload")
    end
    self.controllers = {}
    self.stoppedUpdateControllers = setmetatable({}, { __mode = "k" })
    self.loadedModules = {}
    self.loadedCoreModules = {}
end
