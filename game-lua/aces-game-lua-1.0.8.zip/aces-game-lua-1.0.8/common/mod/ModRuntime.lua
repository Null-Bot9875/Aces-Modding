local function ReadStartupPayload()
    local value = CJson.decode(CS.ModLuaBridge.GetStartupJson())
    assert(type(value) == "table", "MOD 启动清单需要 table")
    return value
end

local payload = ReadStartupPayload()
local ModConfigAuthoring = require("common/mod/ModConfigAuthoring")

local ModRuntime = {}
local STARTUP_FAILURE_MARKER = "ACES_MOD_STARTUP_FAILURE:"

local clientHost = nil
local preloadCallback = nil
local enterLoginCallback = nil
local enterBattleCallback = nil
local recoveryManagerOpened = false

local function CaptureStartupError(value)
    if type(value) == "table" and value.__modStartupFailure then
        return value
    end
    return debug.traceback(tostring(value), 2)
end

local function EncodeStartupFailure(failure)
    return STARTUP_FAILURE_MARKER .. CJson.encode({
        modId = tostring(failure.modId),
        stage = tostring(failure.stage),
        message = tostring(failure.message),
    })
end

function ModRuntime.ReportStartupFailure(failure)
    assert(type(failure) == "table" and failure.__modStartupFailure,
        "MOD 启动失败报告需要结构化 failure")
    local encodedFailure = EncodeStartupFailure(failure)
    CS.ModLuaBridge.ReportStartupFailure(encodedFailure)
    return encodedFailure
end

local function CloseManagerWindow()
    local window = rawget(_G, "ModManagerWindow")
    if window then
        ViewManager.Instance:CloseWindow(window)
    end
end

function ModRuntime.GetCurrentModProfile()
    local profile = {}
    for _, info in ipairs(payload.mods or {}) do
        assert(type(info.id) == "string" and info.id ~= "", "MOD Profile 缺少有效 id")
        assert(type(info.version) == "string" and info.version ~= "", "MOD Profile 缺少有效 version")
        profile[#profile + 1] = {
            id = info.id,
            version = info.version,
        }
    end
    return profile
end

function ModRuntime.ReinstallConfigsForCurrentLanguage()
    local refreshedPayload = ReadStartupPayload()
    return Config.ReinstallMods(refreshedPayload.mods or {})
end

function ModRuntime.StartClient()
    local mods = payload.mods or {}
    if Language.Instance == nil then
        Language.New()
    end
    clientHost = ModHost.New("CLIENT", _G, mods)
    if #mods > 0 then
        CS.ModLuaBridge.ActivateSession()
    end
    local success, errorMessage = xpcall(function()
        Config.InstallMods(clientHost, mods, ModConfigAuthoring)
        local started, failure = clientHost:Start("main")
        if not started then
            error(failure, 0)
        end
    end, CaptureStartupError)
    if not success then
        clientHost:Delete()
        clientHost = nil
        if type(errorMessage) == "table" and errorMessage.__modStartupFailure then
            error(EncodeStartupFailure(errorMessage), 0)
        end
        error(errorMessage, 2)
    end
end

function ModRuntime.BindClientLifecycle()
    assert(clientHost, "Mod 客户端入口尚未启动")
    preloadCallback = function()
        clientHost:GameReady()
    end
    enterLoginCallback = function()
        if payload.pendingModFailure and not recoveryManagerOpened then
            recoveryManagerOpened = true
            mod.ModCtrl:OpenManager()
        else
            CloseManagerWindow()
        end
    end
    enterBattleCallback = function()
        CloseManagerWindow()
    end
    EventManager.Instance:AddEvent(EventDefine.preload_complete, preloadCallback)
    EventManager.Instance:AddEvent(EventDefine.enter_login, enterLoginCallback)
    EventManager.Instance:AddEvent(EventDefine.enter_battle, enterBattleCallback)
end

function ModRuntime.UpdateClient(deltaTime)
    if clientHost then
        clientHost:Update(deltaTime)
    end
end

function ModRuntime.StopClient()
    if preloadCallback then
        EventManager.Instance:RemoveEvent(EventDefine.preload_complete, preloadCallback)
        EventManager.Instance:RemoveEvent(EventDefine.enter_login, enterLoginCallback)
        EventManager.Instance:RemoveEvent(EventDefine.enter_battle, enterBattleCallback)
        preloadCallback = nil
        enterLoginCallback = nil
        enterBattleCallback = nil
        recoveryManagerOpened = false
    end
    if clientHost then
        clientHost:Delete()
        clientHost = nil
    end
end

function ModRuntime.StartLocalServer(env)
    local localServerMods = {}
    for _, info in ipairs(payload.mods or {}) do
        if info.hasLocalServerEntry then
            localServerMods[#localServerMods + 1] = info
        end
    end

    local host = ModHost.New("LOCAL_SERVER", env, localServerMods)
    local started, failure = host:Start("local_server/main")
    if not started then
        host:Delete()
        error(failure, 0)
    end
    local firstUpdateFrame = Time.frameCount
    local timer = TimerManager.Instance:AddTimerByNextFrame(0, 0, function()
        if Time.frameCount > firstUpdateFrame then
            host:UpdateWithoutGameReady(Time.deltaTime)
        end
    end)

    local stopped = false
    local function Stop()
        if stopped then
            return
        end
        stopped = true
        if timer then
            TimerManager.Instance:RemoveTimer(timer)
            timer = nil
        end
        host:Delete()
    end
    return Stop
end

return ModRuntime
