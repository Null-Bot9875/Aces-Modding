Network = BaseClass("Network")

local curProtoId = nil

local MOD_BLOCKED_ONLINE_PROTOCOLS = {
    [3150] = true,
    [3201] = true,
    [3202] = true,
    [3203] = true,
    [3211] = true,
    [3231] = true,
    [3350] = true,
}

NET_DEBUG = true

function Network:__Init(connType)
    local define = NetworkDefine
    self.conn = BaseConn.Create(connType)

    self.onHookRecv = nil
    self.handlers = {}

    -- 本地模式（local_server 本地后端用）
    self.localMode = false
    self.localHandlers = {}
    self.localDispatchQueue = {}
    self.localDispatchTimer = nil

    self.remoteTime = 0
    self.remoteSyncTime = 0

    self.tickTimer = nil
    self.lastTickTime = 0

    self.host = nil
    self.port = nil

    self.tickProtoId = nil
    self.tickTimeout = 0
    self.tickSendInterval = 0
    
    self.conn:SetEvent(ConnEvent.disconnect,self:ToFunc("ConnDisconnect"))

    self.reconnect = NetworkReconnect.New(self)

    self.conn:SetDispatcher(self:ToFunc("Dispatcher"))

    self.resendIds = {}
    self.resendDatas = List.New()

    self.pingStopwatch = CS.System.Diagnostics.Stopwatch()
    self.pingVal = 0
end

function Network:__Delete()
    self:ClearLocalDispatchQueue()
    self:Disconnect()
    self.conn:Delete()
    self.reconnect:Delete()
end

function Network.InitGpbParser()
    GpbParser.New()
    GpbParser.Instance:InitGpb()
end

function Network:SetHookRecv(onHookRecv)
    self.onHookRecv = onHookRecv
end

function Network:SetTick(tickProtoId,tickTimeout,tickSendInterval)
    self.tickProtoId = tickProtoId
    self.tickTimeout = tickTimeout
    self.tickSendInterval = tickSendInterval
end

function Network:Connect(host,port)
    LogInfo(string.format("Network:Connect(%s, %s)", host, port))
    self.host = host
    self.port = port
    self.conn:Connect(host,port)
end

function Network:AddHandler(id,func,isResend)
    if not self.handlers[id] then
        self.handlers[id] = List.New()
    end
    self.handlers[id]:Push(func,func)

    if isResend then
        self.resendIds[id] = true
    end
end

function Network:RemoveHandler(id,func)
    if self.handlers[id] then
        self.handlers[id]:RemoveByIndex(func)
    end
end

function Network:CleanHandler()
    self.handlers = {}
end

-- ===== 本地模式接口（local_server 本地后端用）=====

--- 开启/关闭本地模式
function Network:SetLocalMode(enabled)
    self.localMode = enabled
    if not enabled then
        self:ClearLocalDispatchQueue()
    end
    Log("[Network] 本地模式: " .. (enabled and "ON" or "OFF"))
end

--- 注册本地协议处理器
---@param id number   协议 ID
---@param handler function(id, data, network)  处理函数
function Network:RegisterLocalHandler(id, handler)
    self.localHandlers[id] = handler
end

function Network:ClearLocalDispatchQueue()
    self.localDispatchQueue = {}
    self:_StopLocalDispatchTimer()
end

function Network:IsLocalDispatchIdle()
    return #self.localDispatchQueue <= 0 and self.localDispatchTimer == nil
end

--- 本地模式：向已注册的 handlers 推送数据（模拟网络收包）
---@param protoId number
---@param data table
---@param delayFrame number|nil 延后帧数，默认下一帧
function Network:DispatchLocal(protoId, data, delayFrame)
    if delayFrame == nil then delayFrame = 1 end
    if delayFrame < 0 then delayFrame = 0 end

    table.insert(self.localDispatchQueue, {
        protoId = protoId,
        data = data,
        leftFrame = delayFrame,
    })
    self:_StartLocalDispatchTimer()
end

function Network:_StartLocalDispatchTimer()
    if self.localDispatchTimer then return end
    self.localDispatchTimer = TimerManager.Instance:AddTimerByNextFrame(0, 0, self:ToFunc("_UpdateLocalDispatchQueue"))
end

function Network:_StopLocalDispatchTimer()
    if not self.localDispatchTimer then return end
    if TimerManager and TimerManager.Instance then
        TimerManager.Instance:RemoveTimer(self.localDispatchTimer)
    end
    self.localDispatchTimer = nil
end

function Network:_UpdateLocalDispatchQueue()
    if #self.localDispatchQueue <= 0 then
        self:_StopLocalDispatchTimer()
        return
    end

    local readyMessages = {}
    local waitMessages = {}
    for _, message in ipairs(self.localDispatchQueue) do
        message.leftFrame = message.leftFrame - 1
        if message.leftFrame <= 0 then
            table.insert(readyMessages, message)
        else
            table.insert(waitMessages, message)
        end
    end
    self.localDispatchQueue = waitMessages

    for _, message in ipairs(readyMessages) do
        self:_DispatchLocalNow(message.protoId, message.data)
    end

    if #self.localDispatchQueue <= 0 then
        self:_StopLocalDispatchTimer()
    end
end

function Network:_DispatchLocalNow(protoId, data)
    if self.handlers[protoId] then
        for iter in self.handlers[protoId]:Items() do
            xpcall(iter.value, Network.PackError, data, protoId)
        end
    end

    if self.onHookRecv then
        self.onHookRecv(protoId, data)
    end
end

-- ============================

function Network:Dispatcher(bytes)
    local protoId,data = GpbParser.Instance:UnPack(bytes)

    if protoId == self.tickProtoId then
        self:ResetTickTime()
    end

    if self.resendIds[protoId] and self.resendDatas:ExistIndex(protoId) then
        self.resendDatas:RemoveByIndex(protoId)
    end

    if self.handlers[protoId] then
        for iter in self.handlers[protoId]:Items() do
            xpcall(iter.value,Network.PackError, data, protoId)
        end
    end

    if self.onHookRecv then
        self.onHookRecv(protoId,data)
    end
end

-- function Network:RecvPack()
--     self.conn:Recv()
-- end

function Network.PackError(err)
    LogErrorf("处理协议报错[%s]%s",curProtoId,err)
end

function Network:Send(id,data)
    -- 本地模式：若无本地处理器，必须显式失败，不能隐式走真网络。
    if self.localMode then
        local handler = self.localHandlers[id]
        if handler then
            handler(id, data, self)
            return
        end
        self:_DispatchLocalUnsupported(id)
        return
    end

    if CS.ModLuaBridge.IsSessionActive() and MOD_BLOCKED_ONLINE_PROTOCOLS[id] then
        local message = TI18N("mod_online_unavailable")
        LogError(message)
        if SystemDialog then
            SystemDialog.ShowWarning({
                content = message,
                isHideCancel = true,
            })
        end
        return
    end

    if not self.conn:IsConnect() then
        return
    end

    local byteArray = GpbParser.Instance:Pack(id,data)
    self.conn:Send(byteArray)
    --Log("发送长度",#byteArray)

    if self.resendIds[id] then
        if self.resendDatas:ExistIndex(id) then
            assert(false,string.format("发送协议异常,需要重发的协议不允许未回包之前多次发送[协议id:%s]",id))
        else
            self.resendDatas:Push(byteArray,id)
        end
    end
end

function Network:_DispatchLocalUnsupported(id)
    local msg = "[Network] 本地模式未注册协议: " .. tostring(id)
    if LogError then
        LogError(msg)
    else
        Log(msg)
    end
    self:DispatchLocal(102, { error = msg }, 0)
end

function Network:ResendData()
    for v in self.resendDatas:Items() do
        self.conn:Send(v.value)
    end
end

function Network:RemoveResendData(protoId)
    if self.resendDatas:ExistIndex(protoId) then
        self.resendDatas:RemoveByIndex(protoId)
    end
end

function Network:CleanResend()
    self.resendDatas:Clear()
end

function Network:Update()
    if self.conn:IsConnect() then
        self.conn:Update()
    end
end

--心跳包相关
function Network:StartTick()
    self.lastTickTime = 0
    self:SendTick()
    self:RemoveTickTimer()
    self.tickTimer = TimerManager.Instance:AddTimer(0,self.tickSendInterval,self:ToFunc("SendTick")) 
end

function Network:RestartTick()
    if not self.tickTimer then 
        self.tickTimer = TimerManager.Instance:AddTimer(0,self.tickSendInterval,self:ToFunc("SendTick")) 
    end
end

function Network:StopTick()
    self.lastTickTime = 0
    self.pingVal = 0
    self:RemoveTickTimer()
end

function Network:SendTick(ignoreTimeout)
    -- Log("发送心跳包")
    local time = os.time()

    self.pingStopwatch:Reset()
    self.pingStopwatch:Start()
    
    if not ignoreTimeout and self:IsTimeout(time) then return end
    self:Send(self.tickProtoId,{cltTimeMs = math.floor(self:GetRemoteTimeByMS()),lastPing = self.pingVal})

    self.pingVal = 0
end

function Network:IsTimeout(time)
    if self.lastTickTime == 0 then 
        return false 
    end

    if time - self.lastTickTime <= self.tickTimeout then 
        return false
    else
        LogError("心跳包超时导致网络断开")
        self.conn:Disconnect(NetworkDefine.DisconnectType.tick_timeout)
        return true
    end
end

function Network:RemoveTickTimer()
    if self.tickTimer then 
        TimerManager.Instance:RemoveTimer(self.tickTimer)
        self.tickTimer = nil
    end
end

function Network:ResetTickTime()
    --LogColor("心跳包重置")
    self.lastTickTime = os.time()

    self.pingStopwatch:Stop()
    self.pingVal = math.floor(self.pingStopwatch.Elapsed.TotalMilliseconds)

    self:RestartTick()
end

function Network:ConnDisconnect()
    self:StopTick()
end

function Network:Disconnect(err)
    if not err then err = NetworkDefine.DisconnectType.initiative end
    self.conn:Disconnect(err)
end

function Network:Close()
    self.conn:Close()
end

function Network:SetEvent(event,callBack)
    self.conn:SetEvent(event,callBack)
end

function Network:QueryState()
    Log("网络连接状态",self.conn:GetState())
end

function Network:IsConnect()
    return self.conn:IsConnect()
end

function Network:GetTickTime()
    return self.lastTickTime
end

function Network:SetRemoteTime(time)
    --Log("同步时间",time)
    self.remoteTime = time
    self.remoteSyncTime = Time.realtimeSinceStartup
end

function Network:GetRemoteTime()
    local offsetTime = Time.realtimeSinceStartup - self.remoteSyncTime
	local curTime = math.ceil(self.remoteTime/1000)+ offsetTime
    return curTime
end

function Network:GetRemoteRemainTime(targetTime)
    local offsetTime = Time.realtimeSinceStartup - self.remoteSyncTime
	local curTime = math.ceil(self.remoteTime/1000)+ offsetTime
    

    local remainTime = targetTime - curTime
    return remainTime > 0 and remainTime or 0
end

function Network:GetRemoteRemainTimeByMs(targetTime)
    local offsetTime = Time.realtimeSinceStartup - self.remoteSyncTime
	local curTime = self.remoteTime + offsetTime * 1000
    local remainTime = targetTime - curTime
    return remainTime > 0 and remainTime or 0
end

function Network:GetRemoteTimeByMS()
    local offsetTime = Time.realtimeSinceStartup - self.remoteSyncTime
	return self.remoteTime + offsetTime * 1000
end
