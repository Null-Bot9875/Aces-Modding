FrameCreate = BaseClass("FrameCreate")

function FrameCreate:__Init(args)
    self.args = args
    self.frameTimer = nil
    self.createIndex = 0
end

function FrameCreate:__Delete()
    self:RemoveTimer()
end

function FrameCreate:Start()
    local preNum = self.args.preNum > self.args.maxNum and self.args.maxNum or self.args.preNum
    for i = 1, preNum do
        self:Create()
    end

    if self.createIndex < self.args.maxNum then
        self.frameTimer = TimerManager.Instance:AddTimerByNextFrame(0,0,self:ToFunc("OnUpdate"))
    end
end

function FrameCreate:OnUpdate()
    if self.createIndex + 1 <= self.args.maxNum then
        self:Create()
    else
        self:RemoveTimer()
    end
end

function FrameCreate:Create()
    self.createIndex = self.createIndex + 1
    self.args.onCreate(self.createIndex)
end

function FrameCreate:RemoveTimer()
    if self.frameTimer then
        TimerManager.Instance:RemoveTimer(self.frameTimer)
        self.frameTimer = nil
    end
end