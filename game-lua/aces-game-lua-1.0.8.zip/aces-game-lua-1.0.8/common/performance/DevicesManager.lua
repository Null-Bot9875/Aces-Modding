DevicesManager = SingleClass("DevicesManager")

function DevicesManager:__Init()
    if Application.platform == RuntimePlatform.IPhonePlayer then
        isIOS = true
    elseif Application.platform == RuntimePlatform.Android then
        isAndroid = true
    end

    --是否模拟器
    self.isEmulator = BaseApi.IsEmulator()

    --是否有刘海
    self.supportNotch = false

    --刘海的高度 
    self.notchHeight = 0

    --设备信息
    self.devicesInfo = {}
    self.devicesInfo.deviceName = SystemInfo.deviceName
    self.devicesInfo.deviceModel = SystemInfo.deviceModel
    self.devicesInfo.isEmulator = self.isEmulator
    self.devicesInfo.gpuName =  SystemInfo.graphicsDeviceName
    self.devicesInfo.memorySize =  SystemInfo.systemMemorySize / 1024
    self.devicesInfo.frequeancy = SystemInfo.processorFrequency / 100
    self.devicesInfo.processorType = SystemInfo.processorType

    self.devicesPerformanLevel = nil

    self:InitNotch()
    self:InitPerformanLevel()


    LogInfof("当前设备性能等级[%s]",self.devicesPerformanLevel)
    LogInfof("刘海信息[是否支持刘海:%s][刘海高度:%s]",tostring(self.supportNotch),tostring(self.notchHeight))
    LogTableInfo("设备信息",self.devicesInfo)
end

function DevicesManager:__Delete()

end

--获取刘海参数
function DevicesManager:InitNotch()
    if Application.platform == RuntimePlatform.Android then
        self.supportNotch = AndroidNotchAgent.supportNotch
        self.notchHeight = AndroidNotchAgent.notchHeight
    elseif Application.platform == RuntimePlatform.IPhonePlayer then

    elseif Application.platform == RuntimePlatform.WindowsPlayer then

    end

    if self.notchHeight > 80 then self.notchHeight = 80 end
end

function DevicesManager:GetNotch()
    return self.notchHeight 
end

function DevicesManager:InitPerformanLevel()
    --默认3，例如win
    self.devicesPerformanLevel = PerformanceDefine.DeviceLevel.high
	local gpuName = tostring(SystemInfo.graphicsDeviceName)
	gpuName = string.gsub(gpuName," ","")
	gpuName = string.lower(gpuName)


    if Application.platform == RuntimePlatform.Android then
        self.devicesPerformanLevel = self:CheckAndroidLevel(gpuName)
    elseif Application.platform == RuntimePlatform.IPhonePlayer then
        self.devicesPerformanLevel = self:CheckIPhoneLevel(gpuName)
    elseif Application.platform == RuntimePlatform.WindowsPlayer or Application.platform == RuntimePlatform.OSXPlayer
		or Application.platform == RuntimePlatform.WindowsEditor then
		self.devicesPerformanLevel = self:CheckWindowsLevel(gpuName)
    end

	-- Log("##############设备等级:" .. self.devicesPerformanLevel)
end

function DevicesManager:CheckAndroidLevel(gpuName)
    local level 
    if string.find(gpuName, "adreno") then
        level = self:GetAdrenoGpuLvl(gpuName)
    elseif string.find(gpuName,"mali") then
        level = self:GetMaliGpuLvl(gpuName)
    elseif string.find(gpuName,"powervr") then
        level = self:GetPowerVRGpuLvl(gpuName)
    else	--未知
        level = self:GetUnknownDeviceQualityLvl(gpuName)
    end

    if not level then
		level = self:GetUnknownDeviceQualityLvl(gpuName)
    end

    return level
end




function DevicesManager:CheckIPhoneLevel(gpuName)
    local level
    if string.find(gpuName, "apple") then
        self.devicesPerformanLevel = self:GetAppleGpuLvl(gpuName)
    end

    if not level then
		level = self:GetUnknownDeviceQualityLvl(gpuName)
    end

    return level
end


function DevicesManager:CheckWindowsLevel(gpuName)
	local level = PerformanceDefine.DeviceLevel.middle
	if string.find(gpuName, "nvidia") then
		level = self:GetNvidiaGpuLevel(gpuName)
	elseif string.find(gpuName, "amd") then
		level = self:GetAmdGpuLevel(gpuName)
	elseif string.find(gpuName, "intel") then
		level = self:GetIntelGpuLevel(gpuName)
	end 

	if not level then
		level = self:GetUnknownDeviceQualityLvl()
	end

	return level
end

function DevicesManager:GetIntelGpuLevel(gpuName)
	local level 
	if string.find(gpuName, "arc") then
		if string.find(gpuName, "a770") or string.find(gpuName, "a750") then
			level = PerformanceDefine.DeviceLevel.high
		elseif string.find(gpuName, "a580") or string.find(gpuName, "a380") then
			level = PerformanceDefine.DeviceLevel.middle
		else
			level = PerformanceDefine.DeviceLevel.low
		end
	elseif string.find(gpuName, "iris") then
		if string.find(gpuName, "xe") then
			level = PerformanceDefine.DeviceLevel.low
		else
			level = PerformanceDefine.DeviceLevel.low
		end
	else
		level = PerformanceDefine.DeviceLevel.low
	end
	return level
end

--Amd Radeon rx 7900 xt
function DevicesManager:GetAmdGpuLevel(gpuName)
	local level 
	if string.find(gpuName, "rx") then
		local key1 = string.sub(gpuName,12,14)
		key1 = tonumber(key1)
		local key2 = string.sub(gpuName,12,15)
		key2 = tonumber(key2)
		local key = key2 or key1
		if not key then
			level = self:GetUnknownDeviceQualityLvl(gpuName)
		end
		if key >= 7900 then --RX 7900
			level = PerformanceDefine.DeviceLevel.ultra
		elseif key >= 7800 and key < 7900 then --RX 7800
			level = PerformanceDefine.DeviceLevel.ultra
		elseif key >= 7700 and key < 7800 then --RX 7700
			level = PerformanceDefine.DeviceLevel.high
		elseif key >= 7600 and key < 7700 then --RX 7600
			level = PerformanceDefine.DeviceLevel.middle
		elseif key >= 7500 and key < 7600 then --RX 7500
			level = PerformanceDefine.DeviceLevel.low
		elseif key >= 6900 and key < 7000 then --RX 6900
			level = PerformanceDefine.DeviceLevel.ultra
		elseif key >= 6800 and key < 6900 then --RX 6800
			level = PerformanceDefine.DeviceLevel.ultra
		elseif key >= 6700 and key < 6800 then --RX 6700
			level = PerformanceDefine.DeviceLevel.high
		elseif key >= 6600 and key < 6700 then --RX 6600
			level = PerformanceDefine.DeviceLevel.middle
		elseif key >= 6500 and key < 6600 then --RX 6500
			level = PerformanceDefine.DeviceLevel.low
		elseif key >= 6400 and key < 6500 then --RX 6400
			level = PerformanceDefine.DeviceLevel.low
		elseif key >= 5700 and key < 6000 then --RX 5700
			level = PerformanceDefine.DeviceLevel.high
		elseif key >= 5600 and key < 5700 then --RX 5600
			level = PerformanceDefine.DeviceLevel.middle
		elseif key >= 5000 and key < 5600 then --RX 5000
			level = PerformanceDefine.DeviceLevel.low
		elseif key >= 400 and key < 600 then --RX 400/500
			level = PerformanceDefine.DeviceLevel.low
		end
	elseif string.find(gpuName, "hd") then
		level = PerformanceDefine.DeviceLevel.low
	elseif string.find(gpuName, "rxvega") then
		level = PerformanceDefine.DeviceLevel.middle
	end
	return level
end

function DevicesManager:GetNvidiaGpuLevel(gpuName)
	local level 
	if string.find(gpuName, "gt") or string.find(gpuName, "gs") then
		level = PerformanceDefine.DeviceLevel.middle
	elseif string.find(gpuName, "gtx") then
		local key1 = string.sub(gpuName,17,19)
		key1 = tonumber(key1)
		local key2 = string.sub(gpuName,17,20)
		key2 = tonumber(key2)
		local key = key2 or key1
		if not key then
			level = self:GetUnknownDeviceQualityLvl(gpuName)
		end
		if key >= 1660 then
			level = PerformanceDefine.DeviceLevel.high 
		else
			level = PerformanceDefine.DeviceLevel.middle 
		end
	elseif string.find(gpuName, "rtx") then --nvidia geforce rtx
		local key = string.sub(gpuName,17,20)
		key = tonumber(key)
		if not key then
			level = self:GetUnknownDeviceQualityLvl(gpuName)
		end
		if key >= 4090 then
			level = PerformanceDefine.DeviceLevel.ultra
		elseif key >= 4080 then
			level = PerformanceDefine.DeviceLevel.ultra
		elseif key >= 3090 then
			level = PerformanceDefine.DeviceLevel.ultra
		elseif key >= 3080 then
			level = PerformanceDefine.DeviceLevel.ultra
		elseif key >= 4070 then
			level = PerformanceDefine.DeviceLevel.ultra
		elseif key >= 3070 then
			level = PerformanceDefine.DeviceLevel.ultra
		elseif key >= 2080 then
			level = PerformanceDefine.DeviceLevel.high
		elseif key >= 4060 then
			level = PerformanceDefine.DeviceLevel.high
		elseif key >= 3060 then
			level = PerformanceDefine.DeviceLevel.high
		elseif key >= 2070 then
			level = PerformanceDefine.DeviceLevel.high
		else
			level = PerformanceDefine.DeviceLevel.middle
		end
	end
	return level
end


function DevicesManager:GetAdrenoGpuLvl(gpuName)
	local key = string.sub(gpuName,11,13)
	key = tonumber(key)

	if not key then
		return self:GetUnknownDeviceQualityLvl(gpuName)
	end

	if key >= 700 then
        return PerformanceDefine.DeviceLevel.high
    elseif key < 700 and key >= 650 then
		return PerformanceDefine.DeviceLevel.middle
	else
		return PerformanceDefine.DeviceLevel.low
	end
end

function DevicesManager:GetMaliGpuLvl(gpuName)
	local firstKey = string.sub(gpuName,6,6)
	local secondkey = string.sub(gpuName, 7, -1)
	secondkey = tonumber(secondkey)
	if not secondkey then
		return self:GetUnknownDeviceQualityLvl(gpuName)
	end
	if firstKey == "g" then
		if secondkey >= 76 then
			return PerformanceDefine.DeviceLevel.high
		elseif secondkey < 76 and secondkey >= 71 then
			return PerformanceDefine.DeviceLevel.middle
		else
			return PerformanceDefine.DeviceLevel.low
		end
	else
		if secondkey > 880 then
			return PerformanceDefine.DeviceLevel.middle
		else
			return PerformanceDefine.DeviceLevel.low
		end
	end

end

--G6200
--Marlowe
function DevicesManager:GetPowerVRGpuLvl(gpuName)
	local firstKey = string.sub(gpuName,13,14)

	local specialKey = string.sub(gpuName,13)
	local specialKey2 = string.sub(gpuName,8,10)

	local secondkey = string.sub(gpuName,15,18)
	secondkey = tonumber(secondkey)

	if firstKey == "gt" or firstKey == "gm" then
		if not secondkey then
			return self:GetUnknownDeviceQualityLvl(gpuName)
		end
		if secondkey >= 9000 then
			if secondkey > 9400 then
				return PerformanceDefine.DeviceLevel.high
			elseif secondkey >= 9200 and secondkey < 9400 then
				return PerformanceDefine.DeviceLevel.middle
			else
				return PerformanceDefine.DeviceLevel.low
			end
		elseif secondkey < 9000 and secondkey >= 8000 then
			if secondkey > 8400 then
				return PerformanceDefine.DeviceLevel.high
			elseif secondkey >= 8200 and secondkey < 8400 then
				return PerformanceDefine.DeviceLevel.middle
			else
				return PerformanceDefine.DeviceLevel.low
			end
		else
			return PerformanceDefine.DeviceLevel.low
		end
	elseif firstKey == "ge" then
		if not secondkey then
			return self:GetUnknownDeviceQualityLvl(gpuName)
		end
		if secondkey >= 9000 then
			if secondkey > 9400 then
				return PerformanceDefine.DeviceLevel.high
			elseif secondkey >= 9200 and secondkey < 9400 then
				return PerformanceDefine.DeviceLevel.middle
			else
				return PerformanceDefine.DeviceLevel.low
			end
		elseif secondkey < 9000 and secondkey >= 8000 then
			if secondkey > 8400 then
				return PerformanceDefine.DeviceLevel.middle
			else
				return PerformanceDefine.DeviceLevel.low
			end
		else
			return PerformanceDefine.DeviceLevel.low
		end
	elseif specialKey == "g6200" then
		return PerformanceDefine.DeviceLevel.low
	elseif specialKey == "marlowe" then
		return PerformanceDefine.DeviceLevel.middle
	elseif specialKey2 == "sgx" then
		return PerformanceDefine.DeviceLevel.low
	else
		return self:GetUnknownDeviceQualityLvl(gpuName)
	end
end

function DevicesManager:GetUnknownDeviceQualityLvl(gpuName)
	if Application.platform == RuntimePlatform.IPhonePlayer then
		local frequeancy = SystemInfo.processorFrequency;
		frequeancy = frequeancy / 100;
		
		if frequeancy > 14 then --	6s及以上
			return PerformanceDefine.DeviceLevel.high;
		else
			return PerformanceDefine.DeviceLevel.middle;
		end
	elseif Application.platform == RuntimePlatform.WebGLPlayer then
		return PerformanceDefine.DeviceLevel.middle;
	elseif Application.platform == RuntimePlatform.WindowsPlayer or Application.platform == RuntimePlatform.OSXPlayer
		or Application.platform == RuntimePlatform.WindowsEditor then
		local graphicsMemorySize = SystemInfo.graphicsMemorySize
		graphicsMemorySize = graphicsMemorySize / 1024
		if graphicsMemorySize > 8 then
			return PerformanceDefine.DeviceLevel.ultra;
		elseif graphicsMemorySize <= 8 and graphicsMemorySize > 4 then 
			return PerformanceDefine.DeviceLevel.high;
		else
			return PerformanceDefine.DeviceLevel.middle;
		end
	end

    return self:GetMemorySizeLv();
end

--苹果处理器性能
function DevicesManager:GetAppleGpuLvl(gpuName)
	--applea9gpu
	local firstKey = string.sub(gpuName,7,8)

	firstKey = tonumber(firstKey)

	if firstKey then
		if firstKey >= 10 then
			return PerformanceDefine.DeviceLevel.high
		elseif firstKey >= 9 then
			return PerformanceDefine.DeviceLevel.middle
		else
			return PerformanceDefine.DeviceLevel.low
		end
	else
		return PerformanceDefine.DeviceLevel.middle
	end
end

function DevicesManager:GetMemorySizeLv()
	local memorySize = SystemInfo.systemMemorySize
	memorySize = memorySize / 1024;

	if memorySize >= 6 then
		return PerformanceDefine.DeviceLevel.high;
	elseif memorySize >= 4 then
		return PerformanceDefine.DeviceLevel.middle;
	else
		return PerformanceDefine.DeviceLevel.low;
	end
end





-- 机型设备性能等级
-- 3高端机  2终端机  1低端机
function DevicesManager:GetDeviceLevel()
    return self.devicesPerformanLevel
end

function DevicesManager:IsLevel(level)
    return self.devicesPerformanLevel == level
end

--高于或等于某级别
function DevicesManager:HighThan(level)
    return self.devicesPerformanLevel >= level
end

--判断安卓手机的等级
-- function DevicesManager:CheckAndroidLevel()
--     local deviceType = BaseApi.GetSystemModel()
--     self.devicesInfo.deviceType = deviceType

--     deviceType = string.gsub(deviceType, "+", "")
--     deviceType = string.lower(deviceType)

--     --先直接在表里找
--     local finalLevel = AndroidConfig.DeviceType[deviceType]
--     if not finalLevel then
--         --在表里找不到，有可能有细微的不一样，匹配一下
--         for key, level in pairs(AndroidConfig.DeviceType) do
--             if string.find(deviceType, key) ~= nil then
--                 finalLevel = level
--                 break
--             end
--         end
--     end

--     return finalLevel
-- end


function DevicesManager:Analyse()
    --默认等级都是2 标准画质
    --好一点的机器开到3 最强画质
    --省电模式在设置里自己开
    local level = 2
    -- if KvData.isDebug then
    if false then
        level = 3
    elseif KvData.platform == KvData.PlatformType.Android then
        local deviceInfo = self:MatchingDevicePerformanceInfo()
        self.devicesInfo.cpuKHZ = BaseApi.GetCPUMaxFreqKHz()
        self.devicesInfo.devicesScore = deviceInfo and deviceInfo.score or 0
        if self.devicesInfo.cpuKHZ >= 2600 and self.devicesInfo.realMemory >= 6000 and (not deviceInfo or deviceInfo.score >= 105) then
            level = 3
        end
    elseif KvData.platform == KvData.PlatformType.IPhonePlayer then
        level = 3
    elseif Application.platform == RuntimePlatform.WindowsPlayer then

    end
    return level
end

function DevicesManager:MatchingDevicePerformanceInfo()
    local cpuName = BaseApi.GetHardWare()
    local gpuName = SystemInfo.graphicsDeviceName

    self.devicesInfo.cpuName = cpuName
    self.devicesInfo.gpuName = gpuName

    local function matchingInfoByCpuFunc(firm, num)
        for _,info in ipairs(MobileGpuRanking.ranking) do
            if info.cpu == firm then --厂商匹配上了
                --匹配具体型号
                local nums = StringUtils.Split(info.num, "|")
                for _,n in pairs(nums) do
                    if n == num then
                        return info
                    end
                end
            end
        end
    end

    local function matchingInfoByGpuFunc(finalGpuName)
        for _, info in ipairs(MobileGpuRanking.ranking) do
            if info.gpu == finalGpuName or string.find(info.gpu, finalGpuName) then
                return info
            end
        end
    end

    local devicePerformanceInfo
    if cpuName ~= "" and string.find(cpuName, "Kirin") then
        --kirin芯片的gpu信息不够精确所以到cpu表查询
        local num = string.match(cpuName, "Kirin(.+)")
        local firm = "Kirin"
        devicePerformanceInfo = matchingInfoByCpuFunc(firm, num)
    elseif gpuName ~= "" then
        if string.find(gpuName, "Mali") then
            --除了华为的mali芯片，例如天玑 gpu String能完全匹配上 不用改
            devicePerformanceInfo = matchingInfoByGpuFunc(gpuName)
        elseif string.find(gpuName,"Adreno") then
             --骁龙芯片 例如 Adreno (TM) 660 string需要改下,需要去掉中间的 (TM) 再匹配
            if string.len(gpuName) > 12 then
                local num = string.sub(gpuName, 12)
                local finalGpuName = "Adreno" .. num
                devicePerformanceInfo = matchingInfoByGpuFunc(finalGpuName)
            end
        end
    end
    return devicePerformanceInfo
end
