ObjectPool = BaseClass("ObjectPool",BasePool)

function ObjectPool:__Init()

end

function ObjectPool:__Delete()

end

function ObjectPool:OnCheckNormal(poolKey,poolObj)
    return true
end

function ObjectPool:OnMoveParent(poolKey,poolObj,parentObj)
    poolObj.name = poolKey
    poolObj.transform:SetParent(parentObj.transform)
    poolObj.transform:Reset()
end

function ObjectPool:OnRemove(poolKey,poolObj)
    GameObject.Destroy(poolObj)
end

function ObjectPool:OnPop(poolKey,poolObj)
    poolObj:SetActive(true)
end

function ObjectPool:OnPush(poolKey,poolObj,parentObj)
    poolObj:SetActive(false)
end

function ObjectPool:OnCheckClear()

end 