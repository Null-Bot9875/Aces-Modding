HotReload = SingleClass("HotReload")

function HotReload:__Init()
    self.excludeFiles = 
    {
        "base/ui/UIDefine",
        "define/KvData",
        "base/module/Facade"
    }

    self.reloadFiles = {}
end

function HotReload:__Delete()
end

function HotReload:GetReloadFiles()
    --self.localLuaFileList = {}
    --local temp = {}
    --local luaFile = {}
    --local otherFile = {}
    --local index = 0
    self.reloadFiles = {}
    for path, v in pairs(package.loaded) do
        if self:CheckPath(path) and not self:IsExcludeFile(path) then
            self.reloadFiles[IOUtils.GetFileName(path)] = path
           -- table.insert(self.reloadFiles,path)
        end
        --Log("file",path,IOUtils.GetFileName(path))
        -- table.insert(temp, path)
        -- if self:CheckPath(path) == true then
        --     table.insert(luaFile,path)
        -- else
        --     table.insert(otherFile,path)
        -- end
    end


    
    -- for i,v in ipairs(luaFile) do
    --     if string.find(v, "/data_") ~= nil then
    --         self.localLuaFileList[v] = "data/lua/"..string.sub(v, 6)..".lua"
    --     elseif string.find(v, "fight_config") ~= nil then
    --         self.localLuaFileList[v] = "data/lua/"..string.sub(v, 6)..".lua"
    --     else
    --         -- if not self:IsExcludeFile(v) then
    --         --     self.localLuaFileList[v] = "lua/"..v..".lua"
    --         -- end
    --     end
    -- end
end

function HotReload:IsExcludeFile(file)
    for _,with in ipairs(self.excludeFiles) do
        local index = string.find(file,with)
        if index and index == 1 then
            return true
        end
    end
    return false
end

function HotReload:Reload()
    print("-------热更开始------")
    self:GetReloadFiles()

    self:ReloadFile()

	--HotReload.GetInstance():CheckFilesWitchNeedUpdate(self.localLuaFileList)
    --TimerManager.Add(200, function()
        --HotReload.GetInstance():CheckFilesWitchNeedUpdate(self.localLuaFileList)
    --end)
    print("-------热更结束------")

end

function HotReload:ReloadFile()
    package.loaded["base/setup"] = nil
    require "base/setup"

    for k,v in pairs(self.reloadFiles) do
        if v ~= "base/setup" then
            print("清理了",v)
            package.loaded[v] = nil
            _G[k] = nil
        end
    end

   -- GameManager.Instance:ModuleSetup()

    do return end

    -- TimerManager.Instance:AddTimer(1,3,function ()
    --     require "base/setup"
    -- end)


    -- do return end

    local waiting = WaitForSeconds(0)
    -- --coroutine.yield(waiting)


    -- Log("等待几秒")
    -- if self.c1 ~= nil and coroutine.status(self.c1) ~= "dead" then
    --     LogError("上次热更还没结束稍等")
    --     return
    -- end
	-- Log("正在热更文件。。。")
    self.c1 = coroutine.create(function()
        local errnum = 0
        local index = 0
        for k,v in pairs(self.reloadFiles) do
            index = index + 1
            package.loaded[v] = nil
           _G[k] = nil
            --print("aaa",k,v)

            --require "base/setup"

            -- xpcall(function() require(v) end, function(err)
            --     errnum = errnum + 1
			-- 			LogError(string.format("热更文件%s失败[%s]", v,err))
            -- end, v)

            -- if index % 10 == 0 then
            --     Log("这里执行了?1")
            --     Yield(waiting)
            --     Log("这里执行了?2")
            -- end
        end

        -- for i,v in ipairs(list) do
        --     package.loaded[v] = nil
        --     xpcall(function() require(v) end, function(err)
        --         errnum = errnum + 1
		-- 				LogError(string.format("热更文件%s失败[%s]", v,err))
        --     end, v)
        --     if i%10 == 0 then
        --         Yield(waiting)
        --     end
        --     -- if i > 10 then
        --     --     LogError(string.format("快捷热更文件有%s个可能会卡死，自动中断操作， 请再次修改文件再次操作", #list))
        --     --     return
        --     -- end
        -- end
        IS_HOT_UPDATING = false
		--Log(string.format("快捷热更文件有%s个，%s个失败", #list, errnum))
        self.c1 = nil
    end)
    coroutine.resume(self.c1)
end

function HotReload:CheckPath(path)
    if  string.find(path,"base/") ~= nil or
        string.find(path,"module/") ~= nil or
        string.find(path,"data/") ~= nil then
        return true
    else
        return false
    end
end