RTItem = BaseClass("RTItem")

function RTItem:__Init()
    self.gameObject = nil
    self.transform = nil
    self.blackCamera = nil
    self.blackTexture = nil
    self.whiteCamera = nil
    self.whiteTexture = nil
    self.maskLayer = nil
    self.image = nil
    self.mat = nil

    self.setting = nil

    self.cameraData = nil
    self.mechaCamera = nil
    self.ownCameraData = false
    self.useMechaCamera = false
end

function RTItem:__Delete()
    if self.mat then
        GameObject.Destroy(self.mat)
        self.mat = nil
    end

    if self.cameraData then
        if self.ownCameraData then
            GameObject.Destroy(self.cameraData)
        end
        self.cameraData = nil
    end
    self.ownCameraData = false

    if self.blackTexture then
        RenderTexture.ReleaseTemporary(self.blackTexture)
        self.blackTexture = nil
    end

    if self.whiteTexture then
        RenderTexture.ReleaseTemporary(self.whiteTexture)
        self.whiteTexture = nil
    end

    if self.blackCamera then
        self.blackCamera.targetTexture = nil
        GameObject.Destroy(self.blackCamera)
        self.blackCamera = nil
    end

    if self.whiteCamera then
        self.whiteCamera.targetTexture = nil
        GameObject.Destroy(self.whiteCamera)
        self.whiteCamera = nil
    end

    if self.mechaCamera then
        self.mechaCamera.targetTexture = nil
        self.mechaCamera.enabled = false
        self.mechaCamera = nil
    end

    if self.gameObject then
        GameObject.Destroy(self.gameObject)
        self.gameObject = nil
        self.transform = nil
    end

    if self.image then
        self.image.texture = nil
        self.image.material = nil
        if self.useMechaCamera then
            self.image.enabled = true
        end
        self.image = nil
    end

    self.setting = nil
    self.useMechaCamera = false
end

function RTItem:Start(setting,image,parent)
    self.useMechaCamera = not DISPLAY_MECHA_MODEL_USE_RT

    self.setting = setting
    self.image = image

    if self.useMechaCamera then
        self:StartMechaCamera(parent)
        return
    end

    self.gameObject = GameObject("rt")
    self.transform = self.gameObject.transform

    if parent then
        self.transform:SetParent(parent)
    end

    self.transform.localPosition = setting.pos
    self.transform.localEulerAngles = setting.angle

    ------------
    self.blackCamera = self:CreateCamera("black_camera",Color.black)
    self.whiteCamera = self:CreateCamera("white_camera",Color.white)

    self.blackCamera.gameObject:AddComponent(Rendering.Universal.UniversalAdditionalCameraData)
    self.cameraData = self.blackCamera.gameObject:GetComponent(Rendering.Universal.UniversalAdditionalCameraData)
    self.ownCameraData = true
    self.cameraData.renderPostProcessing = true


    self.blackTexture = self:CreateTexture()
    self.whiteTexture = self:CreateTexture()


    self.blackCamera.targetTexture = self.blackTexture
    self.whiteCamera.targetTexture = self.whiteTexture

    self.mat = self:CreateMaterial()

    self.image.texture = self.whiteTexture
    self.image.material = self.mat
end

function RTItem:StartMechaCamera(parent)
    if self.image then
        self.image.texture = nil
        self.image.material = nil
        self.image.enabled = false
    end

    local cameraObj = GameObject.Find("DrawMechaCamera")
    if not cameraObj then
        LogError("RTItem:StartMechaCamera DrawMechaCamera not found")
        return
    end

    local camera = cameraObj:GetComponent(Camera)
    if not camera then
        LogError("RTItem:StartMechaCamera DrawMechaCamera missing Camera")
        return
    end

    if parent then
        cameraObj.transform.position = parent:TransformPoint(self.setting.pos)
        cameraObj.transform.rotation = parent.rotation * Quaternion.Euler(self.setting.angle)
    else
        cameraObj.transform.position = self.setting.pos
        cameraObj.transform.eulerAngles = self.setting.angle
    end

    self.mechaCamera = camera
    self.mechaCamera.targetTexture = nil
    self:ApplyCameraSetting(self.mechaCamera)
    cameraObj:SetActive(true)
    self.mechaCamera.enabled = true
end

function RTItem:CreateCamera(name,bgColor)
    local obj = GameObject(name)
    obj.transform:SetParent(self.transform)
    obj.transform.localPosition = Vector3.zero
    obj.transform.localEulerAngles = Vector3.zero

    local camera = obj:AddComponent(Camera)
    self:ApplyCameraSetting(camera,bgColor)
    return camera
end

function RTItem:ApplyCameraSetting(camera,bgColor)
    camera.clearFlags = CameraClearFlags.SolidColor
    if bgColor then
        camera.backgroundColor = bgColor
    end
    camera.orthographic = false
    camera.orthographicSize = self.setting.orthographicSize
    camera.fieldOfView = self.setting.orthographicSize

    camera.allowMSAA = false
    camera.allowHDR = false

    local cullingMask = 0
    cullingMask = cullingMask + BitUtils.LShift(1,self.setting.maskLayer)
    camera.cullingMask = cullingMask
end

function RTItem:CreateTexture()
    local width = self.setting.textureWidth == 0 and Screen.width or self.setting.textureWidth
    local height = self.setting.textureHeight == 0 and Screen.height or self.setting.textureHeight
    -- Log(self.setting.textureWidth,self.setting.textureHeight,width,height)
    local texture = RenderTexture.GetTemporary(width,height, 24, RenderTextureFormat.ARGB32)
    if texture:IsCreated() then
        return texture
    end

    texture.antiAliasing = 1

    texture.filterMode = FilterMode.Bilinear
    texture.anisoLevel = 0
    texture.autoGenerateMips = false
    texture.useMipMap = false
    return texture
end

function RTItem:CreateMaterial()
    local mat = Material(ShaderManager.Instance:GetShader("GRenderShader"))
    mat:SetTexture("_MainTex", self.whiteTexture)
    mat:SetTexture("_BlackTex", self.blackTexture)
    return mat
end

function RTItem:SetGrey(flag)
    if self.mat then
        self.mat:SetFloat("_Grey", flag and 1 or 0)
    end
end
