RTUIObject = BaseClass("RTUIObject")

function RTUIObject:__Init()
    self.gameObject = nil
    self.transform = nil

    self.canvasTrans = nil

    self.uiObject = nil

    self.camera = nil

    self.texture = nil
end

function RTUIObject:__Delete()
    if self.texture then
        RenderTexture.ReleaseTemporary(self.texture)
        self.texture = nil
    end

    if self.uiObject then
        GameObject.Destroy(self.uiObject)
        self.uiObject = nil
    end

    if self.gameObject then
        GameObject.Destroy(self.gameObject)
        self.gameObject = nil
        self.transform = nil
    end
end

function RTUIObject:Show(setting,image)
    self.setting = setting
    self.image = image

    local rtCanvasAsset = PreloadManager.Instance:GetAsset(AssetPath.rt_ui_object)
    self.gameObject = GameObject.Instantiate(rtCanvasAsset)
    self.transform = self.gameObject.transform

    self.canvasTrans = self.transform:Find("canvas")
    self.camera = self.transform:Find("camera").gameObject:GetComponent(Camera)
    self.camera.clearFlags = CameraClearFlags.SolidColor
    self.camera.backgroundColor = Color.clear

    self.texture = self:CreateTexture()
    self.camera.targetTexture = self.texture

    self.uiObject = GameObject.Instantiate(setting.uiObject)

    
    BaseUtils.ChangeLayers(self.uiObject,KvData.Layer.layer10)
    self.uiObject.transform:SetParent(self.canvasTrans)

    self.uiObject.transform:SetLocalPosition(0,0,0)
    self.uiObject.transform:SetLocalEulerAngles(0,0,0)
    self.uiObject.transform:SetLocalScale(1,1,1)

    self.camera:Render()

    self.camera.targetTexture = nil

    self.gameObject:SetActive(false)
end

function RTUIObject:CreateTexture()
    local texture = RenderTexture.GetTemporary(self.setting.textureWidth,self.setting.textureHeight, 24, RenderTextureFormat.ARGB32)
    if texture:IsCreated() then
        return texture
    end
    
    texture.graphicsFormat = CS.UnityEngine.Experimental.Rendering.GraphicsFormat.B10G11R11_UFloatPack32
    texture.antiAliasing = 1
    texture.filterMode = FilterMode.Bilinear
    texture.anisoLevel = 0
    texture.useMipMap = false
    return texture
end