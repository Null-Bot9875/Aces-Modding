UIUnitView = BaseClass("UIUnitView")

function UIUnitView:__Init()
    self.gameObject = nil
    self.transform = nil
    self.tpose = nil

    self.rtItem = nil

    self.setting = nil

    self.image = nil

    self.lightLoader = nil
    self.lightScope = nil
    self.lightObj = nil

    self.currMode = 1
    self.onPointerDown = self:ToFunc("OnPointerDown")
end

function UIUnitView:__Delete()
    self:RemoveLightLoader()
    self:ReleasePendingLightScope()

    if self.rtItem then
        self.rtItem:Delete()
        self.rtItem = nil
    end

    if self.tpose then
        self.tpose:Delete()
        self.tpose = nil
    end

    if self.lightObj then
        GameObject.Destroy(self.lightObj)
        self.lightObj = nil
    end

    if self.gameObject then
        GameObject.Destroy(self.gameObject)
        self.gameObject = nil
        self.transform = nil
    end

    if self.sceneNode then
        GameObject.Destroy(self.sceneNode.gameObject)
        self.sceneNode = nil
    end

    self:RemoveAllListeners()
end

function UIUnitView:Show(setting, parent)
    self.sceneNode = GameObject("Scene").transform

    self.setting = setting

    self.gameObject = setting.object
    self.gameObject.name = setting.name or "UIUnitView"
    self.transform = self.gameObject.transform

    self.image = self.transform:Find("raw_image").gameObject:GetComponent(RawImage)


    self.topseNode = GameObject("topse")
    self.topseNode.transform:SetParent(self.sceneNode)

    local transInfo = self.setting.unitTransSetting

    local scale = transInfo.scale or 1
    local pos = transInfo.pos or Vector3.zero
    local angle = transInfo.angle or Vector3.zero


    local angleXAxis = Quaternion.AngleAxis(angle.x, Vector3.right)
    local angleYAxis = Quaternion.AngleAxis(angle.y,Vector3.up)
    local angleZAxis = Quaternion.AngleAxis(angle.z,Vector3.forward)
    local rotation = angleXAxis * angleYAxis * angleZAxis


    self.topseNode.transform:SetLocalScale(scale,scale,scale)
    self.topseNode.transform:SetLocalPosition(pos.x,pos.y,pos.z)
    self.topseNode.transform:SetRotation(rotation.x, rotation.y, rotation.z,rotation.w)

    if parent then
        self.transform:SetParent(parent)
    end

    self.rtItem =  RTItem.New()
    self.rtItem:Start(setting.rtSetting,self.image, self.sceneNode)


    self.tpose = UnitTpose.New()
    self.tpose:Load(setting.unitTposeSetting,self:ToFunc("OnTposeLoaded"))

    if setting.lightIndex then
        local lightFile = string.format("unit/common/light/%s.prefab",setting.lightIndex)
        self.lightScope = AssetScope()
        self.lightLoader = AssetBatchLoader.New(self.lightScope)
        self.lightLoader:Load({{file = lightFile,type = AssetType.Prefab}},self:ToFunc("LightLoaded"))
    end

    if setting.touchSetting then
        self.touchImage = self.transform:Find("touch_image").gameObject:GetComponent(Image)

        local handler = self.touchImage.gameObject:GetComponent(PointerHandler)
        handler.isPointerDown = true

        handler:SetOwner(self)
        handler:SetDown("onPointerDown")
        -- handler:SetUp(self:ToFunc("OnPointerUp"))
    end
end 

function UIUnitView:OnPointerDown()
    self:RemoveAllListeners()
    
    self.moveListenId = TouchManager.Instance:AddListen(TouchDefine.TouchEvent.move,self:ToFunc("OnMechaDrag"),self.pointerId)
    self.cancelListenId = TouchManager.Instance:AddListen(TouchDefine.TouchEvent.cancel,self:ToFunc("OnMehcaCancel"),self.pointerId)
end

function UIUnitView:OnPointerUp()
end

function UIUnitView:OnMechaDrag(touchData)
    local deltaPos = touchData.deltaPos

    -- 将 deltaPos.x 转换为屏幕比例（0~1）
    local screenRatioX = deltaPos.x / Screen.width

    -- 调整旋转系数
    local rotationSpeed = 360 -- 每屏宽度滑动旋转 360 度
    local rotationAmount = screenRatioX * rotationSpeed * -0.5

    -- 应用旋转（假设需要帧率补偿）
    self.topseNode.transform:Rotate(
        Vector3.up, 
        rotationAmount * Time.deltaTime * 60 -- 保持与原有逻辑兼容
    )
end
function UIUnitView:OnMehcaCancel(touchData)
    -- LogTable("OnMehcaCancel",touchData)
    self:RemoveAllListeners()
end

function UIUnitView:RemoveAllListeners()
    if self.moveListenId then
        TouchManager.Instance:RemoveListen(self.moveListenId)
        self.moveListenId = nil
    end

    if self.cancelListenId then
        TouchManager.Instance:RemoveListen(self.cancelListenId)
        self.cancelListenId = nil
    end    
end

function UIUnitView:OnTposeLoaded()
    BaseUtils.ChangeLayers(self.tpose.gameObject,KvData.Layer.layer9)

    self.tpose.transform:SetParent(self.topseNode.transform)

    self.tpose.transform:Reset()


    -- local transInfo = self.setting.unitTransSetting

    -- local scale = transInfo.scale or 1
    -- local pos = transInfo.pos or Vector3.zero
    -- local angle = transInfo.angle or Vector3.zero


    -- local angleXAxis = Quaternion.AngleAxis(angle.x, Vector3.right)
    -- local angleYAxis = Quaternion.AngleAxis(-angle.y,Vector3.up)
    -- local angleZAxis = Quaternion.AngleAxis(angle.z,Vector3.forward)
    -- local rotation = angleXAxis * angleYAxis * angleZAxis


    -- self.tpose.transform:SetLocalScale(scale,scale,scale)
    -- self.tpose.transform:SetLocalPosition(pos.x,pos.y,pos.z)
    -- self.tpose.transform:SetRotation(rotation.x, rotation.y, rotation.z,rotation.w)

    MechaAnimUtil.InitMechaAnim(self.setting.unitTposeSetting.modelId, self.tpose:GetAnimator())
    self:CheckShow()
    if self.loadFinishCallback then
        self.loadFinishCallback()   
    end
end


function UIUnitView:SetLoadFinishCallback(callback)
    self.loadFinishCallback = callback
end

function UIUnitView:LightLoaded(_,hasError)
    if hasError then
        self:RemoveLightLoader()
        self:ReleasePendingLightScope()
        return
    end
    local lightFile = self.lightLoader:GetFile(1)
    self.lightObj = self.lightLoader:Instantiate(lightFile,self.sceneNode)
    self.lightObj:AddComponent(AssetScopeComponent):Adopt(self.lightScope)
    self.lightScope = nil
    self.lightObj.name = "light"
    self:RemoveLightLoader()
    self:CheckShow()
end


function UIUnitView:ReleasePendingLightScope()
    if self.lightScope then
        self.lightScope:Dispose()
        self.lightScope = nil
    end
end

function UIUnitView:CheckShow()
    if self.lightObj and self.tpose.gameObject then
        self.image.gameObject:SetActive(true)
    end
end

function UIUnitView:RemoveLightLoader()
    if self.lightLoader then
        self.lightLoader:Destroy()
        self.lightLoader = nil
    end
end

function UIUnitView:PlayAttackAnim()
    local attackList = MechaAnimUtil.GetAttackAnim(self.setting.unitTposeSetting.modelId)
    if not attackList then return end

    local list = {}
    if self.currMode == 1  then
        for i,v in ipairs(attackList) do
            if not string.find(v,"mode2") then
                table.insert(list,v)
            end
        end
    else
        for i,v in ipairs(attackList) do
            if string.find(v,"mode2") then
                table.insert(list,v)
            end
        end
    end

    local attackAnim = list[math.random(1, #list)]
    self.tpose.animator:Play(attackAnim)
end

function UIUnitView:PlayTransAnim()
    local transList = MechaAnimUtil.GetTransAnimList(self.setting.unitTposeSetting.modelId)
    if not transList then return end
    
    local anim = nil
    local findName = nil
    if self.currMode == 1 then
        findName = "to2"
    else
        findName = "to1"
    end

    for i,v in ipairs(transList) do
        if string.find(v,findName) then
            anim = v
            break
        end
    end

    self.currMode = self.currMode == 1 and 2 or 1
    self.tpose.animator:Play(anim)  
end


function UIUnitView:PlayAnim(animName)
    self.tpose.animator:Play(animName)
end


function UIUnitView:GetTpose()
    return self.tpose
end

function UIUnitView:ActiveTpose(active)
    if self.tpose then
        self.tpose.gameObject:SetActive(active)
    end
end
