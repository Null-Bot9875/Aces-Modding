RichText = StaticClass("RichText")

-- 不再简单按空格分割，而是通过等号和下一个键的位置来确定边界
local function ParseAttributes(attributeString)
    -- attributeString = "type=3 content=Integrate Ability"
    -- 返回：{ type = "3", content = "Integrate Ability" }
    local data = {}
    local pos = 1
    local len = #attributeString
    
    while pos <= len do
        -- 跳过前导空格
        while pos <= len and string.sub(attributeString, pos, pos) == " " do
            pos = pos + 1
        end
        
        if pos > len then
            break
        end
        
        local equalPos = string.find(attributeString, "=", pos)
        if not equalPos then
            break
        end
        
        -- 提取键名
        local key = string.sub(attributeString, pos, equalPos - 1)
        pos = equalPos + 1
        
        -- 查找下一个键的开始位置（通过查找下一个等号前的空格+字符模式）
        local nextKeyPos = len + 1  -- 默认到字符串末尾
        local searchPos = pos
        
        while searchPos <= len do
            local nextEqualPos = string.find(attributeString, "=", searchPos)
            if nextEqualPos then
                
                -- 从等号位置向前查找空格，找到键名的开始位置
                local spacePos = nextEqualPos - 1
                while spacePos > searchPos and string.sub(attributeString, spacePos, spacePos) ~= " " do
                    spacePos = spacePos - 1
                end
                
                if spacePos > searchPos then
                    nextKeyPos = spacePos
                    break
                end
            end
            searchPos = nextEqualPos and (nextEqualPos + 1) or (len + 1)
        end
        
        -- 提取值（去除尾部空格）
        local value = string.sub(attributeString, pos, nextKeyPos - 1)
        value = string.gsub(value, "%s+$", "") -- 去除尾部空格
        
        data[key] = value
        pos = nextKeyPos
    end
    
    return data
end

--
function RichText.Create(richTextInfo)
    local richTextItem = RichTextItem.New(richTextInfo)

    local elements = {}

    local lastIdx = 1
    for tag, val in string.gmatch(richTextInfo.content, "<(.-) (.-)/>") do
        -- Log("RichText tag:" .. tag .. " val:" .. val)
        local logicElementType = RichTextDefine.LogicElementTypeMapping[tag]
        local tagStr = string.format("<%s %s/>", tag, val)
        local startIndex, endIndex = string.find(richTextInfo.content, tagStr, lastIdx, true)
        local beforeStr = string.sub(richTextInfo.content, lastIdx, startIndex - 1)
        lastIdx = lastIdx + #beforeStr + #tagStr

        if beforeStr ~= "" then
            -- 把换行符当成一个元素，单独拆分出来
            local list = {}
            local tmp = ""
            for char in string.gmatch(beforeStr, ".") do
                if char == "\n" then
                    if tmp ~= "" then
                        table.insert(list, tmp)
                    end
                    table.insert(list, char)
                    tmp = ""
                else
                    tmp = tmp .. char
                end
            end
            if tmp ~= "" then
                table.insert(list, tmp)
            end

            for index, value in ipairs(list) do
                local richTextNoneText = RichTextNoneText.New(richTextItem)
                richTextNoneText:ParseData({ content = value })
                table.insert(elements, richTextNoneText)
            end
        end

        -- 使用新的智能属性解析函数
        local data = ParseAttributes(val)

        local map = RichTextDefine.ElementMapping[logicElementType or tag]
        if not map then
            LogError(string.format("没有找到富文本对应的类tag: %s,logicElementType: %s", tag, logicElementType))
            return nil
        end

        local elementClass = _G[map.class]
        local element = elementClass.New(richTextItem)
        element:ParseData(data)
        if logicElementType then
            element:SetLogicElementType(tag)
        end
        table.insert(elements, element)
    end

    local lastStr = string.sub(richTextInfo.content, lastIdx, string.len(richTextInfo.content))
    --Log(lastStr)
    if lastStr ~= "" then
        local richTextNoneText = RichTextNoneText.New(richTextItem)
        richTextNoneText:ParseData({ content = lastStr })
        table.insert(elements, richTextNoneText)
    end

    richTextItem:Create(elements)

    return richTextItem
end

--简述：
--1.富文本格式为:<富文本类型 k1=v1 k2=v2/>
--2.富文本标签在RichTextDefine.Element中定义（当需要新增富文本类型时增加映射）
--3.扩展富文本类，需要实现OnCreate和OnParseData函数（OnCreate为创建富文本内容回调、OnParseData为解析富文本kv数据内容,自行根据富文本类型进行读取）
--4.每个使用的业务层，需要的富文本资源模板也不尽相同，比如A界面需要的正常文本大小为17、B界面需要的正常文本大小为20，因此需要各业务层制作富文本模板，创建富文本对象时，传入RichTextInfo.elementTemplate字段（可参考Assets/Temp/rich_text下的模板资源）



--[[

--测试代码
local richTextInfo = RichTextInfo.New()

richTextInfo.content = "<fastStart />此设备在装配时带有3*<token type=101 />" ..
    "\n[1*<token type=101 />]:对目标敌方机体造成2伤害" ..
    "\n[<energy value=2 />]：在此设备上放置一个充能指示物"


richTextInfo.content = "<rich_text content=再利用 bold=true color=9A00FFFF />  直到本回合结束，你的手牌具有[<rich_text content=再利用 bold=true />]。"

richTextInfo.viewWidth = 254

richTextInfo.elementTemplate = RichTextUtils.GetCardTextTemplate()

richTextInfo.parent = GameObject.Find("Canvas").transform
richTextInfo.width = 20
richTextInfo.height = 20

-- 示例：设置居中对齐
-- richTextInfo.alignment = RichTextDefine.TextAlignment.center
-- 示例：设置右对齐
-- richTextInfo.alignment = RichTextDefine.TextAlignment.right

richTextInfo.onClick = function() SystemMessage.Show("攻击将会使对手扣血") end
RichText.Create(richTextInfo)


--测试流程
--1.打开Assets/Temp/rich_text目录
--2.将目录中的文件拖到Canvas下面
--3.运行上方的测试代码


--]]