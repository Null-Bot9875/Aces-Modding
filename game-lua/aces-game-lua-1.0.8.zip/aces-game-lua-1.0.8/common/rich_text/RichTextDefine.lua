RichTextDefine = StaticClass("RichTextDefine")


RichTextDefine.StartCorner =
{
    left_top = 1,
    right_top = 2,
    left_bottom = 3,
    right_bottom = 4,
}

-- 添加文本对齐方式定义
RichTextDefine.TextAlignment =
{
    left = 1,   -- 左对齐
    center = 2, -- 居中对齐
    right = 3,  -- 右对齐
}

RichTextDefine.Element =
{
    none_text = "none_text",
    rich_text = "rich_text",
    click_text = "click_text",
    card_click_text = "card_click",
    img = "img",
    energy = "energy",
    start = "start",
    fastStart = "fastStart",
    token = "token",
    attack = "attack",
    br = "br",
    attackValue = "attackValue",
    energyValue = "energyValue",
    del = "del",

    lastingEffect = "lastingEffect", -- 永久生效
    hp = "hp", -- 核心装甲

    text_back = "text_back",
}

RichTextDefine.RichTextKeywordIdMap =
{
    [RichTextDefine.Element.attack] =
    {
        id = 3000,
    },
    [RichTextDefine.Element.start] =
    {
        id = 3001,
    },
    [RichTextDefine.Element.fastStart] =
    {
        id = 3002,
    },
    [RichTextDefine.Element.energy] =
    {
        id = 3003,
    },
    [RichTextDefine.Element.token] =
    {
        id = {
            ["101"] = 3004,
            ["102"] = 3005,
            ["103"] = 3006,
            ["104"] = 3007,
            ["105"] = 3008,
            ["106"] = 3009
        },
    },

    [RichTextDefine.Element.hp] =
    {
        id = 3011,
    },
    [RichTextDefine.Element.lastingEffect] =
    {
        id = 3012,
    },
}

RichTextDefine.ElementMapping =
{
    [RichTextDefine.Element.none_text] = { class = "RichTextNoneText" },
    [RichTextDefine.Element.rich_text] = { class = "RichTextNormalText" },
    [RichTextDefine.Element.click_text] = { class = "RichTextClickText" },
    [RichTextDefine.Element.card_click_text] = { class = "RichTextCardClickText" },
    [RichTextDefine.Element.img] = { class = "RichTextImg" },
    [RichTextDefine.Element.energy] = { class = "RichEnergyText" },
    [RichTextDefine.Element.start] = { class = "RichStartText" },
    [RichTextDefine.Element.fastStart] = { class = "RichFastStartText" },
    [RichTextDefine.Element.token] = { class = "RichTokenText" },
    [RichTextDefine.Element.attack] = { class = "RichAttackText" },
    [RichTextDefine.Element.br] = { class = "RichBreakText" },
    [RichTextDefine.Element.attackValue] = { class = "RichAttackValue" },
    [RichTextDefine.Element.energyValue] = { class = "RichEnergyValue" },
    [RichTextDefine.Element.del] = { class = "RichTextDelText" },

    -- [RichTextDefine.Element.lastingEffect] = { class = "RichLastingEffect" },
    [RichTextDefine.Element.hp] = { class = "RichHpText" },
    [RichTextDefine.Element.text_back] = { class = "RichTextWithBack" },
}

RichTextDefine.LogicElementType =
{
    ["summon_unit"] = "summon_unit", -- 召唤物
    ["terminology"] = "terminology", -- 名词解释
}

RichTextDefine.LogicElementTypeMapping =
{
    [RichTextDefine.LogicElementType.summon_unit] = "click_text",
    [RichTextDefine.LogicElementType.terminology] = "click_text",
}

RichTextDefine.FontStyles =
{
    [FontStyles.Normal] = 0,
    [FontStyles.Bold] = 1,
    [FontStyles.Italic] = 2,
    [FontStyles.Underline] = 4,
    [FontStyles.Strikethrough] = 64,
}

RichTextDefine.FixedHeightGap = 0

RichTextDefine.CardFontSize = 30

RichTextDefine.ChoiceFontSize = 30

RichTextDefine.MailFontSize = 36

RichTextDefine.ColorMode =
{
    dark = 1,
    light = 2,
}

RichTextDefine.RichTextType = 
{
    card = "card",
    rouge_choice = "rouge_choice",
}

RichTextDefine.TypeInfoMap = 
{
    [RichTextDefine.RichTextType.card] = 
    {
        fontSize = RichTextDefine.CardFontSize,
        lineSpacing = 0,
        paddingTop = 0,
    },
    [RichTextDefine.RichTextType.rouge_choice] = 
    {
        fontSize = RichTextDefine.ChoiceFontSize,
        lineSpacing = 0,
        paddingTop = 0,
    },
}
