RichTextUtils = StaticClass("RichTextUtils")

function RichTextUtils.ClearCardTextTemplateCache()
    local descTemplate = UIDefine.cardDescTemplate
    UIDefine.cardDescTemplate = nil

    if descTemplate and not BaseUtils.IsNull(descTemplate) then
        GameObject.Destroy(descTemplate)
    end
end

function RichTextUtils.ClearRichTemplateCache()
    RichTextUtils.ClearCardTextTemplateCache()

    local parent = UIDefine.richTemplateParent
    if not parent or BaseUtils.IsNull(parent) then
        return
    end

    for i = parent.childCount - 1, 0, -1 do
        local child = parent:GetChild(i)
        if child and not BaseUtils.IsNull(child.gameObject) then
            GameObject.Destroy(child.gameObject)
        end
    end
end

function RichTextUtils.GetTextSize(content, textTemplate)
    -- textTemplate.textComponent.fontStyle = fontStyle or RichTextDefine.FontStyles[FontStyles.Normal]
    textTemplate.textComponent.text = content

    local v2 = textTemplate.textComponent:GetPreferredValues(content)
    local w, h = v2.x, v2.y

    textTemplate.textComponent.fontStyle = RichTextDefine.FontStyles[FontStyles.Normal]

    if w == 0 or h == 0 then
        LogError(string.format("RichTextUtils.GetTextSize content:%s, w:%s, h:%s ", content, w, h))
    end

    -- text mesh pro 会忽略最后的空格，如果content的最后有多个空格，那么宽度会比实际的宽度小，这里加上空格的宽度
    local spaceNum = 0
    for i = string.len(content), 1, -1 do
        if string.sub(content, i, i) == " " then
            spaceNum = spaceNum + 1
        else
            break
        end
    end

    local spaceW, spaceH = RichTextUtils.GetSpaceSize(textTemplate)
    w = w + spaceW * spaceNum

    return w, h
end

-- 空格的大小
function RichTextUtils.GetSpaceSize(textTemplate)
    textTemplate.textComponent.text = "_"
    local v1 = textTemplate.textComponent:GetPreferredValues("_")

    textTemplate.textComponent.text = "_ _"
    local v2 = textTemplate.textComponent:GetPreferredValues("_ _")

    local w = v2.x - v1.x * 2
    local h = v2.y

    return w, h
end

-- Card Desc
function RichTextUtils.GetRichtextDefaultMat(matNode)
    local mat = matNode:Find("default").gameObject:GetComponent(Image).material
    return mat
end

function RichTextUtils.GetCardTextOutlineMat(matNode)
    local mat = matNode:Find("outline").gameObject:GetComponent(Image).material
    return mat
end

function RichTextUtils.GetChoiceTextTemplate()
    local descTemplate = PreloadManager.Instance:GetAsset(AssetPath.choiceDescTemplate)

    local cardNormal = {}
    cardNormal.original = descTemplate.transform:Find("richtext_normal").gameObject
    cardNormal.originalRect = descTemplate.transform:Find("richtext_normal").gameObject:GetComponent(RectTransform)
    cardNormal.textComponent = cardNormal.original.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)

    local cardClick = {}
    cardClick.original = descTemplate.transform:Find("richtext_click").gameObject
    cardClick.originalRect = descTemplate.transform:Find("richtext_click").gameObject:GetComponent(RectTransform)
    cardClick.textComponent = cardClick.original.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)

    local template =
    {
        [RichTextDefine.Element.none_text] = cardNormal,
        [RichTextDefine.Element.rich_text] = cardNormal,
        [RichTextDefine.Element.card_click_text] = cardClick,
        [RichTextDefine.Element.br] = cardNormal,

        ---
        ["matNode"] = descTemplate.transform:Find("template/mat"),
    }

    return template
end

function RichTextUtils.GetCardTextTemplate()
    local descTemplate = UIDefine.cardDescTemplate
    if not descTemplate then
        local template = PreloadManager.Instance:GetAsset(AssetPath.cardDescTemplate).gameObject
        descTemplate = GameObject.Instantiate(template, UIDefine.richTemplateParent)
        UIDefine.cardDescTemplate = descTemplate
    end

    -- 材质从预制体读取，保证始终使用设计时的字体/描边材质；Clone 可能被复用或修改导致材质不对
    local prefabGo = PreloadManager.Instance:GetAsset(AssetPath.cardDescTemplate).gameObject
    local matNode = prefabGo.transform:Find("template/mat")

    local cardNormal = {}
    cardNormal.original = descTemplate.transform:Find("richtext_normal").gameObject
    cardNormal.originalRect = descTemplate.transform:Find("richtext_normal").gameObject:GetComponent(RectTransform)
    cardNormal.textComponent = cardNormal.original.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)

    local cardClick = {}
    cardClick.original = descTemplate.transform:Find("richtext_click").gameObject
    cardClick.originalRect = descTemplate.transform:Find("richtext_click").gameObject:GetComponent(RectTransform)
    cardClick.textComponent = cardClick.original.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)

    local cardImg = {}
    cardImg.original = descTemplate.transform:Find("richtext_img").gameObject
    cardImg.originalRect = descTemplate.transform:Find("richtext_img").gameObject:GetComponent(RectTransform)
    cardImg.imageComponent = cardImg.original.transform:Find("img").gameObject:GetComponent(Image)

    local cardNumImg = {}
    cardNumImg.original = descTemplate.transform:Find("richtext_numImg").gameObject
    cardNumImg.originalRect = descTemplate.transform:Find("richtext_numImg").gameObject:GetComponent(RectTransform)
    cardNumImg.imageComponent = cardNumImg.original.transform:Find("img").gameObject:GetComponent(Image)
    cardNumImg.textComponent = cardNumImg.original.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)

    local cardTextWithBack = {}
    cardTextWithBack.original = descTemplate.transform:Find("richtext_back").gameObject
    cardTextWithBack.originalRect = cardTextWithBack.original:GetComponent(RectTransform)
    cardTextWithBack.imageComponent = cardTextWithBack.original:GetComponent(Image)
    cardTextWithBack.textComponent = cardTextWithBack.original.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)

    local template =
    {
        [RichTextDefine.Element.none_text] = cardNormal,
        [RichTextDefine.Element.rich_text] = cardNormal,
        [RichTextDefine.Element.click_text] = cardClick,
        [RichTextDefine.Element.energy] = cardNumImg,
        [RichTextDefine.Element.attack] = cardImg,
        [RichTextDefine.Element.fastStart] = cardImg,
        [RichTextDefine.Element.start] = cardImg,
        [RichTextDefine.Element.token] = cardNumImg,
        [RichTextDefine.Element.img] = cardImg,
        [RichTextDefine.Element.br] = cardNormal,
        [RichTextDefine.Element.attackValue] = cardNormal,
        [RichTextDefine.Element.energyValue] = cardNormal,

        -- [RichTextDefine.Element.lastingEffect] = cardImg,
        [RichTextDefine.Element.hp] = cardNumImg,

        [RichTextDefine.Element.text_back] = cardTextWithBack,

        ----
        ["matNode"] = matNode,
        ["original"] = descTemplate.gameObject,
    }

    return template
end

function RichTextUtils.GetDescLuaTable(confName,sheetName,keyIndex,key)
    local luaTable = {}
    -- table 的 desc 直接从多语言获取
    local descLua = Config.Get(confName,sheetName,keyIndex,key).descLua
    for _, t in ipairs(descLua) do
        local tmp ={}
        for k, v in pairs(t) do
            if k == "desc" then
                local textConf = Config.Get(confName,"text","key",v,true)
                if textConf then
                    local desc = textConf.text
                    if descLua.params then
                        for k,v in pairs(descLua.params) do
                            desc = string.gsub(desc, "$" .. k, v) -- 替换参数,例如 $ATTAKVALUE 替换为实际值
                        end
                    end
                    
                    tmp[k] = desc
                else
                    tmp[k] = v
                end
            else
                tmp[k] = v
            end
        end
        table.insert(luaTable, tmp)
    end

    return luaTable
end

function RichTextUtils.GetStrByDesLua(confName,sheetName,keyIndex,key)
    local table = RichTextUtils.GetDescLuaTable(confName,sheetName,keyIndex,key)
    local desc = ""
    for _, v in ipairs(table) do
        desc = desc .. v.desc
    end

    return desc
end

-- 获取卡牌的配置描述
function RichTextUtils.GetCardContent(cardId)
    local desc = ""
    local cardCfg = Config.Get("card_def", "config", "cardId", cardId)
    if not cardCfg or not cardCfg.descLua or cardCfg.descLua == "" then
        return desc
    end

    desc = RichTextUtils.GetStrByDesLua("card_def","config","cardId",cardId)
    
    return desc
end

function RichTextUtils.GetArmContent(armId)
    local desc = ""
    local armCfg = Config.Get("arm_def", "config", "id", armId)
    if not armCfg or not armCfg.descLua or armCfg.descLua == "" then
        return desc
    end

    desc = RichTextUtils.GetStrByDesLua("arm_def","config","id",armId)
    
    return desc
end


function RichTextUtils.GetChipContent(chipId)
    local desc = ""
    local chipCfg = Config.Get("chip_def", "config", "id", chipId)
    if not chipCfg or not chipCfg.descLua or chipCfg.descLua == "" then
        return desc
    end

    desc = RichTextUtils.GetStrByDesLua("chip_def","config","id",chipId)
    
    return desc
end

function RichTextUtils.GetHeroContent(heroId)
    local desc = ""
    local heroCfg = Config.Get("hero_def", "config", "id", heroId)
    if not heroCfg or not heroCfg.descLua or heroCfg.descLua == "" then
        return desc
    end

    desc = RichTextUtils.GetStrByDesLua("hero_def","config","id",heroId)

    return desc
end

function RichTextUtils.GetCardContentList(cardInfo,settings)
    settings = settings or {}
    local contentList = {}
    
    -- 合并descLua和skillDescLua到一个列表中
    local allDescList = {}

    -- local cardConf = Config.Get("card_def", "config", "cardId", cardInfo.cardId)
    local descLua = RichTextUtils.GetDescLuaTable("card_def","config","cardId",cardInfo.cardId)
    local skillDescLua = RichTextUtils.GetSkillDescLua(cardInfo)

    -- 添加descLua内容
    if descLua then
        for _, v in ipairs(descLua) do
            table.insert(allDescList, v)
        end
    end
    
    -- 添加skillDescLua内容
    if skillDescLua then
        for _, v in ipairs(skillDescLua) do
            if not v.showInDetail then
                table.insert(allDescList, v)
            end
        end
    end
    
    -- 统一处理所有描述
    for _, v in ipairs(allDescList) do
        -- 根据换行来分割，创建多个RichTextInfo
        for str in string.gmatch(v.desc, "([^\n]+)") do
            local content = {}
            content.desc = str

            if v.loopNum and RunWorld then
                local loopList, errorKvData = RunWorld.DataSystem:GetDroneLoopCount(cardInfo.id)
                local currLoopNum = #loopList
                if currLoopNum >= v.loopNum then
                    -- 回路颜色 #00DD9C
                    content.fixedColor = Color(0, 221/255, 156/255, 1)
                else
                    content.fixedColor = settings.fixedColor or Color.black
                end
            else
                content.fixedColor = settings.fixedColor or Color.black
            end
            
            -- 拷贝其它属性
            for key, value in pairs(v) do
                if key ~= "desc" then
                    content[key] = value
                end
            end

            table.insert(contentList, content)
        end
    end

    return contentList
end

-- 获取卡牌的完整描述（包括被新增的异能）
function RichTextUtils.GetCardRichTextInfos(descText, cardInfo, settings)
    local contentList = RichTextUtils.GetCardContentList(cardInfo,settings)

    local richInfoList = {}
    for i, v in ipairs(contentList) do
        local richTextInfo = RichTextInfo.New()
        richTextInfo.content = v.desc
        richTextInfo.viewWidth = descText.gameObject:GetComponent(RectTransform).rect.width
        richTextInfo.parent = descText.transform
        richTextInfo.elementTemplate = RichTextUtils.GetCardTextTemplate()
        richTextInfo.attrMap = cardInfo.attrMap
        richTextInfo.cardInfo = cardInfo
        richTextInfo.lineSpacing = (settings and settings.lineSpacing) or 0
        richTextInfo.fontSize = (settings and settings.fontSize) or RichTextDefine.CardFontSize
        richTextInfo.isHighlight = v.isHighlight

        for key, value in pairs(v) do
            if key ~= "desc" then
                richTextInfo[key] = value
            end
        end
        table.insert(richInfoList, richTextInfo)
    end

    return richInfoList
end

function RichTextUtils.GetSkillDescLua(cardInfo)
    if not cardInfo then
        return {}
    end

    if not cardInfo.attrMap then
        return {}
    end

    local skillDescLua = {}
    local skillList = {}
    local attrMap = cardInfo.attrMap
    -- for _, v in ipairs(attrMap) do
    --     if v.attr == BattleDefine.CardAttrType.skillAdd then
    --         table.insert(skillList, v.skillId)
    --     end
    -- end

    -- 静态异能和异能都加入显示
    for _, v in ipairs(cardInfo.skills or {}) do
        table.insert(skillList, v.skillId)
    end

    for _, v in ipairs(cardInfo.staticSkills or {}) do
        if not RichTextUtils.IsLoopSkill(v.skillId) then
            table.insert(skillList, v.skillId)
        end
    end

    for _, skillId in ipairs(skillList) do
        local skillConf = Config.Get("battle_skill_def", "config", "skillId", skillId) or
            Config.Get("static_skill_def", "config", "id", skillId)
        if skillConf and skillConf.visibility > BattleDefine.Visibility.invisible then
            if skillConf.desc and skillConf.desc ~= "" then
                table.insert(skillDescLua, { desc = skillConf.desc, showInDetail = true ,skillId = skillId})
            end
        end
    end

    local cardConf = Config.Get("card_def", "config", "cardId", cardInfo.cardId)
    if cardConf.tagMap[BattleDefine.CardTagType.drone_device] then
        -- 静态异能里面 找到条件是回路的
        local loopSkillList = {}
        for _, v in ipairs(cardInfo.staticSkills) do
            if v.cardId ~= cardInfo.cardId and RichTextUtils.IsLoopSkill(v.skillId) then
                table.insert(loopSkillList, { skillId = v.skillId, loopNum = condConf.minValue })
            end
        end

        for _, v in ipairs(loopSkillList) do
            local skillId = v.skillId
            local loopNum = v.loopNum
            local skillConf = Config.Get("static_skill_def", "config", "id", skillId)
            if skillConf and skillConf.visibility > BattleDefine.Visibility.invisible then
                if skillConf.desc and skillConf.desc ~= "" then
                    table.insert(skillDescLua, { desc = skillConf.desc, loopNum = loopNum ,showInDetail = false, skillId = skillId})
                end
            end
        end
    end

    return skillDescLua
end

function RichTextUtils.IsLoopSkill(skillId)
    local conf = Config.Get("static_skill_def", "config", "id", skillId)
    for _, condId in ipairs(conf.conditionListSelf) do
        local condConf = Config.Get("battle_condition_def", "config", "id", condId)
        if condConf and condConf.args.valueKey == "dirCount" then
            if condConf.minValue > 0 and condConf.maxValue == -1 then
                return true
            end
        end
    end

    return false
end

-- 获取富文本对应的Icon
function RichTextUtils.GetRichTextIcon(content)
    local iconList = {}

    for tag, val in string.gmatch(content, "<(.-) (.-)/>") do
        local data = {}
        for str in string.gmatch(val, "([^ ]+)") do
            local kvIndex = string.find(str, "=")
            local key = string.sub(str, 0, kvIndex - 1)
            local endIdx = string.find(str, " ") or string.find(str, " ")
            if not endIdx then
                endIdx = string.len(str)
            end
            local val = string.sub(str, kvIndex + 1, endIdx)
            data[key] = val
        end
        local map = RichTextDefine.RichTextKeywordIdMap[tag]
        if map then
            if tag == RichTextDefine.Element.token then
                local id = map.id[data.type]
                local path = AssetPath.RichTextIcon[tag][data.type]
                table.insert(iconList, { id = id, path = path })
            else
                local id = map.id
                local path = AssetPath.RichTextIcon[tag]
                table.insert(iconList, { id = id, path = path })
            end
        end
    end

    -- 去重
    local temp = {}
    for _, icon in ipairs(iconList) do
        if not temp[icon.id] then
            temp[icon.id] = icon
        end
    end

    iconList = {}
    for _, icon in pairs(temp) do
        table.insert(iconList, icon)
    end

    return iconList
end

function RichTextUtils.SetRichTextAlignment(richTextInfo, alignment)
    -- 验证alignment是有效值
    if alignment ~= RichTextDefine.TextAlignment.left and 
       alignment ~= RichTextDefine.TextAlignment.center and 
       alignment ~= RichTextDefine.TextAlignment.right then
        LogError("Invalid text alignment value: " .. tostring(alignment))
        richTextInfo.alignment = RichTextDefine.TextAlignment.left
        return
    end
    
    richTextInfo.alignment = alignment
end

local function extractAttackValues(content)
    local values = {}
    local idx = 1
    for tag, val in string.gmatch(content, "<(attackValue) (.-)/>") do
        local data = {}
        local pos = 1
        local len = #val
        while pos <= len do
            while pos <= len and string.sub(val, pos, pos) == " " do
                pos = pos + 1
            end
            if pos > len then break end
            local equalPos = string.find(val, "=", pos)
            if not equalPos then break end
            local key = string.sub(val, pos, equalPos - 1)
            pos = equalPos + 1
            local nextKeyPos = len + 1
            local searchPos = pos
            while searchPos <= len do
                local nextEqualPos = string.find(val, "=", searchPos)
                if nextEqualPos then
                    local spacePos = nextEqualPos - 1
                    while spacePos > searchPos and string.sub(val, spacePos, spacePos) ~= " " do
                        spacePos = spacePos - 1
                    end
                    if spacePos > searchPos then
                        nextKeyPos = spacePos
                        break
                    end
                end
                searchPos = nextEqualPos and (nextEqualPos + 1) or (len + 1)
            end
            local value = string.sub(val, pos, nextKeyPos - 1)
            value = string.gsub(value, "%s+$", "")
            data[key] = value
            pos = nextKeyPos
        end
        table.insert(values, { index = idx, value = data.value, effectId = data.effectId })
        idx = idx + 1
    end
    return values
end

local function diffNormalText(prevText, currText)
    if prevText == currText then
        return currText
    end

    -- 比较去除数字后的文本骨架：若骨架不同说明两段文字结构已变化
    -- （例如当前段比前一版本多了 "与+2/+2" 这种纯新增内容），此时逐位对比数字会产生误判
    -- 直接返回 currText，不做任何高亮处理
    local prevSkeleton = string.gsub(prevText, "%d+", "")
    local currSkeleton = string.gsub(currText, "%d+", "")
    if prevSkeleton ~= currSkeleton then
        return currText
    end

    local prevNums = {}
    for num in string.gmatch(prevText, "%d+") do
        table.insert(prevNums, num)
    end

    -- 逐段拼接，避免 gsub 替换到已插入的高亮标签中的数字
    local result = ""
    local numIdx = 1
    local lastPos = 1
    for startPos, num, endPos in string.gmatch(currText, "()(%d+)()") do
        result = result .. string.sub(currText, lastPos, startPos - 1)
        local prevNum = prevNums[numIdx]
        if prevNum and num ~= prevNum then
            result = result .. string.format("<rich_text color=00DD9C content=%s/>", num)
        else
            result = result .. num
        end
        numIdx = numIdx + 1
        lastPos = endPos
    end
    result = result .. string.sub(currText, lastPos)

    return result
end

local function parseAndDiffRichText(prevContent, currContent)
    local prevAttackValues = extractAttackValues(prevContent)
    local currAttackValues = extractAttackValues(currContent)

    -- 预先将 prevContent 按 tag 顺序拆分为文本段，避免内层循环每次从头搜索
    -- prevSegs[i] 是第 i-1 个 tag 之后、第 i 个 tag 之前的文本（prevSegs[1] 为首个 tag 之前）
    local prevSegs = {}
    local prevSplitPos = 1
    for prevTag, prevVal in string.gmatch(prevContent, "<(.-) (.-)/>") do
        local prevTagStr = string.format("<%s %s/>", prevTag, prevVal)
        local pStart = string.find(prevContent, prevTagStr, prevSplitPos, true)
        if pStart then
            table.insert(prevSegs, string.sub(prevContent, prevSplitPos, pStart - 1))
            prevSplitPos = pStart + #prevTagStr
        end
    end
    -- 最后一段：最后一个 tag 之后的文本
    table.insert(prevSegs, string.sub(prevContent, prevSplitPos))

    local resultContent = ""
    local lastIdx = 1
    local attackValueIdx = 1
    -- 顺序消费 prevSegs，与 curr 的各段一一对应
    local prevSegIdx = 1

    for tag, val in string.gmatch(currContent, "<(.-) (.-)/>") do
        local tagStr = string.format("<%s %s/>", tag, val)
        local startIndex, endIndex = string.find(currContent, tagStr, lastIdx, true)
        local beforeStr = string.sub(currContent, lastIdx, startIndex - 1)
        lastIdx = lastIdx + #beforeStr + #tagStr

        if beforeStr ~= "" then
            -- 取与当前 curr 段对应的 prev 段（若 prev 段不存在则视为全新内容，传空串）
            local prevBeforeStr = prevSegs[prevSegIdx] or ""
            resultContent = resultContent .. diffNormalText(prevBeforeStr, beforeStr)
        end

        -- 向后移动 prev 段指针（无论 beforeStr 是否为空，curr tag 消耗一个 prev 段）
        prevSegIdx = prevSegIdx + 1

        if tag == "attackValue" then
            local prevVal = prevAttackValues[attackValueIdx]
            local currVal = currAttackValues[attackValueIdx]
            if prevVal and currVal and prevVal.value ~= currVal.value then
                resultContent = resultContent .. string.format("<%s %s diff=true/>", tag, val)
            else
                resultContent = resultContent .. tagStr
            end
            attackValueIdx = attackValueIdx + 1
        else
            resultContent = resultContent .. tagStr
        end
    end

    local lastStr = string.sub(currContent, lastIdx, string.len(currContent))
    if lastStr ~= "" then
        -- 取最后一个 prev 段与 curr 末尾段对比（若 prev 已无对应段则视为新增内容）
        local prevLastStr = prevSegs[prevSegIdx] or ""
        resultContent = resultContent .. diffNormalText(prevLastStr, lastStr)
    end

    return resultContent
end

function RichTextUtils.DiffCardContentList(prevCardId, currCardInfo, settings)
    settings = settings or {}
    local prevContentList = RichTextUtils.GetCardContentList({ cardId = prevCardId }, settings)
    local currContentList = RichTextUtils.GetCardContentList(currCardInfo, settings)

    local resultList = {}
    -- prevIdx 作为顺序游标，向前贪心查找匹配的 prev 行
    -- 处理 prev 比 curr 多行（如升级移除了关键字行）的情况，避免下标错位和重复
    local prevIdx = 1

    for i = 1, #currContentList do
        local currItem = currContentList[i]
        local newItem = {}
        for k, v in pairs(currItem) do
            newItem[k] = v
        end

        -- 优先向前查找与 currItem 内容完全相同的 prev 行（跳过已删除的行）
        local matchedPrev = nil
        for j = prevIdx, #prevContentList do
            if prevContentList[j].desc == currItem.desc then
                matchedPrev = prevContentList[j]
                prevIdx = j + 1
                break
            end
        end

        -- 未找到精确匹配（内容有变化），按当前游标位置取 prev 行做 diff
        if not matchedPrev then
            matchedPrev = prevContentList[prevIdx]
            if matchedPrev then
                prevIdx = prevIdx + 1
            end
        end

        if matchedPrev and matchedPrev.desc and currItem.desc then
            local diffDesc = parseAndDiffRichText(matchedPrev.desc, currItem.desc)
            newItem.desc = diffDesc
        end

        table.insert(resultList, newItem)
    end

    return resultList
end
