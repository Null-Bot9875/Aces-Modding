RichAttackText = BaseClass("RichAttackText", RichTextElement)

function RichAttackText:__Init()
    self.path = AssetPath.RichTextIcon[RichTextDefine.Element.attack]
    self.img = nil -- sprite
    self.elementType = RichTextDefine.Element.attack
    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    local loadList = {}
    table.insert(loadList, { file = self.path, type = AssetType.Sprite })

    -- 后面这部分定义可以绑定到配置上
    self.colorMap = 
    {
        [RichTextDefine.ColorMode.light] = Color(50/255, 52/255, 64/255),
        [RichTextDefine.ColorMode.dark] = Color(1, 1, 1),
    }

    self.assetLoader:Load(loadList, self:ToFunc("AssetLoaded"))
end

function RichAttackText:__Delete()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end

    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function RichAttackText:AssetLoaded()
    self.img = self.assetLoader:GetAsset(self.path)

    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function RichAttackText:OnCreate()
    local objects = self:CreateAttackText(self.img)
    for i, v in ipairs(objects) do
        local imgComponent = v.obj.transform:Find("img").gameObject:GetComponent(Image)
        imgComponent.sprite = v.img
        --imgComponent:SetNativeSize()

        local richTextInfo = self.richTextItem:GetRichTextInfo()
        if richTextInfo.fixedColor == Color.gray then
            imgComponent.grey = true
        end

        v.obj.transform:Find("del").gameObject:SetActive(richTextInfo.delLine)

        local textComponent = v.obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
        self:SetFontStyle(textComponent)

        if self.colorMap[richTextInfo.colorMode] then
            textComponent.color = self.colorMap[richTextInfo.colorMode]
        end
    end
end

function RichAttackText:OnParseData(kvData)
end

function RichAttackText:CreateAttackText(image)
    local objects = {}
    local width, height = self.richTextItem:GetImageSize(image)
    local flag = self.richTextItem:CheckWidth(width)
    if not flag then
        self.richTextItem:EnterNewLine()
    end

    self.richTextItem:UpdateLineHeight(height)
    local obj = self.richTextItem:AddElementObj(self.elementType, width, height)
    table.insert(objects, { obj = obj, img = image })

    return objects
end
