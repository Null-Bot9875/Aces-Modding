RichAttackValue = BaseClass("RichAttackValue", RichTextElement)

function RichAttackValue:__Init()
    self.elementType = RichTextDefine.Element.attackValue
    self.value = nil
    self.diff = false
end

function RichAttackValue:__Delete()

end

function RichAttackValue:OnCreate()
    local content, color = self:GetContent()
    local objects = self:CreateText(content, 0)
    for i, v in ipairs(objects) do
        local text = v.obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)

        local richTextInfo = self.richTextItem:GetRichTextInfo()
        if richTextInfo.fixedColor then
            text.color = richTextInfo.fixedColor
        end

        if self.diff then
            text.color = Color(0, 221/255, 156/255, 1)
        elseif color then
            text.color = color
        end

        self:SetFontStyle(text)

        text.text = v.str

        v.obj.transform:Find("del").gameObject:SetActive(richTextInfo.delLine)
    end
end

function RichAttackValue:OnParseData(kvData)
    self.value = kvData["value"]
    self.effectId = kvData["effectId"]
    self.diff = kvData["diff"] == "true"
end

function RichAttackValue:GetContent()
    local map = self.richTextItem.richTextInfo.attrMap or {}
    local val = nil
    if self.effectId then
        local effectConf = Config.Get("battle_effect_def", "config", "effectId", self.effectId)
        if effectConf then
            val = effectConf.value
        end

        for i, v in ipairs(map) do
            if v.attr == self.effectId then
                val = v.value
                break
            end
        end
    else
        val = self.value
        for i, v in ipairs(map) do
            if v.attr == BattleDefine.CardAttrType.damageAdd then
                val = v.value + val
            end
        end
    end

    local color = nil
    if val then
        local num = tonumber(val)
        local confVal = tonumber(self.value)
        if num > confVal then
            color = Color.red
        elseif num < confVal then
            color = Color.green
        end
    end

    local content = val == nil and self.value or tostring(val)
    return content, color
end
