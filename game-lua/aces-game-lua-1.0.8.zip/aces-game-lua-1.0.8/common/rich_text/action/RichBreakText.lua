RichBreakText = BaseClass("RichBreakText",RichTextElement)

function RichBreakText:__Init()
    self.elementType = RichTextDefine.Element.br
    self.content = nil
end

function RichBreakText:__Delete()
    
end

function RichBreakText:OnCreate()
    self.richTextItem:EnterNewLine()
end

function RichBreakText:OnParseData(kvData)
end