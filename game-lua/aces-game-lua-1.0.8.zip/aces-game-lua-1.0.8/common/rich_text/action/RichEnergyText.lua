-- 能量的显示
RichEnergyText = BaseClass("RichEnergyText", RichTextElement)

function RichEnergyText:__Init()
    self.path = AssetPath.RichTextIcon[RichTextDefine.Element.energy]
    self.img = nil -- sprite
    self.elementType = RichTextDefine.Element.energy
    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    local loadList = {}
    table.insert(loadList, { file = self.path, type = AssetType.Sprite })

    -- 后面这部分定义可以绑定到配置上
    self.colorMap = 
    {
        [RichTextDefine.ColorMode.light] = Color(50/255, 52/255, 64/255),
        [RichTextDefine.ColorMode.dark] = Color(1, 1, 1),
    }

    self.assetLoader:Load(loadList, self:ToFunc("AssetLoaded"))
end

function RichEnergyText:__Delete()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end

    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function RichEnergyText:AssetLoaded()
    self.img = self.assetLoader:GetAsset(self.path)

    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function RichEnergyText:OnCreate()
    local content = self:GetContent()
    local objects = self:CreateEnergyText(content, self.img)
    for i, v in ipairs(objects) do
        local imgComponent = v.obj.transform:Find("img").gameObject:GetComponent(Image)
        imgComponent.sprite = self.img
        --imgComponent:SetNativeSize()

        local richTextInfo = self.richTextItem:GetRichTextInfo()

        if richTextInfo.fixedColor == Color.gray then
            imgComponent.grey = true
        end

        local textComponent = v.obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
        if content ~= "" then
            textComponent.text = content
            textComponent.raycastTarget = false

            if self.colorMap[richTextInfo.colorMode] then
                textComponent.color = self.colorMap[richTextInfo.colorMode]
            end
        else
            textComponent.gameObject:SetActive(false)
            -- 移动图片位置
            local imgRect = imgComponent.gameObject:GetComponent(RectTransform)

            local imgW, imgH = self.richTextItem:GetImageSize(self.img)
            imgRect.anchoredPosition = Vector2(0, 0)
        end

        v.obj.transform:Find("del").gameObject:SetActive(richTextInfo.delLine)

        self:SetFontStyle(textComponent)
    end
end

function RichEnergyText:OnParseData(kvData)
    self.value = kvData["value"]
    self.effectId = kvData["effectId"]
end

function RichEnergyText:GetContent()
    local map = self.richTextItem.richTextInfo.attrMap or {}
    local val = nil
    if self.effectId then
        local effectConf = Config.Get("battle_effect_def", "config", "effectId", self.effectId)
        if effectConf then
            val = effectConf.value
        end

        for i, v in ipairs(map) do
            if v.attr == self.effectId then
                val = v.value
                break
            end
        end
    else
        val = self.value
    end

    if not val then
        return ""
    end

    return val .. "*"
end

function RichEnergyText:CreateEnergyText(content, image)
    local objects = {}
    local textW, textH = 0, 0
    if self.value then
        textW, textH = self:GetTextSize(content)
    end
    local imgW, imgH = textH * 0.65, textH * 0.65

    local totalWeight = textW + imgW
    local maxHeight = math.max(textH, imgH)
    local flag = self.richTextItem:CheckWidth(totalWeight)

    if not flag then
        self.richTextItem:EnterNewLine()
    end

    self.richTextItem:UpdateLineHeight(maxHeight)
    local obj = self.richTextItem:AddElementObj(self.elementType, totalWeight, maxHeight)
    table.insert(objects, { obj = obj, str = content })

    local textComponent = obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
    textComponent.transform:SetSizeDelata(textW, textH)
    textComponent.transform:SetAnchoredPosition(textW * 0.5, -textH * 0.5)

    local imgComponent = obj.transform:Find("img").gameObject:GetComponent(Image)
    imgComponent.transform:SetSizeDelata(imgW, imgH)
    imgComponent.transform:SetAnchoredPosition(textW, -((textH - imgH) * 0.5))

    return objects
end
