RichEnergyValue = BaseClass("RichEnergyValue", RichTextElement)

function RichEnergyValue:__Init()
    self.elementType = RichTextDefine.Element.energyValue
    self.value = nil
end

function RichEnergyValue:__Delete()

end

function RichEnergyValue:OnCreate()
    local content, color = self:GetContent()
    local objects = self:CreateText(content, 0)
    for i, v in ipairs(objects) do
        local text = v.obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
        if color then
            text.color = color
        end

        local richTextInfo = self.richTextItem:GetRichTextInfo()
        
        self:SetFontStyle(text)

        text.text = v.str

        v.obj.transform:Find("del").gameObject:SetActive(richTextInfo.delLine)
    end
end

function RichEnergyValue:OnParseData(kvData)
    self.value = kvData["value"]
end

function RichEnergyValue:GetContent()
    local map = self.richTextItem.richTextInfo.attrMap or {}
    local val = nil
    local color = nil
    for i, v in ipairs(map) do
        if v.attr == BattleDefine.CardAttrType.costValue then
            val = v.value
            break
        end
    end

    if val then
        local confVal = tonumber(self.value)
        if val > confVal then
            color = Color.red
        elseif val < confVal then
            color = Color.green
        end
    end

    local content = val == nil and self.value or tostring(val)
    return content, color
end
