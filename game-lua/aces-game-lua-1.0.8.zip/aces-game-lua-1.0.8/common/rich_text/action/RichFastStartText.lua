RichFastStartText = BaseClass("RichFastStartText", RichTextElement)

function RichFastStartText:__Init()
    self.path = AssetPath.RichTextIcon[RichTextDefine.Element.fastStart]
    self.img = nil -- sprite
    self.elementType = RichTextDefine.Element.fastStart
    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    local loadList = {}
    table.insert(loadList, { file = self.path, type = AssetType.Sprite })

    self.assetLoader:Load(loadList, self:ToFunc("AssetLoaded"))
end

function RichFastStartText:__Delete()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end

    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function RichFastStartText:AssetLoaded()
    self.img = self.assetLoader:GetAsset(self.path)

    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function RichFastStartText:OnCreate()
    local objects = self:CreateImg(self.img)
    for i, v in ipairs(objects) do
        local imgComponent = v.obj.transform:Find("img").gameObject:GetComponent(Image)
        imgComponent.sprite = v.img
        --imgComponent:SetNativeSize()

        local richTextInfo = self.richTextItem:GetRichTextInfo()
        if richTextInfo.fixedColor == Color.gray then
            imgComponent.grey = true
        end


        v.obj.transform:Find("del").gameObject:SetActive(richTextInfo.delLine)
    end
end

function RichFastStartText:OnParseData(kvData)
end

function RichFastStartText:CreateImg(image)
    local objects = {}
    local width, height = self.richTextItem:GetImageSize(image)
    local flag = self.richTextItem:CheckWidth(width)
    if not flag then
        self.richTextItem:EnterNewLine()
    end

    self.richTextItem:UpdateLineHeight(height)
    local obj = self.richTextItem:AddElementObj(self.elementType, width, height)
    table.insert(objects, { obj = obj, img = image })

    return objects
end
