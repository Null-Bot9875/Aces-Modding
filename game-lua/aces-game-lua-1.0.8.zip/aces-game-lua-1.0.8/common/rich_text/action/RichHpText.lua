-- 能量的显示
RichHpText = BaseClass("RichHpText", RichTextElement)

function RichHpText:__Init()
    self.path = AssetPath.RichTextIcon[RichTextDefine.Element.hp]
    self.img = nil -- sprite
    self.elementType = RichTextDefine.Element.hp
    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    local loadList = {}
    table.insert(loadList, { file = self.path, type = AssetType.Sprite })

    self.assetLoader:Load(loadList, self:ToFunc("AssetLoaded"))
end

function RichHpText:__Delete()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end

    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function RichHpText:AssetLoaded()
    self.img = self.assetLoader:GetAsset(self.path)

    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function RichHpText:OnCreate()
    local objects = self:CreateHpText(self.value, self.img)
    for i, v in ipairs(objects) do
        local imgComponent = v.obj.transform:Find("img").gameObject:GetComponent(Image)
        imgComponent.sprite = self.img
        --imgComponent:SetNativeSize()

        local richTextInfo = self.richTextItem:GetRichTextInfo()

        if richTextInfo.fixedColor == Color.gray then
            imgComponent.grey = true
        end

        local textComponent = v.obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
        if self.value then
            textComponent.text = self.value
            textComponent.raycastTarget = false
        else
            textComponent.gameObject:SetActive(false)
            -- 移动图片位置
            local imgRect = imgComponent.gameObject:GetComponent(RectTransform)

            local imgW, imgH = 40.36, 40.36
            -- local imgW, imgH = self.richTextItem:GetImageSize(self.img)
            imgRect.anchoredPosition = Vector2(0, 0)
        end


        v.obj.transform:Find("del").gameObject:SetActive(richTextInfo.delLine)

        self:SetFontStyle(textComponent)
    end
end

function RichHpText:OnParseData(kvData)
    if kvData["value"] then
        self.value = kvData["value"] .. "*"
    end
end

function RichHpText:CreateHpText(content, image)
    local objects = {}
    local textW, textH = 0, 0
    if self.value then
        textW, textH = self:GetTextSize(content, self:GetFontStyle())
    end
    -- local imgW, imgH = self.richTextItem:GetImageSize(image)
    local imgW, imgH = textH*0.65, textH*0.65

    local totalWeight = textW + imgW
    local maxHeight = math.max(textH, imgH)
    local flag = self.richTextItem:CheckWidth(totalWeight)

    if not flag then
        self.richTextItem:EnterNewLine()
    end

    self.richTextItem:UpdateLineHeight(maxHeight)
    local obj = self.richTextItem:AddElementObj(self.elementType, totalWeight, maxHeight)
    table.insert(objects, { obj = obj, str = content })

    local textComponent = obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
    textComponent.transform:SetSizeDelata(textW, textH)
    textComponent.transform:SetAnchoredPosition(textW * 0.5, -textH * 0.5)

    local imgComponent = obj.transform:Find("img").gameObject:GetComponent(Image)
    imgComponent.transform:SetSizeDelata(imgW, imgH)
    imgComponent.transform:SetAnchoredPosition(textW, -((textH - imgH) * 0.5))

    return objects
end
