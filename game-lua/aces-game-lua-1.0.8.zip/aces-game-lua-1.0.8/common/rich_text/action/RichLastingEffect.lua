RichLastingEffect = BaseClass("RichLastingEffect", RichTextElement)

function RichLastingEffect:__Init()
    self.path = AssetPath.RichTextIcon[RichTextDefine.Element.lastingEffect]
    self.img = nil -- sprite
    self.elementType = RichTextDefine.Element.lastingEffect
    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    local loadList = {}
    table.insert(loadList, { file = self.path, type = AssetType.Sprite })

    self.assetLoader:Load(loadList, self:ToFunc("AssetLoaded"))
end

function RichLastingEffect:__Delete()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end

    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function RichLastingEffect:AssetLoaded()
    self.img = self.assetLoader:GetAsset(self.path)

    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function RichLastingEffect:OnCreate()
    local objects = self:CreateLastingText(self.img)
    for i, v in ipairs(objects) do
        local imgComponent = v.obj.transform:Find("img").gameObject:GetComponent(Image)
        imgComponent.sprite = v.img
        --imgComponent:SetNativeSize()

        local richTextInfo = self.richTextItem:GetRichTextInfo()
        if richTextInfo.fixedColor == Color.gray then
            imgComponent.grey = true
        end

        v.obj.transform:Find("img/del").gameObject:SetActive(richTextInfo.delLine)
    end
end

function RichLastingEffect:OnParseData(kvData)
end

function RichLastingEffect:CreateLastingText(image)
    local objects = {}
    
    local width, height = 130*.65, 52.7*.65
    local flag = self.richTextItem:CheckWidth(width)
    if not flag then
        self.richTextItem:EnterNewLine()
    end

    self.richTextItem:UpdateLineHeight(height)
    local obj = self.richTextItem:AddElementObj(self.elementType, width, height)
    table.insert(objects, { obj = obj, img = image })

    local imgComponent = obj.transform:Find("img").gameObject:GetComponent(Image)
    imgComponent.transform:SetSizeDelata(width, height)
    imgComponent.transform:SetAnchoredPosition(0, -(52.7 - height) * 0.5)

    -- local delRect = obj.transform:Find("del").gameObject:GetComponent(RectTransform)
    -- delRect:SetSizeDelta(width, 1)

    return objects
end
