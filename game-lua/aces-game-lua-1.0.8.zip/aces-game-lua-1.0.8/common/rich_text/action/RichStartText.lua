RichStartText = BaseClass("RichStartText", RichTextElement)

function RichStartText:__Init()
    self.path = AssetPath.RichTextIcon[RichTextDefine.Element.start]
    self.img = nil -- sprite
    self.elementType = RichTextDefine.Element.start
    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    local loadList = {}
    table.insert(loadList, { file = self.path, type = AssetType.Sprite })

    self.assetLoader:Load(loadList, self:ToFunc("AssetLoaded"))
end

function RichStartText:__Delete()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end

    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function RichStartText:AssetLoaded()
    self.img = self.assetLoader:GetAsset(self.path)

    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function RichStartText:OnCreate()
    local objects = self:CreateImg(self.img)
    for i, v in ipairs(objects) do
        local imgComponent = v.obj.transform:Find("img").gameObject:GetComponent(Image)
        imgComponent.sprite = v.img
        --imgComponent:SetNativeSize()

        local richTextInfo = self.richTextItem:GetRichTextInfo()

        if richTextInfo.fixedColor == Color.gray then
            imgComponent.grey = true
        end

        v.obj.transform:Find("del").gameObject:SetActive(richTextInfo.delLine)
    end
end

function RichStartText:OnParseData(kvData)
end

function RichStartText:CreateImg(image)
    local objects = {}
    local width, height = self.richTextItem:GetImageSize(image)
    local flag = self.richTextItem:CheckWidth(width)
    if not flag then
        self.richTextItem:EnterNewLine()
    end

    self.richTextItem:UpdateLineHeight(height)
    local obj = self.richTextItem:AddElementObj(self.elementType, width, height)
    table.insert(objects, { obj = obj, img = image })

    return objects
end
