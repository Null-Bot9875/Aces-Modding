RichTextDelText = BaseClass("RichTextDelText", RichTextElement)

function RichTextDelText:__Init()
    self.elementType = RichTextDefine.Element.rich_text
    self.content = nil
end

function RichTextDelText:__Delete()

end

function RichTextDelText:OnCreate()
    -- 删除线
    local fontStyle = RichTextDefine.FontStyles[FontStyles.Normal] -- Reset font style
    fontStyle = fontStyle | RichTextDefine.FontStyles[FontStyles.Strikethrough]

    -- 灰色
    local color = Color.gray

    local objects = self:CreateText(self.content, 0, fontStyle)
    for i, v in ipairs(objects) do
        local textComponent = v.obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
        textComponent.text = v.str
        textComponent.raycastTarget = false
        textComponent.fontStyle = fontStyle
        textComponent.color = color
    end
end

function RichTextDelText:OnParseData(kvData)
    self.content = kvData.content
end
