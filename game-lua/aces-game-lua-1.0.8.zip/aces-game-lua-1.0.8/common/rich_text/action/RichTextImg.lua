RichTextImg = BaseClass("RichTextImg", RichTextElement)

function RichTextImg:__Init()
    self.elementType = RichTextDefine.Element.img
    
    self.color = nil
    self.imgPath = nil
    self.img = nil -- sprite
    self.assetScope = nil
    self.assetLoader = nil
end

function RichTextImg:__Delete()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end

    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function RichTextImg:OnCreate()
    local r, g, b, a = nil, nil, nil, nil
    if self.color then
        r, g, b, a = ColorUtils.HexToColorVal(self.color)
    end

    local objects = self:CreateImg(self.img)
    for i, v in ipairs(objects) do
        local imgComponent = v.obj.transform:Find("img").gameObject:GetComponent(Image)
        imgComponent.sprite = v.img
        imgComponent:SetNativeSize()
        if self.color then
            UnityUtils.SetColor(imgComponent, r, g, b, a)
        end

        local rectTransform = imgComponent.gameObject:GetComponent(RectTransform)
        rectTransform.anchoredPosition = Vector2.zero

        local richTextInfo = self.richTextItem:GetRichTextInfo()
        if richTextInfo.fixedColor == Color.gray then
            imgComponent.grey = true
        end

        -- v.obj.transform:Find("del").gameObject:SetActive(richTextInfo.delLine)
    end
end

function RichTextImg:OnParseData(kvData)
    self.color = self.richTextItem.richTextInfo.toColor[kvData["color"]] or kvData["color"]
    -- self.imgPath = UITex("rich_text/card/".. kvData["path"])
    self.imgPath = AssetPath.GetRichtextIcon(kvData["path"])

    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    self.assetLoader:Load({ { file = self.imgPath, type = AssetType.Sprite } },
        self:ToFunc("AssetLoaded"))
end

function RichTextImg:AssetLoaded(image)
    self.img = self.assetLoader:GetAsset(self.imgPath)

    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function RichTextImg:CreateImg(image)
    local objects = {}
    local width, height = image.rect.width, image.rect.height
    local flag = self.richTextItem:CheckWidth(width)
    if not flag then
        self.richTextItem:EnterNewLine()
    end

    self.richTextItem:UpdateLineHeight(height)
    height = self.richTextItem:GetLineHeight()
    local obj = self.richTextItem:AddElementObj(self.elementType, width, height)
    table.insert(objects, { obj = obj, img = image })

    return objects
end
