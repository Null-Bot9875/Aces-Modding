RichTextNoneText = BaseClass("RichTextNoneText",RichTextElement)

function RichTextNoneText:__Init()
    self.elementType = RichTextDefine.Element.none_text
    self.content = nil
end

function RichTextNoneText:__Delete()
    
end

function RichTextNoneText:OnCreate()
    -- self.content = "。回复3装甲。 若此牌在废弃区，当你废弃非同名的其它卡牌时，将此牌返回你的手牌。"
    local objects = self:CreateText(self.content,0)
    -- LogTable("objects",objects)
    for i,v in ipairs(objects) do
        local textComponent = v.obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
        -- Log("textComponent.text:" .. v.str)
        textComponent.text = v.str
        textComponent.raycastTarget = false
        local num = RichTextDefine.FontStyles[FontStyles.Normal] -- Reset font style

        textComponent.fontStyle = num

        local richTextInfo = self.richTextItem:GetRichTextInfo()
        if richTextInfo.fixedColor then
            textComponent.color = richTextInfo.fixedColor
        end

        self:SetFontStyle(textComponent)

        v.obj.transform:Find("del").gameObject:SetActive(richTextInfo.delLine)
    end
end

function RichTextNoneText:OnParseData(kvData)
    self.content = kvData["content"]
end