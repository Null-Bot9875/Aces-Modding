RichTextNormalText = BaseClass("RichTextNormalText", RichTextElement)

function RichTextNormalText:__Init()
    self.elementType = RichTextDefine.Element.rich_text
    self.content = nil
    self.color = nil
    self.bold = false
    self.italic = false
    self.underline = false
    self.strikethrough = false
end

function RichTextNormalText:__Delete()

end

function RichTextNormalText:OnCreate()
    local content, color = self:GetContent()
    local objects = self:CreateText(content, 0)
    for i, v in ipairs(objects) do
        local textComponent = v.obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
        textComponent.text = v.str
        textComponent.raycastTarget = false
        -- if self.color then
            -- local textColor = ColorUtils.HexToColor(self.color)
            -- textComponent.color = textColor
            --textComponent:SetColor(r, g, b, a)
        -- end
        if color then
            textComponent.color = color
        end

        local richTextInfo = self.richTextItem:GetRichTextInfo()
        -- if richTextInfo.fixedColor then
            -- textComponent.color = richTextInfo.fixedColor
        -- end

        v.obj.transform:Find("del").gameObject:SetActive(richTextInfo.delLine)

        self:SetFontStyle(textComponent)
    end
end

function RichTextNormalText:OnParseData(kvData)
    self.content = kvData.content
    self.color = self.richTextItem.richTextInfo.toColor[kvData.color] or kvData.color
    self.bold = kvData.bold
    self.italic = kvData.italic
    self.underline = kvData.underline
    self.strikethrough = kvData.strikethrough
    -- self.loopNum = kvData.loopNum
end

function RichTextNormalText:GetContent()
    local color = nil
    if self.richTextItem.richTextInfo.fixedColor then
        color = self.richTextItem.richTextInfo.fixedColor
    end

    if self.color then
        color = ColorUtils.HexToColor(self.color)
    end

    local content = tostring(self.content)
    return content, color
end
