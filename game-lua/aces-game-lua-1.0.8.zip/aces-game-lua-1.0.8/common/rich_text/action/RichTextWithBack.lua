RichTextWithBack = BaseClass("RichTextWithBack", RichTextElement)

function RichTextWithBack:__Init()
    self.elementType = RichTextDefine.Element.text_back
    self.content = nil
    self.canSplit = false

    self.typeParamMap = {
        ["1"] =
        {
            ["icon"] = "back_1",
            ["maxWidth"] = 400,
            ["minWidth"] = 50,
            ["paddingLeft"] = 10,
            ["paddingRight"] = 10,
        },
        ["2"] =
        {
            ["icon"] = "back_2",
            ["maxWidth"] = 400,
            ["minWidth"] = 50,
            ["paddingLeft"] = 10,
            ["paddingRight"] = 10,
        },
        ["3"] =
        {
            ["icon"] = "back_3",
            ["maxWidth"] = 400,
            ["minWidth"] = 100,
            ["paddingLeft"] = 20,
            ["paddingRight"] = 20,
        },
        ["4"] =
        {
            ["icon"] = "back_4",
            ["maxWidth"] = 400,
            ["minWidth"] = 100,
            ["paddingLeft"] = 20,
            ["paddingRight"] = 20,
        },
        ["5"] =
        {
            ["icon"] = "back_5",
            ["maxWidth"] = 400,
            ["minWidth"] = 100,
            ["paddingLeft"] = 20,
            ["paddingRight"] = 20,
        }
    }

    self.iconLoader = IconLoader.Create()
end

function RichTextWithBack:__Delete()
    if self.iconLoader then
        self.iconLoader:Delete()
        self.iconLoader = nil
    end
end

function RichTextWithBack:GetTextSize(content)
    local template = self.richTextItem.richTextInfo.elementTemplate[self.elementType]
    self:SetFontStyle(template.textComponent)
    self:SetupComponent(self.type, content, template.original)
    -- local x, y = RichTextUtils.GetTextSize(content, template)
    -- template.textComponent.fontMaterial = RichTextUtils.GetRichtextDefaultMat(template)
    local rect = template.original:GetComponent(RectTransform).rect
    local x, y = rect.width, rect.height
    return x, y
end

function RichTextWithBack:OnCreate()
    local objects = self:CreateText(self.content, 0)
    for i, v in ipairs(objects) do
        local textComponent = v.obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
        self:SetupComponent(self.type, v.str, v.obj)

        -- if self.color then
        --     local textColor = ColorUtils.HexToColor(self.color)
        --     textComponent.color = textColor
        -- end

        -- local richTextInfo = self.richTextItem:GetRichTextInfo()
        -- if richTextInfo.fixedColor then
            -- textComponent.color = richTextInfo.fixedColor
        -- end

        self:SetFontStyle(textComponent)

        local image = v.obj.transform:Find("back").gameObject:GetComponent(Image)
        -- local path = string.format("UI/Textures/RichText/%s.png", self.typeParamMap[self.type].icon)
        if not self.typeParamMap[self.type] then
            self.type = "1"
        end

        local path = AssetPath.GetRichtextIcon(self.typeParamMap[self.type]["icon"])
        self.iconLoader:LoadIcon(image, path)
    end
end

function RichTextWithBack:SetupComponent(type, text, gameObject)
    local adapt = gameObject:GetComponent(AdaptTextWithBack)
    local param = self.typeParamMap[type]
    adapt.maxWidth = param.maxWidth
    adapt.minWidth = param.minWidth
    adapt.paddingLeft = param.paddingLeft
    adapt.paddingRight = param.paddingRight

    local textComponent = gameObject.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
    textComponent.text = text
    textComponent.raycastTarget = false

    adapt:Adapt()
end

function RichTextWithBack:OnParseData(kvData)
    self.content = kvData.content
    self.color = self.richTextItem.richTextInfo.toColor[kvData.color] or kvData.color
    self.bold = kvData.bold
    self.italic = kvData.italic
    self.underline = kvData.underline
    self.strikethrough = kvData.strikethrough
    self.type = kvData.type
end
