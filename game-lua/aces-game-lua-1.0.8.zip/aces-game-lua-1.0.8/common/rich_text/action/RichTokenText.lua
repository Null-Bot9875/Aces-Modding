RichTokenText = BaseClass("RichTokenText", RichTextElement)

function RichTokenText:__Init()
    self.img = nil -- sprite
    self.elementType = RichTextDefine.Element.token
    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
end

function RichTokenText:__Delete()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end

    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function RichTokenText:AssetLoaded()
    self.img = self.assetLoader:GetAsset(self.path)

    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function RichTokenText:OnCreate()
    local objects = self:CreateToken(self.value, self.img)
    for i, v in ipairs(objects) do
        local imgComponent = v.obj.transform:Find("img").gameObject:GetComponent(Image)
        imgComponent.sprite = self.img
        --imgComponent:SetNativeSize()

        local textComponent = v.obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
        if self.value then
            textComponent.text = self.value
            textComponent.raycastTarget = false
        else
            textComponent.gameObject:SetActive(false)
            -- 移动图片位置
            local imgRect = imgComponent.gameObject:GetComponent(RectTransform)

            local imgW, imgH = self.richTextItem:GetImageSize(self.img)
            imgRect.anchoredPosition = Vector2(0, 0)
        end

        self:SetFontStyle(textComponent)

        local richTextInfo = self.richTextItem:GetRichTextInfo()
        if richTextInfo.fixedColor == Color.gray then
            imgComponent.grey = true
        end

        v.obj.transform:Find("del").gameObject:SetActive(richTextInfo.delLine)
    end
end

function RichTokenText:OnParseData(kvData)
    local pathMap = AssetPath.RichTextIcon[RichTextDefine.Element.token]
    self.path = pathMap[kvData.type]
    local loadList = {}
    table.insert(loadList, { file = self.path, type = AssetType.Sprite })
    self.assetLoader:Load(loadList, self:ToFunc("AssetLoaded"))

    if kvData["value"] then
        self.value = kvData["value"] .. "*"
    end
end

function RichTokenText:CreateToken(content, image)
    local objects = {}
    local textW, textH = 0, 0
    if self.value then
        textW, textH = self:GetTextSize(content)
    end
    -- local imgW, imgH = self.richTextItem:GetImageSize(image)
    local imgW, imgH = textH*0.65, textH*0.65


    local totalWeight = textW + imgW
    local maxHeight = math.max(textH, imgH)
    local flag = self.richTextItem:CheckWidth(totalWeight)

    if not flag then
        self.richTextItem:EnterNewLine()
    end

    self.richTextItem:UpdateLineHeight(maxHeight)
    local obj = self.richTextItem:AddElementObj(self.elementType, totalWeight, maxHeight)
    table.insert(objects, { obj = obj, str = content })

    local textComponent = obj.transform:Find("text").gameObject:GetComponent(TextMeshProUGUI)
    textComponent.transform:SetSizeDelata(textW, textH)
    textComponent.transform:SetAnchoredPosition(textW * 0.5, -textH * 0.5)

    local imgComponent = obj.transform:Find("img").gameObject:GetComponent(Image)
    imgComponent.transform:SetSizeDelata(imgW, imgH)
    -- imgComponent.transform:SetAnchoredPosition(textW, 0)
    imgComponent.transform:SetAnchoredPosition(textW, -((textH - imgH) * 0.5))
    return objects
end
