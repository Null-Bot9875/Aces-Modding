RichTextElement = BaseClass("RichTextElement")

function RichTextElement:__Init(richTextItem)
    self.richTextItem = richTextItem
    self.elementType = RichTextDefine.Element.none
    self.kvData = nil
    self.canSplit = true
end

function RichTextElement:__Delete()

end

function RichTextElement:SetKvData(kvData)
    self.kvData = kvData
end

function RichTextElement:GetTextSize(content)
    local template = self.richTextItem.richTextInfo.elementTemplate[self.elementType]
    self:SetFontStyle(template.textComponent)
    local x,y = RichTextUtils.GetTextSize(content,template)
    local matNode = self.richTextItem.richTextInfo.elementTemplate.matNode
    template.textComponent.fontMaterial = RichTextUtils.GetRichtextDefaultMat(matNode)

    return x,y
end

function RichTextElement:CreateText(content,appendHeight)
    local objects = {}
    local width,height = self:GetTextSize(content)
    local flag = self.richTextItem:CheckWidth(width)
    if flag then
        if content == "\n" then
            self.richTextItem:EnterNewLine()
        else
            self.richTextItem:UpdateLineHeight(height)
            local obj = self.richTextItem:AddElementObj(self.elementType,width,height)
            local layoutElement = obj.gameObject:GetComponent(LayoutElement)
            if not layoutElement then
                layoutElement = obj.gameObject:AddComponent(LayoutElement)
            end
            layoutElement.preferredWidth = width
            layoutElement.preferredHeight = height
            table.insert(objects,{obj = obj,str = content})
        end
    else
        if not self.canSplit and self.richTextItem:HasElementInCurrentLine() then
            -- 术语类富文本优先整块换到下一行，避免单词在标签内被裁断
            self.richTextItem:EnterNewLine()
            return self:CreateText(content,appendHeight)
        end

        local textList = StringUtils.SplitToTable(content)
        self:CreateTextList(textList,1,appendHeight,objects)
    end
    return objects
end

--[[
避免直接使用sub函数，因为sub函数会根据字符串的编码来截取，可能会导致截取到半个字符，从而导致文本显示不完整。
local s = "你好"  -- UTF-8编码下占6字节（每个汉字3字节）
print(s:sub(1, 3))  -- 输出 "你"（正确）
print(s:sub(2, 3))  -- 输出乱码！（截断了多字节字符）

比如出现'。'结尾，使用sub函数会截取到半个字符，从而导致文本显示不完整。
使用table.concat来避免这个问题。
]]
function RichTextElement:CreateTextList(textList,beginIndex,appendHeight,objects)
    local str = ""
    local widthTotal = 0
    local maxHeight = 0
    local flag = false

    local tmpStr = ""
    local textListLenght = #textList
    local lastSpaceIndex = nil
    local initIndex = beginIndex
    
    -- 使用 table.concat 来避免字符串拼接可能导致的编码问题
    local function concatText(startIdx, endIdx)
        local parts = {}
        for i = startIdx, endIdx do
            table.insert(parts, textList[i])
        end
        return table.concat(parts)
    end
    
    for i = beginIndex,textListLenght do
        local curStr = textList[i]
        tmpStr = concatText(initIndex, i)
        -- 使用总量来检测，兼容加粗字体      
        local curWidth, height = self:GetTextSize(tmpStr)

        if curStr == " " then
            lastSpaceIndex = i
        end

        if curStr == "\n" then
            beginIndex = i
            flag = true
            break
        elseif self.richTextItem:CheckWidth(curWidth) then
            str = tmpStr
            widthTotal = curWidth
            local heightTotal = height + appendHeight
            if heightTotal > maxHeight then
                maxHeight = heightTotal
            end

            beginIndex = i
            flag = true
        elseif lastSpaceIndex then
            -- 裁掉空格之后的字符
            str = concatText(initIndex, lastSpaceIndex)
            beginIndex = lastSpaceIndex
            flag = true
            break
        else
            break
        end
    end

    if maxHeight > 0 then
        self.richTextItem:UpdateLineHeight(maxHeight)
    end

    if str ~= "" then
        local obj = self.richTextItem:AddElementObj(self.elementType,widthTotal,maxHeight)
        local layoutElement = obj.gameObject:GetComponent(LayoutElement)
        if not layoutElement then
            layoutElement = obj.gameObject:AddComponent(LayoutElement)
        end
        layoutElement.preferredWidth = widthTotal
        layoutElement.preferredHeight = maxHeight

        table.insert(objects,{obj = obj,str = str})
    end

    if beginIndex < textListLenght or (beginIndex == textListLenght and not flag) then
        self.richTextItem:EnterNewLine()
        self:CreateTextList(textList,flag and beginIndex + 1 or beginIndex,appendHeight,objects)
    end
end

function RichTextElement:ParseData(kvData)
    self.kvData = kvData

    self.bold = kvData.bold
    self.italic = kvData.italic
    self.underline = kvData.underline
    self.strikethrough = kvData.strikethrough
    self:OnParseData(kvData)
end

function RichTextElement:OnParseData(kvData)
    assert(false,"解析富文本元素失败，子类未实现相应解析方法" .. kvData)
end

function RichTextElement:SetLogicElementType(logicElementType)
    self.logicElementType = logicElementType
end

function RichTextElement:SetFontStyle(textComponent)
    local fontStyle = self:GetFontStyle()
    local richTextInfo = self.richTextItem:GetRichTextInfo()

    if richTextInfo.fixedFontStyle then
        fontStyle = fontStyle | RichTextDefine.FontStyles[richTextInfo.fixedFontStyle]
        return
    end
    
    textComponent.fontStyle = fontStyle

    if self.bold or richTextInfo.fixedColor == Color.white then
        local matNode = self.richTextItem.richTextInfo.elementTemplate.matNode
        local mat = RichTextUtils.GetCardTextOutlineMat(matNode)
        textComponent.fontMaterial = mat
    end

    local template = self.richTextItem.richTextInfo.elementTemplate[self.elementType]
    textComponent.fontSize = self.richTextItem.richTextInfo.fontSize or template.textComponent.fontSize
end

function RichTextElement:GetFontStyle()
    local fontStyle = RichTextDefine.FontStyles[FontStyles.Normal] -- Reset font style

    if self.bold then
        fontStyle = fontStyle | RichTextDefine.FontStyles[FontStyles.Bold]
    end

    if self.italic then
        fontStyle = fontStyle | RichTextDefine.FontStyles[FontStyles.Italic]
    end

    if self.underline then
        fontStyle = fontStyle | RichTextDefine.FontStyles[FontStyles.Underline]
    end

    if self.strikethrough then
        fontStyle = fontStyle | RichTextDefine.FontStyles[FontStyles.Strikethrough]
    end

    return fontStyle
end
