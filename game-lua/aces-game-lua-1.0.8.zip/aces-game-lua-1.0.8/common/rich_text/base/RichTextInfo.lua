RichTextInfo = BaseClass("RichTextInfo")

function RichTextInfo:__Init()
    self.content = nil
    --self.fontName = nil
    self.lineSpacing = 0
    self.viewWidth = 0
    --self.viewHeight = 0
    self.elementTemplate = nil
    self.startCorner = RichTextDefine.StartCorner.left_top
    self.parent = nil

    self.paddingTop = 0
    self.paddingBottom = 0
    self.paddingLeft = 0
    self.paddingRight = 0

    -- 对齐方式，默认为左对齐
    self.alignment = RichTextDefine.TextAlignment.left

    self.onClick = nil

    self.toColor = {}

    self.inputData = {}



    self.fixedColor = nil
    self.fixedFontStyle = nil
    self.delLine = nil

    self.fontSize = nil
    
    --kv_data
end

function RichTextInfo:__Delete()

end
