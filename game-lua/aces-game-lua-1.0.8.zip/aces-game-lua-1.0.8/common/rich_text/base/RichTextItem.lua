RichTextItem = BaseClass("RichTextItem")

function RichTextItem:__Init(richTextInfo)
    self.richTextInfo = richTextInfo
    self.elements = nil
    self.gameObject = nil
    self.transform = nil
    self.curLine = 0
    self.curX = 0
    self.curY = 0
    self.curLineHeight = 0

    --每一行的信息
    --{beginY=0,height=0,objs={}}
    self.lineInfos = {}


    self:EnterNewLine()
    self:CreateRoot()
end

function RichTextItem:__Delete()
    if self.elements then
        for _, element in ipairs(self.elements) do
            element:Delete()
        end
        self.elements = nil
    end

    if self.gameObject then
        GameObject.Destroy(self.gameObject)
        self.gameObject = nil
    end

    self.transform = nil
    self.richTextInfo = nil
    self.lineInfos = nil
end

function RichTextItem:CreateRoot()
    local richTextItem = GameObject("rich_text_item")
    local rectTransform = richTextItem:AddComponent(RectTransform)
    richTextItem.transform:SetParent(self.richTextInfo.parent)
    richTextItem.transform:Reset()
    richTextItem.transform:SetSizeDelata(self.richTextInfo.viewWidth,0)
    
    local type = self.richTextInfo.startCorner
    if type == RichTextDefine.StartCorner.left_top then
        rectTransform.pivot = Vector2(0,1)
        rectTransform.anchorMin = Vector2(0,1)
        rectTransform.anchorMax = Vector2(0,1)
        rectTransform:SetAnchoredPosition(self.richTextInfo.paddingLeft,-self.richTextInfo.paddingTop)
    elseif type == RichTextDefine.StartCorner.left_bottom then
        rectTransform.pivot = Vector2(0,0)
        rectTransform.anchorMin = Vector2(0,0)
        rectTransform.anchorMax = Vector2(0,0)
        rectTransform:SetAnchoredPosition(self.richTextInfo.paddingLeft,self.richTextInfo.paddingBottom)
    elseif type == RichTextDefine.StartCorner.right_top then
        rectTransform.pivot = Vector2(1,1)
        rectTransform.anchorMin = Vector2(1,1)
        rectTransform.anchorMax = Vector2(1,1)
        rectTransform:SetAnchoredPosition(-self.richTextInfo.paddingRight,-self.richTextInfo.paddingTop)
    elseif type == RichTextDefine.StartCorner.right_bottom then
        rectTransform.pivot = Vector2(1,0)
        rectTransform.anchorMin = Vector2(1,0)
        rectTransform.anchorMax = Vector2(1,0)
        rectTransform:SetAnchoredPosition(-self.richTextInfo.paddingRight,self.richTextInfo.paddingBottom)
    end

    richTextItem:AddComponent(LayoutElement)

    self.gameObject = richTextItem
    self.transform = self.gameObject.transform
end

function RichTextItem:Create(elements)
    self.elements = elements
    for i,v in ipairs(self.elements) do
        v:OnCreate()
    end

    -- 最后处理每行元素的对齐方式
    self:AdjustLineAlignments()

    self.gameObject:GetComponent(LayoutElement).preferredHeight = self.transform.rect.height
end

-- 添加新方法，统一处理所有行的对齐方式
function RichTextItem:AdjustLineAlignments()
    local alignment = self.richTextInfo.alignment
    if alignment == RichTextDefine.TextAlignment.left then
        -- 左对齐是默认的，不需要调整
        return
    end
    
    -- 遍历每一行，调整该行中所有元素的位置
    for lineIdx, lineInfo in ipairs(self.lineInfos) do
        if #lineInfo.objs > 0 then
            -- 计算该行的总宽度
            local lineWidth = 0
            for _, obj in ipairs(lineInfo.objs) do
                local layoutElement = obj:GetComponent(LayoutElement)
                lineWidth = lineWidth + layoutElement.preferredWidth
            end
            
            -- 计算需要偏移的距离
            local offset = 0
            if alignment == RichTextDefine.TextAlignment.center then
                -- 居中对齐，将整行向右移动(可用宽度-行宽度)/2
                offset = (self.richTextInfo.viewWidth - self.richTextInfo.paddingLeft - self.richTextInfo.paddingRight - lineWidth) / 2
            elseif alignment == RichTextDefine.TextAlignment.right then
                -- 右对齐，将整行向右移动(可用宽度-行宽度)
                offset = self.richTextInfo.viewWidth - self.richTextInfo.paddingLeft - self.richTextInfo.paddingRight - lineWidth
            end
            
            -- 应用偏移
            if offset > 0 then
                for _, obj in ipairs(lineInfo.objs) do
                    local pos = obj.transform.anchoredPosition
                    obj.transform:SetAnchoredPosition(pos.x + offset, pos.y)
                end
            end
        end
    end
end

function RichTextItem:EnterNewLine()
    -- 初始X坐标始终从左边界开始，不受对齐方式影响
    self.curX = self.richTextInfo.paddingLeft
    if self.lineInfos[self.curLine] then
        self.curY = self.curY + self.lineInfos[self.curLine].height + self.richTextInfo.lineSpacing
    end

    self.curLine = self.curLine + 1
    local info = {}
    info.beginY = 0
    info.height = 0
    info.objs = {}
    table.insert(self.lineInfos,info)
end

function RichTextItem:AddElementObj(elementType,width,height)
    local original = self.richTextInfo.elementTemplate[elementType].original
    local object = GameObject.Instantiate(original)
    object.transform:SetParent(self.transform)
    object.transform:Reset()

    object.transform:SetParent(self.transform)

    -- 根据pivot设置位置，anchorMin & anchorMax 永远都是(0,1)
    local x = 0
    if object.transform.pivot.x == 0.5 then
        x = self.curX + width * 0.5
    elseif object.transform.pivot.x == 1 then
        x = self.curX + width
    elseif object.transform.pivot.x == 0 then
        x = self.curX        
    else
        LogError(string.format("elementType:%s pivot.x:%s",elementType,object.transform.pivot.x))
    end

    local y = 0
    if object.transform.pivot.y == 0.5 then
        y = -(self.curY + height * 0.5)
    elseif object.transform.pivot.y == 1 then
        y = -self.curY
    elseif object.transform.pivot.y == 0 then
        y = -(self.curY + height)
    else
        LogError(string.format("elementType:%s pivot.y:%s",elementType,object.transform.pivot.y))
    end

    -- object.transform:SetAnchoredPosition(self.curX + width * 0.5,-(self.curY + height * 0.5))
    object.transform:SetAnchoredPosition(x,y)
    object.transform:SetSizeDelata(width,height)

    local info = self.lineInfos[self.curLine]
    table.insert(info.objs,object)

    self.curX = self.curX + width

    return object
end

function RichTextItem:AddCurX(val)
    self.curX = self.curX + val
end

function RichTextItem:HasElementInCurrentLine()
    local info = self.lineInfos[self.curLine]
    return info and #info.objs > 0 or false
end

function RichTextItem:CheckWidth(width)
    local usableWidth = self.richTextInfo.viewWidth - self.curX - self.richTextInfo.paddingLeft - self.richTextInfo.paddingRight
    return width <= usableWidth
end

function RichTextItem:UpdateLineHeight(height)
    local info = self.lineInfos[self.curLine]
    if height > info.height then
        info.height = height
        self.transform:SetSizeDelata(self.richTextInfo.viewWidth,self.curY + info.height)
    end
end

function RichTextItem:GetLineHeight()
    local info = self.lineInfos[self.curLine]
    return info.height
end

function RichTextItem:GetImageSize(image)
    return image.rect.width, image.rect.height
end

function RichTextItem:GetPreferredHeight()
    return self.gameObject:GetComponent(LayoutElement).preferredHeight 
end

function RichTextItem:GetRichTextInfo()
    return self.richTextInfo
end
