SdkManager = SingleClass("SdkManager")

local function IsSteamChannel()
    return BaseSetting.channel == LoginDefine.ChannelName.steam
        or BaseSetting.channel == LoginDefine.ChannelName.steamrelease
        or BaseSetting.channel == LoginDefine.ChannelName.steamdemo
end

function SdkManager:__Init( )
    self.sdk = nil
    self.isInitSucceed = false
    self.isTicketSucceed = false
    self.isTicketRequesting = false
    self.onInitResult = nil
    self.onTicketResult = nil
end

function SdkManager:__Delete()
end

function SdkManager:SetInitResult(onInitResult)
    self.onInitResult = onInitResult
end

function SdkManager:InitSdk()
    --根据渠道初始化相应sdk
    if BaseSetting.channel == LoginDefine.ChannelName.steam 
        or BaseSetting.channel == LoginDefine.ChannelName.steamrelease
        or BaseSetting.channel == LoginDefine.ChannelName.steamdemo then
        self.sdk = SteamSdkWrapper.New()
    elseif BaseSetting.channel == LoginDefine.ChannelName.wegame then
        self.sdk = WegameSdkWrapper.New()
    elseif BaseSetting.channel == LoginDefine.ChannelName.stovedemo 
        or BaseSetting.channel == LoginDefine.ChannelName.stoverelease then
        self.sdk = StoveSdkWrapper.New()
    end

    if self.sdk then
        self.isTicketSucceed = false
        self.isTicketRequesting = false
        self.sdk:SetInitResult(self:ToFunc("OnInitDone"))
        self.sdk:OnInitSdk()
    end
end

function SdkManager:HasSdk()
    return self.sdk ~= nil
end

function SdkManager:IsInitSucceed()
    return self.isInitSucceed
end

function SdkManager:IsTicketSucceed()
    return self.isTicketSucceed
end

function SdkManager:SetTicketResult(onTicketResult)
    self.onTicketResult = onTicketResult
end

function SdkManager:RequestTicket()
    assert(self.sdk ~= nil, "SDK 未初始化")
    assert(self.sdk.RequestTicket ~= nil, "当前 SDK 不支持单独请求 Ticket")

    if self.isTicketSucceed then
        self:OnTicketDone(true, 0)
        return
    end

    if self.isTicketRequesting then
        return
    end

    self.isTicketRequesting = true
    self.sdk:SetTicketResult(self:ToFunc("OnTicketDone"))
    self.sdk:RequestTicket()
end

function SdkManager:OnInitDone(flag,num)
    Log("初始化Sdk完成")
    if flag then
        self.isInitSucceed = true
        if not IsSteamChannel() then
            self.isTicketSucceed = true
        end
    end

    if self.onInitResult then
        self.onInitResult(flag,num)
    end
end

function SdkManager:OnTicketDone(flag,num)
    if flag then
        self.isTicketSucceed = true
        self.isTicketRequesting = false
    end

    if self.onTicketResult then
        self.onTicketResult(flag,num)
    end
end

function SdkManager:GetUid()
    return self.sdk:GetUid()
end

function SdkManager:GetToken()
    return self.sdk:GetToken()
end

function SdkManager:SyncLocalAchievements(completedIds)
    if self.sdk and self.sdk.SyncLocalAchievements then
        self.sdk:SyncLocalAchievements(completedIds)
    end
end

function SdkManager:AsyncDirtyWordsFilter(text)
    if self.sdk and self.sdk.AsyncDirtyWordsFilter then
        self.sdk:AsyncDirtyWordsFilter(text)
    else
        EventManager.Instance:SendEvent(EventDefine.dirty_words_filter_done,{text = text,result = true,output = text })
    end
end
