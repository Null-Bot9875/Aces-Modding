SdkWrapperBase = BaseClass("SdkWrapperBase")

function SdkWrapperBase:__Init( )
    self.onInitResult = nil
end

function SdkWrapperBase:__Delete()
end

function SdkWrapperBase:SetInitResult(onInitResult)
    self.onInitResult = onInitResult
end

function SdkWrapperBase:InitDone(flag,num)
    if self.onInitResult then
        self.onInitResult(flag,num)
    end
end

function SdkWrapperBase:OnInitSdk()
end
function SdkWrapperBase:GetToken()
    return nil
end
function SdkWrapperBase:GetUid()
    return nil
end

