SteamSdkWrapper = BaseClass("SteamSdkWrapper",SdkWrapperBase)

local function HasLocalLaunchArg()
    local args = CS.System.Environment.GetCommandLineArgs()
    for index = 0, args.Length - 1 do
        if tostring(args[index]) == "-local" then
            return true
        end
    end
    return false
end

function SteamSdkWrapper:__Init( )
    self.ticketCallback = self:ToFunc("OnTicketCallback")
    self.statsReadyCallback = self:ToFunc("OnStatsReadyCallback")
    self.statsStoredCallback = self:ToFunc("OnStatsStoredCallback")
    self.ticket = nil
    self.ticketBase64  = nil
    self.ticketErrorNum = 0
    self.onTicketResult = nil
    self.localRoleReady = false
    self.statsRequested = false
    self.storeRetryRequired = false
    self.localAchievements = {}
    self.lastStoreAchievements = {}
end

function SteamSdkWrapper:__Delete()
end

function SteamSdkWrapper:OnInitSdk()
    SteamSdkProxy.InitSdk()
    SteamSdkProxy.Instance:SetTicketCallback(self,"ticketCallback")
    SteamSdkProxy.Instance:SetAchievementCallbacks(self, "statsReadyCallback", "statsStoredCallback")

    if SteamSdkProxy.Instance:IsInitialized() then
        self.ticketErrorNum = 1
        self:InitDone(true,self.ticketErrorNum)
        self:EnsureStatsRequest()
    else
        self:InitDone(false,self.ticketErrorNum)
    end
end

function SteamSdkWrapper:IsLocalAchievementEligible()
    return BaseSetting.channel == LoginDefine.ChannelName.steamrelease
        and HasLocalLaunchArg()
        and LocalServerMode
        and LocalServerMode.Instance
        and LocalServerMode.Instance:IsLocalMode()
end

function SteamSdkWrapper:EnsureStatsRequest()
    if self.statsRequested or not self:IsLocalAchievementEligible() then
        return
    end

    self.statsRequested = SteamSdkProxy.Instance:RequestCurrentStats()
    if not self.statsRequested then
        LogErrorf("Steam成就 stats 请求失败[appId:%s]", SteamSdkProxy.Instance:GetAppID())
    end
end

function SteamSdkWrapper:SyncLocalAchievements(completedIds)
    if not self:IsLocalAchievementEligible() then
        return
    end

    self.localRoleReady = true
    self.localAchievements = {}
    for _, achievementId in ipairs(completedIds or {}) do
        local conf = Config.Get("steam_achievements_def", "config", "id", achievementId)
        local key = conf and conf.key or ""
        if key == "" then
            LogErrorf("Steam成就 key 无效[id:%s][key:%s][appId:%s]",
                tostring(achievementId), tostring(key), SteamSdkProxy.Instance:GetAppID())
        else
            self.localAchievements[#self.localAchievements + 1] = {
                id = achievementId,
                key = key,
            }
        end
    end

    self:EnsureStatsRequest()
    self:TrySyncLocalAchievements()
end

function SteamSdkWrapper:OnStatsReadyCallback(success, result)
    if not success then
        self.statsRequested = false
        LogErrorf("Steam成就 stats 获取失败[result:%s][appId:%s]",
            tostring(result), SteamSdkProxy.Instance:GetAppID())
        return
    end
    self:TrySyncLocalAchievements()
end

function SteamSdkWrapper:TrySyncLocalAchievements()
    if not self.localRoleReady or not SteamSdkProxy.Instance:IsStatsReady() then
        return
    end

    local missingAchievements = {}
    for _, achievement in ipairs(self.localAchievements) do
        local state = SteamSdkProxy.Instance:GetAchievementState(achievement.key)
        if state < 0 then
            self:LogAchievementError("查询失败", achievement)
        elseif state == 0 then
            if SteamSdkProxy.Instance:SetAchievement(achievement.key) then
                missingAchievements[#missingAchievements + 1] = achievement
            else
                self:LogAchievementError("设置失败", achievement)
            end
        end
    end

    if #missingAchievements == 0 and not self.storeRetryRequired then
        return
    end

    self.lastStoreAchievements = #missingAchievements > 0 and missingAchievements or self.localAchievements
    if not SteamSdkProxy.Instance:StoreStats() then
        self.storeRetryRequired = true
        self:LogStoreErrors("提交调用失败")
        self.lastStoreAchievements = {}
    end
end

function SteamSdkWrapper:OnStatsStoredCallback(success, result)
    if not success then
        self.storeRetryRequired = true
        self:LogStoreErrors("提交回调失败 result=" .. tostring(result))
    else
        self.storeRetryRequired = false
    end
    self.lastStoreAchievements = {}
end

function SteamSdkWrapper:LogAchievementError(reason, achievement)
    LogErrorf("Steam成就%s[id:%s][key:%s][appId:%s]", reason,
        tostring(achievement.id), tostring(achievement.key), SteamSdkProxy.Instance:GetAppID())
end

function SteamSdkWrapper:LogStoreErrors(reason)
    for _, achievement in ipairs(self.lastStoreAchievements) do
        self:LogAchievementError(reason, achievement)
    end
end

function SteamSdkWrapper:RequestTicket()
    assert(SteamSdkProxy.Instance:IsInitialized(), "Steam SDK 未初始化完成")
    SteamSdkProxy.Instance:GetTicket()
end

function SteamSdkWrapper:SetTicketResult(onTicketResult)
    self.onTicketResult = onTicketResult
end

function SteamSdkWrapper:TicketDone(flag,num)
    if self.onTicketResult then
        self.onTicketResult(flag,num)
    end
end

function SteamSdkWrapper:OnTicketCallback(result,ticket,ticketBase64,error)
    Log("获取Ticket信息",result,ticket,error)
    if result == 1 and error == "" then
        self.ticket = ticket
        self.ticketBase64 = ticketBase64
        self:TicketDone(true,self.ticketErrorNum)
    else
        self:TicketDone(false,self.ticketErrorNum)
        self.ticketErrorNum = self.ticketErrorNum + 1
        SteamSdkProxy.Instance:GetTicket()
        LogInfof("Steam票据获取失败[result:%s][error:%s]",result,error)
    end
end

function SteamSdkWrapper:GetToken()
    return self.ticketBase64
end

function SteamSdkWrapper:GetUid()
    return SteamSdkProxy.Instance:GetSteamID()
end
