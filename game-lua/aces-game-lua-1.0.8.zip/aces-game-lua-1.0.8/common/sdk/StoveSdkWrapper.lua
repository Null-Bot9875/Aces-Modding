StoveSdkWrapper = BaseClass("StoveSdkWrapper",SdkWrapperBase)

function StoveSdkWrapper:__Init()
    self.ticketCallback = self:ToFunc("OnTicketCallback")
    self.initCallback = self:ToFunc("OnInitCallback")
    
    self.stoveUserId = nil
    self.sessionTicket = nil
    self.ticketErrorNum = 0
end

function StoveSdkWrapper:__Delete()
end

function StoveSdkWrapper:OnInitSdk()
    -- 设置回调
    StoveSdkProxy.Instance:SetInitCallback(self,"initCallback")
    StoveSdkProxy.Instance:SetTicketCallback(self,"ticketCallback")
    
    -- 启动异步初始化
    StoveSdkProxy.InitSdk()
end

function StoveSdkWrapper:OnInitCallback(success)
    Log("Stove SDK初始化回调", tostring(success))
    if success then
        self.ticketErrorNum = 1
        StoveSdkProxy.Instance:GetTicket()
    else
        self:InitDone(false, self.ticketErrorNum)
    end
end

function StoveSdkWrapper:OnTicketCallback(result, stoveUserId, sessionTicket)
    Log("获取Stove Ticket信息", result, stoveUserId, sessionTicket)
    if result == 0 then
        self.stoveUserId = stoveUserId
        self.sessionTicket = sessionTicket
        self:InitDone(true,self.ticketErrorNum)
    else
        self:InitDone(false,self.ticketErrorNum)
        self.ticketErrorNum = self.ticketErrorNum + 1
        StoveSdkProxy.Instance:GetTicket()
        Log("Stove票据获取失败[result:%s]", result)
    end
end

function StoveSdkWrapper:GetToken()
    return self.sessionTicket
end

function StoveSdkWrapper:GetUid()
    return self.stoveUserId
end
