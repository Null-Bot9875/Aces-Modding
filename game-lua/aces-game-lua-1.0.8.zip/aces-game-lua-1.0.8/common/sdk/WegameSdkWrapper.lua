WegameSdkWrapper = BaseClass("WegameSdkWrapper",SdkWrapperBase)


function WegameSdkWrapper:__Init()
    self.ticketCallback = self:ToFunc("OnTicketCallback")
    self.dirtyWordsFilterCallback = self:ToFunc("OnDirtyWordsFilterCallback")

    self.railId = nil
    self.sessionTicket  = nil
    self.ticketErrorNum = 0
end

function WegameSdkWrapper:__Delete()
end

function WegameSdkWrapper:OnInitSdk()
    WegameSdkProxy.InitSdk()
    WegameSdkProxy.Instance:SetTicketCallback(self,"ticketCallback")
    WegameSdkProxy.Instance:SetDirtyWordsFilterCallback(self,"dirtyWordsFilterCallback")
    if WegameSdkProxy.Instance:IsInitialized() then
        self.ticketErrorNum = 1
        WegameSdkProxy.Instance:GetTicket()
    else
        self:InitDone(false,self.ticketErrorNum)
    end
end

function WegameSdkWrapper:OnTicketCallback(result,railId,sessionTicket)
    Log("获取Ticket信息",result,railId,sessionTicket)
    if result == 0 then --成功
        self.railId = railId
        self.sessionTicket = sessionTicket
        self:InitDone(true,self.ticketErrorNum)
    else
        self:InitDone(false,self.ticketErrorNum)
        self.ticketErrorNum = self.ticketErrorNum + 1
        WegameSdkProxy.Instance:GetTicket()
        LogInfof("wegame票据获取失败[result:%s]",result)
    end
end

function WegameSdkWrapper:OnDirtyWordsFilterCallback(hasDirtyWords,output,source)
    Log(string.format("脏词过滤[hasDirtyWords:%s][output:%s][source:%s]",hasDirtyWords,output,source))
    EventManager.Instance:SendEvent(EventDefine.dirty_words_filter_done,{text = source,hasDirtyWords = hasDirtyWords,output = output})
end

function WegameSdkWrapper:AsyncDirtyWordsFilter(text)
    if text == "" then
        EventManager.Instance:SendEvent(EventDefine.dirty_words_filter_done,{text = text,hasDirtyWords = false,output = text})
        return
    end
    
    WegameSdkProxy.Instance:AsyncDirtyWordsFilter(text,true,text)
end

function WegameSdkWrapper:GetToken()
    return self.sessionTicket
end

function WegameSdkWrapper:GetUid()
   return self.railId
end
