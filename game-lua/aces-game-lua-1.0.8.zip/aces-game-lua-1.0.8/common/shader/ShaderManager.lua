ShaderManager = SingleClass("ShaderManager")

function ShaderManager:__Init( )
    EventManager.Instance:AddEvent(EventDefine.preload_complete,self:ToFunc("OnPreloadComplete"))
    self.assetScope = AssetScope()
    self.shaderLoader = nil
    self.shaders = {}
end

function ShaderManager:__Delete()
    EventManager.Instance:RemoveEvent(EventDefine.preload_complete,self:ToFunc("OnPreloadComplete"))
    self:RemoveLoader()
    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end


function ShaderManager:OnPreloadComplete()
    local shaders = {}
    --table.insert(shaders,{file = "shader/ui/outline_ex.shader", type = AssetType.Object} )
    -- table.insert(shaders,{file = "shader/vertexlitfastcutout.shader", type = AssetType.Object} )
    -- table.insert(shaders,{file = "shader/fastmatcap.shader", type = AssetType.Object} )
    --table.insert(shaders,{file = "shader/SYPackages/character/character_lit.shader", type = AssetType.Object} )
    --table.insert(shaders,{file = "shader/SYPackages/ShadersCache/Charactors/Toon/Toon_Lit.shader", type = AssetType.Object} )

    table.insert(shaders,{file = "shader/ui/GRenderShader.shader", type = AssetType.Object} )
    table.insert(shaders,{file = "shader/nilo_toon_urp/Shaders/NiloToonCharacter.shader", type = AssetType.Object} )
    self.shaderLoader = AssetBatchLoader.New(self.assetScope)
    self.shaderLoader:Load(shaders,self:ToFunc("OnShaderComplete"))
end

function ShaderManager:OnShaderComplete()
    local shader = self.shaderLoader:GetAsset("shader/ui/GRenderShader.shader")
    self.shaders["GRenderShader"] = shader

    local shader = self.shaderLoader:GetAsset("shader/nilo_toon_urp/Shaders/NiloToonCharacter.shader")

    --local _ = self.shaderLoader:GetAsset("shader/SYPackages/ShadersCache/Charactors/Toon/Toon_Lit.shader")

    -- self.vertexlitfastcutout = self.shaderLoader:GetAsset("shader/vertexlitfastcutout.shader")

    -- self.unitShader = self.shaderLoader:GetAsset("shader/fastmatcap.shader")

    -- self.heroShader = self.shaderLoader:GetAsset("shader/nprshading/shader/standardnpr.shader")
    
    self:RemoveLoader()
end

function ShaderManager:GetShader(name)
    return self.shaders[name]
end

function ShaderManager:RemoveLoader()
    if self.shaderLoader then
        self.shaderLoader:Destroy()
        self.shaderLoader = nil
    end
end
