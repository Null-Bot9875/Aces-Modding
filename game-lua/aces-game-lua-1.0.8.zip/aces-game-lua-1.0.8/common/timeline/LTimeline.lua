LTimeline = BaseClass("LTimeline", SECBBase)

function LTimeline:__Init()
    self.lockUid = 0
    self.lockNum = 0
    self.lockInfos = {}

    self.runIndex = 0
    self.isFinish = true

    self.rate = 10000


    self.length = 0

    self.duration = nil

    self.onComplete = nil

    self.nodes = nil
    self.waitRunNodes = SECBList.New()
    self.runNodes = SECBList.New()
    self.uidToIndexs = {}
    self.completeNum = 0

    -- 记录已启动的节点
    self.startedNodesMap = {}
end

function LTimeline:__Delete()
    if self.nodes then
        for _, v in ipairs(self.nodes) do
            v.behavior:Delete()
        end
    end

    self.startedNodesMap = {}
end

function LTimeline:SetNodes(nodes)
    self.nodes = nodes
    self.length = #nodes

    if self.length <= 0 then
        return
    end

    self.waitRunNodes:Push({ node = nodes[1], startTime = 0, runTime = 0 }, nodes[1].behavior.uid)
    self.uidToIndexs[nodes[1].behavior.uid] = 1
    for i = 2, self.length do
        self.uidToIndexs[nodes[i].behavior.uid] = i
        if nodes[i].time ~= -1 then
            self.waitRunNodes:Push({ node = nodes[i], startTime = 0, runTime = 0 }, nodes[i].behavior.uid)
        end
    end
end

function LTimeline:Init(...)
    self:OnInit(...)
end

function LTimeline:IsFinish()
    return self.isFinish
end

function LTimeline:SetRate(rate)
    self.rate = rate
end

function LTimeline:Start(...)
    self.runIndex = 1
    self.rate = 10000
    self.isFinish = false

    self:OnStart(...)

    self:Update(0)

    if self.length <= 0 then
        self:CheckFinish()
    end
end

function LTimeline:Update(deltaTime)
    if self.isFinish then
        return
    end


    for iter in self.runNodes:Items() do
        local nodeInfo = iter.value
        nodeInfo.runTime = nodeInfo.runTime + deltaTime
        nodeInfo.node.behavior:Update(deltaTime)
    end

    -- 防止 runNodes 循环中 behavior 同步完成导致 timeline 被删除
    if self.isFinish then
        return
    end

    for iter in self.waitRunNodes:Items() do
        local nodeInfo = iter.value
        nodeInfo.startTime = nodeInfo.startTime + deltaTime
        if nodeInfo.startTime >= nodeInfo.node.time then
            self.waitRunNodes:RemoveByIndex(nodeInfo.node.behavior.uid)
            self:AddRunNode(nodeInfo)
        end
    end
end

function LTimeline:AddRunNode(nodeInfo)
    if self.startedNodesMap[nodeInfo.node.behavior.uid] then
        return
    end

    self.runNodes:Push(nodeInfo, nodeInfo.node.behavior.uid)
    nodeInfo.node.behavior:SetComplete(self:ToFunc("BehaviorComplete"))
    nodeInfo.node.behavior:Start()
    nodeInfo.node.behavior:Update(0)
    self.startedNodesMap[nodeInfo.node.behavior.uid] = true
end

function LTimeline:BehaviorComplete(behavior)
    local uid = behavior.uid

    self.completeNum = self.completeNum + 1

    self.runNodes:RemoveByIndex(uid)

    local index = self.uidToIndexs[uid]
    -- if self.nodes[index + 1] and self.nodes[index + 1].time == -1 then
    --     self:AddRunNode({ node = self.nodes[index + 1], startTime = 0, runTime = 0 })
    -- else
    --     self:CheckFinish()
    -- end

    -- 行为完成后：
    -- 1) 启动后续所有 time = -1 节点（保持原有串行含义）
    local nextIndex = index + 1
    local nextNode = self.nodes[nextIndex]
    if nextNode and nextNode.time == -1 then
        local function StartNode(node)
            local nuid = node.behavior.uid
            if self.runNodes:ExistIndex(nuid) or self.waitRunNodes:ExistIndex(nuid) or self.startedNodesMap[nuid] then
                return
            end
            
            self:AddRunNode({ node = node, startTime = 0, runTime = 0 })
        end

        local list = {}
        for i = nextIndex, self.length do
            local node = self.nodes[i]
            if node and node.time == -1 then
                table.insert(list, node)
            end
        end

        for _, node in ipairs(list) do
            StartNode(node)
        end
    else
        self:CheckFinish()
    end
end

function LTimeline:SetComplete(onComplete)
    self.onComplete = onComplete
end

function LTimeline:Lock()
    self.lockUid = self.lockUid + 1
    self.lockNum = self.lockNum + 1
    self.lockInfos[self.lockUid] = {} --可记录堆栈信息
    return self.lockUid
end

function LTimeline:Unlock(lockUid)
    if self.lockInfos[lockUid] then
        self.lockNum = self.lockNum - 1
        self.lockInfos[lockUid] = nil
        self:CheckFinish()
    end
end

function LTimeline:CheckFinish()
    if not self.isFinish
        and self.completeNum >= self.length
        and self.lockNum <= 0 then
        self.isFinish = true
        if self.onComplete then
            self.onComplete()
        end
        self:OnFinish()
    end
end

function LTimeline:SetDuration(duration)
    self.duration = duration
end

function LTimeline:Abort()
    self.isFinish = true
    self:OnAbort()
end

function LTimeline:OnInit(...)
end

function LTimeline:OnStart()
end

function LTimeline:OnAbort()
end

function LTimeline:OnFinish()
end
