-- Lua reference-path scanner for xLua managed-shell leak diagnosis.
-- Pairs with XLua.XLuaLeakTool (C# side) to resolve userdata -> pool id,
-- then walks _G + debug registry to record every path that pins a cs object.
--
-- Usage from Lua (GM console / F10):
--   MMLeakTool.Instance:TakeSnapshot("before_battle")
--   -- play battle, exit to login
--   MMLeakTool.Instance:TakeSnapshot("after_battle")
--   MMLeakTool.Instance:DumpDiff("before_battle","after_battle")

MMLeakTool = SingleClass("MMLeakTool")

-- Globals that must NOT be walked (builtin, bootmap, known-weak or tool-owned).
local SKIP_GLOBAL = {
    string=1, table=1, math=1, io=1, os=1, debug=1, coroutine=1,
    package=1, _G=1, _VERSION=1, arg=1,
    jit=1, bit=1, tolua=1, xlua=1,
    CS=1, UnityEngine=1,
    ClassToFile=1, FileToClass=1, ModuleMapping=1, ClassToModule=1,
    DataToFile=1, CJson=1,
    ["_LOADED"]=1, ["_PRELOAD"]=1, ["_ENV"]=1,
    MMLeakTool=1,
    DebugFightClassClear=1, DebugFightClassCreate=1,
}

-- Registry entries to skip (_LOADED is redundant with _G; xlua caches are weak).
local SKIP_REGISTRY_KEY = {
    _LOADED=1, _PRELOAD=1,
}

local MAX_PATHS_PER_ID = 3
local MAX_PATH_LEN     = 1000
local MAX_NODES        = 500000    -- safety cap: stop walking after N nodes
local PROGRESS_EVERY   = 50000     -- log every N nodes
local WALK_REGISTRY    = false     -- walking registry drags in main thread / unsafe
local WALK_THREADS     = false     -- walking coroutine stacks is risky in editor

local function escapeKey(k)
    local t = type(k)
    if t == "string" then
        if string.match(k, "^[%a_][%w_]*$") then
            return "." .. k
        end
        return string.format("[%q]", k)
    end
    if t == "number" or t == "boolean" then
        return "[" .. tostring(k) .. "]"
    end
    return "[<" .. t .. ">]"
end

local function extendPath(path, seg)
    if #path + #seg > MAX_PATH_LEN then
        return path .. "..<truncated>"
    end
    return path .. seg
end

local function isWeak(t)
    local mt = getmetatable(t)
    if type(mt) ~= "table" then return false end
    local mode = rawget(mt, "__mode")
    return type(mode) == "string" and mode ~= ""
end

function MMLeakTool:__Init()
    self._snapshots = {}
    self._skipGc = false
end

function MMLeakTool:SetSkipGC(skip)
    self._skipGc = skip and true or false
    Log("[MMLeakTool] skipGC = " .. tostring(self._skipGc))
end

function MMLeakTool:_ensureCS()
    if self._inited then return true end
    local ok, tool = pcall(function() return CS.XLua.XLuaLeakTool end)
    if not ok or tool == nil then
        LogError("[MMLeakTool] CS.XLua.XLuaLeakTool 未编译到工程中")
        return false
    end
    self._tool = tool
    local env = CS.LuaManager.Instance.LuaEnv
    tool.Init(env)
    self._inited = true
    return true
end

-- Walk from all roots; for every userdata encountered, query its pool id and
-- record a path. Returns { ids = set(id->true), pathsById = {id -> {str,...}} }.
function MMLeakTool:_scan()
    if not self:_ensureCS() then return nil end

    local tool = self._tool
    local visited = {}
    local pathsById = {}
    local idSet = {}
    local nodesWalked = 0
    local truncated = false

    local stack = {}
    -- Mark visited at push time so multiple refs don't bloat the stack.
    -- Only tables/functions/threads are de-duped; userdata path recording is
    -- idempotent per-id (we let it hit every path).
    local function push(node, path)
        local tn = type(node)
        if tn == "table" or tn == "function" or tn == "thread" then
            if visited[node] then return end
            visited[node] = true
            if tn == "table" and isWeak(node) then return end
        end
        stack[#stack + 1] = node
        stack[#stack + 1] = path
    end

    -- Root 1: _G (skip filtered names)
    for k, v in pairs(_G) do
        if type(k) == "string" and SKIP_GLOBAL[k] == nil then
            push(v, "_G" .. escapeKey(k))
        end
    end

    -- Root 2: debug registry (OFF by default — registry[1] is the main coroutine
    -- and walking its live stack can hang the editor).
    if WALK_REGISTRY then
        local reg = debug.getregistry()
        if type(reg) == "table" and not visited[reg] then
            visited[reg] = true
            if not isWeak(reg) then
                for k, v in pairs(reg) do
                    local skip = false
                    if type(k) == "string" and SKIP_REGISTRY_KEY[k] then skip = true end
                    -- skip the main-thread entry and any thread at top level
                    if type(v) == "thread" then skip = true end
                    if not skip then
                        push(v, "registry" .. escapeKey(k))
                    end
                end
            end
        end
    end

    local function recordUserdata(ud, path)
        local id = tool.GetIdOfObject(ud)
        if id == nil or id < 0 then return end
        idSet[id] = true
        local list = pathsById[id]
        if list == nil then
            list = {}
            pathsById[id] = list
        end
        if #list < MAX_PATHS_PER_ID then
            list[#list + 1] = path
        end
    end

    while #stack > 0 do
        local path = stack[#stack]; stack[#stack] = nil
        local node = stack[#stack]; stack[#stack] = nil

        nodesWalked = nodesWalked + 1
        if nodesWalked > MAX_NODES then
            truncated = true
            break
        end
        if nodesWalked % PROGRESS_EVERY == 0 then
            Log(string.format("[MMLeakTool] scanning... nodes=%d stack=%d",
                nodesWalked, #stack / 2))
        end

        local t = type(node)
        if t == "userdata" then
            recordUserdata(node, path)
        elseif t == "table" then
            -- already visited/filtered by push(); just walk body
            for k, v in pairs(node) do
                local seg = escapeKey(k)
                local tv = type(v)
                if tv == "userdata" then
                    recordUserdata(v, path .. seg)
                elseif tv == "table" or tv == "function" or tv == "thread" then
                    push(v, extendPath(path, seg))
                end
                local tk = type(k)
                if tk == "userdata" then
                    recordUserdata(k, path .. "<key>")
                elseif tk == "table" or tk == "function" then
                    push(k, extendPath(path, "<key>"))
                end
            end
            -- follow metatable __index (critical for proxies like `mod`)
            local mt = getmetatable(node)
            if type(mt) == "table" then
                local idx = rawget(mt, "__index")
                if type(idx) == "table" then
                    push(idx, extendPath(path, "<mt.__index>"))
                elseif type(idx) == "function" then
                    push(idx, extendPath(path, "<mt.__index-fn>"))
                end
            end
        elseif t == "function" then
            local i = 1
            while true do
                local name, val = debug.getupvalue(node, i)
                if name == nil then break end
                local seg = "{upvalue '" .. name .. "'}"
                local tv = type(val)
                if tv == "userdata" then
                    recordUserdata(val, path .. seg)
                elseif tv == "table" or tv == "function" or tv == "thread" then
                    push(val, extendPath(path, seg))
                end
                i = i + 1
            end
        elseif t == "thread" then
            -- Walking coroutine stacks is skipped by default: the main thread
            -- is *running*, and debug.getlocal on it can hang the editor. Set
            -- WALK_THREADS = true at your own risk.
            if WALK_THREADS then
                local ok, err = pcall(function()
                    for level = 0, 16 do
                        local info = debug.getinfo(node, level, "f")
                        if info == nil then break end
                        local i = 1
                        while true do
                            local name, val = debug.getlocal(node, level, i)
                            if name == nil then break end
                            local seg = string.format("{thread L%d '%s'}", level, name)
                            local tv = type(val)
                            if tv == "userdata" then
                                recordUserdata(val, path .. seg)
                            elseif tv == "table" or tv == "function" then
                                push(val, extendPath(path, seg))
                            end
                            i = i + 1
                        end
                    end
                end)
                if not ok then
                    Log("[MMLeakTool] skip thread: " .. tostring(err))
                end
            end
        end
    end

    return {
        ids = idSet,
        pathsById = pathsById,
        nodesWalked = nodesWalked,
        truncated = truncated,
    }
end

-- TakeSnapshot: force GC, query C# pool, run Lua walker, tag destroyed shells.
-- Stored under self._snapshots[name].
function MMLeakTool:TakeSnapshot(name)
    if not self:_ensureCS() then return nil end
    local tool = self._tool

    local t0 = os.clock()
    if self._skipGc then
        tool.LuaGC()
    else
        tool.FullGC()
    end
    local t1 = os.clock()
    Log(string.format("[MMLeakTool] GC phase: %.2fs", t1 - t0))

    local walk = self:_scan()
    if walk == nil then return nil end
    local t2 = os.clock()
    Log(string.format("[MMLeakTool] scan phase: %.2fs (nodes=%d)",
        t2 - t1, walk.nodesWalked))

    local csIds = tool.GetAliveObjectIds()
    local typeById = {}
    local destroyedById = {}
    local isUnityById = {}
    -- csIds is a CS int[]. Index via .Length / [i].
    local count = csIds.Length or #csIds
    for i = 0, count - 1 do
        local id = csIds[i]
        typeById[id] = tool.GetTypeNameById(id)
        destroyedById[id] = tool.IsUnityObjectDestroyedById(id)
        isUnityById[id] = tool.IsUnityObjectById(id)
    end
    local t3 = os.clock()
    Log(string.format("[MMLeakTool] cs-enumerate phase: %.2fs (ids=%d)",
        t3 - t2, count))

    local snap = {
        name = name,
        time = os.time(),
        poolCapacity = tool.PoolCapacity(),
        aliveCount = tool.AliveCount(),
        delegateBridges = tool.DelegateBridgeAliveCount(),
        typeById = typeById,
        destroyedById = destroyedById,
        isUnityById = isUnityById,
        pathsById = walk.pathsById,
        reachedIds = walk.ids,
        nodesWalked = walk.nodesWalked,
        truncated = walk.truncated,
        summary = tool.SummarizeAlive(30),
    }
    self._snapshots[name] = snap

    Log(string.format(
        "[MMLeakTool] snapshot '%s': alive=%d cap=%d delegates=%d lua-nodes=%d%s",
        name, snap.aliveCount, snap.poolCapacity, snap.delegateBridges,
        snap.nodesWalked, snap.truncated and " (TRUNCATED)" or ""))
    return snap
end

function MMLeakTool:GetSnapshot(name)
    return self._snapshots[name]
end

function MMLeakTool:ClearSnapshot(name)
    if name == nil then
        self._snapshots = {}
    else
        self._snapshots[name] = nil
    end
end

-- Diff: ids present in 'after' but not in 'before'. Groups by type, flags
-- destroyed shells, and includes recorded paths.
function MMLeakTool:_diff(beforeName, afterName)
    local before = self._snapshots[beforeName]
    local after  = self._snapshots[afterName]
    if before == nil then
        LogError("[MMLeakTool] 未找到快照: " .. tostring(beforeName))
        return nil
    end
    if after == nil then
        LogError("[MMLeakTool] 未找到快照: " .. tostring(afterName))
        return nil
    end

    local leaked = {}          -- id -> true
    local byType = {}          -- typeName -> { total, destroyed, ids = {..} }
    for id in pairs(after.reachedIds or {}) do
        if not (before.reachedIds and before.reachedIds[id]) then
            leaked[id] = true
            local tn = after.typeById[id] or "<unknown>"
            local row = byType[tn]
            if row == nil then
                row = { total = 0, destroyed = 0, ids = {} }
                byType[tn] = row
            end
            row.total = row.total + 1
            if after.destroyedById[id] then row.destroyed = row.destroyed + 1 end
            if #row.ids < 20 then row.ids[#row.ids + 1] = id end
        end
    end

    -- Also report c# pool ids that exist in after-pool but were not reachable
    -- from Lua walk — those are "orphans" (cs holding, lua unreachable: not our
    -- leak) OR hidden behind weak/skipped roots (missed by walker).
    local csOnlyLeaked = {}
    for id in pairs(after.typeById) do
        if not (before.typeById[id]) and not after.reachedIds[id] then
            csOnlyLeaked[#csOnlyLeaked + 1] = id
        end
    end

    return {
        before = before,
        after = after,
        leakedIds = leaked,
        byType = byType,
        csOnlyLeaked = csOnlyLeaked,
    }
end

-- Format diff as a report string.
function MMLeakTool:FormatDiff(beforeName, afterName)
    local d = self:_diff(beforeName, afterName)
    if d == nil then return "" end

    local before, after = d.before, d.after
    local sb = {}
    local function w(s) sb[#sb + 1] = s end

    w(string.format("==== MMLeakTool Diff '%s' -> '%s' ====\n", beforeName, afterName))
    w(string.format("before: alive=%d cap=%d delegates=%d (nodes=%d%s)\n",
        before.aliveCount, before.poolCapacity, before.delegateBridges,
        before.nodesWalked, before.truncated and "+trunc" or ""))
    w(string.format("after : alive=%d cap=%d delegates=%d (nodes=%d%s)\n",
        after.aliveCount, after.poolCapacity, after.delegateBridges,
        after.nodesWalked, after.truncated and "+trunc" or ""))

    -- sort types by destroyed desc then total desc
    local rows = {}
    for tn, row in pairs(d.byType) do
        rows[#rows + 1] = { name = tn, total = row.total, destroyed = row.destroyed, ids = row.ids }
    end
    table.sort(rows, function(a, b)
        if a.destroyed ~= b.destroyed then return a.destroyed > b.destroyed end
        if a.total ~= b.total then return a.total > b.total end
        return a.name < b.name
    end)

    local grandTotal, grandDestroyed = 0, 0
    for _, r in ipairs(rows) do
        grandTotal = grandTotal + r.total
        grandDestroyed = grandDestroyed + r.destroyed
    end

    w(string.format("\n[Lua-pinned leaked objects] total=%d destroyed_shells=%d\n",
        grandTotal, grandDestroyed))

    for _, r in ipairs(rows) do
        w(string.format("\n--- %s   total=%d destroyed_shells=%d\n",
            r.name, r.total, r.destroyed))
        local samples = 0
        for _, id in ipairs(r.ids) do
            local dFlag = after.destroyedById[id] and " [DESTROYED]" or ""
            w(string.format("  id=%d%s\n", id, dFlag))
            local paths = after.pathsById[id]
            if paths then
                for i = 1, #paths do
                    w("    " .. paths[i] .. "\n")
                end
            else
                w("    (no path recorded)\n")
            end
            samples = samples + 1
            if samples >= 10 then
                if #r.ids > 10 then
                    w(string.format("  ... (%d more ids)\n", #r.ids - 10))
                end
                break
            end
        end
    end

    if #d.csOnlyLeaked > 0 then
        w(string.format("\n[C#-only leaked (not reachable from Lua walk)] count=%d\n",
            #d.csOnlyLeaked))
        local shown = 0
        for _, id in ipairs(d.csOnlyLeaked) do
            w(string.format("  id=%d type=%s%s\n", id,
                after.typeById[id] or "<?>",
                after.destroyedById[id] and " [DESTROYED]" or ""))
            shown = shown + 1
            if shown >= 50 then
                w(string.format("  ... (%d more)\n", #d.csOnlyLeaked - 50))
                break
            end
        end
    end

    w("\n[After-snapshot type summary]\n")
    w(after.summary or "")

    return table.concat(sb)
end

-- Dump a diff report to desktop /游戏日志/mm_leak/.
function MMLeakTool:DumpDiff(beforeName, afterName, filePath)
    local report = self:FormatDiff(beforeName, afterName)
    if report == "" then return nil end

    local file = filePath
    if file == nil then
        local folder = CS.System.Environment.GetFolderPath(
            CS.System.Environment.SpecialFolder.DesktopDirectory) .. "/游戏日志/mm_leak/"
        local fileName = CS.System.DateTime.Now:ToString("yyyyMMddHHmmss") ..
            "_" .. tostring(beforeName) .. "_vs_" .. tostring(afterName) .. ".log"
        file = folder .. fileName
    end
    IOUtils.CreateFolderByFile(file)
    IOUtils.WriteAllText(file, report)
    Log("[MMLeakTool] 内存泄漏报告已写出: " .. file)
    return file
end

-- Dump full snapshot (not a diff) for one-off inspection.
function MMLeakTool:DumpSnapshot(name, filePath)
    local snap = self._snapshots[name]
    if snap == nil then
        LogError("[MMLeakTool] 未找到快照: " .. tostring(name))
        return nil
    end
    local sb = {}
    sb[#sb + 1] = string.format("==== MMLeakTool Snapshot '%s' ====\n", name)
    sb[#sb + 1] = string.format("alive=%d cap=%d delegates=%d nodes=%d%s\n\n",
        snap.aliveCount, snap.poolCapacity, snap.delegateBridges,
        snap.nodesWalked, snap.truncated and " (TRUNCATED)" or "")
    sb[#sb + 1] = snap.summary or ""
    sb[#sb + 1] = "\n\n[Lua-reachable objects with paths]\n"
    for id, paths in pairs(snap.pathsById) do
        local tn = snap.typeById[id] or "<unknown>"
        local dFlag = snap.destroyedById[id] and " [DESTROYED]" or ""
        sb[#sb + 1] = string.format("id=%d type=%s%s\n", id, tn, dFlag)
        for i = 1, #paths do
            sb[#sb + 1] = "  " .. paths[i] .. "\n"
        end
    end

    local file = filePath
    if file == nil then
        local folder = CS.System.Environment.GetFolderPath(
            CS.System.Environment.SpecialFolder.DesktopDirectory) .. "/游戏日志/mm_leak/"
        local fileName = CS.System.DateTime.Now:ToString("yyyyMMddHHmmss") ..
            "_snap_" .. tostring(name) .. ".log"
        file = folder .. fileName
    end
    IOUtils.CreateFolderByFile(file)
    IOUtils.WriteAllText(file, table.concat(sb))
    Log("[MMLeakTool] 快照报告已写出: " .. file)
    return file
end
