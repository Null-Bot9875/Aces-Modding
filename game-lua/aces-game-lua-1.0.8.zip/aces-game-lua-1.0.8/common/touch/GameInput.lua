local GameInput = {}

local RawInput = CS.UnityEngine.Input

function GameInput.IsBlocked()
    if RuntimeDeveloperConsole.IsInputCaptured() then
        return true
    end

    return BattleReplayInputGate ~= nil
        and BattleReplayInputGate.IsPlayerInputBlocked ~= nil
        and BattleReplayInputGate.IsPlayerInputBlocked()
end

function GameInput.GetAxis(axisName)
    if GameInput.IsBlocked() then
        return 0
    end
    return RawInput.GetAxis(axisName)
end

function GameInput.GetKey(key)
    return not GameInput.IsBlocked() and RawInput.GetKey(key)
end

function GameInput.GetKeyDown(key)
    return not GameInput.IsBlocked() and RawInput.GetKeyDown(key)
end

function GameInput.GetKeyUp(key)
    return not GameInput.IsBlocked() and RawInput.GetKeyUp(key)
end

function GameInput.GetMouseButton(button)
    return not GameInput.IsBlocked() and RawInput.GetMouseButton(button)
end

function GameInput.GetMouseButtonDown(button)
    return not GameInput.IsBlocked() and RawInput.GetMouseButtonDown(button)
end

function GameInput.GetMouseButtonUp(button)
    return not GameInput.IsBlocked() and RawInput.GetMouseButtonUp(button)
end

function GameInput.GetMousePosition()
    return RawInput.mousePosition
end

function GameInput.GetTouchCount()
    if GameInput.IsBlocked() then
        return 0
    end
    return RawInput.touchCount
end

function GameInput.GetTouch(index)
    if GameInput.IsBlocked() then
        return nil
    end
    return RawInput.GetTouch(index)
end

return GameInput
