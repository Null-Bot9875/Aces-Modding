-- 分页容器
HorizontalPageContainer = BaseClass("HorizontalPageContainer")

function HorizontalPageContainer:__Init()
    self.itemPageMap = {}
    self.items = {}

    self.refItems = {}

    self.currentPage = nil
    self.itemsPerPage = 0 -- 一页能显示的items数量
    self.totalPages = 0   -- 需要根据items数量和itemsPerPage计算


    -- 回调
    self.pageChangeCallback = nil    -- params: pageNumber
    self.itemPosSetCallback = nil    -- params: index, pos
    -- 筛选显示的items
    self.itemIsVisibleCallback = nil -- params: index  return: isVisible (bool)
    self.getItemCallback = nil       -- params: index  return: item, gameObject,args
    self.recycleItemCallback = nil   -- params: item

    self.isInitRef = false

    self.setting = {}
    --[[

        setting.size                          -- 容器大小
        setting.useScrollView                 -- 是否使用ScrollView
        setting.itemSize                      -- item大小
        setting.padding                       -- padding, grid layout group的padding
        setting.spacing                       -- spacing, grid layout group的spacing
        setting.isLoop                        -- 是否循环
        setting.fullNum                       -- 完整的全部item数量
        setting.itemPosSetCallback            -- item位置设置回调
        setting.recycleItemCallback           -- 回收item回调
        setting.itemIsVisibleCallback         -- item是否可见回调
        setting.pageChangeCallback            -- 页面切换回调
        setting.getItemCallback               -- 获取item回调
        setting.refreshContatinCallback       -- 刷新容器回调
    --]]
end

function HorizontalPageContainer:__Delete()
    for k, v in ipairs(self.items) do
        if v.item then
            v.item:Destroy()
        end
    end
    self.items = nil
    self.itemPageMap = nil

    GameObject.Destroy(self.gameObject)
end

function HorizontalPageContainer:CacheObject(object)
    self.refContent = object:Find("ref/content")
    self.refCanvasGroup = object:Find("ref").gameObject:GetComponent(CanvasGroup)
    self.refGridLayoutGroup = object:Find("ref/content").gameObject:GetComponent(GridLayoutGroup)
    self.refItem = object:Find("template/ref_item")

    self.content = object:Find("view_port/content")
    self.pointerHandler = object:Find("view_port").gameObject:GetComponent(PointerHandler)

    self.rectTransform = object.gameObject:GetComponent(RectTransform)
end

function HorizontalPageContainer:Show(setting)
    -- settings
    self:UpdateSetting(setting)

    --
    self.pointerHandler:SetOwner(self)
    self.pointerHandler:SetDrag("startDrag", "", "endDrag")
    self.pointerHandler.isDrag = true
    self.pointerHandler.isPointerDown = true

    self.refCanvasGroup.alpha = 0

    -- 初始化content
    -- local contentRect = self.content.gameObject:GetComponent(RectTransform)
    -- local refRect = self.refContent.gameObject:GetComponent(RectTransform)
    -- contentRect.sizeDelta = Vector2(refRect.rect.width, refRect.rect.height)

    if self.refreshContatinCallback then
        self.refreshContatinCallback()
    end
    
    self:ChangePage(1)
end

function HorizontalPageContainer:UpdateSetting(setting)
    for k, v in pairs(setting) do
        self.setting[k] = v
    end

    local parentSize = self.parent.gameObject:GetComponent(RectTransform).sizeDelta
    -- self.rectTransform.sizeDelta = Vector2(setting.size.width, setting.size.height)
    self.rectTransform.sizeDelta = parentSize

    self.pageChangeCallback = self.setting.pageChangeCallback
    self.itemPosSetCallback = self.setting.itemPosSetCallback
    self.itemIsVisibleCallback = self.setting.itemIsVisibleCallback
    self.getItemCallback = self.setting.getItemCallback
    self.recycleItemCallback = self.setting.recycleItemCallback
    self.refreshContatinCallback = self.setting.refreshContatinCallback

    self.refGridLayoutGroup.cellSize = Vector2(self.setting.itemSize.width, self.setting.itemSize.height)
    self.refGridLayoutGroup.spacing = Vector2(self.setting.spacing.x or 0, self.setting.spacing.y or 0)

    self.refGridLayoutGroup.padding.left = self.setting.padding.left or 0
    self.refGridLayoutGroup.padding.right = self.setting.padding.right or 0
    self.refGridLayoutGroup.padding.top = self.setting.padding.top or 0
    self.refGridLayoutGroup.padding.bottom = self.setting.padding.bottom or 0


    self.itemsPerPage = self.setting.itemsPerPage or 0
    self.fullNum = self.setting.fullNum or 0
    --

    -- 筛选后的item数量
    self.totalNum = 0
    for i = 1, self.fullNum do
        local flag = true
        if self.itemIsVisibleCallback then
            flag = self.itemIsVisibleCallback(i)
        end

        if flag then
            self.totalNum = self.totalNum + 1
        end


        local data = {}
        data.index = i
        data.isVisible = flag
        data.item = nil
        data.gameObject = nil

        local currPage = math.ceil(i / self.itemsPerPage)
        data.page = currPage
        table.insert(self.items, data)
    end

    self.totalPages = math.ceil(self.totalNum / self.itemsPerPage)
end

function HorizontalPageContainer:GetPageItems(pageNumber)
    local items = {}
    local count = 0
    for k, v in ipairs(self.items) do
        if v.page == pageNumber then
            count = count + 1
            if not v.item and v.isVisible then

                local gameObject, item, args = self.getItemCallback(v.index)
                v.item = item
                v.gameObject = gameObject
                v.args = args

                
                local rect = v.gameObject.gameObject:GetComponent(RectTransform)
                rect.anchorMin = Vector2(0, 1)
                rect.anchorMax = Vector2(0, 1)
                item:SetParent(self.content)
            end
            
            v.gameObject.transform.anchoredPosition = self:GetItemPos(count)
            table.insert(items, v)
        end
    end
    return items
end

function HorizontalPageContainer:GetItemPos(count)
    if not self.isInitRef then
        self.isInitRef = true
        for i = 1, self.itemsPerPage, 1 do
            local refGo = GameObject.Instantiate(self.refItem.gameObject, self.refContent)
            self.refItems[i] = refGo
        end
        --

        LayoutRebuilder.ForceRebuildLayoutImmediate(self.refContent)
    end

    local refGo = self.refItems[count]
    return refGo.transform.anchoredPosition
end

---------------------------------------- 对外接口 ----------------------------------------
function HorizontalPageContainer:GetItems()
    return self.items    
end

function HorizontalPageContainer:RefreshContainer()
    -- 筛选后的item数量
    self.totalNum = 0
    for i = 1, self.fullNum do
        local flag = true
        if self.itemIsVisibleCallback then
            flag = self.itemIsVisibleCallback(i)
        end

        if flag then
            self.totalNum = self.totalNum + 1
        end

        local data = {}
        if not self.items[i] then
            data.index = i
            data.isVisible = flag
            data.item = nil
            data.gameObject = nil
        else
            data = self.items[i]
            data.isVisible = flag
        end

        local currPage = math.ceil(i / self.itemsPerPage)
        data.page = currPage
        
        self.items[i] = data
    end

    self.totalPages = math.ceil(self.totalNum / self.itemsPerPage) or 0
    if not self.currentPage then
        self.currentPage = 1
    end
    if self.currentPage > self.totalPages then
        self.currentPage = self.totalPages
    end
    if self.currentPage < 1 then
        self.currentPage = 1
    end

    if self.refreshContatinCallback then
        self.refreshContatinCallback()
    end

    self:ChangePage(self.currentPage, true)
end

function HorizontalPageContainer:AddItem()
    self.fullNum = self.fullNum + 1

    self:RefreshContainer()
end

function HorizontalPageContainer:RemoveItem(index)
    self.fullNum = self.fullNum - 1
    local item = self.items[index]
    if item.item then
        item.item:Destroy()
        table.remove(self.items, index)
    else
        Log("移出失败"..index)
    end


    self:RefreshContainer()
end

function HorizontalPageContainer:GetTotalPages()
    return self.totalPages
end

function HorizontalPageContainer:GetCurrentPage()
    return self.currentPage
end

-- 获取当前页面有几个item
function HorizontalPageContainer:GetCurrCount()
    local count = 0
    for k, v in ipairs(self.items) do
        if v.page == self.currentPage then
            count = count + 1
        end
    end
    return count
end

-- 切换页面
function HorizontalPageContainer:ChangePage(pageNumber, isForce)
    if (not isForce and pageNumber < 1) or pageNumber > (self.totalPages or 0) then
        return
    end

    if not isForce and self.currentPage == pageNumber then
        return
    end

    -- TODO 刷新之后的内容，然后动效过去？
    local beforePage = self.currentPage
    self.currentPage = pageNumber

    -- 隐藏
    local items = self:GetPageItems(beforePage)
    for k, v in ipairs(items) do
        local item = v.item
        if item then
            item:Hide()
        end
    end

    -- 刷新
    local items = self:GetPageItems(self.currentPage)
    for k, v in ipairs(items) do
        local item = v.item
        if item then
            item:Show(v.args)
        end
    end        

    if self.pageChangeCallback then
        self.pageChangeCallback(self.currentPage)
    end
end

-- 下一页
function HorizontalPageContainer:NextPage()
    if not self.currentPage then
        return
    end
    local index = self.currentPage + 1
    if self.setting.isLoop then
        if index > self.totalPages then
            index = 1
        end
    end

    self:ChangePage(index)
end

-- 上一页
function HorizontalPageContainer:PreviousPage()
    if not self.currentPage then
        return
    end
    local index = self.currentPage - 1
    if self.setting.isLoop then
        if index < 1 then
            index = self.totalPages
        end
    end

    self:ChangePage(index)
end

function HorizontalPageContainer.Create(parent)
    local template = PreloadManager.Instance:GetAsset(AssetPath.horizontaPageContainer)
    local item = HorizontalPageContainer.New()
    -- local go = GameObject.Instantiate(template, parent)
    local go = GameObject.Instantiate(template, parent)
    item.gameObject = go
    item:CacheObject(go.transform)
    -- go.transform:Reset()
    item.parent = parent
    return item
end
