UnitTimeline = BaseClass("UnitTimeline",LTimeline)

function UnitTimeline:__Init()
    self.timelineBehaviors = {}
    self.uid = 0
    self.updateTimer = TimerManager.Instance:AddTimer(0,0,self:ToFunc("OnUpdate"))
end

function UnitTimeline:__Delete()
    self.timelineBehaviors = {}
    if self.updateTimer then
        TimerManager.Instance:RemoveTimer(self.updateTimer)
        self.updateTimer = nil
    end
end

function UnitTimeline:OnInit(conf,args)
    local nodes = {}

    for _, v in ipairs(conf) do
        local class  = _G[v.type]

        if class then
            local node = {}

            local uid = v.uid

            if not uid or uid == "" then
                uid = self:GetTimelineNodeUid()
            end

            local timelineBehavior = class.New()
            timelineBehavior:Init(uid,v,args)
            node.behavior = timelineBehavior
            node.time = v.time
            table.insert(nodes,node)

            self.timelineBehaviors[uid] = timelineBehavior
        else
            LogError("创建机体行为异常，未知的机体行为类型[行为类型:%s]",tostring(v.type))
        end
    end
    self:SetNodes(nodes)
end

function UnitTimeline:GetTimelineNodeUid()
    self.uid = self.uid + 1
    return self.uid
end

function UnitTimeline:GetTimelineNode(uid)
    return self.timelineBehaviors[uid]
end

function UnitTimeline:OnStart()
end

function UnitTimeline:OnAbort()
end

function UnitTimeline:OnFinish()
end

function UnitTimeline:OnUpdate()
    self:Update(Time.deltaTime)
end


function UnitTimeline.Create(confName,args)
    if not Config.HasConf(confName) then
        LogErrorf("不存在机体行为配置文件[%s]",confName)
        return nil
    end
    local animDatas = Config.GetLua(confName)
    if not animDatas then
        LogErrorf("不存在机体行为配置文件[%s]",confName)
        return nil
    end

    local unitTimeline = UnitTimeline.New()
    unitTimeline:Init(animDatas,args)

    return unitTimeline
end