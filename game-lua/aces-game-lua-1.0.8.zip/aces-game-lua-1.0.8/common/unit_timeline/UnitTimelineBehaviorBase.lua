UnitTimelineBehaviorBase = BaseClass("UnitTimelineBehaviorBase")

function UnitTimelineBehaviorBase:__Init()
    self.uid = nil
    self.conf = nil
    self.args = nil
    self.onComplete = nil
    self.onHookComplete = nil
end

function UnitTimelineBehaviorBase:__Delete()
end

function UnitTimelineBehaviorBase:Init(uid,conf,args,...)
    self.uid = uid
    self.conf = conf
    self.args = args
    self:OnInit(...)
end

function UnitTimelineBehaviorBase:Start()
    self:OnStart()
end

function UnitTimelineBehaviorBase:Update(deltaTime)
    self:OnUpdate(deltaTime)
end

function UnitTimelineBehaviorBase:SetComplete(onComplete)
    self.onComplete = onComplete
end

function UnitTimelineBehaviorBase:SetHookComplete(onComplete)
    self.onHookComplete = onComplete
end

function UnitTimelineBehaviorBase:TimelineDone(...)
    if self.onHookComplete then
        self.onHookComplete(self,...)
    end
    if self.onComplete then
        self.onComplete(self,...)
    end
end

-- 虚函数
function UnitTimelineBehaviorBase:OnInit(...)
end
function UnitTimelineBehaviorBase:OnStart()
end
function UnitTimelineBehaviorBase:OnUpdate(deltaTime)
end
function UnitTimelineBehaviorBase:OnDestroy()
end