PlayViewUnitAnim = BaseClass("PlayViewUnitAnim",UnitTimelineBehaviorBase)

function PlayViewUnitAnim:__Init()
    self.doneTimer = nil
end

function PlayViewUnitAnim:__Delete()
    self:RemoveDoneTimer()
end

function PlayViewUnitAnim:OnInit()
end

function PlayViewUnitAnim:OnStart()
    if not self.args.unit or BaseUtils.IsNull(self.args.unit) then
        self:TimelineDone()
        return
    end

    if not self.args.unit.tpose or BaseUtils.IsNull(self.args.unit.tpose) then
        self:TimelineDone()
        return
    end

    if not self.args.unit.tpose.animator or BaseUtils.IsNull(self.args.unit.tpose.animator) then
        self:TimelineDone()
        return
    end

    self.args.unit.tpose.animator:Play(self.conf.animName)

    local lastTime = nil
    if self.conf.isDynamicDuration or self.conf.duration < 0 then
        lastTime = BaseUtils.GetAnimatorClipTime(self.args.unit.tpose.animator,self.conf.animName) * 1000
    else
        lastTime = self.conf.duration
    end

    if lastTime and lastTime > 0 then
        self.doneTimer = TimerManager.Instance:AddTimer(1,lastTime * 0.001,self:ToFunc("DoneTimer"))
        self.doneTimer:SetScale(true)
    else
        self:TimelineDone()
    end
end

function PlayViewUnitAnim:DoneTimer()
    self.doneTimer = nil
    self:TimelineDone()
end


function PlayViewUnitAnim:RemoveDoneTimer()
    if self.doneTimer then
        TimerManager.Instance:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end