PlayViewUnitAudio = BaseClass("PlayViewUnitAudio",UnitTimelineBehaviorBase)

function PlayViewUnitAudio:__Init()
    self.doneTimer = nil
    self.audioUid = nil
end

function PlayViewUnitAudio:__Delete()
    self:RemoveAudio()
    self:RemoveDoneTimer()
end

function PlayViewUnitAudio:OnInit()
end

function PlayViewUnitAudio:OnRecover()
    -- if self.conf.unProgress and self.conf.audioId then
    --     AudioManager.Instance:PlayCarrier(self.conf.audioId)
    -- end
end

function PlayViewUnitAudio:OnStart()
    LogTable("播放音效TB",self.conf.audioId)
    if self.conf.audioId then
        self.audioUid = AudioManager.Instance:PlayCarrier(self.conf.audioId)
    end

    local lastTime = nil
    if not self.conf.unProgress and self.conf.duration > 0 then
        lastTime = self.conf.duration
    end

    if lastTime and lastTime > 0 then
        self.doneTimer = TimerManager.Instance:AddTimer(1,lastTime * 0.001,self:ToFunc("DoneTimer"))
        self.doneTimer:SetScale(true)
    else
        self:TimelineDone()
    end
end

function PlayViewUnitAudio:DoneTimer()
    self.doneTimer = nil
    self:RemoveAudio()
    self:TimelineDone()
end

function PlayViewUnitAudio:RemoveDoneTimer()
    if self.doneTimer then
        TimerManager.Instance:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function PlayViewUnitAudio:RemoveAudio()
    if self.audioUid and not self.conf.unProgress then
        AudioManager.Instance:StopCarrier(self.audioUid)
        self.audioUid = nil
    end
end