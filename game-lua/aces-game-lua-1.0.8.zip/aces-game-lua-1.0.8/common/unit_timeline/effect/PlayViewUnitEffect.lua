PlayViewUnitEffect = BaseClass("PlayViewUnitEffect",UnitTimelineBehaviorBase)

function PlayViewUnitEffect:__Init()
    self.effect = nil
    self.doneTimer = nil
end

function PlayViewUnitEffect:__Delete()
    self:RemoveEffect()
    self:RemoveDoneTimer()
end

function PlayViewUnitEffect:OnInit()
end

function PlayViewUnitEffect:OnStart()
    if not self.args.unit or BaseUtils.IsNull(self.args.unit) then
        self:TimelineDone()
        return
    end
    local unit = self.args.unit
    if not unit.tpose or BaseUtils.IsNull(unit.tpose) or not unit.tpose.transform then
        self:TimelineDone()
        return
    end

    local boneTrans = unit.tpose.transform:Find(self.conf.bindBone)
    if not boneTrans then
        local objectMapping = unit.tpose.gameObject:GetComponent(ObjectMapping)
        if objectMapping then
            local bonePath = objectMapping:GetPath(self.conf.bindBone)
            if bonePath and bonePath ~= "" then
                boneTrans = unit.tpose.transform:Find(bonePath)
            end
        end
    end

    if not boneTrans or BaseUtils.IsNull(boneTrans) then
        self:TimelineDone()
        return
    end


    local setting = {}
    setting.assetId = self.conf.assetId
    setting.pos = self.conf.pos
    setting.rotate = self.conf.rotate
    setting.scale = self.conf.scale
    setting.bone = KvData.Bone.custom
    setting.customBone = self.conf.bindBone
    setting.parent = boneTrans
    setting.layer = KvData.Layer.layer9

    self.effect = SimpleEffect.New()
    self.effect:Init(setting)
    self.effect:Play()

    self.doneTimer = TimerManager.Instance:AddTimer(1,self.conf.duration * 0.001,self:ToFunc("DoneTimer"))
    self.doneTimer:SetScale(true)
end


function PlayViewUnitEffect:DoneTimer()
    self.doneTimer = nil
    self:TimelineDone()
end

function PlayViewUnitEffect:RemoveDoneTimer()
    if self.doneTimer then
        TimerManager.Instance:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function PlayViewUnitEffect:RemoveEffect()
    if self.effect then
        self.effect:Delete()
        self.effect = nil
    end
end