PlayViewUnitFixedEffect = BaseClass("PlayViewUnitFixedEffect",UnitTimelineBehaviorBase)

function PlayViewUnitFixedEffect:__Init()
end

function PlayViewUnitFixedEffect:__Delete()
    self:RemoveEffect()
end

function PlayViewUnitFixedEffect:OnInit()
end

function PlayViewUnitFixedEffect:OnStart()
    if not self.args.unit or BaseUtils.IsNull(self.args.unit) then
        self:TimelineDone()
        return
    end

    if not self.args.unit.tpose or BaseUtils.IsNull(self.args.unit.tpose) then
        self:TimelineDone()
        return
    end

    if not self.args.unit.tpose.transform or BaseUtils.IsNull(self.args.unit.tpose.transform) then
        self:TimelineDone()
        return
    end

    local boneTrans = self.args.unit.tpose.transform:Find(self.conf.bindBone)
    if not boneTrans then
        local objectMapping = self.args.unit.tpose.gameObject:GetComponent(ObjectMapping)
        if objectMapping then
            local bonePath = objectMapping:GetPath(self.conf.bindBone)
            if bonePath and bonePath ~= "" then
                boneTrans = self.args.unit.tpose.transform:Find(bonePath)
            end
        end
    end


    local setting = {}
    setting.assetId = self.conf.assetId
    setting.pos = self.conf.pos
    setting.rotate = self.conf.rotate
    setting.scale = self.conf.scale
    setting.bone = KvData.Bone.custom
    setting.customBone = self.conf.bindBone
    setting.parent = boneTrans
    setting.layer = KvData.Layer.layer9


    self.effect = SimpleEffect.New()
    self.effect:Init(setting)
    self.effect:Play()

    self:TimelineDone()
end



function PlayViewUnitFixedEffect:RemoveEffect()
    if self.effect then
        self.effect:Delete()
        self.effect = nil
    end
end