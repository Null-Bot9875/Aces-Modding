TransitionView = BaseClass("TransitionView")

function TransitionView:__Init()
    self.sequenceList = {}
    self.isOpenTransition = false -- 标记是打开还是关闭
    self.currentFadeId = 0        -- 当前动画ID，用于取消动画

    EventManager.Instance:AddEvent(EventDefine.asset_loaded, self:ToFunc("OnAssetLoaded"))
end

function TransitionView:__Delete()
    EventManager.Instance:RemoveEvent(EventDefine.asset_loaded, self:ToFunc("OnAssetLoaded"))
    self:ClearSequence()
    self:ClearTimer()
end

function TransitionView:ClearTimer()
    if self.completeTimer then
        TimerManager.Instance:RemoveTimer(self.completeTimer)
        self.completeTimer = nil
    end
    if self.updateTimer then
        TimerManager.Instance:RemoveTimer(self.updateTimer)
        self.updateTimer = nil
    end
    if self.closeTimer then
        TimerManager.Instance:RemoveTimer(self.closeTimer)
        self.closeTimer = nil
    end
end

function TransitionView:ClearSequence()
    for _, seq in ipairs(self.sequenceList) do
        seq:Kill()
    end
    self.sequenceList = {}
end

function TransitionView:InitState()
    self.currentTransitionType = nil
    self.currentClassName = nil
    self.currentCallback = nil
    self.isOpenTransition = false
    self:ClearSequence()
end

-- 检查是否有正在进行的转场
function TransitionView:IsTransitioning(className)
    if self.currentTransitionType == nil then
        return false
    end
    if className then
        return self.currentClassName == className
    end
    return true
end

-- 执行转场动画, callback为转场动画合适的时候的回调
-- 比如黑屏过度的时候，在全黑的时候执行回调
-- @param isOpen: true=打开窗口（等待资源加载），false/nil=关闭窗口（立即fade out）
function TransitionView:ExecuteTransition(transitionType, callback, className, isOpen)
    -- 如果有正在进行的转场，立即完成回调，但保持黑幕透明度
    if self.currentTransitionType ~= nil then
        if self.currentCallback then
            self.currentCallback()
        end
        -- 清理动画序列，但保持透明度（不重置 alpha）
        self:ClearSequence()
    end

    self.currentClassName = className
    self.currentTransitionType = transitionType
    self.currentCallback = callback
    self.isOpenTransition = isOpen or false

    if transitionType == KvData.TransitionType.black then
        self:ExecuteTransitionBlack(callback)
    else
        self.currentCallback()
    end
end

-- ==================== 叠黑转场 ====================
function TransitionView:ExecuteTransitionBlack(callback)
    self.currentCallback = callback

    local canvasGroup = UIDefine.transBlackMaskCanvasGroup
    local currentAlpha = canvasGroup.alpha -- 获取当前透明度

    canvasGroup.blocksRaycasts = true

    self:ClearTimer()
    -- 如果当前已经是黑屏（从之前的 close 转场过来），直接执行回调
    if currentAlpha >= 0.95 then
        self.completeTimer = TimerManager.Instance:AddTimerByNextFrame(1, 0.1, self:ToFunc("OnTransitionBlackComplete"))
    else
        -- 从当前透明度渐变到全黑（正常的打开流程）
        local remainingDuration = UIDefine.TransitionConfig.blackFadeDuration * (1 - currentAlpha)
        self:ExecuteFadeWithFrameGuard(canvasGroup, 1, remainingDuration, function()
            self.completeTimer = TimerManager.Instance:AddTimerByNextFrame(1, 0.2, self:ToFunc("OnTransitionBlackComplete"))
        end)
    end
end

function TransitionView:ExecuteTransitionBlackStep2()
    local canvasGroup = UIDefine.transBlackMaskCanvasGroup
    local duration = UIDefine.TransitionConfig.blackFadeDuration

    -- Log("ExecuteTransitionBlackStep2 start",Time.frameCount)

    -- 使用分帧+真实时间混合方案，防止卡顿时动画跳过
    self:ExecuteFadeWithFrameGuard(canvasGroup, 0, duration, function()
        canvasGroup.blocksRaycasts = false
        -- Log("ExecuteTransitionBlackStep2 end",Time.frameCount)
    end)

    self.currentCallback = nil
    self.currentTransitionType = nil
    self.currentClassName = nil
end

-- 分帧保护的淡入淡出动画，防止卡顿导致跳帧
-- @param canvasGroup: 目标 CanvasGroup
-- @param targetAlpha: 目标透明度 (0-1)
-- @param duration: 动画时长（秒）
-- @param onComplete: 完成回调
function TransitionView:ExecuteFadeWithFrameGuard(canvasGroup, targetAlpha, duration, onComplete)
    -- 递增动画ID，用于取消旧动画
    self.currentFadeId = self.currentFadeId + 1
    local fadeId = self.currentFadeId

    local startAlpha = canvasGroup.alpha
    local minFrames = math.max(math.ceil(duration * 60), 6) -- 按60帧计算，最少6帧
    local frameCount = 0
    local startTime = Time.realtimeSinceStartup

    local function UpdateFade()
        -- 如果ID不匹配，说明有新动画开始了，取消当前动画
        if fadeId ~= self.currentFadeId then
            return
        end

        frameCount = frameCount + 1
        local elapsed = Time.realtimeSinceStartup - startTime

        -- 双重进度控制：时间进度和帧数进度
        local timeProgress = elapsed / duration
        local frameProgress = frameCount / minFrames
        -- 取较大值保证至少执行够帧数，同时也能按时间完成
        local progress = math.max(timeProgress, frameProgress)
        progress = math.min(progress, 1.0)

        -- 计算当前透明度
        canvasGroup.alpha = startAlpha + (targetAlpha - startAlpha) * progress

        -- 判断是否完成
        if progress >= 1.0 and frameCount >= minFrames then
            canvasGroup.alpha = targetAlpha
            if onComplete then
                onComplete()
            end
        else
            -- 继续下一帧
            self.updateTimer = TimerManager.Instance:AddTimerByNextFrame(1, 0, UpdateFade)
        end
    end

    -- 开始执行
    UpdateFade()
end

-- 静态方法：执行淡入淡出动画（不依赖实例状态，可被外部调用）
-- @param targetAlpha: 目标透明度 (0-1)
-- @param duration: 动画时长（秒）
-- @param onComplete: 完成回调
-- @return: 返回取消函数，调用可取消动画
function TransitionView.ExecuteFade(targetAlpha, duration, onComplete)
    local canvasGroup = UIDefine.transBlackMaskCanvasGroup
    
    local startAlpha = canvasGroup.alpha
    local minFrames = math.max(math.ceil(duration * 60), 6)
    local frameCount = 0
    local startTime = Time.realtimeSinceStartup
    local currentTimer = nil
    local isCancelled = false
    
    local function UpdateFade()
        if isCancelled then
            return
        end
        
        frameCount = frameCount + 1
        local elapsed = Time.realtimeSinceStartup - startTime
        
        local timeProgress = elapsed / duration
        local frameProgress = frameCount / minFrames
        local progress = math.max(timeProgress, frameProgress)
        progress = math.min(progress, 1.0)
        
        canvasGroup.alpha = startAlpha + (targetAlpha - startAlpha) * progress
        
        if progress >= 1.0 and frameCount >= minFrames then
            canvasGroup.alpha = targetAlpha
            currentTimer = nil
            if onComplete then
                onComplete()
            end
        else
            currentTimer = TimerManager.Instance:AddTimerByNextFrame(1, 0, UpdateFade)
        end
    end
    
    local function Cancel()
        isCancelled = true
        if currentTimer then
            TimerManager.Instance:RemoveTimer(currentTimer)
            currentTimer = nil
        end
    end
    
    UpdateFade()
    return Cancel
end

function TransitionView:OnTransitionBlackComplete()
    self.currentCallback()

    -- 如果是关闭窗口，callback 执行后立即 fade out
    if not self.isOpenTransition then
        -- 延迟一小段时间再 fade out，让关闭动作完成
        self.closeTimer = TimerManager.Instance:AddTimerByNextFrame(1, 0.1, self:ToFunc("OnCloseTransitionComplete"))
    end
end

-- 执行并清理当前转场
function TransitionView:ExecuteAndClearTransition()
    if self.currentTransitionType == KvData.TransitionType.black then
        if self.currentCallback then
            self.currentCallback()
            Log("强制清理转场")

            self:ClearTimer()
            -- 清理所有动画序列
            self:ClearSequence()
            -- 重置状态
            self.currentTransitionType = nil
            self.currentClassName = nil
            self.currentCallback = nil
            self.isOpenTransition = false
    
            -- 立即重置黑幕透明度
            local canvasGroup = UIDefine.transBlackMaskCanvasGroup
            if canvasGroup then
                canvasGroup.alpha = 0
                canvasGroup.blocksRaycasts = false
            end
        end
    end
end

function TransitionView:OnCloseTransitionComplete()
    if self.currentTransitionType == KvData.TransitionType.black then
        self:ExecuteTransitionBlackStep2()
    end
end

function TransitionView:OnAssetLoaded(assetName)
    if self.currentClassName ~= assetName then
        return
    end

    if self.currentTransitionType == KvData.TransitionType.black then
        self:ExecuteTransitionBlackStep2()
    end
end

-- 清理转场状态（用于退出登录、重连等场景）
function TransitionView:Clean()
    self:ClearTimer()
    -- 清理所有动画序列
    self:ClearSequence()

    -- 重置状态
    self.currentTransitionType = nil
    self.currentClassName = nil
    self.currentCallback = nil
    self.isOpenTransition = false

    -- 立即重置黑幕透明度
    local canvasGroup = UIDefine.transBlackMaskCanvasGroup
    if canvasGroup then
        canvasGroup.alpha = 0
        canvasGroup.blocksRaycasts = false
    end

    -- 重新添加事件监听（因为 EventManager.Clean() 可能已经清空了所有监听）
    EventManager.Instance:RemoveEvent(EventDefine.asset_loaded, self:ToFunc("OnAssetLoaded"))
    EventManager.Instance:AddEvent(EventDefine.asset_loaded, self:ToFunc("OnAssetLoaded"))
end
