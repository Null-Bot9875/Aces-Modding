ViewDefine = SingleClass("ViewDefine")




ViewDefine.Layer =
{
    ["LoginWindow"] = 0,
    ["BattleLoadWindow"] = 32736,
}

-- ViewDefine.AutoOpenPriority =
-- {
--     ["RankWindow"] = 1,
--     ["ObtainedNewUnitWindow"] = 2,
-- }

ViewDefine.Layer["MainuiPanel"] = 0
ViewDefine.Layer["BattleMainPanel"] = 20


ViewDefine.Layer["BattleMainPanel_Lock"] = 32736


ViewDefine.Layer["MainuiPanel_Top_Bottom"] = ViewDefine.Layer["BattleMainPanel_Lock"] + 1

ViewDefine.Layer["GuideView"] = ViewDefine.Layer["MainuiPanel_Top_Bottom"] + 1


ViewDefine.Layer["BattleReadyEnterWindow"] = ViewDefine.Layer["GuideView"] + 1


ViewDefine.Layer["PlayerGuideView_Effect"] = ViewDefine.Layer["BattleReadyEnterWindow"] + 1


ViewDefine.Layer["GetMechaWindow"] = ViewDefine.Layer["PlayerGuideView_Effect"] + 1



ViewDefine.Layer["SystemDialogPanel"] = ViewDefine.Layer["GetMechaWindow"] + 1
ViewDefine.Layer["SystemDialogTipsPanel"] = ViewDefine.Layer["GetMechaWindow"] + 1
ViewDefine.Layer["SystemDialogSingleTipPanel"] = ViewDefine.Layer["GetMechaWindow"] + 1

ViewDefine.Layer["ReconnectPanel"] = ViewDefine.Layer["SystemDialogPanel"] + 1

ViewDefine.Layer["SystemMessagePanel"] = ViewDefine.Layer["ReconnectPanel"] + 1
ViewDefine.Layer["FeedbackWindow"] = 32738


ViewDefine.Layer["Max"] = ViewDefine.Layer["SystemMessagePanel"] + 1



ViewDefine.WindowIdToName =
{
    
}
