ViewManager = SingleClass("ViewManager")

function ViewManager:__Init()
    -- 窗口实例缓存
    self.windows = {}
    -- 窗口堆栈（栈顶是当前显示的窗口）
    self.windowStack = {}
    self.orderLayer = 10
    self.checkMainui = true
    self.adaptiveHeightMaskObj = nil

    self.transitionView = TransitionView.New()
    EventManager.Instance:AddEvent(EventDefine.preload_complete, self:ToFunc("OnPreloadComplete"))
end

function ViewManager:__Delete()
    if self.transitionView then
        self.transitionView:Destroy()
        self.transitionView = nil
    end
end

function ViewManager:OnPreloadComplete()
    -- 现在使用设置camera的output rect值来实现了
    --if self.adaptiveHeightMaskObj == nil then
    --    self:CreateAdaptiveHeightMask()
    --end
end

function ViewManager:SetCheckMainui(flag)
    self.checkMainui = flag
end

function ViewManager:RemoveWindow(windowName)
    self.windows[windowName] = nil
end

-- function ViewManager:OpenWindowById(id,args)
--     local winName = ViewDefine.WindowIdToName[id]
--     return self:OpenWindowByName(winName)
-- end

function ViewManager:OpenWindow(win, args, isCache)
    local winName = win.__className
    return self:OpenWindowByName(winName, args, isCache)
end

function ViewManager:OpenWindowByName(winName, args, isCache)
    local windowClass = GetClass(winName)
    assert(windowClass ~= nil, string.format("没有对应的窗口类[win:%s]", tostring(winName)))
    if not self:CanOpenWindow(windowClass, args) then
        return false
    end
    -- LogError("OpenWindowByName: %s", winName)
    self.transitionView:ExecuteAndClearTransition()

    if windowClass.__transitionType == KvData.TransitionType.black then
        self.transitionView:ExecuteTransition(KvData.TransitionType.black,
            function() return self:__OpenWindow(winName, args, isCache) end, winName, true) -- true=打开窗口
    else
        return self:__OpenWindow(winName, args, isCache)
    end
end

function ViewManager:__OpenWindow(winName, args, isCache)
    -- 检查是否有正在关闭的窗口
    local existWin = self.windows[winName]
    if existWin and existWin.isDeleteWindow then
        -- destroy模式：强制销毁重建
        if existWin.cacheMode == UIDefine.CacheMode.destroy then
            existWin:CloseComplete()
            existWin = nil
        elseif existWin.cacheMode == UIDefine.CacheMode.hide then
            -- hide模式：复用窗口
            existWin.isDeleteWindow = false
            existWin.isHideing = false
        end
    end

    local windowClass = GetClass(winName)
    local win = existWin or self:CreateWindow(windowClass)
    self.windows[winName] = win
    if isCache then
        win:CreateCache()
        return true
    end

    win:SetOrderLayer(ViewDefine.Layer[win.winName] or self:GetMaxOrderLayer())
    -- 打开时先按窗口的 addOrderLayer 预留层级，再取当前 order 赋值，避免多窗口同帧打开时 order 未生效
    local addVal = windowClass.__addOrderLayer or 2
    self:AddOrderLayer(addVal)
    
    -- 将窗口压入堆栈
    self:PushWindow(winName)

    if win.__gaussian then
        win:Gaussian()
    end

    win:Show(args)

    EventManager.Instance:SendEvent(EventDefine.open_window, winName)
    return true
end

-- 堆栈操作：将窗口压入堆栈
function ViewManager:PushWindow(winName)
    -- 先从堆栈中移除（如果存在）
    self:RemoveFromStack(winName)

    local addWin = self.windows[winName]
    if not addWin then return end

    -- 根据 orderLayer 找到合适的位置插入
    local index = nil
    for i = #self.windowStack, 1, -1 do
        local win = self.windows[self.windowStack[i]]
        if win and addWin.orderLayer >= win.orderLayer then
            index = i
            break
        end
    end

    table.insert(self.windowStack, index and index + 1 or 1, winName)
end

-- 堆栈操作：从堆栈中移除指定窗口
function ViewManager:RemoveFromStack(winName)
    for i = #self.windowStack, 1, -1 do
        if self.windowStack[i] == winName then
            table.remove(self.windowStack, i)
            return
        end
    end
end

-- 堆栈操作：获取栈顶窗口
function ViewManager:GetTopWindow()
    if #self.windowStack > 0 then
        local topWinName = self.windowStack[#self.windowStack]
        return topWinName, self.windows[topWinName]
    end
    return nil, nil
end

-- 堆栈操作：获取窗口在堆栈中的索引
function ViewManager:GetWindowStackIndex(winName)
    for i = #self.windowStack, 1, -1 do
        if self.windowStack[i] == winName then
            return i
        end
    end
    return nil
end

function ViewManager:CanOpenWindow(windowClass, args)
    if not windowClass.IsOpen then
        return true
    else
        return windowClass.IsOpen(args)
    end
end

function ViewManager:CacheWindow(windowName)
    self:OpenWindow(windowName, nil, true)
end

function ViewManager:CreateWindow(windowClass)
    local window = windowClass.New()
    window:SetParent(UIDefine.canvasRoot)
    return window
end

function ViewManager:OpenComplete(window)
    if not self.windows[window.winName] then
        self.windows[window.winName] = window
    end

    local index = self:GetWindowStackIndex(window.winName)
    if not index then return end

    local isTopWindow = (index == #self.windowStack)

    -- 栈顶窗口：显示自己，隐藏下层
    if isTopWindow then
        if window:IsTempHide() then
            window:TempShowWindow()
            EventManager.Instance:SendEvent(EventDefine.temp_show_window, window.winName)
        end

        self:HideWindowBelow(index, window)
    else
        -- 非栈顶窗口：隐藏自己
        if not window.__holdShow then
            window:TempHideWindow()
            EventManager.Instance:SendEvent(EventDefine.temp_hide_window, window.winName)
        end
    end

    self:CheckMainui(window)
    EventManager.Instance:SendEvent(EventDefine.open_window_complete, window.winName)
end

-- 隐藏指定窗口下层的窗口
function ViewManager:HideWindowBelow(index, currentWindow)
    if currentWindow.notTempHide then return end

    local belowWinName = self.windowStack[index - 1]
    if not belowWinName then return end

    local belowWin = self.windows[belowWinName]
    if belowWin and not belowWin:IsTempHide() and not belowWin.__holdShow then
        belowWin:TempHideWindow()
        EventManager.Instance:SendEvent(EventDefine.temp_hide_window, belowWinName)
    end
end

function ViewManager:CheckMainui()
    if not self.checkMainui then
        return
    end

    if #self.windowStack <= 0 then
        mod.MainuiFacade:SendEvent(MainuiPanel.Event.ActiveMainui, true)
    else
        local _, currWindow = self:GetCurWindow()
        if currWindow and currWindow.__showMainui ~= nil then
            mod.MainuiFacade:SendEvent(MainuiPanel.Event.ActiveMainui, currWindow.__showMainui == true)
        else
            mod.MainuiFacade:SendEvent(MainuiPanel.Event.ActiveMainui, false)
        end
    end
end

function ViewManager:CloseComplete(winName)
    local _, topWin = self:GetTopWindow()
    if topWin then
        self:CheckMainui(topWin)
    end
end

function ViewManager:TempShowWindow()
    local topWinName, topWin = self:GetTopWindow()
    if not topWin then
        return
    end

    topWin:TempShowWindow()
    EventManager.Instance:SendEvent(EventDefine.temp_show_window, topWinName)
end

function ViewManager:GetCurWindow()
    return self:GetTopWindow()
end

function ViewManager:IsCurWindow(win)
    local topWinName = self:GetTopWindow()
    return topWinName == win.__className
end

function ViewManager:CloseWindow(win)
    local winName = win.__className
    self:CloseWindowByName(winName)
end

function ViewManager:HasWindowOpen()
    if #self.windowStack <= 0 then
        return false
    end

    for _, winName in ipairs(self.windowStack) do
        local win = self.windows[winName]
        if win and win:IsActive() then
            return true
        end
    end

    return false
end

-- 关闭最上层的窗口
function ViewManager:HotKeyCloseWindow()
    local _, topWin = self:GetTopWindow()
    if not topWin then return end
    return topWin:OnHotKeyCloseWindow()
end

function ViewManager:CloseWindowByName(winName)
    local win = self.windows[winName]
    if not win then return end

    if win.__transitionType == KvData.TransitionType.black then
        self.transitionView:ExecuteTransition(KvData.TransitionType.black,
            function() return self:__CloseWindow(winName) end, winName, false) -- false=关闭窗口
    else
        return self:__CloseWindow(winName)
    end
end

function ViewManager:__CloseWindow(winName)
    local win = self.windows[winName]
    if not win then return end

    local topWinName = self:GetTopWindow()
    local isCurWindow = topWinName == winName

    -- 从堆栈中移除窗口
    self:RemoveFromStack(winName)

    -- 显示新的栈顶窗口
    self:TempShowWindow()

    self:CheckMainui(win)

    -- 如果是当前窗口，那么走个过度再关闭
    win:CloseWindow(not isCurWindow)
    EventManager.Instance:SendEvent(EventDefine.close_window, winName)
end

function ViewManager:GetWindow(win)
    local windowName = win.__className
    return self.windows[windowName]
end

-- 检查窗口是否存在
function ViewManager:IsOpenWindow(win)
    local winName = win.__className
    local winItem = self.windows[winName]
    return winItem and winItem:IsActive() and self:IsCurWindow(win) and winItem:IsInited()
end

function ViewManager:HasView()
    return #self.windowStack > 0
end

-- 检查窗口是否打开过，不一定激活状态
function ViewManager:HasWindow(win)
    local winName = win.__className
    return self:HasWindowByName(winName)
end

function ViewManager:HasWindowByName(winName)
    local window = self.windows[winName]
    return window ~= nil and not window.isDeleteWindow == true
end

function ViewManager:GetShowWindowTotal()

end

function ViewManager:GetMaxOrderLayer()
    self.orderLayer = self.orderLayer + 2
    return self:GetCurOrderLayer()
end

function ViewManager:GetCurOrderLayer()
    return self.orderLayer
end

function ViewManager:IsExistWindow()
end

function ViewManager:AddOrderLayer(val)
    self.orderLayer = self.orderLayer + val
end

function ViewManager:SetOrderLayer(val)
    self.orderLayer = val
end

function ViewManager:CloseAllWindow(skipCheckMainui)
    local closeWindows = {}
    for k, _ in pairs(self.windows) do
        table.insert(closeWindows, k)
    end
    for _, winName in ipairs(closeWindows) do
        local win = self.windows[winName]
        win:CloseWindow(true)
        EventManager.Instance:SendEvent(EventDefine.close_window, winName)
    end

    self.windowStack = {}
    self.orderLayer = 10
    if not skipCheckMainui then
        self:CheckMainui()
    end
end

function ViewManager:CloseAllWindowExcept(exceptWindows)
    local exceptWindowMap = {}
    if type(exceptWindows) == "table" then
        for k, v in pairs(exceptWindows) do
            if type(k) == "number" then
                exceptWindowMap[v] = true
            elseif v then
                exceptWindowMap[k] = true
            end
        end
    end

    local closeWindows = {}
    for winName, _ in pairs(self.windows) do
        if not exceptWindowMap[winName] then
            table.insert(closeWindows, winName)
        end
    end

    for _, winName in ipairs(closeWindows) do
        local win = self.windows[winName]
        if win then
            win:CloseWindow(true)
            EventManager.Instance:SendEvent(EventDefine.close_window, winName)
        end
    end

    local remainStack = {}
    for _, winName in ipairs(self.windowStack) do
        if exceptWindowMap[winName] and self.windows[winName] and self.windows[winName]:IsActive() then
            table.insert(remainStack, winName)
        end
    end

    self.windowStack = remainStack
    if #self.windowStack <= 0 then
        self.orderLayer = 10
    end

    self:CheckMainui()
end

function ViewManager:CleanAllWindow()
    local closeWindows = {}
    for k, _ in pairs(self.windows) do
        table.insert(closeWindows, k)
    end
    for _, winName in ipairs(closeWindows) do
        local win = self.windows[winName]
        win:Destroy()
    end

    self.windowStack = {}
    self.windows = {}
    self.orderLayer = 10
    self.checkMainui = true
    
    -- 清理转场状态（避免黑幕残留）
    if self.transitionView then
        self.transitionView:Clean()
    end
end

function ViewManager:GetWindowParent()
    local windowParent = PoolManager.Instance:Pop(PoolType.object, PoolDefine.PoolKey.window_parent)
    if not windowParent then
        local parentObjAssets = PreloadManager.Instance:GetAsset(AssetPath.windowParent)
        windowParent = GameObject.Instantiate(parentObjAssets)
    end
    return windowParent
end

function ViewManager:GetPanelParent()
    local panelParent = PoolManager.Instance:Pop(PoolType.object, PoolDefine.PoolKey.panel_parent)
    if not panelParent then
        local parentObjAssets = PreloadManager.Instance:GetAsset(AssetPath.panelParent)
        panelParent = GameObject.Instantiate(parentObjAssets)
    end
    return panelParent
end

function ViewManager:Adaptive(rectTrans, adaptiveLeft, adaptiveRight)
    if not rectTrans then
        return
    end

    local notchHeight = DevicesManager.Instance:GetNotch()
    if adaptiveLeft and notchHeight > 0 then
        rectTrans.offsetMin = Vector2(notchHeight, 0)
        --rectTrans.offsetMax = Vector2(0,-notchHeight)
    end

    local bottomAdaptiveHeight = 0
    if adaptiveRight and bottomAdaptiveHeight > 0 then
        rectTrans.offsetMin = Vector2(0.0, bottomAdaptiveHeight)
    end
end

function ViewManager:CreateAdaptiveHeightMask()
    local maskAssets = PreloadManager.Instance:GetAsset(AssetPath.adaptiveHeightMask)
    self.adaptiveHeightMaskObj = GameObject.Instantiate(maskAssets)
    self.adaptiveHeightMaskObj.transform:SetParent(UIDefine.canvasRoot, false)
end

function ViewManager:ActiveAdaptiveHeightMask(flag)
    if self.adaptiveHeightMaskObj == nil then
        return
    end
    
    self.adaptiveHeightMaskObj:SetActive(flag)
end

function ViewManager:ExecuteBlackTransition(callback, className, isOpen)
    self.transitionView:ExecuteTransition(KvData.TransitionType.black, callback, className, isOpen)
end
