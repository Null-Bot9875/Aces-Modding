ViewStackManager = SingleClass("ViewStackManager")

function ViewStackManager:__Init()
    self.waitWindowInfos = {}
    self.curShowWindowInfo = nil
end


function ViewStackManager:Clean()
	self.waitWindowInfos = {}
    self.curShowWindowInfo = nil
end

function ViewStackManager:Push(win, args)
    table.insert(self.waitWindowInfos, {win = win, args = args})
    
end

function ViewStackManager:NextWindow()
    if not self.curShowWindowInfo or not ViewManager.Instance:IsOpenWindow(self.curShowWindowInfo.win) then --打开下一个界面
        if #self.waitWindowInfos > 0 then
            self.curShowWindowInfo = table.remove(self.waitWindowInfos, #self.waitWindowInfos)
            ViewManager.Instance:OpenWindow(self.curShowWindowInfo.win, self.curShowWindowInfo.args)
        end
    end
end

function ViewStackManager:Update()
    if #self.waitWindowInfos <= 0 then
        return
    end

    self:NextWindow()
end