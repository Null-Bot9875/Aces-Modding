UIEffect = BaseClass("UIEffect")

local uid = 0
local function GetUid()
    uid = uid + 1
    return uid
end

function UIEffect:__Init()
    self.uid = 0
    self.gameObject = nil
    self.transform = nil
    self.effect = nil
    self.setting = nil

    self.isActive = true
    self.isPool = false
    self.isLoad = false
    self.isPlay = false

    self.assetLoader = nil
    self.assetScope = nil

    self.playTimer = nil
    self.delayTimer = nil

    self.effectType = nil

    self.onComplete = nil

    self.effectPath = nil

    self.order = nil
end

function UIEffect:__Delete()
    self:RemoveLoader()
    self:ReleasePendingScope()
    if self.effect and not BaseUtils.IsNull(self.effect) then
        if self.isPool then
            PoolManager.Instance:Push(PoolType.object,self.effectPath,self.effect)
        else
            GameObject.Destroy(self.effect)
        end
        self.effect = nil
    end

    if self.gameObject and not BaseUtils.IsNull(self.gameObject) then
        PoolManager.Instance:Push(PoolType.object,PoolDefine.PoolKey.ui_empty_object,self.gameObject)
        self.gameObject = nil
        self.transform = nil
    end

    self:RemoveTimer()
end

--[[
    setting = {
        confId / assetId    配置ID / 资源ID
        delayTime           开始时间
        lastTime            持续时间
        pos                 位置
        scale               缩放
        isPool              是否缓存，默认true
        onLoad              加载完成回调
        onComplete          播放结束回调
        parent              挂载点
        order               层级
        timeScale           时间缩放
        effectType
        name
        layer               层级
        deleteOnComplete
    }
]]--
function UIEffect:Init(setting)
    self.setting = setting

    self.uid = GetUid()
    self.gameObject = BaseUtils.GetUIEmptyObject()
    self.transform = self.gameObject.transform

    if not self.setting.assetId then
        LogErrorAny("请指定UI特效的资源ID",self.setting)
        return
    end

    self:SetParent(self.setting.parent)

    if self.setting.pos then
        self:SetPos(self.setting.pos.x or 0,self.setting.pos.y or 0,self.setting.pos.z or 0)
    elseif  self.setting.worldPos then
        self:SetWorldPos(self.setting.worldPos.x or 0,self.setting.worldPos.y or 0,self.setting.worldPos.z or 0)
    end

    if self.setting.scale then
        self:SetScale(self.setting.scale,self.setting.scale,self.setting.scale)
    end

    if self.setting.rotate then
        self:SetRotate(self.setting.rotate.x or 0,self.setting.rotate.y or 0,self.setting.rotate.z or 0)
    end

    self.effectPath = string.format("effect/prefab/%s.prefab",tostring(self.setting.assetId))
    if not AssetLoader.Instance:IsLocationValid(self.effectPath) then
        self.effectPath = string.format("effect_outsrc/prefab/%s.prefab",tostring(self.setting.assetId))
    end

    
    self.isPool = self.setting.isPool or false
    self.effectType = self.setting.effectType
    self.onLoad = self.setting.onLoad
    self.onComplete = self.setting.onComplete
    self.order = self.setting.order

    self.gameObject.name = self.setting.name or string.format("effect:%s",tostring(self.setting.assetId))

    self:OnInit()
end

function UIEffect:GetId()
    return self.uid
end

function UIEffect:GetGroup()
    return self.setting.group or ""
end

function UIEffect:SetComplete(onComplete)
    self.onComplete = onComplete
end

function UIEffect:LoadEffect()
    if self.isLoad then
        return
    end
    self.isLoad = true

    local effect = PoolManager.Instance:Pop(PoolType.object,self.effectPath)
    if effect then
        effect.transform:SetParent(self.transform)
        self:SetEffect(effect)
    else
        self.assetScope = AssetScope()
        self.assetLoader = AssetBatchLoader.New(self.assetScope)
        self.assetLoader:Load({{file = self.effectPath,type = AssetType.Prefab}},self:ToFunc("EffectLoaded"))
    end
end

function UIEffect:EffectLoaded(_,hasError)
    if not self then
        return
    end
    if hasError then
        self:RemoveLoader()
        self:ReleasePendingScope()
        return
    end
    local effect = self.assetLoader:Instantiate(self.effectPath,self.transform,false)
    effect:AddComponent(AssetScopeComponent):Adopt(self.assetScope)
    self.assetScope = nil
    self:SetEffect(effect)
    self:RemoveLoader()
end

function UIEffect:SetEffect(effect)
    if not self then
        return
    end
    if not effect then
        LogError(string.format("UIEffect 加载特效失败:%s", self.effectPath or "unknown"))
        return
    end
    self.effect = effect
    self.effect.transform:Reset()

    local effectInfo = self.effect:GetComponent(EffectInfo)
    if not effectInfo then
        LogError(string.format("特效%s,不存在EffectInfo组件",self.effectPath))
        return
    end

    self.lastTime = effectInfo.lastTime


    self:SetOrder(self.order)
    local layer = self.setting.layer or KvData.Layer.ui
    BaseUtils.ChangeLayers(self.effect,layer)

    if self.onLoad then
        self.onLoad(self, self.setting.args)
    end

    self:BeginPlay()
end

function UIEffect:SetParent(parent)
    self.transform:SetParent(parent)
    self.transform:Reset()
end

function UIEffect:SetPos(x,y,z)
    self.transform:SetAnchoredPosition3D(x,y,z)
    -- if self.setting.pos then
    --     local offsetX = self.setting.pos.x or 0
    --     local offsetY = self.setting.pos.y or 0
    --     self.transform:SetAnchoredPosition(x + offsetX,y + offsetY)
    -- end
end

function UIEffect:SetWorldPos(x,y,z)
    self.transform:SetPosition(x,y,z)
    -- if self.setting.pos then
    --     local offsetX = self.setting.pos.x or 0
    --     local offsetY = self.setting.pos.y or 0
    --     local offsetZ = self.setting.pos.z or 0
    --     self.transform:SetPosition(x + offsetX,y + offsetY,z + offsetZ)
    -- end
end

function UIEffect:SetScale(x,y,z)
    x = x or 1000
    y = y or 1000
    z = z or 1000
    self.transform:SetLocalScale(x * 0.001,y * 0.001,z * 0.001)
end

function UIEffect:SetRotate(x,y,z)
    self.transform:SetLocalEulerAngles(x * 0.001,y * 0.001,z * 0.001)
end

function UIEffect:RefreshWorldPos()
    
end


function UIEffect:SetOrder(order)
    self.order = order
    if self.order and self.effect and not BaseUtils.IsNull(self.effect) then
        UIUtils.SetEffectSortingOrder(self.effect,self.order)
    end
end

function UIEffect:BeginPlay()
    if not self.effect or not self.isPlay then
        return
    end

    self:SetActive(true)
    if self.lastTime > 0 then
        self.playTimer = TimerManager.Instance:AddTimer(1,self.lastTime * 0.001, self:ToFunc("PlayComplete") )
        self.playTimer:SetScale(self.setting.timeScale == nil and true or self.setting.timeScale)
    end
end

function UIEffect:GetDuration()
    return self.lastTime
end

function UIEffect:PlayComplete()
    self.playTimer = nil
    self.isPlay = false

    if self.onComplete then
        self.onComplete(self.uid,self.setting.args)
    end

    if self:IsValid() then
        if not self.setting.notAutoHide then
            self:SetActive(false)
        end
        
        if self.setting.autoDelete then
            self:Delete()
        end
    end
end

function UIEffect:RemoveLoader()
	if self.assetLoader then 
        self.assetLoader:Destroy()
	    self.assetLoader = nil 
    end
end

function UIEffect:SetActive(flag)
    if self.isActive ~= flag and not BaseUtils.IsNull(self.gameObject) then
        self.isActive = flag
        self.gameObject:SetActive(flag)
    end
end

function UIEffect:Play()
    if self.isPlay then
        return
    end

    self.isPlay = true
    self:LoadEffect()
    if self.setting.delayTime and self.setting.delayTime > 0 then
        self:DelayPlay()
    else
        self:BeginPlay()
    end

    -- self:OnPlay()
end

function UIEffect:DelayPlay()
    self:SetActive(false)
    self.delayTimer = TimerManager.Instance:AddTimer(1,self.setting.delayTime * 0.001, self:ToFunc("DelayComplete") )
    self.delayTimer:SetScale(self.setting.timeScale == nil and true or self.setting.timeScale)
end

function UIEffect:DelayComplete()
    self.delayTimer = nil
    self:BeginPlay()
end

function UIEffect:Stop()
    self.isPlay = false
    self:SetActive(false)
    self:RemoveTimer()
end

function UIEffect:RemoveTimer()
    if self.delayTimer then 
        TimerManager.Instance:RemoveTimer(self.delayTimer)
        self.delayTimer = nil
    end
    if self.playTimer then 
        TimerManager.Instance:RemoveTimer(self.playTimer)
        self.playTimer = nil
    end
end

function UIEffect:IsActive()
    return self.isActive
end

function UIEffect:IsValid()
    return self.gameObject ~= nil
end

--虚函数
function UIEffect:OnInit()
end
function UIEffect:OnPlay()
end

function UIEffect:ReleasePendingScope()
    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end
