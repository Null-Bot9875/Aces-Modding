KvData = {}

KvData.PlatformType =
{
	["WindowsEditor"] = 7,
	["OSXEditor"] = 0,
	["IPhonePlayer"] = 8,
	["Android"] = 11,
	["OSXPlayer"] = 1,
	["WindowsPlayer"] = 2,
	["WebGLPlayer"] = 17,
}

KvData.DeviceLevel =
{
	low = 1,
	middle = 2,
	high = 3,
}

KvData.platform = nil

KvData.mainCamera = nil


KvData.Layer = 
{
    default = LayerMask.GetMask("Default"), --默认层
	layer6 =  LayerMask.NameToLayer("Layer6"), --战斗对象层
	layer7 =  LayerMask.NameToLayer("Layer7"), --战斗特效层
	layer8 =  LayerMask.NameToLayer("Layer8"), --战斗射线层/表现层
	layer9 =  LayerMask.NameToLayer("Layer9"), --战斗操作层
	layer10 = LayerMask.NameToLayer("Layer10"), --战斗遮罩层
	ui = LayerMask.NameToLayer("UI"), 	     	--UI层
}

KvData.screenCenter = Vector2(Screen.width * 0.5,Screen.height * 0.5)



KvData.RoleData =
{
	none = 0,
	max_hp = 1, --最大血量
	max_action = 2, --最大行动力
	money = 3, --金钱
	mind = 4, --心智
	feel = 5, --感知
	strength = 6,--力量
	san = 7,--理智
	calm = 8,--平静


	--token
	clue = 50, --线索
	gift = 51, -- 灵感

	--
	hp = 100,--血量
	action = 101,--行动力
}


KvData.RoleDataToName =
{
	[KvData.RoleData.mind] = "心智"
}

KvData.ConfigRoleData =
{
	["血量"] = KvData.RoleData.hp,
	["行动力"] = KvData.RoleData.action,
	["金钱"] = KvData.RoleData.money,
	["心智"] = KvData.RoleData.mind,
	["感知"] = KvData.RoleData.feel,
	["力量"] = KvData.RoleData.strength,
	["理智"] = KvData.RoleData.san,
	["平静"] = KvData.RoleData.calm,

	["线索"] = KvData.RoleData.clue,
	["灵感"] = KvData.RoleData.gift,

	["血量"] = KvData.RoleData.hp,
	["行动力"] = KvData.RoleData.action,
}




KvData.Attr =
{
	max_hp = 101, --最大血量
	max_shield = 102, --最大护盾
	atk = 103, --攻击力
	str = 104, --力量
	int = 105, --智力
	dex = 106, --敏捷
	con = 107, --体质
	sp = 108, --意志
	luk = 109, --幸运
	
}

KvData.AttrToName =
{
	[KvData.Attr.max_hp] = "max_hp",  --最大生命值
	[KvData.Attr.max_shield] = "max_shield", --最大护盾
	[KvData.Attr.atk] = "atk", --攻击力
	[KvData.Attr.str] = "str", --力量
	[KvData.Attr.int] = "int", --智力
	[KvData.Attr.dex] = "dex", --敏捷
	[KvData.Attr.con] = "con",  --体质
	[KvData.Attr.sp] = "sp", --意志
	[KvData.Attr.luk] = "luk", --幸运
}

KvData.AttrNameToId =
{
	[KvData.AttrToName[KvData.Attr.max_hp]] = KvData.Attr.max_hp,
	[KvData.AttrToName[KvData.Attr.max_shield]] = KvData.Attr.max_shield,
	[KvData.AttrToName[KvData.Attr.atk]] = KvData.Attr.atk,
	[KvData.AttrToName[KvData.Attr.str]] = KvData.Attr.str,
	[KvData.AttrToName[KvData.Attr.int]] = KvData.Attr.int,
	[KvData.AttrToName[KvData.Attr.dex]] = KvData.Attr.dex,
	[KvData.AttrToName[KvData.Attr.con]] = KvData.Attr.con,
	[KvData.AttrToName[KvData.Attr.sp]] = KvData.Attr.sp,
	[KvData.AttrToName[KvData.Attr.luk]] = KvData.Attr.luk,
}

KvData.ItemMap = 
{
	iskra_credit = 1001, -- 星火币
}

KvData.DeviceType =
{
	none = 0, --无
	engine = 1, --引擎
	armor = 2, --装甲
	frame = 3, --框架
	weapon = 4, --武器
	extra = 5, --额外
	carrier1 = 6, --基础整备班
	carrier2 = 7, --基础能源协议
    mode = 8,--模式
    ultimate = 9,-- 终结技
}

KvData.DeviceTypeStrMap = 
{
	[KvData.DeviceType.none] = "none",
	[KvData.DeviceType.engine] = "engine",
	[KvData.DeviceType.armor] = "armor",
	[KvData.DeviceType.frame] = "frame",
	[KvData.DeviceType.weapon] = "weapon",
	[KvData.DeviceType.extra] = "extra",
	[KvData.DeviceType.carrier1] = "carrier1",
	[KvData.DeviceType.carrier2] = "carrier2",
	[KvData.DeviceType.mode] = "mode",
	[KvData.DeviceType.ultimate] = "ultimate",
}

KvData.RareType =
{
	default = 0,
	c = 1,
	u = 2,
	r = 3,
	sr = 4,
	exr = 5,
}

KvData.CardRareStrMap = 
{
	[KvData.RareType.default] = "c",
	[KvData.RareType.c] = "c",
	[KvData.RareType.u] = "u",
	[KvData.RareType.r] = "r",
	[KvData.RareType.sr] = "ser",
	[KvData.RareType.exr] = "exr",
}

KvData.CardRareStrMap2 = 
{
	[KvData.RareType.default] = "C",
	[KvData.RareType.c] = "C",
	[KvData.RareType.u] = "U",
	[KvData.RareType.r] = "R",
	[KvData.RareType.sr] = "SER",
	[KvData.RareType.exr] = "EXR",
}

KvData.Bone = 
{
	floot = 1,--脚底
	hit = 2,--命中

	root = 100, --根节点（不带有任何旋转）
	origin = 101,--模型原点（跟随模型旋转）
	custom = 102,
}

KvData.BoneName = 
{
	floot = "bp_root",
	hit = "bp_hit",

	root = "root",
	origin = "origin",
	custom = "custom",
	buff = "bp_buff"
}

KvData.BoneIndex = 
{
	[KvData.Bone.floot] = KvData.BoneName.floot,
	[KvData.Bone.hit] = KvData.BoneName.hit,

	[KvData.Bone.root] = KvData.BoneName.root,
	[KvData.Bone.origin] = KvData.BoneName.origin,
	[KvData.Bone.custom] = KvData.BoneName.custom,
}

KvData.UIPivot = 
{
	left_top = Vector2(0,1),
	left_bottom = Vector2(0,0),
	right_top = Vector2(1,1),
	right_bottom = Vector2(1,0),
	center = Vector2(0.5,0.5),
	middle_left = Vector2(0,0.5),
	middle_right = Vector2(1,0.5),
	middle_top = Vector2(0.5,1),
	middle_bottom = Vector2(0.5,0),
}


KvData.CardTypeMap =
{
    [1] = BattleDefine.CardType.green,
    [2] = BattleDefine.CardType.red,
    [3] = BattleDefine.CardType.blue,
    [4] = BattleDefine.CardType.white,
    [5] = BattleDefine.CardType.yellow,
}

-- 双色设计废除
-- 按位或运算
KvData.CardType = 
{
    green = 1,         -- 绿色
    red = 2,           -- 红色
    green_red = 3,     -- 绿红
    blue = 4,          -- 蓝色
    green_blue = 5,    -- 绿蓝
    red_blue = 6,      -- 红蓝
    white = 8,         -- 白色
    green_white = 9,   -- 绿白
    red_white = 10,    -- 红白
    blue_white = 12,   -- 蓝白
    yellow = 16,       -- 黄色
    green_yellow = 17, -- 绿黄
    red_yellow = 18,   -- 红黄
    blue_yellow = 20,  -- 蓝黄
    white_yellow = 24, -- 白黄
    all_color = 31,    -- 全色
	pupple = 32,       -- 紫色
}

KvData.ColorRareStrMap =
{
	[KvData.CardType.green] = "GREEN",
	[KvData.CardType.red] = "RED",
	[KvData.CardType.blue] = "BLUE",
	[KvData.CardType.white] = "WHITE",
	[KvData.CardType.yellow] = "YELLOW",
	[KvData.CardType.green_red] = "GREEN_RED",
	[KvData.CardType.green_blue] = "GREEN_BLUE",
	[KvData.CardType.red_blue] = "RED_BLUE",
	[KvData.CardType.green_white] = "GREEN_WHITE",
	[KvData.CardType.red_white] = "RED_WHITE",
	[KvData.CardType.blue_white] = "BLUE_WHITE",
	[KvData.CardType.green_yellow] = "GREEN_YELLOW",
	[KvData.CardType.red_yellow] = "RED_YELLOW",
	[KvData.CardType.blue_yellow] = "BLUE_YELLOW",
	[KvData.CardType.white_yellow] = "WHITE_YELLOW",
	[KvData.CardType.all_color] = "ALL_COLOR",
	[KvData.CardType.pupple] = "PUPPLE",
}

KvData.PointerType = 
{
	none = 0,
	pointerDown = 1,
	pointerUp = 2,
	pointerClick = 3,
	pointerLongPress = 4,
	pointerDrag = 5,
	pointerBeginDrag = 6,
	pointerEndDrag = 7,
	pointerEnter = 8,
	pointerExit = 9,
	rightClick = 10,
	rightDown = 11,
	rightUp = 12,
}

KvData.frameCountPerSecond = 24


KvData.ArmType = 
{
    arm = "arm",--手臂
    armour = "armour", --装甲
    back = "back",--背包
}

KvData.TransitionType = 
{
	none = 0,
	-- 1~10 为全局转场动画
    black = 1,

	-- 11以上, 为view自身的转场动画
    fade = 11,
}

--------------------------------------------------------------------------------------------------

KvData.frameCount = 0

KvData.luaDebug = false

KvData.standardScreenWidth  = 720
KvData.standardScreenHeight = 1280
KvData.curScreenWidth  = 0
KvData.curScreenHeight = 0

KvData.minScreenWidth  = 0
KvData.minScreenHeight = 0
KvData.maxScreenWidth  = 0
KvData.maxScreenHeight = 0


--全局变量
IS_DEBUG = false --是否调试（编辑器、pc环境一定为true，其它平台根据特殊操作开启）
IS_EDITOR = false --是否编辑器环境
IS_PC = false --是否PC端
SHOW_CARD_ID = false --是否显示卡牌与战斗道具ID
SHOW_CARD_ID_SETTING_KEY = "Settings.ShowCardIds"

DISPLAY_MECHA_MODEL_USE_RT = true --主界面机甲展示是否使用摄像机渲染到rendertexture的方式展示，否的话使用叠加摄像机的方式展示
IS_SMALL_SCREEN = false --是否是小屏幕


KvData.jit = false

KvData.enableCardDeferredClear = false
