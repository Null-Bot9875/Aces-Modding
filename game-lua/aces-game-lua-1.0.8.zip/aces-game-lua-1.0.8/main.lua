require "base/setup"

function Main()
    LogInfo("当前平台:"..tostring(Application.platform))
    LogInfof("1屏幕宽:%s,高:%s", Screen.width, Screen.height)
    
    InitSetting()

    InitObject()

    InitClass()

    ModRuntime.StartClient()

    GameManager.Instance:Start()
    ModRuntime.BindClientLifecycle()
end

function InitObject()
    local eventSystem = GameObject.Find("EventSystem")
    UIDefine.eventSystem = eventSystem.gameObject
    GameObject.DontDestroyOnLoad(UIDefine.eventSystem)

    UIDefine.canvasRoot = GameObject.Find("Canvas").transform
    GameObject.DontDestroyOnLoad(UIDefine.canvasRoot.gameObject)

    local overlayObj = GameObject.Find("CanvasOverlay")
    UIDefine.canvasOverlay = overlayObj.transform
    local canvas = overlayObj:GetComponent(Canvas)
    canvas.renderMode = RenderMode.ScreenSpaceOverlay
    GameObject.DontDestroyOnLoad(UIDefine.canvasOverlay.gameObject)

    UIDefine.additionalShaderChannels = UIDefine.canvasRoot.gameObject:GetComponent(Canvas).additionalShaderChannels
    local size = UIDefine.canvasRoot.sizeDelta
    KvData.curScreenWidth  = size.x
    KvData.curScreenHeight = size.y

    KvData.minScreenWidth  = BaseSetting.minScreenWidth
    KvData.minScreenHeight = BaseSetting.minScreenHeight
    KvData.maxScreenWidth  = BaseSetting.maxScreenWidth
    KvData.maxScreenHeight = BaseSetting.maxScreenHeight

    LogInfof("2屏幕宽:%s,高:%s", KvData.curScreenWidth, KvData.curScreenHeight)


    local mixedObj = GameObject("mixed")
    local rectTrans = mixedObj:AddComponent(RectTransform)
    rectTrans.anchorMin = Vector2.zero
    rectTrans.anchorMax = Vector2.zero
    mixedObj.transform:SetParent(UIDefine.canvasRoot)
    mixedObj.transform:Reset()
    mixedObj.transform:SetSizeDelata(0,0)

    local calcPosNode = GameObject("calc_pos_node")
    calcPosNode:AddComponent(RectTransform)
    calcPosNode.transform:SetParent(mixedObj.transform)
    calcPosNode.transform:Reset()
    calcPosNode.transform:SetSizeDelata(0,0)

    local layoutEle = calcPosNode:AddComponent(LayoutElement)
    layoutEle.ignoreLayout = true

    local gameObject = GameObject.Find("DEBUG")
    gameObject:SetActive(IS_DEBUG)

    UIDefine.calcPosNode = calcPosNode.transform


    local templateNode = GameObject("template")
    templateNode:AddComponent(RectTransform)
    templateNode.transform:SetParent(mixedObj.transform)
    templateNode.transform:Reset()
    templateNode.transform:SetSizeDelata(0,0)
    templateNode:SetActive(false)


	UIDefine.uiCamera = GameObject.Find("UICamera"):GetComponent(Camera)
    GameObject.DontDestroyOnLoad(UIDefine.uiCamera.gameObject)

    KvData.mainCamera = GameObject.Find("MainCamera"):GetComponent(Camera)
    KvData.mainCamera.gameObject:AddComponent(Skybox)
    GameObject.DontDestroyOnLoad(KvData.mainCamera.gameObject)


    local richTemplateParent = GameObject("rich_template_parent")
    local canvasGroup = richTemplateParent:AddComponent(CanvasGroup)
    canvasGroup.alpha = 0
    canvasGroup.blocksRaycasts = false
    canvasGroup.interactable = false
    richTemplateParent.transform:SetParent(UIDefine.canvasRoot)
    richTemplateParent.transform:Reset()
    UIDefine.richTemplateParent = richTemplateParent.transform

    -- 创建叠黑转场蒙层
    local transBlackMask = GameObject("ui_interface_trans")
    transBlackMask.transform:SetParent(UIDefine.canvasOverlay)
    transBlackMask.transform:Reset()

    local transRectTrans = transBlackMask:AddComponent(RectTransform)
    transRectTrans.anchorMin = Vector2.zero
    transRectTrans.anchorMax = Vector2.one
    transRectTrans.offsetMin = Vector2.zero
    transRectTrans.offsetMax = Vector2.zero
    
    local transImage = transBlackMask:AddComponent(Image)
    transImage.color = Color.black  -- 纯黑色
    transImage.raycastTarget = true  -- 接受射线检测，用于阻挡操作
    
    local transCanvasGroup = transBlackMask:AddComponent(CanvasGroup)
    transCanvasGroup.alpha = 0  -- 初始透明
    transCanvasGroup.blocksRaycasts = false  -- 初始不阻挡（黑屏时会设为 true）
    transCanvasGroup.interactable = false  -- 不可交互

    local canvas = transBlackMask:AddComponent(Canvas)
    canvas.overrideSorting = true
    canvas.sortingOrder = 32767 - 10
    
    UIDefine.transBlackMask = transBlackMask.transform
    UIDefine.transBlackMaskCanvasGroup = transCanvasGroup

    PointerHandler.longPressTime = 0.2

    RenderSettings.skybox = nil
    KvData.mainCamera.clearFlags = CameraClearFlags.SolidColor
    KvData.mainCamera.gameObject:GetComponent(Skybox).material = nil
end

function InitClass()
    GameManager.New()
end

function ModuleSetup(module)
    local class = GetClass(module)
    if class == nil then LogErrorf("无法找到模块入口[%s]",module) return end
	local facade =  class.New(class)
end

function Update()
    GameManager.Instance:Update()
    ModRuntime.UpdateClient(Time.deltaTime)
end

function LateUpdate()
    GameManager.Instance:LateUpdate()
end

function StopModRuntime()
    ModRuntime.StopClient()
end

function RegisterDeveloperConsoleCommands()
    if mod and mod.GmCtrl then
        mod.GmCtrl:RegisterDeveloperConsoleCommands()
    end
end

function ExecuteDeveloperConsoleCommand(command, args)
    if not mod or not mod.GmCtrl then
        error("GmCtrl is unavailable")
    end

    local luaArgs = {}
    if type(args) == "table" then
        luaArgs = args
    elseif args then
        for index = 0, args.Length - 1 do
            table.insert(luaArgs, args[index])
        end
    end
    mod.GmCtrl:ExecuteDeveloperConsoleCommand(command, luaArgs)
end

local function StopLocalServer()
    local localServerMode = LocalServerMode and LocalServerMode.Instance
    if localServerMode then
        localServerMode:StopLocalServer()
    end
end

function OnApplicationFocus(flag)
    GameManager.Instance:OnApplicationFocus(flag)
end

function OnApplicationQuit()
    StopLocalServer()
    StopModRuntime()
    GameManager.Instance:OnApplicationQuit()
end

function InitPlatform()
    
end

function InitSetting()
    KvData.luaDebug = BaseSetting.debug and BaseSetting.luaDebug

    if Application.platform == RuntimePlatform.Android then
        KvData.platform = KvData.PlatformType.Android
        -- Application.targetFrameRate = 30
        -- BaseApi:HideBar()
    elseif Application.platform == RuntimePlatform.IPhonePlayer then
        KvData.platform = KvData.PlatformType.IPhonePlayer
    elseif Application.platform == RuntimePlatform.WindowsEditor then
        KvData.platform = KvData.PlatformType.WindowsEditor
        IS_DEBUG = true
        IS_EDITOR = true
        IS_PC = true
    elseif Application.platform == RuntimePlatform.OSXEditor then
        KvData.platform = KvData.PlatformType.OSXEditor
        IS_DEBUG = true
        IS_EDITOR = true
        IS_PC = true
    elseif Application.platform == RuntimePlatform.OSXPlayer then
        KvData.platform = KvData.PlatformType.OSXPlayer
        IS_DEBUG = true
        IS_PC = true
    elseif Application.platform == RuntimePlatform.WindowsPlayer then
        KvData.platform = KvData.PlatformType.WindowsPlayer
        IS_PC = true
    elseif Application.platform == RuntimePlatform.WebGLPlayer then
        KvData.platform = KvData.PlatformType.WebGLPlayer
        IS_DEBUG = true
    end

    if BaseSetting.debug or PlayerPrefsEx.GetInt("IS_DEBUG", 0) > 0  then
        IS_DEBUG = true
    end
    SHOW_CARD_ID = PlayerPrefsEx.GetInt(SHOW_CARD_ID_SETTING_KEY, 0) > 0

    DISPLAY_MECHA_MODEL_USE_RT = IS_PC
    IS_SMALL_SCREEN = Application.isMobilePlatform

    -- if PlayerPrefsEx.GetInt("IS_DEBUG", 0) == 0 then
    --     IS_DEBUG = false
    -- end

    --TODO:调试阶段，先开启
end
