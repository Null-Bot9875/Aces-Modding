BagFacade = BaseClass("BagFacade",Facade)
BagFacade.Event = EventEnum.New(
	"UseCardRet"
)
function BagFacade:__Init()

end

function BagFacade:__InitFacade()
    self:BindProxy(BagProxy)
    self:BindCtrl(BagCtrl)
end
