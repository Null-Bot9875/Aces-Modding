BagCtrl = BaseClass("BagCtrl", Controller)

function BagCtrl:__Init()
end

function BagCtrl:__Delete()

end

function BagCtrl:__InitComplete()

end


function BagCtrl:ParseItemReturnInfo(ris)
    local itemReturnInfos = {}
    for i = 1, #ris do
        local retrurnInfo = ris[i]
        table.insert(itemReturnInfos, retrurnInfo)
    end

    -- 获得道具界面
    ViewManager.Instance:OpenWindow(PropGetWindow, { ris = itemReturnInfos })
end


function BagCtrl:GetCanExchangeCfgById(itemId)
    local num = Config.GetNum("item_exchange_def", "config")
    for i = 1, num do
        local conf = Config.Get("item_exchange_def", "config", "index", i)
        if conf.targetItemId == itemId then
            return conf
        end
    end
    return nil
end

function BagCtrl:ParseCardPvpReturnInfo(ris)
    local cardReturnInfos = {}
    for i = 1, #ris do
        local retrurnInfo = ris[i]
        if retrurnInfo.effect == CommonDefine.Effect.cardPvp then
            table.insert(cardReturnInfos, retrurnInfo)
        end
    end

    if #cardReturnInfos > 0 then
        ViewManager.Instance:OpenWindow(CardDisplayWindow, { returnInfos = cardReturnInfos })
    end
end


function BagCtrl:ParseBasePvpReturnInfo(ris)
    local cardReturnInfos = {}
    for i = 1, #ris do
        local retrurnInfo = ris[i]
        if retrurnInfo.effect == CommonDefine.Effect.basePvp then
            table.insert(cardReturnInfos, retrurnInfo)
        end
    end

    if #cardReturnInfos > 0 then
        ViewManager.Instance:OpenWindow(CardDisplayWindow, { returnInfos = cardReturnInfos })
    end
end

function BagCtrl:ParseReturnInfo(ris)
    local effectMap = {}
    for _, v in ipairs(ris) do
        if effectMap[v.effect] == nil then
            effectMap[v.effect] = {}
        end

        table.insert(effectMap[v.effect], v)
    end

    for k, v in pairs(effectMap) do
        if k == CommonDefine.Effect.item then
            self:ParseItemReturnInfo(v)
        elseif k == CommonDefine.Effect.cardPvp then
            self:ParseCardPvpReturnInfo(v)
        elseif k == CommonDefine.Effect.basePvp then
            self:ParseBasePvpReturnInfo(v)
        end
    end
end
