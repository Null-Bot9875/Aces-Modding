BagDefine = StaticClass("BagDefine")

BagDefine.PropKind = {
    Consume = 1,
    Material = 2,
    ImportantAsset = 3,
    CardPack = 4,
    Card = 5,
}

BagDefine.BagKindName = 
{
    [BagDefine.PropKind.Consume] = TI18N("item_kind_consume"),
    [BagDefine.PropKind.Material] = TI18N("item_kind_material"),
    [BagDefine.PropKind.ImportantAsset] = TI18N("item_kind_important")
}


BagDefine.CoinDefine = {
    Xinghuo = 1001,
    wAgnerMetal = 1002,
    energy = 1003,
    research = 1004,
}

BagDefine.ItemType = {
    Currency = 1,
    Prop = 2,
}