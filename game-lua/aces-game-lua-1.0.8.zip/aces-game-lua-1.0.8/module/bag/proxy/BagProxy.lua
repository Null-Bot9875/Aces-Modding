BagProxy = BaseClass("BagProxy",Proxy)

function BagProxy:__Init()
    self.itemBag = {}
    self.packInfos = {}
end

function BagProxy:__InitProxy()
    self:BindMsg(3401) -- 物品更新
    self:BindMsg(3402) -- 物品删除通知
    self:BindMsg(3403) -- 物品使用
    self:BindMsg(3405) -- 手动物品删除

    self:BindMsg(3404) -- 兑换

    
    self:BindMsg(3406) -- 开包使用

    self:BindMsg(3050)--仓库背包通知
end


--仓库背包通知
function BagProxy:Recv_3050(data)
    LogTable("接收3050", data)
    self.itemBag = data.itemBag
    for k, v in pairs(data.packInfos) do
        self:AddSinglePackInfo(v)
    end
end


function BagProxy:AddSinglePackInfo(packInfo)
    if not self.packInfos[packInfo.id] then
        self.packInfos[packInfo.id] = {}
    end
    self.packInfos[packInfo.id] = packInfo    
end

--物品更新通知
function BagProxy:Recv_3401(data)
    LogTable("接收3401", data)

    mod.BagProxy:SetItemOne(data.info)
    mod.PveFacade:SendEvent(PveFacade.Event.RefreshPlyaerInfo)

    EventManager.Instance:SendEvent(EventDefine.on_prop_update, data.info)
end

--物品删除通知
function BagProxy:Recv_3402(data)
    LogTable("接收3402", data)

    mod.BagProxy:DelItemOne(data.id)
    mod.PveFacade:SendEvent(PveFacade.Event.RefreshPlyaerInfo)

    EventManager.Instance:SendEvent(EventDefine.on_prop_delete, data.id)
end

--物品使用请求
function BagProxy:Send_3403(id, count)
    local data = {}
    data.id = id
    data.count = count
    LogTable("发送3403", data)
    return data
end

--物品使用返回
function BagProxy:Recv_3403(data)
    LogTable("接收3403", data)
end


--手动删除物品请求
function BagProxy:Send_3405(ids)
    local data = {}
    data.ids = ids
    LogTable("发送3405", data)
    return data
end


--手动删除物品返回
function BagProxy:Recv_3405(data)
    LogTable("接收3405", data)
    
    EventManager.Instance:SendEvent(EventDefine.on_prop_delete_handle, data.ids)
end

--兑换请求
function BagProxy:Send_3404(targetItemId, count, costItemId)
    local data = {}
    data.targetItemId = targetItemId
    data.count = count
    data.costItemId = costItemId
    LogTable("发送3404", data)
    return data
end

--兑换返回
function BagProxy:Recv_3404(data)
    LogTable("接收3404", data)
    mod.CommonChangeProxy:ParseReturnInfo(data.ris,CommonDefine.ReturnInfoIndexMap[3404])
end


--卡包使用
function BagProxy:Send_3406(id, count)
    local data = {}
    data.id = id
    data.count = count
    LogTable("发送3406", data)
    return data
end

--卡包使用返回
function BagProxy:Recv_3406(data)
    LogTable("接收3406", data)
    self:AddSinglePackInfo(data.packInfo)
    --data.ris
    ViewManager.Instance:OpenWindow(CardOpenWindow, {itemUid = data.id, id = data.packInfo.id, ris = data.ris, count = data.count})
    mod.CommonChangeProxy:ParseReturnInfo(data.extraRis,CommonDefine.ReturnInfoIndexMap[3406])
    
    mod.BagFacade:SendEvent(BagFacade.Event.UseCardRet)
end


----------------------------数据处理--------------------------------
function BagProxy:GetAllItemBag()
    return self.itemBag
end

function BagProxy:GetItemDataById(id)
    for k, v in pairs(self.itemBag) do
        if v.id == id then
            return v            
        end
    end
end

function BagProxy:GetItemCount(itemId)
    local count = 0
    for _, value in ipairs(self.itemBag) do
        if value.itemId == itemId then
            count = count + value.count
        end
    end

    return count
end

function BagProxy:SetItemOne(itemOne)
    for index, value in ipairs(self.itemBag) do
        if value.id == itemOne.id then
            self.itemBag[index] = itemOne
            return
        end
    end

    table.insert(self.itemBag, itemOne)
end

function BagProxy:DelItemOne(id)
    for index, value in ipairs(self.itemBag) do
        if value.id == id then
            table.remove(self.itemBag, index)
            return
        end
    end
end


function BagProxy:GetCardBagList()
    local cardBagDatas = {}
    for k, v in pairs(self.itemBag) do    
        local itemCfg = Config.Get("item_def", "config", "id", v.itemId)
        if itemCfg and itemCfg.kind == BagDefine.PropKind.CardPack then
            table.insert(cardBagDatas, v)
        end
    end

    return cardBagDatas
end


function BagProxy:GetPackInfoById(id)
    return self.packInfos[id]
end