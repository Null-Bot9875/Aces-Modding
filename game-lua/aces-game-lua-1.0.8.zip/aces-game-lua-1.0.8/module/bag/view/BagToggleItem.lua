BagToggleItem = BaseClass("BagToggleItem", BaseView)
function BagToggleItem:__Init()
end

function BagToggleItem:__CacheObject()
    self.bgBtn = self:Find("clickArea", Button)
    self.selectNode = self:Find("selectNode").gameObject
    self.nameText = self:Find("clickArea/text", TextMeshProUGUI)
    self.selectNameText = self:Find("selectNode/text", TextMeshProUGUI)
end

function BagToggleItem:__BindListener()
    self.bgBtn:SetClick(self:ToFunc("OnBgBtnClick"))
end

function BagToggleItem:__Show()
    self.nameText.text = self.args.name
    self.selectNameText.text = self.args.name
end


function BagToggleItem:SetSelect(isSelect)
    self.selectNode:SetActive(isSelect)
end

function BagToggleItem:SetClickCallback(callback, args)
    self.clickCallback = callback
    self.clickArgs = args
end


function BagToggleItem:OnBgBtnClick()
    if self.clickCallback then
        self.clickCallback(self.clickArgs)
    end
end