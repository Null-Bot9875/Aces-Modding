BagWindow = BaseClass("BagWindow", BaseWindow)
BagWindow.timerName = "ItemTimeLimit"

function BagWindow:__Init()
    self:SetAsset("ui/prefab/bag/bag_window.prefab", AssetType.Prefab)
    self.capacityNum = 108
    self.kindArray = {BagDefine.PropKind.Consume,BagDefine.PropKind.Material,BagDefine.PropKind.ImportantAsset}
    self.kindToggleItems = {}
    self.itemGrids = {}
    self.cacheItemGrids = {}
    self.defaultSelKind = BagDefine.PropKind.Consume
end

function BagWindow:__Create()
end

function BagWindow:__Delete()
    for k, v in pairs(self.kindToggleItems) do
        v:Destroy()
    end

    for k, v in pairs(self.itemGrids) do
        v:Destroy()
    end

    for k, v in pairs(self.cacheItemGrids) do
        v:Destroy()
    end
    
    
    if self.numInputItem then
        self.numInputItem:Destroy()
    end

    self:RemoveLimitTimer()

    if self.topLeftItem then
        self.topLeftItem:Destroy()
        self.topLeftItem = nil
    end

    
    EventManager.Instance:RemoveEvent(EventDefine.on_prop_delete,self:ToFunc("OnPropDelete"))
    EventManager.Instance:RemoveEvent(EventDefine.on_prop_delete_handle,self:ToFunc("OnPropDeleteHandle"))
    EventManager.Instance:RemoveEvent(EventDefine.on_prop_update,self:ToFunc("OnPropUpdate"))
end

function BagWindow:__CacheObject()
    self.gridScrollRect = self:Find("main/gridScrollView", ScrollRect)
    self.kindItemTemplate = self:Find("template/kindItem").gameObject
    self.gridItemTemplate = self:Find("template/gridItem").gameObject
    self.kindListNode = self:Find("back/adapt_left/kindList").gameObject
    
    self.cacheNode = self:Find("template/cache").transform
    self.topLeftItemObj = self:Find("back/adapt_left/top_left_item").gameObject

    self.propDetailNode = self:Find("main/prop_detail").gameObject
    self.propNameTxt = self:Find("main/prop_detail/prop_name", TextMeshProUGUI)
    self.qualityLineImg = self:Find("main/prop_detail/quality_line_img", Image)
    
    self.descTxt = self:Find("main/prop_detail/desc_txt", TextMeshProUGUI)
    self.expireTimeTxt = self:Find("main/prop_detail/expire_time", TextMeshProUGUI)
    self.propTypeTxt = self:Find("main/prop_detail/prop_type", TextMeshProUGUI) 

    self.inputNode = self:Find("main/prop_detail/operate_node/inputNode").gameObject
    self.noPropTipsNode = self:Find("main/no_prop_tips").gameObject

    self.operateNode = self:Find("main/prop_detail/operate_node").gameObject
    
end

function BagWindow:__BindListener()
    self:Find("main/prop_detail/operate_node/use_btn", Button):SetClick(self:ToFunc("OnUseBtnClick"))
    self:Find("main/prop_detail/delete_btn", Button):SetClick(self:ToFunc("OnDeleteBtnClick"))
end


function BagWindow:__BindEvent()
    EventManager.Instance:AddEvent(EventDefine.on_prop_delete,self:ToFunc("OnPropDelete"))
    EventManager.Instance:AddEvent(EventDefine.on_prop_delete_handle,self:ToFunc("OnPropDeleteHandle"))
    EventManager.Instance:AddEvent(EventDefine.on_prop_update,self:ToFunc("OnPropUpdate"))
end

function BagWindow:__Show()
    if not self.topLeftItem then
        self.topLeftItem = TopLeftItem.New()
        self.topLeftItem:SetObject(self.topLeftItemObj.gameObject)
    end

    if not self.numInputItem then
        self.numInputItem = NumInputItem.New()
        self.numInputItem:SetObject(self.inputNode)
        self.numInputItem:SetNumChangeCallback(self:ToFunc("OnNumChange"))
    end
    self.numInputItem:Hide()

    local args = {}
    args.title = TI18N("bag")
    args.win = self
    args.helpGroup = CommonDefine.HelpGroupName.Bag
    self.topLeftItem:Show(args)
    self.propDetailNode.gameObject:SetActive(false)

    self:RefreshKindList()
    


end

function BagWindow:OnPropDelete(id)
    local itemGrid = self:GetItemGridById(id)
    if itemGrid and not itemGrid:IsExpire() then
        self:CacheSingleItemGird(id)
    end

    self:RemoveLimitTimer()
    self:SelectFirstPropItem()
end

function BagWindow:OnPropDeleteHandle(ids)
    for k, id in pairs(ids) do
        self:CacheSingleItemGird(id)
    end

    self:RemoveLimitTimer()
    self:SelectFirstPropItem()
end

function BagWindow:SelectFirstPropItem()
    self:GenerateBagData()
    local bagDatas = self.bagDataList[self.curSelectKind]
    if bagDatas and #bagDatas > 0 then
       self:OnClickProp(bagDatas[1])
       self.noPropTipsNode.gameObject:SetActive(false)
    else
        self.propDetailNode.gameObject:SetActive(false) 
        self.noPropTipsNode.gameObject:SetActive(true)
    end
end


function BagWindow:CacheSingleItemGird(id)
    local itemGrid = self:GetItemGridById(id)
    if not itemGrid then
       return 
    end
    for k, v in pairs(self.itemGrids) do
        if itemGrid == v then
            table.remove(self.itemGrids, k)
            itemGrid:SetParent(self.cacheNode.transform)
            itemGrid:SetSelect(false)
            itemGrid.gameObject:SetActive(false)
            break
        end
    end

    table.insert(self.cacheItemGrids, itemGrid) 
end

--params ItemOne
function BagWindow:OnPropUpdate(info)
    local itemCfg = Config.Get("item_def", "config", "id", info.itemId) 
    if not itemCfg or not itemCfg.kind or itemCfg.kind ~= self.curSelectKind then
        return
    end

    local itemGrid = self:GetItemGridById(info.id)
    if itemGrid then  --更改已存在道具的信息
        itemGrid:Show(info)
    else  --新增道具
        local itemGrid = self:GetPropItem()
        itemGrid:Show(info)
        self.noPropTipsNode.gameObject:SetActive(false)
    end

    self:RefreshPropDetail()
end


function BagWindow:GetItemGridById(id)
    for k, v in pairs(self.itemGrids) do
        if v:GetItemUid() == id then
            return v
        end
    end
end


function BagWindow:RefreshKindList()
    for k, v in pairs(self.kindArray) do
        local nameStr = BagDefine.BagKindName[v] 
        local go = GameObject.Instantiate(self.kindItemTemplate, self.kindListNode.transform)
        local item = BagToggleItem.New()
        item:SetClickCallback(self:ToFunc("OnSelectToggle"), v)
        item:SetObject(go)
        item:Show({name = nameStr})
        item:SetSelect(false)
        item.gameObject:SetActive(true)
        self.kindToggleItems[v] = item
    end
    self:OnSelectToggle(self.defaultSelKind)
end

function BagWindow:OnSelectToggle(kind)
    if self.curSelectKind then
        self.kindToggleItems[self.curSelectKind]:SetSelect(false)
    end
    self.curSelectKind = kind
    Log("OnSelectToggle : " .. kind)
    self.kindToggleItems[kind]:SetSelect(true)
    self:GenerateBagData()
    self:RefreshBagScrollList()
end

function BagWindow:GenerateBagData()
    local allItems = mod.BagProxy:GetAllItemBag()
    self.bagDataList = {}

    for k, v in pairs(self.kindArray) do
        self.bagDataList[v] = {}
    end

    for i, v in ipairs(allItems) do
        local itemCfg = Config.Get("item_def", "config", "id", v.itemId)
        if not itemCfg then
           LogError("no item_def, id : ".. tostring(v.itemId))
        end
        if self.bagDataList[itemCfg.kind] then
            table.insert(self.bagDataList[itemCfg.kind], v)
        end
    end

    LogTable("bagDataList" , self.bagDataList)
end

function BagWindow:RefreshBagScrollList()
    self:CachePropList()
    local bagDatas = self.bagDataList[self.curSelectKind]

    if bagDatas and #bagDatas > 0 then
        for i = 1, #bagDatas do
            local item = self:GetPropItem()
            item:Show(bagDatas[i])
            if i == 1 then
               self:OnClickProp(bagDatas[i]) 
            end
        end
        self.noPropTipsNode.gameObject:SetActive(false)
    else
        self.propDetailNode.gameObject:SetActive(false)
        self.noPropTipsNode.gameObject:SetActive(true)
    end

end


function BagWindow:CachePropList()
    for k, item in pairs(self.itemGrids) do
        item:SetParent(self.cacheNode.transform)
        item.gameObject:SetActive(false)
        item:SetSelect(false)
    end

    while #self.itemGrids > 0 do
        local propItem = table.remove(self.itemGrids,1)
        table.insert(self.cacheItemGrids, propItem) 
    end 
end


function BagWindow:GetPropItem()
    local item 
    if #self.cacheItemGrids > 0 then
        item = table.remove(self.cacheItemGrids, 1) 
    else
        local go = GameObject.Instantiate(self.gridItemTemplate, self.gridScrollRect.content)
        item = ItemGrid.New()
        item:SetObject(go)
        item:SetClickCallback(self:ToFunc("OnClickProp"))
        item:SetDragCallBack(self:ToFunc("OnBeginDrag"), self:ToFunc("OnDrag"), self:ToFunc("OnEndDrag"))
    end
    item.gameObject:SetActive(true)
    item:SetParent(self.gridScrollRect.content)
    table.insert(self.itemGrids, item)
    return item
end

function BagWindow:OnClickProp(itemData)
    if self.selectUid then
        local itemGrid = self:GetItemGridById(self.selectUid) 
        if itemGrid then
            itemGrid:SetSelect(false)
        end
    end

    self.selectUid = itemData.id
    local itemGrid = self:GetItemGridById(self.selectUid) 
    itemGrid:SetSelect(true)
    LogTable("itemData#############" , itemData)
    self:RefreshPropDetail()
end


function BagWindow:RefreshPropDetail()
    local itemData = mod.BagProxy:GetItemDataById(self.selectUid)

    if not self.selectUid or not itemData then
        return
    end 

    self.propDetailNode.gameObject:SetActive(true)
    local itemCfg = Config.Get("item_def", "config", "id", itemData.itemId)
    self.propNameTxt.text = itemCfg.name
    self.propTypeTxt.text = BagDefine.BagKindName[itemCfg.kind] 
    self.descTxt.text = itemCfg.desc
    self.inputNum = 1
    self.numInputItem:Show({maxCount = itemData.count})

    self.operateNode.gameObject:SetActive(true)
    if not itemCfg.useEffect or not next(itemCfg.useEffect) then
        self.operateNode.gameObject:SetActive(false)
    end
    self:SetSprite(self.qualityLineImg,AssetPath.GetPropQuailityLineIcon(itemCfg.quality), true) 
    self:RefreshTime()
end


function BagWindow:OnUseBtnClick()
    local itemData = mod.BagProxy:GetItemDataById(self.selectUid)
    local itemCfg = Config.Get("item_def", "config", "id", itemData.itemId)
    if not itemCfg.useEffect or not next(itemCfg.useEffect) then
        SystemMessage.ShowError(TI18N("bag_can_not_use")) 
        return
    end

    mod.BagFacade:SendMsg(3403, itemData.id, self.inputNum)
end


function BagWindow:OnDeleteBtnClick()
    local itemData = mod.BagProxy:GetItemDataById(self.selectUid)
    mod.BagFacade:SendMsg(3405,  {itemData.id})
end



function BagWindow:RefreshTime()
    self.expireTimeTxt.text = TI18N("bag_forever_use_time")
    local itemData = mod.BagProxy:GetItemDataById(self.selectUid)
    if itemData.expire and itemData.expire > 0 then
        local endTimeStamp = itemData.expire
        -- local remainTime = Network.Instance:GetRemoteRemainTime(endTimeStamp)
        if endTimeStamp > 0 then
            self:TimeRunCallback()
            if not self.limitTimer then
                self.limitTimer = self:AddTimer(self.timerName,0,1,self:ToFunc("TimeRunCallback"))
            end
        end
    else
        self:RemoveLimitTimer()
    end
end

function BagWindow:TimeRunCallback()
    local itemData = mod.BagProxy:GetItemDataById(self.selectUid)
    if not itemData then
        self:RemoveLimitTimer()
        return 
    end
    local endTimeStamp = itemData.expire 
    local remainTime = Network.Instance:GetRemoteRemainTime(endTimeStamp)
    remainTime = math.floor(remainTime)
    if remainTime > 0 then
        local timeStr = TimeUtils.GetTimeFormatDayIV(remainTime)
        self.expireTimeTxt.text = TI18N("item_use_left", timeStr)
    else
        self:RemoveLimitTimer()
        self.expireTimeTxt.text = TI18N("item_time_expire")
    end
end

function BagWindow:RemoveLimitTimer()
    if self.limitTimer then
        self:RemoveTimer(self.timerName)
        self.limitTimer = nil
    end
end

function BagWindow:OnNumChange(num)
    self.inputNum = num
end


function BagWindow:OnBeginDrag(eventData)
    if self.gridScrollRect then
        self.gridScrollRect:OnBeginDrag(eventData)
    end
end

function BagWindow:OnDrag(eventData)
    if self.gridScrollRect then
        self.gridScrollRect:OnDrag(eventData)
    end
end

function BagWindow:OnEndDrag(eventData)
    if self.gridScrollRect then
        self.gridScrollRect:OnEndDrag(eventData)
    end
end
