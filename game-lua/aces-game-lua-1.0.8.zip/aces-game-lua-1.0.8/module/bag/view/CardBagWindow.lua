CardBagWindow = BaseClass("CardBagWindow", BaseWindow)

function CardBagWindow:__Init()
    self:SetAsset("ui/prefab/bag/card_bag_window.prefab", AssetType.Prefab)

end

function CardBagWindow:__Create()
    self.currencyItemList = CurrencyListView.New()
    self.currencyItemList:SetParent(self.currencyNodeTrans)
end

function CardBagWindow:__Delete()
    if self.currencyItemList then
        self.currencyItemList:Destroy() 
    end

    
    EventManager.Instance:RemoveEvent(EventDefine.on_prop_delete,self:ToFunc("OnPropDelete"))
    EventManager.Instance:RemoveEvent(EventDefine.on_prop_update,self:ToFunc("OnPropUpdate"))
end


function CardBagWindow:__CacheObject()
    self.cardList = self:Find("hadPack/cardList", CircleList)
    self.openBtn = self:Find("hadPack/openBtn", Button)
    self.openBtnTxt = self:Find("hadPack/openBtn/openBtnTxt", TextMeshProUGUI)

    self.baseCountTxt = self:Find("hadPack/baseCountTxt", TextMeshProUGUI)
    self.regularCountTxt = self:Find("hadPack/regularCountTxt", TextMeshProUGUI)
    
    self.noPackNode = self:Find("noPack").gameObject
    self.hadPackNode = self:Find("hadPack").gameObject

    
    self.currencyNodeTrans = self:Find("currencyNode").transform

    self.cardList.OnSelectCallback = 
    function(trans, index, args)
        args.OnSelect(args.caller, trans, index)
    end


    self.cardList.OnCreateItemCallback =
    function(trans, index, args)
        args.OnCreate(args.caller, trans, index)
    end
    
end

function CardBagWindow:__BindListener()
    self:Find("closeBtn", Button):SetClick(self:ToFunc("OnCloseClick"))
    self:Find("noPack/buyCard", Button):SetClick(self:ToFunc("OnGoBuyBtnClick"))
    self.openBtn:SetClick(self:ToFunc("OnOpenBtnClick"))
end

function CardBagWindow:OnGoBuyBtnClick()
    local cardShopDatas = mod.ShopProxy:GetShopDatasByType(ShopDefine.Type.Card)
    if not cardShopDatas or not next(cardShopDatas) then
        SystemMessage.Show(TI18N("shop_not_open_tips"))
        return
    end 
    ViewManager.Instance:OpenWindow(CardShopWindow)
    ViewManager.Instance:CloseWindow(CardBagWindow)
end

function CardBagWindow:__BindEvent()
    EventManager.Instance:AddEvent(EventDefine.on_prop_delete,self:ToFunc("OnPropDelete"))
    EventManager.Instance:AddEvent(EventDefine.on_prop_update,self:ToFunc("OnPropUpdate"))
    
    self:BindEvent(BagFacade.Event.UseCardRet)
end

function CardBagWindow:UseCardRet()
    self:RefreshPackRewardInfo()
end

function CardBagWindow:__Show()
    self:RefreshCardList()
    self:RefreshCurrency()
end


function CardBagWindow:OnPropDelete()
    self:RefreshCardList()
end

function CardBagWindow:OnPropUpdate()
    self:RefreshCardList()
end

function CardBagWindow:RefreshCurrency()
    self.currencyItemList:Show({BagDefine.CoinDefine.Xinghuo, BagDefine.CoinDefine.wAgnerMetal,BagDefine.CoinDefine.energy})
end

function CardBagWindow:RefreshCardList()
    self.cardBagDatas = mod.BagProxy:GetCardBagList()
    if not self.cardBagDatas or not next(self.cardBagDatas) then
        self.noPackNode.gameObject:SetActive(true)
        self.hadPackNode.gameObject:SetActive(false)
    else
        self.noPackNode.gameObject:SetActive(false)
        self.hadPackNode.gameObject:SetActive(true)
        self.cardList:SetItemNum(#self.cardBagDatas, {caller = self, OnCreate = self.OnItemCreateCallback, OnSelect = self.OnSelectCard})

    end

end

function CardBagWindow:OnItemCreateCallback(trans, index, caller)
    local bagData = self.cardBagDatas[index + 1]
    local btn = trans:Find("clickArea").gameObject:GetComponent(Button)
    local icon = trans:Find("icon").gameObject:GetComponent(Image)
    local numTxt = trans:Find("numTxt").gameObject:GetComponent(TextMeshProUGUI)
    btn:SetClick(self:ToFunc("OnBtnClick"), index)

    numTxt.text = bagData.count
    self:SetSprite(icon, AssetPath.GetPropIcon(bagData.itemId))
    if index == 0 then
        self:OnSelectCard(trans, index)
    end
end

function CardBagWindow:OnSelectCard(trans, index)
    if self.selectIndex then
        local lastItem = self.cardList:GetItemByIndex(self.selectIndex)
        if  lastItem  then
            -- lastItem.transform:SetLocalScale(1,1,1)
            local tween = TweenScaleAnim.New(lastItem.transform,Vector3(1,1,1),0.3)
            tween:Play()
        end
    end
    self.selectIndex = index

    local tween = TweenScaleAnim.New(trans,Vector3(1.2,1.2,1),0.3)
    tween:Play()
    self:RefreshBtnState()
    self:RefreshPackRewardInfo()
end


function CardBagWindow:RefreshPackRewardInfo()
    local bagData = self.cardBagDatas[self.selectIndex + 1]
    if not bagData then
       return 
    end
    local itemCfg = Config.Get("item_def", "config", "id",  bagData.itemId)
    local packInfo = mod.BagProxy:GetPackInfoById(itemCfg.useEffect.cardPack.id)
    if not packInfo then
        return
    end
    self.regularCountTxt.text = TI18N("card_base_reward",packInfo.baseCount)
    self.baseCountTxt.text = TI18N("card_regular_reward",packInfo.regularCount)
end

function CardBagWindow:OnOpenBtnClick()
    local bagData = self.cardBagDatas[self.selectIndex + 1]
    if bagData.count >= 10 then
        self:SendOpenCardMsg(10)
    else
        self:SendOpenCardMsg(bagData.count)
    end
end

function CardBagWindow:SendOpenCardMsg(num)
    local bagData = self.cardBagDatas[self.selectIndex + 1]
    mod.BagFacade:SendMsg(3406, bagData.id, num)
end

function CardBagWindow:OnBtnClick(index)
    if index == self.selectIndex then
        self:SendOpenCardMsg(1)
    else
        self.cardList:JumpToIndex(index)
    end
end


function CardBagWindow:RefreshBtnState()
    local bagData = self.cardBagDatas[self.selectIndex + 1]
    if bagData.count > 10 then
        self.openBtnTxt.text = TI18N("card_open_card_num", 10)
    else
        self.openBtnTxt.text = TI18N("card_open_all_card")
    end
end

function CardBagWindow:OnCloseClick()
    ViewManager.Instance:CloseWindow(CardBagWindow)
end