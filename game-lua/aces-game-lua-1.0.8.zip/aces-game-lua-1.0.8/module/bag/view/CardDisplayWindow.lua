CardDisplayWindow = BaseClass("CardDisplayWindow", BaseWindow)
CardDisplayWindow.notTempHide = true

function CardDisplayWindow:__Init()
    self.cardItemList = {}
    self:SetAsset("ui/prefab/bag/card_display_window.prefab", AssetType.Prefab)
end

function CardDisplayWindow:__Delete()
    for i = 1, #self.cardItemList do
        self.cardItemList[i]:Destroy()
    end

    self.cardItemList = nil
end

function CardDisplayWindow:__CacheObject()
    self.buttonConfirm = self:Find("main/button_confirm", Button)
    self.cardScrollRect = self:Find("main/cardSrollRect", ScrollRect)
end

function CardDisplayWindow:__BindListener()
end

function CardDisplayWindow:__BindEvent()
    self.buttonConfirm:SetClick(self:ToFunc("OnClickConfirmButton"))
end

function CardDisplayWindow:__Show()
    LogTable("CardDisplayWindow:__Show", self.args)
  

    for i, returnInfo in ipairs(self.args.returnInfos) do
        self:RefreshCardView(returnInfo)
    end
end

function CardDisplayWindow:__RepeatShow()
    for i, returnInfo in ipairs(self.args.returnInfos) do
        self:RefreshCardView(returnInfo)
    end
end


--270 379
function CardDisplayWindow:RefreshCardView(returnInfo)
    if returnInfo.effect == CommonDefine.Effect.basePvp then
        local cardItem = MechaCardItem.Create(self.cardScrollRect.content)
        cardItem:RemoveCanvas()
        cardItem.transform:SetLocalScale(0.5,0.5,0.5)
        local args = {}
        args.baseId = returnInfo.id
        args.kvData = {}
        cardItem:Show(args)
        table.insert(self.cardItemList, cardItem)
    elseif returnInfo.effect == CommonDefine.Effect.cardPvp then
        local cardId = returnInfo.id 
        local cardCfg = Config.Get("card_def", "config", "cardId", cardId)
        if not cardCfg then
            LogError("cardId not found", cardId)
        else
            local cardItem = BaseCardItem.Create(cardCfg, self.cardScrollRect.content)
            cardItem:RemoveCanvas()
            cardItem.transform:SetLocalScale(0.5,0.5,0.5)
            local args = {}
            args.cardInfo = { cardId = cardId }
            args.kvData = {}
            cardItem:Show(args)
            table.insert(self.cardItemList, cardItem)

            -- local setting = {}
            -- setting.target = cardItem.pointerHandler.gameObject
            -- setting.fixedScale = true
            -- setting.cardInfo = {cardId = cardId}
            -- setting.cardDir = BattleDefine.Direction.right
            -- -- setting.enterHoverFunc = self:ToFunc("EnterFunc")
            -- -- setting.exitHoverFunc = self:ToFunc("ExitFunc")
            -- local hoverHandler = CardHoverHandler.New()
            -- hoverHandler:Init(setting)
        
            -- table.insert(self.hoverHandlers, { cardId = cardId, hoverHandler = hoverHandler })
        end

    end
end

function CardDisplayWindow:OnClickConfirmButton()
    if self.args.confirmFunc then
        self.args.confirmFunc()
    end

    ViewManager.Instance:CloseWindow(CardDisplayWindow)
end
