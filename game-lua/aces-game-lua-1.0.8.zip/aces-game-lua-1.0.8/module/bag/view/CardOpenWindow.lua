CardOpenWindow = BaseClass("CardOpenWindow", BaseWindow)

function CardOpenWindow:__Init()
    self:SetAsset("ui/prefab/bag/card_open_window.prefab", AssetType.Prefab)
    self.cardItemList = {}
    self.hoverHandlers = {}
end

function CardOpenWindow:__Create()
end

function CardOpenWindow:__Delete()
    self:ClearItems()
end

function CardOpenWindow:ClearItems()
    for k, v in pairs(self.cardItemList) do
        v:Destroy()
    end
    
    for _, value in pairs(self.hoverHandlers) do
        value.hoverHandler:Delete()
    end
end

function CardOpenWindow:__CacheObject()
    self.oneCardScrollRect = self:Find("one/cardList",ScrollRect)
    self.baseCountTxt = self:Find("one/baseCountTxt", TextMeshProUGUI)
    self.regularCountTxt = self:Find("one/regularCountTxt", TextMeshProUGUI)

    self.batchCardScrollRect = self:Find("batch/cardList",ScrollRect)

    self.oneNode = self:Find("one").gameObject
    self.batchNode = self:Find("batch").gameObject

    self.openOneBtnObj = self:Find("one/openOneBtn").gameObject
    self.openAllBtnObj = self:Find("one/openAllBtn").gameObject

    
    self.openAllBtnTxt = self:Find("one/openAllBtn/openAllBtnTxt", TextMeshProUGUI)

    
    self.batchOpenAllBtnObj = self:Find("batch/openAllBtn").gameObject
    self.batchContinueBtnObj = self:Find("batch/continueOpenBtn").gameObject

end

function CardOpenWindow:__BindListener()
    self:Find("closeBtn", Button):SetClick( self:ToFunc("OnCloseClick"))

    self:Find("one/openOneBtn", Button):SetClick( self:ToFunc("OnOneBtnClick"))
    self:Find("one/openAllBtn", Button):SetClick( self:ToFunc("OnAllbtnClick"))
    
    self:Find("batch/continueOpenBtn",Button):SetClick(self:ToFunc("OnBatchContinueClick"))
    
end

function CardOpenWindow:OnBatchContinueClick()
    ViewManager.Instance:CloseWindow(CardOpenWindow)
end

function CardOpenWindow:OnOneBtnClick()
    local itemData = mod.BagProxy:GetItemDataById(self.args.itemUid)
    if not itemData then
       return 
    end
    mod.BagFacade:SendMsg(3406, self.args.itemUid, 1)
end


function CardOpenWindow:OnAllbtnClick()
    local itemData = mod.BagProxy:GetItemDataById(self.args.itemUid)
    if not itemData then
       return 
    end
    local num = itemData.count
    if itemData.count > 10 then
        num = 10
    end
    mod.BagFacade:SendMsg(3406, self.args.itemUid, num)
end


function CardOpenWindow:__BindEvent()
end

function CardOpenWindow:__Show()
    self:Refresh()
end

function CardOpenWindow:__RepeatShow()
    self:Refresh()
end

function CardOpenWindow:Refresh()
    local isBatch = self.args.count > 1
    self.oneNode:SetActive(not isBatch)
    self.batchNode:SetActive(isBatch)

    if isBatch then
        self:RefreshBatch()
    else
        self:RefreshOne()
    end


end
--270 378.775
function CardOpenWindow:RefreshOne()
    self:RefreshCardList(self.oneCardScrollRect.content)

    local packInfo = mod.BagProxy:GetPackInfoById(self.args.id)
    self.regularCountTxt.text = TI18N("card_base_reward",packInfo.baseCount)
    self.baseCountTxt.text = TI18N("card_regular_reward",packInfo.regularCount)

    local itemData = mod.BagProxy:GetItemDataById(self.args.itemUid)
    if not itemData then
        self.openAllBtnObj:SetActive(false)
        self.openOneBtnObj:SetActive(false)
    else
        self.openAllBtnObj:SetActive(itemData.count > 0)
        self.openOneBtnObj:SetActive(itemData.count > 1)
        self.openAllBtnTxt.text = itemData.count >= 10 and TI18N("card_open_card_num", 10) or TI18N("card_open_all_card") 
    end
end

function CardOpenWindow:RefreshBatch()
    self:RefreshCardList(self.batchCardScrollRect.content)

    self.batchOpenAllBtnObj.gameObject:SetActive(false)
    self.batchContinueBtnObj.gameObject:SetActive(true)
end


function CardOpenWindow:GenerateRisInfos()
    self.risInfos = {} 
    

    for i, returnInfo in ipairs(self.args.ris) do
        local qualityValue = 999
        for k, extent in pairs(returnInfo.extends) do
            if extent.key == "quality" then
                qualityValue = extent.value 
               break
            end
        end
        local template = {effect = returnInfo.effect, id = returnInfo.id, value = returnInfo.value, quality = qualityValue}
        table.insert(self.risInfos, template)
    end


end

function CardOpenWindow:RefreshCardList(parent)
    self:GenerateRisInfos()
    table.sort(self.risInfos, self:ToFunc("OnSortRisInfos"))
    self:ClearItems()
    for i, v in ipairs(self.risInfos) do
        if v.effect == CommonDefine.Effect.basePvp then
            local cardItem = MechaCardItem.Create(parent)
            cardItem:RemoveCanvas()
            cardItem.transform:SetLocalScale(0.5,0.5,0.5)
            local args = {}
            args.baseId = v.id
            args.kvData = {}
            cardItem:Show(args)
            table.insert(self.cardItemList, cardItem)
        elseif v.effect == CommonDefine.Effect.cardPvp then
            local cardId = v.id 
            local cardCfg = Config.Get("card_def", "config", "cardId", cardId)
            if not cardCfg then
                LogError("cardId not found", cardId)
            else
                local cardItem = BaseCardItem.Create(cardCfg, parent)
                cardItem:RemoveCanvas()
                cardItem.transform:SetLocalScale(0.5,0.5,0.5)
                local args = {}
                args.cardInfo = { cardId = cardId }
                args.kvData = {}
                cardItem:Show(args)
                table.insert(self.cardItemList, cardItem)
    
                local setting = {}
                setting.target = cardItem.pointerHandler.gameObject
                setting.fixedScale = true
                setting.cardInfo = {cardId = cardId}
                setting.cardDir = BattleDefine.Direction.right
                -- setting.enterHoverFunc = self:ToFunc("EnterFunc")
                -- setting.exitHoverFunc = self:ToFunc("ExitFunc")
                if not IS_PC then
                    setting.showCardTypes = { KvData.PointerType.pointerDown }
                    setting.clearCardTypes = { }
                end
                
                local hoverHandler = CardHoverHandler.New()
                hoverHandler:Init(setting)
            
                table.insert(self.hoverHandlers, { cardId = cardId, hoverHandler = hoverHandler })
            end
        end
    end
end

function CardOpenWindow:OnSortRisInfos(a,b)
    return a.quality > b.quality
end

function CardOpenWindow:OnCloseClick()
    ViewManager.Instance:CloseWindow(CardOpenWindow)
end