InputExtendView = BaseClass("InputExtendView", ExtendView)

function InputExtendView:__Init()

end

function InputExtendView:__CacheObject()
    self.numInputField = self:Find("inputNode/numInputField", TMP_InputField)
end

function InputExtendView:__BindListener()
    self:Find("inputNode/minBtn", Button):SetClick(self:ToFunc("OnMinBtnClick"))
    self:Find("inputNode/maxBtn", Button):SetClick(self:ToFunc("OnMaxBtnClick"))
    self:Find("inputNode/increaseBtn", Button):SetClick(self:ToFunc("OnIncreaseBtnClick"))
    self:Find("inputNode/reduceBtn", Button):SetClick(self:ToFunc("OnReduceBtnClick"))
    self.numInputField:SetValueChanged(self:ToFunc("OnNumInputChange"))
end

function InputExtendView:__Show()
    self.MainView.inputNum = 1
    self.maxValue = self.MainView.args.count
    self.numInputField.text = 1
    self.minValue = 1
end

function InputExtendView:OnMinBtnClick()
    self.MainView.inputNum = 1
    self:OnNumChange()
end

function InputExtendView:OnMaxBtnClick()
    self.MainView.inputNum = self.maxValue
    self:OnNumChange()
end

function InputExtendView:OnIncreaseBtnClick()
    self.MainView.inputNum = self.MainView.inputNum + 1;
    self.MainView.inputNum = math.min(self.MainView.inputNum, self.maxValue)
    self:OnNumChange()
end

function InputExtendView:OnReduceBtnClick()
    self.MainView.inputNum = self.MainView.inputNum - 1;
    self.MainView.inputNum = math.max(self.MainView.inputNum, 1)
    self:OnNumChange()
end

function InputExtendView:OnNumChange()
    self.numInputField.text = self.MainView.inputNum
end

function InputExtendView:OnNumInputChange(str)
    local inputNum = tonumber(str)
    inputNum = math.min(inputNum, self.maxValue)
    inputNum = math.max(inputNum, 1)

    self.numInputField.text = inputNum
    self.MainView.inputNum  = inputNum
end

