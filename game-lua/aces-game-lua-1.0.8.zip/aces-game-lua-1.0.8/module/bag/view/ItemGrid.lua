ItemGrid = BaseClass("ItemGrid", BaseView)
function ItemGrid:__Init()
end

function ItemGrid:__CacheObject()
    self.root = self:Find("root").gameObject
    self.selectNode = self:Find("select_img").gameObject
end

function ItemGrid:__BindListener()
end

function ItemGrid:__Delete()
    if self.propItem then
        self.propItem:Destroy()
        self.propItem = nil
    end
end

function ItemGrid:__Create()
  
end

function ItemGrid:GetItemUid()
    if not self.args then
        return 0
    end
    return self.args.id
end

function ItemGrid:IsEmptyGrid()
    return not self.args or not next(self.args) 
end

function ItemGrid:__Show()
    self:Refresh()
end

function ItemGrid:IsExpire()
    if not self.propItem or self:IsEmptyGrid() then
        return false
    end
    return self.propItem:IsExpire()
end

function ItemGrid:__RepeatShow()
    self:Refresh()
end



function ItemGrid:OnItemClick()
    -- if self:IsExpire() then
    --     SystemMessage.Show(TI18N("item_expire_tips"))
    --     return
    -- end

    -- ViewManager.Instance:OpenWindow(PropUseWindow, self.args)
    -- end

    if self.clickCallBack then
       self.clickCallBack(self.args) 
    end
end

function ItemGrid:SetClickCallback(func)
    self.clickCallBack = func
end


function ItemGrid:Refresh()
    if not self:IsEmptyGrid() then
        if not self.propItem then
            self.propItem = PropItem.Create(self.root.transform)
        end
        self.propItem:Show({itemData = self.args})
        self.propItem.transform:SetLocalScale(0.9,0.9,0.9)
        self.propItem:SetClickCallback(self:ToFunc("OnItemClick"))
        self.propItem:SetDragCallBack(self:ToFunc("OnBeginDrag"), self:ToFunc("OnDrag"), self:ToFunc("OnEndDrag"))
    else
        if  self.propItem then
            self.propItem:Hide()
        end
    end
end


function ItemGrid:OnBeginDrag(eventData)
    if self.beginDragCallback then
        self.beginDragCallback(eventData) 
    end
end

function ItemGrid:OnDrag(eventData)
    if self.onDragCallback then
        self.onDragCallback(eventData) 
    end
end

function ItemGrid:OnEndDrag(eventData)
    if self.onEndDragCallback then
        self.onEndDragCallback(eventData) 
    end
end


function ItemGrid:SetDragCallBack(beginDragCallback, onDragCallback, onEndDragCallback)
    self.beginDragCallback = beginDragCallback
    self.onDragCallback = onDragCallback
    self.onEndDragCallback = onEndDragCallback
end

function ItemGrid:SetSelect(isSelect)
    self.selectNode.gameObject:SetActive(isSelect)
end