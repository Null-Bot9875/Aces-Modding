NumInputItem = BaseClass("NumInputItem", BaseView)

function NumInputItem:__Init()

end

function NumInputItem:__CacheObject()
    self.numInputField = self:Find("numInputField", TMP_InputField)
end

function NumInputItem:__BindListener()
    self:Find("minBtn", Button):SetClick(self:ToFunc("OnMinBtnClick"))
    self:Find("maxBtn", Button):SetClick(self:ToFunc("OnMaxBtnClick"))
    self:Find("increaseBtn", Button):SetClick(self:ToFunc("OnIncreaseBtnClick"))
    self:Find("reduceBtn", Button):SetClick(self:ToFunc("OnReduceBtnClick"))
    self.numInputField:SetValueChanged(self:ToFunc("OnNumInputChange"))
end

function NumInputItem:__Show()
    self.inputNum = 1
    self.maxValue = self.args.maxCount
    self.numInputField.text = 1
    self.minValue = 1
end

function NumInputItem:__RepeatShow()
    self.inputNum = 1
    self.maxValue = self.args.maxCount
    self.numInputField.text = 1
    self.minValue = 1
end


function NumInputItem:OnMinBtnClick()
    self.inputNum = 1
    self:OnNumChange()
end

function NumInputItem:OnMaxBtnClick()
    self.inputNum = self.maxValue
    self:OnNumChange()
end

function NumInputItem:OnIncreaseBtnClick()
    self.inputNum = self.inputNum + 1;
    self.inputNum = math.min(self.inputNum, self.maxValue)
    self:OnNumChange()
end

function NumInputItem:OnReduceBtnClick()
    self.inputNum = self.inputNum - 1;
    self.inputNum = math.max(self.inputNum, 1)
    self:OnNumChange()
end

function NumInputItem:OnNumChange()
    self.numInputField.text = self.inputNum
end

function NumInputItem:OnNumInputChange(str)
    local inputNum = tonumber(str)
    inputNum = math.min(inputNum, self.maxValue)
    inputNum = math.max(inputNum, 1)

    self.numInputField.text = inputNum
    self.inputNum = inputNum
    if self.callback then
       self.callback(self.inputNum) 
    end
end

function NumInputItem:SetNumChangeCallback(callback)
    self.callback = callback
end

