PropCardDetailView = BaseClass("PropCardDetailView", PropTipsBase)
PropCardDetailView.notTempHide = true
function PropCardDetailView:__Init()
    self:SetAsset("ui/prefab/bag/prop_card_detail_view.prefab", AssetType.Prefab)
    self:SetViewType(UIDefine.ViewType.panel)
    self.spacing = Vector2(20, 20)

    self.richTextList = {}
    self.maxNameWidth = 380
end


function PropCardDetailView:__Create()
    -- self.propItem = PropItem.Create(self:Find("itemNode"))
end

function PropCardDetailView:__Delete()
    if self.propItem then
        self.propItem:Destroy()
    end

    for _, richText in ipairs(self.richTextList) do
        richText:Delete()
    end
    self.richTextList = nil

    if self.loopScrollSequnce then
        self.loopScrollSequnce:Kill()
    end
    self.loopScrollSequnce = nil
end

function PropCardDetailView:__CacheObject()
    self.itemNode = self:Find("main/content/prop_node").transform
    self.nameTxt = self:Find("main/content/name_info/name_text", TextMeshProUGUI)
    self.nameLayout = self:Find("main/content/name_info/name_text", LayoutElement)
    self.countTxt = self:Find("main/content/count", TextMeshProUGUI)
    -- self.descTxt = self:Find("main/content/desc", TextMeshProUGUI)
    self.scrollDesc = self:Find("main/content/scroll_desc", ScrollRect)

    self.qualityImg = self:Find("main/content/name_info/quality/quality_img", Image)
    self.qualityName = self:Find("main/content/name_info/quality/quality_name", TextMeshProUGUI)

    self.mainRectTrans = self:Find("main", RectTransform) 
    self.contentRectTrans = self:Find("main/content", RectTransform) 
end

function PropCardDetailView:__BindListener()
end


function PropCardDetailView:__Show()
    self:RefreshContent()
    self:CalcOffset()
    self:RefreshLayout()
end


function PropCardDetailView:RefreshContent()
    self.cardConf = Config.Get("card_def", "config", "cardId", self.args.cardData.cardId)
    if not self.cardConf then
        LogError("card_def表中找不到id为"..self.args.cardData.cardId.."的卡牌配置")
        return
    end

    self.nameTxt.text = self.cardConf.name
    local width = self.nameTxt.preferredWidth
    self.nameLayout.preferredWidth = math.min(width, self.maxNameWidth)
    -- TODO desc 是富文本
    -- self.descTxt.text = self.cardConf.desc
    -- self.descTxt.text = ""

    for _, richText in ipairs(self.richTextList) do
        richText:Delete()
    end
    
    local settings = {}
    settings.fontSize = 36
    settings.fixedColor = Color(50/255, 52/255, 64/255)
    settings.colorMode = RichTextDefine.ColorMode.light

    local richTextList = nil
    richTextList = RichTextUtils.GetCardRichTextInfos(self.scrollDesc.content, {cardId = self.args.cardData.cardId},settings)

    local height = 0
    for _, richTextInfo in ipairs(richTextList) do
        richTextInfo.paddingTop = height
        local richText = RichText.Create(richTextInfo)
        height = height + richText:GetPreferredHeight() + RichTextDefine.FixedHeightGap
        table.insert(self.richTextList, richText)
    end

    self.countTxt.text = ""
    if self.args.cardData.count then
        self.countTxt.text = TI18N("prop_detail_num","X"..self.args.cardData.count)
    end

    self:SetSprite(self.qualityImg, AssetPath.GetPropQuailityIcon2(self.cardConf.rare))
    self.qualityName.text = KvData.CardRareStrMap2[self.cardConf.rare]

    if not self.propItem then
        self.propItem = RewardPropItem.Create(self.itemNode.transform)
    end

    local args = {}
    args.effect = CommonDefine.Effect.cardPvp
    args.effectValue = { id = self.args.cardData.cardId, count = self.args.cardData.count }
    self.propItem:Show(args)
    self.propItem.transform:SetLocalScale(0.82,0.82,0.82)

    local scrollHeight = self.scrollDesc.gameObject:GetComponent(RectTransform).sizeDelta.y
    if height > scrollHeight then
        local seq = DOTween.Sequence()
        seq:AppendInterval(2)
        seq:Append(self.scrollDesc:DOVerticalNormalizedPos(0, 2))
        seq:AppendInterval(2)

        seq:SetLoops(-1, DG.Tweening.LoopType.Yoyo)
        seq:Play()

        self.loopScrollSequnce = seq
    end
end


function PropCardDetailView.Create()
    local panel = PropCardDetailView.New()
    panel:SetParent(UIDefine.canvasRoot)

    return panel
end