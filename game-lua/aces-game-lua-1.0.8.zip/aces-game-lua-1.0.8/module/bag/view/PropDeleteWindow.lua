PropDeleteWindow = BaseClass("PropDeleteWindow", BaseWindow)
PropDeleteWindow.notTempHide = true
function PropDeleteWindow:__Init()
    self:SetAsset("ui/prefab/bag/prop_delete_window.prefab", AssetType.Prefab)
end


function PropDeleteWindow:__Create()
    self.propItem = PropItem.Create(self:Find("itemNode"))
end

function PropDeleteWindow:__Delete()
    if self.propItem then
        self.propItem:Destroy()
    end
end

function PropDeleteWindow:__CacheObject()
    self.numTxt = self:Find("numTxt", TextMeshProUGUI)
end

function PropDeleteWindow:__BindListener()
    self:Find("sureBtn", Button):SetClick(self:ToFunc("OnSureBtnClick"))
    self:Find("closeBtn", Button):SetClick(self:ToFunc("OnCloseClick"))
    self:Find("cancelBtn", Button):SetClick(self:ToFunc("OnCloseClick"))
end


function PropDeleteWindow:OnSureBtnClick()
    -- mod.BagProxy:Send_3405()
    mod.BagFacade:SendMsg(3405,  {self.args.id})
    
    ViewManager.Instance:CloseWindow(PropDeleteWindow)
    ViewManager.Instance:CloseWindow(PropUseWindow)
end

function PropDeleteWindow:__Show()
    self.propItem:Show({itemData = self.args})
    self.numTxt.text = TI18N("item_left_num", self.args.count)
end


-- function PropDeleteWindow:__ExtendView()
    -- self:ExtendView(InputExtendView)
-- end


function PropDeleteWindow:OnCloseClick()
    ViewManager.Instance:CloseWindow(PropDeleteWindow)
end
