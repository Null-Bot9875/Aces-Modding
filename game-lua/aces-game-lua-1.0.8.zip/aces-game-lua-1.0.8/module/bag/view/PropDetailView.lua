PropDetailView = BaseClass("PropDetailView", PropTipsBase)
PropDetailView.notTempHide = true
function PropDetailView:__Init()
    self:SetAsset("ui/prefab/bag/prop_detail_view.prefab", AssetType.Prefab)
    self:SetViewType(UIDefine.ViewType.panel)
    self.spacing = Vector2(20, 20)

    self.maxNameWidth = 380
end


function PropDetailView:__Create()
    -- self.propItem = PropItem.Create(self:Find("itemNode"))
end

function PropDetailView:__Delete()
    if self.propItem then
        self.propItem:Destroy()
    end
end

function PropDetailView:__CacheObject()
    self.itemNode = self:Find("main/content/prop_node").transform
    self.nameTxt = self:Find("main/content/name_info/name_text", TextMeshProUGUI)
    self.nameLayout = self:Find("main/content/name_info/name_text", LayoutElement)
    self.countTxt = self:Find("main/content/count", TextMeshProUGUI)
    self.descTxt = self:Find("main/content/desc", TextMeshProUGUI)

    self.qualityImg = self:Find("main/content/name_info/quality/quality_img", Image)
    self.qualityName = self:Find("main/content/name_info/quality/quality_name", TextMeshProUGUI)

    self.mainRectTrans = self:Find("main", RectTransform) 
    self.contentRectTrans = self:Find("main/content", RectTransform) 
end

function PropDetailView:__BindListener()
end


function PropDetailView:__Show()
    self:RefreshContent()
    self:CalcOffset()
    self:RefreshLayout()
end


function PropDetailView:RefreshContent()
    self.itemCfg = Config.Get("item_def", "config", "id", self.args.itemData.itemId)
    self.nameTxt.text = self.itemCfg.name
    local width = self.nameTxt.preferredWidth
    self.nameLayout.preferredWidth = math.min(width, self.maxNameWidth)
    self.descTxt.text = self.itemCfg.desc

    self.countTxt.text = ""
    if self.args.itemData.count then
        self.countTxt.text = TI18N("prop_detail_num","X"..self.args.itemData.count)
    end

    self:SetSprite(self.qualityImg, AssetPath.GetPropQuailityIcon2(self.itemCfg.quality))
    self.qualityName.text = KvData.CardRareStrMap2[self.itemCfg.quality]

    if not self.propItem then
        self.propItem = PropItem.Create(self.itemNode.transform)
    end
    self.propItem:Show({itemData = self.args.itemData})
    self.propItem.transform:SetLocalScale(0.82,0.82,0.82)
end


function PropDetailView.Create()
    local panel = PropDetailView.New()
    panel:SetParent(UIDefine.canvasRoot)

    return panel
end