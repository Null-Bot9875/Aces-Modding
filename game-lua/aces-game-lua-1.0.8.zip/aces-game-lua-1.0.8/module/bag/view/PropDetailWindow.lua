PropDetailWindow = BaseClass("PropDetailWindow", BaseWindow)
PropDetailWindow.notTempHide = true
PropDetailWindow.__showTop = true
function PropDetailWindow:__Init()
    self:SetAsset("ui/prefab/prop/prop_detail_window.prefab", AssetType.Prefab)
end


function PropDetailWindow:__Create()
end

function PropDetailWindow:__Delete()
    if self.cardItem then
        self.cardItem:Destroy()
    end
end

function PropDetailWindow:__CacheObject()
    self.nameText = self:Find("main/name_txt", TextMeshProUGUI)
    self.numTxt = self:Find("main/num_txt", TextMeshProUGUI)
    self.descTxt = self:Find("main/desc_txt", TextMeshProUGUI)
    self.qualityIcon = self:Find("main/quality_icon", Image)
    self.qualityTxt = self:Find("main/quality_icon/text", TextMeshProUGUI)

    self.cardNode = self:Find("main/card_node").gameObject
    self.cardParent = self:Find("main/card_node/card_parent").transform

    
    self.qualityLightIcon = self:Find("main/quality_light", Image)
    self.qualityLineIcon = self:Find("main/quality_line", Image)
    
end

function PropDetailWindow:__BindListener()
    self:Find("close_btn", Button):SetClick(self:ToFunc("OnCloseClick"))
end

function PropDetailWindow:__Show()
    self:Refresh()
end

function PropDetailWindow:__RepeatShow()
    self:Refresh()
end

function PropDetailWindow:Refresh()
    local itemCfg = Config.Get("item_def", "config", "id",  self.args.itemId)
    self.nameText.text = itemCfg.name
    self.descTxt.text = itemCfg.desc

    
    self:SetSprite(self.qualityLineIcon, AssetPath.GetDialogQualityLineIcon(itemCfg.quality))
    
    self:SetSprite(self.qualityLightIcon, AssetPath.GetDialogQualityLightIcon(itemCfg.quality))

    
    local num = self.args.num or 1
    self.numTxt.text = TI18N("prop_detail_num", "X"..num)
    self:SetSprite(self.qualityIcon, AssetPath.GetPropQuailityIcon2(itemCfg.quality))
    self.qualityTxt.text = KvData.CardRareStrMap2[itemCfg.quality]

    self.cardNode.gameObject:SetActive(false)
    if itemCfg.kind == BagDefine.PropKind.Card then
    -- if true then
        self.cardNode.gameObject:SetActive(true)
        local cardId = itemCfg.useEffect.cardId
        -- local cardId = 3538
        local cardConf = Config.Get("card_def", "config", "cardId", cardId)
        self.cardItem = BaseCardItem.Create(cardConf, self.cardParent)
        local args    = {}
        args.cardInfo = { cardId = cardId }
        args.kvData   = {}
        self.cardItem:Show(args)
        self.cardItem:RemoveCanvas()
        self.cardItem.transform:SetLocalScale(0.6,0.6,0.6)
        self.cardItem.transform:SetLocalEulerAngles(-13.2,-17.8,-16.8)
    end


end

function PropDetailWindow:OnCloseClick()
    ViewManager.Instance:CloseWindow(PropDetailWindow)
end
