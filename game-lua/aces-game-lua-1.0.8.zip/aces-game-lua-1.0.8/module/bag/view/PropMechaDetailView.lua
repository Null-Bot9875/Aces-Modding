PropMechaDetailView = BaseClass("PropMechaDetailView", PropTipsBase)
PropMechaDetailView.notTempHide = true
function PropMechaDetailView:__Init()
    self:SetAsset("ui/prefab/bag/prop_mecha_detail_view.prefab", AssetType.Prefab)
    self:SetViewType(UIDefine.ViewType.panel)
    self.spacing = Vector2(20, 20)

    self.richTextList = {}
    self.maxNameWidth = 380
end


function PropMechaDetailView:__Create()
    -- self.propItem = PropItem.Create(self:Find("itemNode"))
end

function PropMechaDetailView:__Delete()
    if self.propItem then
        self.propItem:Destroy()
    end

    for _, richText in ipairs(self.richTextList) do
        richText:Delete()
    end
    self.richTextList = nil
end

function PropMechaDetailView:__CacheObject()
    self.itemNode = self:Find("main/content/prop_node").transform
    self.nameTxt = self:Find("main/content/name_info/name_text", TextMeshProUGUI)
    self.nameLayout = self:Find("main/content/name_info/name_text", LayoutElement)
    self.countTxt = self:Find("main/content/count", TextMeshProUGUI)
    -- self.descTxt = self:Find("main/content/desc", TextMeshProUGUI)
    self.scrollDesc = self:Find("main/content/scroll_desc", ScrollRect)

    self.qualityImg = self:Find("main/content/name_info/quality/quality_img", Image)
    self.qualityName = self:Find("main/content/name_info/quality/quality_name", TextMeshProUGUI)

    self.mainRectTrans = self:Find("main", RectTransform) 
    self.contentRectTrans = self:Find("main/content", RectTransform) 

    self.textDesc = self:Find("main/content/scroll_desc/Viewport/Content/text_desc", TextMeshProUGUI)
end

function PropMechaDetailView:__BindListener()
end


function PropMechaDetailView:__Show()
    self:RefreshContent()
    self:CalcOffset()
    self:RefreshLayout()
end


function PropMechaDetailView:RefreshContent()
    self.mechaConf = Config.Get("card_base_def", "config", "baseId", self.args.mechaData.baseId)
    if not self.mechaConf then
        LogError("card_base_def表中找不到id为"..self.args.mechaData.baseId.."的机甲配置")
        return
    end

    self.nameTxt.text = self.mechaConf.name
    local width = self.nameTxt.preferredWidth
    self.nameLayout.preferredWidth = math.min(width, self.maxNameWidth)

    self.textDesc.text = self.mechaConf.desc


    self.countTxt.text = ""
    if self.args.mechaData.count then
        self.countTxt.text = TI18N("prop_detail_num","X"..self.args.mechaData.count)
    end

    self:SetSprite(self.qualityImg, AssetPath.GetPropQuailityIcon2(self.mechaConf.rare))
    self.qualityName.text = KvData.CardRareStrMap2[self.mechaConf.rare]

    if not self.propItem then
        self.propItem = RewardPropItem.Create(self.itemNode.transform)
    end

    local args = {}
    args.effect = CommonDefine.Effect.base
    args.effectValue = { id = self.args.mechaData.baseId, count = self.args.mechaData.count }
    self.propItem:Show(args)
    -- self.propItem.transform:SetLocalScale(0.82,0.82,0.82)
end


function PropMechaDetailView.Create()
    local panel = PropMechaDetailView.New()
    panel:SetParent(UIDefine.canvasRoot)

    return panel
end