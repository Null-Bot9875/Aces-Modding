PropTipsBase = BaseClass("PropTipsBase", BasePanel)
PropTipsBase.notTempHide = true
function PropTipsBase:__Init()
    self.spacing = Vector2(0,0)
    self.offsetPos = Vector2(0,0)
end


function PropTipsBase:__Create()
end

function PropTipsBase:__Delete()
end

function PropTipsBase:__CacheObject()
    self.mainRectTrans = self:Find("main", RectTransform) 
    self.contentRectTrans = self:Find("main/content", RectTransform) 
    self.targetRectTrans = self.args.target:GetComponent(RectTransform)

end

function PropTipsBase:__BindListener()
end


function PropTipsBase:__Show()
end


function PropTipsBase:CalcOffset()
    local targetSizeDelta = self.targetRectTrans.sizeDelta
    local targeScale = self.targetRectTrans.transform.localScale
    self.offsetPos.x = targetSizeDelta.x * targeScale.x / 2 + self.spacing.x
    self.offsetPos.y = targetSizeDelta.y * targeScale.y / 2 + self.spacing.y
end


function PropTipsBase:RefreshLayout()
    UIUtils.ForceRebuildLayoutImmediate(self.contentRectTrans.gameObject)
    self.mainRectTrans.sizeDelta = self.contentRectTrans.sizeDelta

    local hoverRectTransform = self.args.target:GetComponent(RectTransform)
    local screenPos = UIUtils.GetScreenScaledPos(UIDefine.uiCamera,hoverRectTransform)
    local targetScreenPos = self:AdjustScreenPos(screenPos)
    -- local calRect = UIDefine.calcPosNode.gameObject:GetComponent(RectTransform)
    -- calRect.anchoredPosition = targetScreenPos
    -- local pos = calRect.position
    self.mainRectTrans.anchoredPosition = targetScreenPos
end


function PropTipsBase:AdjustScreenPos(screenPos)
    local viewWidth = self:GetWidth()
    local viewHeight = self:GetHeight()

    local showScreenPos = self:GetShowScreenPos(screenPos)


    local leftPosX = showScreenPos.x - viewWidth / 2 
    local rightPosX = showScreenPos.x +  viewWidth / 2 
    local upPosY = showScreenPos.y + viewHeight / 2
    local downPosY = showScreenPos.y - viewHeight / 2


    -- 超框判断
    if leftPosX < 0 then  
        showScreenPos.x = 0+ viewWidth / 2
    end

    if rightPosX > KvData.curScreenWidth then  
        showScreenPos.x = KvData.curScreenWidth - viewWidth / 2
    end
        
    if upPosY > KvData.curScreenHeight then  
        showScreenPos.y = KvData.curScreenHeight - viewHeight / 2
    end

    if downPosY < 0 then  
        showScreenPos.y = 0 + viewHeight / 2
    end

    
    return showScreenPos
end


function PropTipsBase:GetShowScreenPos(screenPos)
    local viewWidth = self:GetWidth()
    local viewHeight = self:GetHeight()
    local showScreenPos = Vector2(screenPos.x + viewWidth / 2 + self.offsetPos.x, screenPos.y)

    if screenPos.x > KvData.curScreenWidth / 2 then
        if screenPos.y > KvData.curScreenHeight / 2 then --位于右上,显示在目标左下角
            showScreenPos = Vector2(screenPos.x - viewWidth / 2 - self.offsetPos.x, screenPos.y + self.offsetPos.y - viewHeight / 2)
        else -- 位于右上,显示在目标左上角
            showScreenPos = Vector2(screenPos.x - viewWidth / 2 - self.offsetPos.x, screenPos.y - self.offsetPos.y + viewHeight / 2 )
        end
    else
        if screenPos.y > KvData.curScreenHeight / 2 then --左上
            showScreenPos = Vector2(screenPos.x + viewWidth / 2 + self.offsetPos.x, screenPos.y + self.offsetPos.y - viewHeight / 2)
        else --左下
            showScreenPos = Vector2(screenPos.x + viewWidth / 2 + self.offsetPos.x, screenPos.y - self.offsetPos.y + viewHeight / 2 )
        end
    end

    return showScreenPos

end


function PropTipsBase:GetHeight()
    return self.mainRectTrans.sizeDelta.y

end

function PropTipsBase:GetWidth()
    return self.mainRectTrans.sizeDelta.x
end

