PropUseWindow = BaseClass("PropUseWindow", BaseWindow)
PropUseWindow.notTempHide = true
function PropUseWindow:__Init()
    self:SetAsset("ui/prefab/bag/prop_use_window.prefab", AssetType.Prefab)
end


function PropUseWindow:__Create()
    self.propItem = PropItem.Create(self:Find("itemNode"))
end

function PropUseWindow:__Delete()
    if self.propItem then
        self.propItem:Destroy()
    end
end

function PropUseWindow:__CacheObject()
    self.timeLimitText = self:Find("timeLimitText", TextMeshProUGUI)
    self.numTxt = self:Find("numTxt", TextMeshProUGUI)
    self.itemNameTxt = self:Find("itemNameTxt", TextMeshProUGUI)
    self.descTxt = self:Find("descTxt", TextMeshProUGUI)

    self.inputNode = self:Find("inputNode").gameObject
    self.useBtn = self:Find("useBtn", Button)
    
end

function PropUseWindow:__BindListener()
    self.useBtn:SetClick(self:ToFunc("OnUseBtnClick"))
    self:Find("closeBtn", Button):SetClick(self:ToFunc("OnCloseClick"))
    self:Find("deleteBtn", Button):SetClick(self:ToFunc("OnDeleteClick"))
end


function PropUseWindow:OnUseBtnClick()
    mod.BagFacade:SendMsg(3403, self.args.id, self.inputNum)
    ViewManager.Instance:CloseWindow(PropUseWindow)
end

function PropUseWindow:__Show()
    self:RefreshTime()
    self.propItem:Show({itemData = self.args})
    self.numTxt.text = TI18N("item_left_num", self.args.count)
    local itemCfg = Config.Get("item_def", "config", "id", self.args.itemId)
    self.itemNameTxt.text = itemCfg.name
    self.descTxt.text = itemCfg.desc

    if itemCfg.useEffect and next(itemCfg.useEffect) then
        self.inputNode:SetActive(true)
        self.useBtn.gameObject:SetActive(true)
    else
        self.inputNode:SetActive(false)
        self.useBtn.gameObject:SetActive(false)
    end
end

function PropUseWindow:RefreshTime()
    self.timeLimitText.text = ""
    if self.args.expire and self.args.expire > 0 then
        local endTimeStamp = self.args.expire
        -- local remainTime = Network.Instance:GetRemoteRemainTime(endTimeStamp)
        if endTimeStamp > 0 then
            self:TimeRunCallback()
            self.limitTimer = self:AddTimer("ItemTimeLimit",0,1, self:ToFunc("TimeRunCallback"))
        end
    end
end

function PropUseWindow:TimeRunCallback()
    local endTimeStamp = self.args.expire 
    local remainTime = Network.Instance:GetRemoteRemainTime(endTimeStamp)
    remainTime = math.floor(remainTime)
    if remainTime > 0 then
        local timeStr = TimeUtils.GetTimeFormatDayIV(remainTime)
        self.timeLimitText.text = TI18N("item_use_left", timeStr)
    else
        self:RemoveLimitTimer()
        self.timeLimitText.text = TI18N("item_time_expire")
    end
end

function PropUseWindow:RemoveLimitTimer()
    if self.limitTimer then
        TimerManager.Instance:RemoveTimer(self.limitTimer)
        self.limitTimer = nil
    end
end


function PropUseWindow:__ExtendView()
    self:ExtendView(InputExtendView)
end


function PropUseWindow:OnCloseClick()
    ViewManager.Instance:CloseWindow(PropUseWindow)
end

function PropUseWindow:OnDeleteClick()
    ViewManager.Instance:OpenWindow(PropDeleteWindow, self.args)
end