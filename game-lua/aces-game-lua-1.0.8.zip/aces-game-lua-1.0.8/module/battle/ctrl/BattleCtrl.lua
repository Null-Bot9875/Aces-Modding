BattleCtrl = BaseClass("BattleCtrl",Controller)

local function GetBattleObjectPoolKeys()
    local cardTypes = {
        TacticCardItem,
        DeviceCardItem,
        DeviceDroneCardItem,
        MechaCardItem,
        HeroCardItem,
    }

    local poolKeys = {}
    for _, cardType in ipairs(cardTypes) do
        if cardType and cardType.poolKey then
            table.insert(poolKeys, cardType.poolKey)
        end
    end

    return poolKeys
end

function BattleCtrl:__Init()
    self.enterBattleData = nil
    self.enterBattleSource = nil
    self.pendingReenterData = nil
    self.pendingReenterSource = nil
    self.transitionCleanupTimer = nil
    self.transitionCleanupOperation = nil
    self.transitionCleanupCallback = nil
    self.isTransitionCleaning = false
    self.pendingExitBattleArgs = nil
    self.exitMainuiCheckTimer = nil
end

function BattleCtrl:__Delete()
    self:ClearTransitionCleanup()
    if RunWorld then
        self:DestroyBattle(RunWorld)
        mod.BattleProxy:SetRunWorld(nil)
    end
end

function BattleCtrl:__InitComplete()
end

local function GetBattleLoadWindowNodeId(battleType)
    if battleType ~= BattleDefine.BattleType.pve then
        return nil
    end

    local curNodeInfo = mod.PveRogueProxy:GetCurrEpNodeInfo()
    if not curNodeInfo then
        return nil
    end

    return curNodeInfo.nodeId
end

function BattleCtrl:EnterBattle(data, source)
    self.enterBattleData = data
    self.enterBattleSource = source or mod.BattleProxy:ConsumePendingEnterSource()

    local battleType = data and data.baseInfo and data.baseInfo.type or nil
    local pveNodeId = GetBattleLoadWindowNodeId(battleType)

    local args = {}
    args.onShowComplete = self:ToFunc("OnBattleLoadWindowShowComplete")
    args.battleType = battleType
    args.pveNodeId = pveNodeId
    ViewManager.Instance:OpenWindow(BattleLoadWindow,args)
end

function BattleCtrl:OnBattleLoadWindowShowComplete()
    if self:ShouldRunTransitionCleanup(self.enterBattleSource) then
        self:StartTransitionCleanup(self:ToFunc("DoEnterBattleInit"), {
            [BattleLoadWindow.__className] = true,
        })
        return
    end

    self:DoEnterBattleInit()
end

function BattleCtrl:DoEnterBattleInit()
    local data = self.enterBattleData
    self.enterBattleData = nil
    self.enterBattleSource = nil

    if not data then
        return
    end

    self:SnapshotLeakDiagnostics()


    local opts = SECBOptions.New()
    opts:SetComponentOrder(BattleDefine.ComponentInitOrder,BattleDefine.ComponentUpdateOrder,BattleDefine.ComponentDelOrder)

    local runWorld = PvpWorld.New(opts)

    runWorld:SetUid(1)
    runWorld:SetWorldType(data.baseInfo.type)

    --TODO:正式化设置角色uid,mod.RoleProxy:GetRoleUid()
    local roleUid = mod.RoleProxy:GetRoleUid()
    Log("角色uid",roleUid)
    runWorld.DataSystem:SetRoleUid(roleUid)

    mod.BattleProxy:AddWorld(runWorld)

    mod.BattleProxy:SetRunWorld(runWorld)

    runWorld.EnterSystem:Enter(data)
end

function BattleCtrl:ExitBattle(world, nextBattleData, nextBattleSource)
    local battleType = world.DataSystem.enterData.baseInfo.type
    local sectionId = world.DataSystem:GetSectionId()
    self:DestroyBattle(world)

    if RunWorld ~= world then
        return
    end
    
    mod.BattleProxy:SetRunWorld(nil)
    ViewManager.Instance:SetCheckMainui(true)
    ViewManager.Instance:CloseAllWindow(true)

    local args = {}
    args.battleType = battleType
    args.sectionId = sectionId
    self.pendingExitBattleArgs = args
    self.pendingReenterData = nextBattleData
    self.pendingReenterSource = nextBattleSource

    self:StartTransitionCleanup(self:ToFunc("OnExitBattleCleanupComplete"))
end

function BattleCtrl:DestroyBattle(world)
    mod.BattleProxy:RemoveWorld(world.uid)

    local stopwatch = CS.System.Diagnostics.Stopwatch()
    stopwatch:Start()
    world:Destroy()
    stopwatch:Stop()
    local runTime = stopwatch.Elapsed.TotalMilliseconds
    Log("清理耗时",runTime)
end

function BattleCtrl:ShouldRunTransitionCleanup(source)
    return source == mod.BattleProxy.EnterSource.normal
end

function BattleCtrl:StartTransitionCleanup(onComplete, exceptWindows)
    if self.isTransitionCleaning then
        return
    end

    self.isTransitionCleaning = true
    self.transitionCleanupCallback = onComplete

    if exceptWindows then
        ViewManager.Instance:CloseAllWindowExcept(exceptWindows)
    end

    PoolManager.Instance:CleanByType(PoolType.battle_effect)
    self:ClearBattleObjectPools()
    BaseCardItem.ClearDeferredRefreshState()
    RichTextUtils.ClearRichTemplateCache()

    collectgarbage("collect")
    if LuaManager.Instance and LuaManager.Instance.LuaEnv then
        LuaManager.Instance.LuaEnv:FullGc()
    end

    -- if AssetLoader.Instance then
    --     AssetLoader.Instance:ReleaseAsset()
    -- end

    self.transitionCleanupOperation = Resources.UnloadUnusedAssets()
    if self.transitionCleanupOperation and not self.transitionCleanupOperation.isDone then
        self.transitionCleanupTimer = TimerManager.Instance:AddTimerByNextFrame(1, 0, self:ToFunc("OnTransitionCleanupPoll"))
    else
        self:FinishTransitionCleanup()
    end
end

function BattleCtrl:ClearBattleObjectPools()
    for _, poolKey in ipairs(GetBattleObjectPoolKeys()) do
        PoolManager.Instance:ClearPoolByKey(PoolType.object, poolKey)
    end
end

function BattleCtrl:OnTransitionCleanupPoll()
    self.transitionCleanupTimer = nil

    if self.transitionCleanupOperation and not self.transitionCleanupOperation.isDone then
        self.transitionCleanupTimer = TimerManager.Instance:AddTimerByNextFrame(1, 0, self:ToFunc("OnTransitionCleanupPoll"))
        return
    end

    self:FinishTransitionCleanup()
end

function BattleCtrl:FinishTransitionCleanup()
    local callback = self.transitionCleanupCallback

    self.transitionCleanupOperation = nil
    self.transitionCleanupCallback = nil
    self.isTransitionCleaning = false

    CS.System.GC.Collect()
    CS.System.GC.WaitForPendingFinalizers()
    CS.System.GC.Collect()

    if callback then
        callback()
    end
end

function BattleCtrl:ClearTransitionCleanup()
    if self.transitionCleanupTimer then
        TimerManager.Instance:RemoveTimer(self.transitionCleanupTimer)
        self.transitionCleanupTimer = nil
    end

    self.transitionCleanupOperation = nil
    self.transitionCleanupCallback = nil
    self.isTransitionCleaning = false
    self:ClearExitMainuiCheck()
end

function BattleCtrl:StartExitMainuiCheck()
    self:ClearExitMainuiCheck()
    self.exitMainuiCheckTimer = TimerManager.Instance:AddTimerByNextFrame(1, 0, self:ToFunc("OnExitMainuiCheck"))
end

function BattleCtrl:OnExitMainuiCheck()
    self.exitMainuiCheckTimer = nil

    local transitionView = ViewManager.Instance and ViewManager.Instance.transitionView
    if transitionView and transitionView:IsTransitioning() then
        self.exitMainuiCheckTimer = TimerManager.Instance:AddTimerByNextFrame(1, 0, self:ToFunc("OnExitMainuiCheck"))
        return
    end

    ViewManager.Instance:CheckMainui()
end

function BattleCtrl:ClearExitMainuiCheck()
    if self.exitMainuiCheckTimer then
        TimerManager.Instance:RemoveTimer(self.exitMainuiCheckTimer)
        self.exitMainuiCheckTimer = nil
    end
end

function BattleCtrl:OnExitBattleCleanupComplete()
    local args = self.pendingExitBattleArgs
    local nextBattleData = self.pendingReenterData
    local nextBattleSource = self.pendingReenterSource
    self.pendingExitBattleArgs = nil
    self.pendingReenterData = nil
    self.pendingReenterSource = nil

    ViewManager.Instance:ActiveAdaptiveHeightMask(true)

    Network.Instance:CleanResend()

    Time.timeScale = 1.0

    if args and not nextBattleData then
        EventManager.Instance:SendEvent(EventDefine.exit_battle,args)
        self:StartExitMainuiCheck()
    end

    mod.BattleFacade:SendEvent(BattleRecordPanel.Event.ClearRecord)

    self:ReportLeakDiagnostics()

    if nextBattleData then
        self:EnterBattle(nextBattleData, nextBattleSource)
    end
end

-- 记录战斗开始时的全局订阅者快照，用于退战后对照差值
function BattleCtrl:SnapshotLeakDiagnostics()
    if not IS_EDITOR then return end

    self._leakEventSnapshot = {}
    if EventManager.Instance and EventManager.Instance.events then
        for evt, action in pairs(EventManager.Instance.events) do
            local key = evt and evt.value or tostring(evt)
            local n = 0
            if action and action.callBackDict then
                for _ in pairs(action.callBackDict) do n = n + 1 end
            end
            self._leakEventSnapshot[key] = n
        end
    end

    if DebugFightClassCreate then
        for _, info in pairs(DebugFightClassCreate) do info.num = 0 end
    end
end

-- 退战后输出残留报告：战斗作用域对象存活数 + 全局事件订阅者差值
function BattleCtrl:ReportLeakDiagnostics()
    if not IS_EDITOR then return end

    collectgarbage("collect")
    collectgarbage("collect")

    -- 1) 战斗作用域存活对象聚合
    local aliveByClass = {}
    local sampleByClass = {}
    if DebugFightClassClear then
        for obj, tb in pairs(DebugFightClassClear) do
            local name = obj._type and obj._type.__className or "?"
            aliveByClass[name] = (aliveByClass[name] or 0) + 1
            if not sampleByClass[name] then sampleByClass[name] = tb end
        end
    end

    local sorted = {}
    for name, n in pairs(aliveByClass) do
        table.insert(sorted, {name = name, alive = n, created = (DebugFightClassCreate and DebugFightClassCreate[name] and DebugFightClassCreate[name].num) or 0})
    end
    table.sort(sorted, function(a, b) return a.alive > b.alive end)

    LogInfof("====== [LeakReport] 战斗对象残留 共 %d 类 ======", #sorted)
    local topN = math.min(#sorted, 20)
    for i = 1, topN do
        local r = sorted[i]
        LogInfof("[LeakReport] %-40s alive=%d  created=%d", r.name, r.alive, r.created)
    end
    for i = 1, math.min(5, #sorted) do
        local r = sorted[i]
        LogInfof("[LeakReport] sample traceback [%s]:\n%s", r.name, tostring(sampleByClass[r.name]))
    end

    -- 2) 全局事件订阅者差值
    local snapshot = self._leakEventSnapshot or {}
    self._leakEventSnapshot = nil

    local deltas = {}
    if EventManager.Instance and EventManager.Instance.events then
        for evt, action in pairs(EventManager.Instance.events) do
            local key = evt and evt.value or tostring(evt)
            local n = 0
            if action and action.callBackDict then
                for _ in pairs(action.callBackDict) do n = n + 1 end
            end
            local before = snapshot[key] or 0
            if n ~= before then
                table.insert(deltas, {key = key, before = before, after = n, delta = n - before})
            end
            snapshot[key] = nil
        end
    end
    for key, before in pairs(snapshot) do
        if before ~= 0 then
            table.insert(deltas, {key = key, before = before, after = 0, delta = -before})
        end
    end
    table.sort(deltas, function(a, b) return math.abs(a.delta) > math.abs(b.delta) end)

    LogInfof("====== [LeakReport] 全局事件订阅者变化 共 %d 个 ======", #deltas)
    for _, d in ipairs(deltas) do
        LogInfof("[LeakReport] event=%-40s before=%d after=%d delta=%+d", tostring(d.key), d.before, d.after, d.delta)
    end
    LogInfof("====== [LeakReport] end ======")
end


function BattleCtrl:CheckReconnet()
    if not RunWorld then
        return
    end

    Log("开始进行战斗重连")

    RunWorld.StateSystem:SetReconnect(true)
    mod.BattleProxy:SetPendingEnterSource(mod.BattleProxy.EnterSource.reconnect)
    mod.BattleFacade:SendMsg(4001,RunWorld.DataSystem.enterData.battleId)
end
