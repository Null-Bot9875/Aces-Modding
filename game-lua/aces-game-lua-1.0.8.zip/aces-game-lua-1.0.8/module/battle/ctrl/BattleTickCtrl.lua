BattleTickCtrl = BaseClass("BattleTickCtrl",Controller)

function BattleTickCtrl:__Init()
end

function BattleTickCtrl:ResetData()

end

function BattleTickCtrl:Update(deltaTime)
    for _,world in pairs(mod.BattleProxy.worlds) do
        world:Update(deltaTime)
    end
end

function BattleTickCtrl:LateUpdate(deltaTime)
end