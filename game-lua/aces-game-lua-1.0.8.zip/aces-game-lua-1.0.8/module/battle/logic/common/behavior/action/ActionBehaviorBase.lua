ActionBehaviorBase = BaseClass("ActionBehaviorBase",SECBBehavior)

function ActionBehaviorBase:__Init()
    self.onComplete = nil
    self.onPreComplete = nil
    self.isRunComplete = false
    self.isPreComplete = false
    self.args = nil
end

function ActionBehaviorBase:__Delete()
end

function ActionBehaviorBase:SetComplete(onComplete)
    self.onComplete = onComplete
end

function ActionBehaviorBase:SetPreComplete(onPreComplete)
    self.onPreComplete = onPreComplete
end

function ActionBehaviorBase:SetArgs(args)
    self.args = args
end

function ActionBehaviorBase:Start()
    self:OnStart()
end

function ActionBehaviorBase:ActionPreComplete()
    self.isPreComplete = true
    if self.onPreComplete then
        self.onPreComplete(self)
    end
end

function ActionBehaviorBase:ActionComplete()
    self.isRunComplete = true
    self:OnComplete()
    if self.onComplete then
        self.onComplete(self)
    end
end

function ActionBehaviorBase:IsPreComplete()
    return self.isPreComplete
end

function ActionBehaviorBase:IsComplete()
    return self.isRunComplete
end

--
function ActionBehaviorBase:OnStart() end
function ActionBehaviorBase:OnComplete() end
