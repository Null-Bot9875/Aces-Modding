UseHandCardAB = BaseClass("UseHandCardAB", ActionBehaviorBase)

function UseHandCardAB:__Init()
    self.isComplete = false
    self.timelineBehavior = nil
end

function UseHandCardAB:__Delete()
    if self.timelineBehavior then
        self.timelineBehavior:Delete()
        self.timelineBehavior = nil
    end

    Log("手牌使用完成",tostring(self.isComplete))

    if not self.isComplete then
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.SwitchHandCardState,self.args.cardData.id,BattleDefine.CardState.normal)
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.RefreshHandCardPos,self.args.cardData.id,true)
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.ActiveCanUseRoot,self.args.cardData.id,true)
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.PlayHandCardWaitEffect,self.args.cardData.id,false)
    end
end

function UseHandCardAB:OnUpdate(deltaTime)
    if self.timelineBehavior then
        self.timelineBehavior:Update(deltaTime)
    end
end

function UseHandCardAB:OnInit()

end

function UseHandCardAB:OnStart()
    LogTable("使用卡牌AB", self.args)

    -- local conf = Config.Get("card_def","config","cardId",self.args.cardData.cardId)
    -- --打开选择界面
    -- if not (#conf.targetIds == 1 and conf.targetIds[1] == 0) then
    --     local selInfos = {}
    --     for _, targetId in ipairs(conf.targetIds) do
    --         local targetInfo = {}
    --         targetInfo.targetId = targetId
    --         targetInfo.effectId = conf.effectId
    --         table.insert(selInfos, targetInfo)
    --     end

    --     local args = {}
    --     args.roleUid = self.world.DataSystem.roleUid
    --     args.srcUid = self.world.DataSystem.roleUid
    --     args.selInfos = selInfos
    --     args.canCancel = true
    --     args.autoConfirm = self.world.MixedSystem:CheckCardAutoConfirm(conf.cardId)
    --     args.kvData = {}
    --     args.kvData.fromArea = BattleDefine.CardAreaDef.stack

    --     args.baseInfo = self.args.cardData

    --     local timelineBehavior = SelectTargetTB.New()
    --     timelineBehavior:SetWorld(self.world)
    --     timelineBehavior:SetUid(self.world:GetUid(SECBBehaviorComponent))
    --     timelineBehavior:SetArgs(args)
    --     timelineBehavior:SetComplete(self:ToFunc("BehaviorDone"))
    --     timelineBehavior:Init()

    --     self.timelineBehavior = timelineBehavior
    --     self.timelineBehavior:Start()
    -- else
        self:SendUse(self.args.selectData)
    -- end
end

-- function UseHandCardAB:BehaviorDone(_, selectResult)
--     Log("使用卡牌AB完成")
--     local isCancel = selectResult.isCancel
--     local isCanSelect = selectResult.isCanSelect

--     -- 无目标选择的时候直接返回
--     if not isCanSelect or isCancel then
--         EventManager.Instance:SendEvent(EventDefine.cancel_card_ob_start)
--         mod.BattleFacade:SendEvent(BattleHandCardView.Event.PlayHandCardWaitEffect,self.args.cardData.id,false)

--         self:ActionComplete()
--         return
--     end

--     -- 合并
--     local targets = selectResult.data or {} 
--     local finalTargets = {}
--     for _, target in ipairs(targets) do
--         table.insert(finalTargets, target)
--     end

--     local selectData = self.args.selectData or {}
--     for _, target in ipairs(selectData) do
--         table.insert(finalTargets, target)
--     end

--     if not isCancel then
--         self.sendData = finalTargets
--         if self.world.CameraSystem:IsBlending() then
--             self:AddEvent(BattleEvent.camera_switch_complete, self:ToFunc("OnCameraComplete"))
--         else
--             self:OnCameraComplete()
--         end
--         --self:SendUse(finalTargets)
--     end
-- end

function UseHandCardAB:OnCameraComplete()
    self:SendUse(self.args.selectData)
end

function UseHandCardAB:SendUse(dataList)
    mod.BattleFacade:SendEvent(BattleHandCardView.Event.SwitchHandCardState,self.args.cardData.id,BattleDefine.CardState.control)
    
    local data = {}
    data.cardUid = self.args.cardData.id
    data.targets = dataList
    data.costType = 0

    mod.BattleFacade:SendMsg(4004, 1, { { key = "handCard", val = data } })
    

    self.isComplete = true

    AudioManager.Instance:PlayScene("hand_card_1")

    self:ActionComplete()
end

function UseHandCardAB:MoveCard()
    local worldPos = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackTopTransform)
    local type = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackType)

    local moveArgs = {}
    moveArgs.x = worldPos.x
    moveArgs.y = worldPos.y
    moveArgs.scale = type == BattleDefine.StackDir.left and BattleDefine.CardScale.stack.x or BattleDefine.CardScale.stack.x
    moveArgs.angle = 0
    moveArgs.time = 0.3
    -- moveArgs.onComplete = self:ToFunc("MoveComplete")

    --
    mod.BattleFacade:SendEvent(BattleHandCardView.Event.SwitchHandCardState,self.args.cardData.id,BattleDefine.CardState.move_target,moveArgs)
end