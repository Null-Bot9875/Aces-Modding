UseTacticHandCardAB = BaseClass("UseTacticHandCardAB", ActionBehaviorBase)

function UseTacticHandCardAB:__Init()
    self.isComplete = false
    self.timelineBehavior = nil
end

function UseTacticHandCardAB:__Delete()
    if self.timelineBehavior then
        self.timelineBehavior:Delete()
        self.timelineBehavior = nil
    end

    if not self.isComplete then
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.RefreshHandCardPos,self.args.cardData.id,true)
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.ActiveCanUseRoot,self.args.cardData.id,true)
    end
end

function UseTacticHandCardAB:OnUpdate(deltaTime)
    if self.timelineBehavior then
        self.timelineBehavior:Update(deltaTime)
    end
end

function UseTacticHandCardAB:OnInit()

end

function UseTacticHandCardAB:OnStart()
    LogTable("使用策略牌AB", self.args)

    local conf = Config.Get("card_def","config","cardId",self.args.cardData.cardId)
    --打开选择界面
    if not (#conf.targetIds == 1 and conf.targetIds[1] == 0) then
        local selInfos = {}
        for _, targetId in ipairs(conf.targetIds) do
            local targetInfo = {}
            targetInfo.targetId = targetId
            targetInfo.effectId = conf.effectId
            table.insert(selInfos, targetInfo)
        end

        local args = {}
        args.roleUid = self.world.DataSystem.roleUid
        args.srcUid = self.world.DataSystem.roleUid
        args.selInfos = selInfos
        args.canCancel = true
        args.autoConfirm = self.world.MixedSystem:CheckCardAutoConfirm(conf.cardId)
        args.kvData = {}
        args.kvData.fromArea = BattleDefine.CardAreaDef.stack

        args.baseInfo = self.args.cardData

        local timelineBehavior = SelectTargetTB.New()
        timelineBehavior:SetWorld(self.world)
        timelineBehavior:SetUid(self.world:GetUid(SECBBehaviorComponent))
        timelineBehavior:SetArgs(args)
        timelineBehavior:SetComplete(self:ToFunc("BehaviorDone"))
        timelineBehavior:Init()

        self.timelineBehavior = timelineBehavior
        self.timelineBehavior:Start()
    else
        self:SendUse(self.args.selectData)
    end
end

function UseTacticHandCardAB:BehaviorDone(_, selectResult)
    Log("使用策略牌AB完成")
    local isCancel = selectResult.isCancel
    local isCanSelect = selectResult.isCanSelect

    -- 无目标选择的时候直接返回
    if not isCanSelect or isCancel then
        EventManager.Instance:SendEvent(EventDefine.cancel_card_ob_start)
        self:ActionComplete()
        return
    end

    -- 合并
    local targets = selectResult.data or {} 
    local finalTargets = {}
    for _, target in ipairs(targets) do
        table.insert(finalTargets, target)
    end

    local selectData = self.args.selectData or {}
    for _, target in ipairs(selectData) do
        table.insert(finalTargets, target)
    end

    if not isCancel then
        self:SendUse(finalTargets)
    end
end

function UseTacticHandCardAB:SendUse(dataList)
    local data = {}
    data.cardUid = self.args.cardData.id
    data.targets = dataList
    data.costType = 0

    mod.BattleFacade:SendMsg(4004, 1, { { key = "handCard", val = data } })

    self.isComplete = true
    self:ActionComplete()
end
