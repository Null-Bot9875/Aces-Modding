ActorChangeAB = BaseClass("ActorChangeAB",ActionBehaviorBase)

function ActorChangeAB:__Init()
end

function ActorChangeAB:__Delete()

end

function ActorChangeAB:OnInit()

end

function ActorChangeAB:OnStart()
    LogTable("移交优先权",self.args)

    --optional int32 actor = 1;//当前优先权
    --optional int32 roundStage = 2;//当前阶段

    self.world.DataSystem:SetCurPriorityRoleUid(self.args.actor)

    self.world.CarrierSystem:SetPriorityCarrierEffect(self.args.actor)
    --self.world.MixedSystem:CheckEnemyRoleInfo()

    local roleUid = self.world.DataSystem.roleUid
    local isSelf = roleUid == self.args.actor
    if isSelf then
    else
        self.world.OperateSystem:CancelOperate()
    end


    mod.GuideEventCtrl:Trigger(GuideDefine.Event.actor_change, isSelf)

    
    EventManager.Instance:SendEvent(EventDefine.on_actor_change, isSelf)
    --PvpRoleInfoView:ActiveEnemyInfos(flag)

    self.world.DataSystem:SetRoundStep(self.args.roundStage)

    self.world.StateSystem:CheckAttackState()

    -- mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.RefreshAllSlotEnable,BattleDefine.Camp.self)

    -- local lastTime = self.world.CameraSystem:PlayCameraByUid(self.args.actor)
    -- if lastTime and lastTime > 0 then
    --     -- self.cameraTimer = self.world.TimerSystem:AddTimer(1, lastTime, self:ToFunc("ActorChangeABDone"))
    --     self:ActorChangeABDone()
    -- else
    --     self:ActorChangeABDone()
    -- end
    -- mod.BattleFacade:SendEvent(BattleFuncBtnView.Event.RefreshEndBtnState)

    local roleUid = self.world.DataSystem.roleUid
    if self.args.roundStage == BattleDefine.RoundStep.battle_play then
        self.world.StateSystem.playerClickEndButton = true
    end

    -- 允许刷新结束按钮的特效
    if self.args.roundStage == BattleDefine.RoundStep.main1 and self.world.DataSystem:IsCurActiveRole(roleUid) then
        self.world.StateSystem.playerClickEndButton = false
        self.world.OperateSystem.isSendEndTurn = false
    end

    if self.args.roundStage == BattleDefine.RoundStep.battle_play and self.world.DataSystem:IsCurActiveRole(roleUid) then
        mod.GuideEventCtrl:Trigger(GuideDefine.Event.round_end)
    end

    self:ActorChangeABDone()
end

function ActorChangeAB:ActorChangeABDone()
    self.cameraTimer = nil
    self:ActionComplete()
end

function ActorChangeAB:OnCancel()

end

function ActorChangeAB:OnUpdate(deltaTime)

end