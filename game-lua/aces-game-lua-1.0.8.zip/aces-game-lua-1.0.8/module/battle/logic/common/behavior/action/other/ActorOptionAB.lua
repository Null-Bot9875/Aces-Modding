ActorOptionAB = BaseClass("ActorOptionAB", ActionBehaviorBase)

function ActorOptionAB:__Init()
end

function ActorOptionAB:__Delete()
end

function ActorOptionAB:OnInit()
end

function ActorOptionAB:OnStart()
    LogTable("选项AB", self.args)
    -- AI 托管时不弹窗
    local isAiHosting = (self.world.StateSystem:GetCacheInfo("auto_ai_enabled") == true)
    if isAiHosting then
        self:ActionComplete()
        return
    end

    local hasOption = false
    local camp = self.world.DataSystem:GetCamp(self.args.uid)
    if camp == BattleDefine.Camp.self then
        local options = self.args.option
        if options and #options > 0 then
            local effectId = options[1]
            local conf = Config.Get("battle_effect_def", "config", "effectId", effectId)
            if conf and conf.event == 21 then
                local args = {}
                args.option = self.args.option
                args.onClickConfirm = self:ToFunc("OnClickConfirm")
                ViewManager.Instance:OpenWindow(RogueSelectCardWindow, args)
                hasOption = true
            end
        end
    end

    
    if not hasOption then
        self:ActionComplete()
    end
end

-- function ActorOptionAB:OnClickCancel()
--     local data = {}
--     data.selOption = 0

--     mod.BattleFacade:SendMsg(4004, 10, { { key = "operation", val = data } })
--     self:ActionComplete()
-- end

function ActorOptionAB:OnClickConfirm(selectOptionId)
    local data = {}
    data.selOption = selectOptionId

    mod.BattleFacade:SendMsg(4004, 10, { { key = "operation", val = data } })
    self:ActionComplete()
end

function ActorOptionAB:OnUpdate(deltaTime)
end
