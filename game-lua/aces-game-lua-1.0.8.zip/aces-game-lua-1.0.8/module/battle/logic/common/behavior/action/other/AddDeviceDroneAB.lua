AddDeviceDroneAB = BaseClass("AddDeviceDroneAB", ActionBehaviorBase)

function AddDeviceDroneAB:__Init()
    self.actionTimeline = nil
end

function AddDeviceDroneAB:__Delete()
    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end

    if self.preTimer then
        self.world.TimerSystem:RemoveTimer(self.preTimer)
        self.preTimer = nil
    end
end

function AddDeviceDroneAB:OnInit()
end

function AddDeviceDroneAB:OnStart()
    LogTable("新增无人机AB", self.args)

    -- 检查是否已经预创建
    local cardUid = self.args.deviceInfo[1].cardUid
    local isPreCreated = self.world.StateSystem:GetCacheInfo(string.format("pre_created_device_%s", cardUid))
    
    if isPreCreated then
        -- 实体已经预创建，只更新数据
        Log(string.format("新增无人机AB: 检测到预创建实体 cardUid=%s，只更新数据", tostring(cardUid)))
        
        self.entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(cardUid)
        if not self.entity then
            LogError(string.format("新增无人机AB: 预创建实体不存在 cardUid=%s，重新创建", tostring(cardUid)))
            -- 预创建失败，重新创建
            self.entity = self.world.DroneDeviceSystem:CreateSingleDevice(self.args.camp, self.args.deviceInfo, true)
        else
            -- 更新实体数据（如果有需要更新的属性）
            self.world.DroneDeviceSystem:UpdateSingleDevice(self.args.deviceInfo, nil)
        end
        
        -- 清除预创建标记
        self.world.StateSystem:SetCacheInfo(string.format("pre_created_device_%s", cardUid), nil)

        -- 初始化运行时爆炸死亡标记
        if self.entity then
            local initCardInfo = self.world.DataSystem:GetCardInfo(cardUid)
            if initCardInfo then
                self.entity.ObjectDataComponent:RefreshRuntimeExplode(initCardInfo)
            end
        end

        -- 跳过入场动画，直接完成
        self:ActionPreComplete()
        self:TimelineDone()
        return
    end
    
    -- 正常创建流程
    self.entity = self.world.DroneDeviceSystem:CreateSingleDevice(self.args.camp, self.args.deviceInfo, true)

    -- 初始化运行时爆炸死亡标记
    local initCardInfo = self.world.DataSystem:GetCardInfo(cardUid)
    if initCardInfo then
        self.entity.ObjectDataComponent:RefreshRuntimeExplode(initCardInfo)
    end

    -- 新增机体沿用当前 DeviceTopInfo 强制隐藏状态（自由镜头隐藏时也不打开）
    local forceHidden = self.world.DroneDeviceSystem:GetDeviceTopInfoForceHidden()
    self.entity.DeviceTopInfoComponent:SetActive(not forceHidden)

    if not self.entity.TposeComponent:ExistTpose() then
        self.entity.TposeComponent:AddTposeListener(self:ToFunc("AddActionTimeline"))
    else
        self:AddActionTimeline()
    end

    -- local deviceInfo = self.args.deviceInfo
    -- local camp = self.args.camp
    -- for _, v in ipairs(deviceInfo) do
    --     local cardInfo, roleUid = self.world.DataSystem:GetCardInfo(v.cardUid)
    --     self.world.SceneSystem:SetGridInfo(camp, v.position, cardInfo.hp, cardInfo.attk)
    --     self.world.SceneSystem:ActiveGridInfo(camp,v.position,true)
    -- end
end

function AddDeviceDroneAB:AddActionTimeline()
    self.entity.TposeComponent:RemoveTposeListener()

    local modelId = self.entity.ObjectDataComponent.modelId
    local mode = self.entity.TposeComponent.mode
    local confName = string.format("%s_%s_entrance", modelId, mode)
    if not Config.HasConf(confName) then
        confName = "common_1_entrance"
    end
    Log(string.format("新增无人机AB，使用timeline：%s", confName))

    local playDatas = Config.GetLua(confName)
    local playActions = {}
    for _, v in ipairs(playDatas) do
        table.insert(playActions, { args = nil, action = v })
    end

    local cardUid = self.entity.ObjectDataComponent:GetCardUid()
    local roleUid = self.world.DataSystem:GetRoleUids(self.args.camp)[1]
    local execArgs = {}
    execArgs.info = {
        effectSrcValue = self.args.deviceUid,
        effectSrcType = BattleDefine.EffectSrcType.card_attk,
        markTargetMap = {
            [BattleDefine.MarkTargetType.src] = {cardUid},
            [BattleDefine.MarkTargetType.target] = {},
        },
        srcPlayer = roleUid,
    }
    execArgs.targetRoleUids = {}

    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(self.entity, playActions, execArgs)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()

    -- self.startTime = Time.realtimeSinceStartup
    self:ActionPreComplete()
end

function AddDeviceDroneAB:OnCancel()
end

function AddDeviceDroneAB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end

function AddDeviceDroneAB:TimelineDone()
    self.entity.DynamicEffectComponent:SetIsHide(false)
    self.entity.DynamicEffectComponent:RefreshEffect()
    self:ActionComplete()
end
