AddPlayerAB = BaseClass("AddPlayerAB",ActionBehaviorBase)

function AddPlayerAB:__Init()
    self.doneTimer = nil
end

function AddPlayerAB:__Delete()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function AddPlayerAB:OnInit()
end

function AddPlayerAB:OnStart()
    LogTable("添加机甲AB",self.args)

    self.world.DataSystem:AddRoleData(self.args.baseInfo,self.args.statusInfo)

    self.world.CarrierSystem:CreateCarrier(self.args.baseInfo.uid)

    self.doneTimer = self.world.TimerSystem:AddTimer(1,1,self:ToFunc("OnDoneTimer"))
end

function AddPlayerAB:OnCancel()
end

function AddPlayerAB:OnUpdate(deltaTime)
end

function AddPlayerAB:OnDoneTimer()
    self.doneTimer = nil
    self:ActionComplete()
end