
-- 所有添加堆叠的表现，只在这里处理，无视卡牌移动
AddStackActionAB = BaseClass("AddStackActionAB", ActionBehaviorBase)

-- 卡牌首次进入堆叠的最短显示时长（秒，使用真实时间，无视倍速）
local FIRST_TIME_MIN_DISPLAY_SEC = 1.5

function AddStackActionAB:__Init()
    self.addAnim = nil
    self.doneTimer = nil
    self.doneNum = 0
    self.carrierPlayTimeline = nil
    self.flyActiveTimeline = nil

    self.waitTime = 0.1
    self.hideCardTime = 0.3
    self.stackAdded = false

    -- 首次进入堆叠相关
    self.isFirstTime = false
    self.stackStartTime = 0
    self.firstTimeTimer = nil

    -- 无人机触发式异能格子高亮
    self.dronePassiveHighLightCamp = nil
    self.dronePassiveHighLightIndex = nil

    -- 无人机飞行动画 OnComplete 保底定时器
    self.dronePassiveFallbackTimer = nil
end

function AddStackActionAB:__Delete()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end

    if self.moveTimer then
        self.world.TimerSystem:RemoveTimer(self.moveTimer)
        self.moveTimer = nil
    end

    if self.addAnim then
        self.addAnim:Delete()
        self.addAnim = nil
    end

    if self.carrierPlayTimeline then
        self.carrierPlayTimeline:Delete()
        self.carrierPlayTimeline = nil
    end

    if self.flyActiveTimeline then
        self.flyActiveTimeline:Delete()
        self.flyActiveTimeline = nil
    end

    if self.preTimer then
        self.world.TimerSystem:RemoveTimer(self.preTimer)
        self.preTimer = nil
    end

    if self.hideTimer then
        TimerManager.Instance:RemoveTimer(self.hideTimer)
        self.hideTimer = nil
    end

    if self.firstTimeTimer then
        TimerManager.Instance:RemoveTimer(self.firstTimeTimer)
        self.firstTimeTimer = nil
    end

    if self.dronePassiveFallbackTimer then
        self.world.TimerSystem:RemoveTimer(self.dronePassiveFallbackTimer)
        self.dronePassiveFallbackTimer = nil
    end

    -- 清除残留的格子高亮
    if self.dronePassiveHighLightCamp and self.dronePassiveHighLightIndex then
        if self.world and self.world.SceneSystem then
            self.world.SceneSystem:ShowStackHighLight(self.dronePassiveHighLightCamp, self.dronePassiveHighLightIndex, false)
        end
        self.dronePassiveHighLightCamp = nil
        self.dronePassiveHighLightIndex = nil
    end
end

function AddStackActionAB:OnInit()

end

function AddStackActionAB:OnStart()
    LogTable("添加堆叠AB", self.args)

    if not self:CheckCardConfig() then
        self.world.DataSystem:AddStackInfo(self.args.info)
        self:ActionComplete()
        return
    end

    self.isFirstTime = false
    -- 检查该 cardId 是否首次进入堆叠（CheckCardConfig 可能已修正 cardId）
    if self.args.info.cardInfo.cardId == 0 then
        if self.args.info.effectSrcType == BattleDefine.EffectSrcType.chip_effect then
            self.isFirstTime = self.world.StateSystem:CheckAndMarkFirstTimeStackChip(self.args.info.effectSrcValue)
        end
    else
        self.isFirstTime = self.world.StateSystem:CheckAndMarkFirstTimeStackCard(self.args.info.cardInfo.cardId)
    end

    local camp = self.world.DataSystem:GetCamp(self.args.info.actor)
    if self.args.info.cardInfo.cardId ~= 0 and camp == BattleDefine.Camp.self then
        self.isFirstTime = false
    end

    self.world.StateSystem:SetCacheInfo(string.format("%s_time", self.args.info.stackId), Time.time)

    self:ClearVirtualEnergy(camp)

    if self:IsDirectUseCardType() then
        -- 获取来源对象的位置和缩放（隐藏前），用于堆叠项飞行动画的起点
        local fromWorldPos, fromScale = self:GetDirectUseSourceTransform()

        -- 隐藏来源对象（手牌或道具）
        self:HideDirectUseSource()

        -- 创建堆叠项 + 更新数据
        self.stackAdded = true
        self:ProcessAddStack()
        self:ProcessUIEffect()

        -- 堆叠项从来源位飞到堆叠目标位（fire-and-forget）
        self:PlayHandToStackFlyAnim(fromWorldPos, fromScale)

        -- 首次出现等满最短显示时长，否则立即完成
        self:TryCompleteWithDelay()
        return
    else
        self:AddStackAndProcess(camp)
    end
end

function AddStackActionAB:CheckCardConfig()
    local cardConf = Config.Get("card_def", "config", "cardId", self.args.info.cardInfo.cardId)
    local skillConfig = Config.Get("battle_skill_def", "config", "skillId", self.args.info.skillId)

    if not cardConf then
        if skillConfig.extend.linkCardId then
            self.args.info.cardInfo.cardId = skillConfig.extend.linkCardId
            return true
        elseif self.args.info.effectSrcType == BattleDefine.EffectSrcType.item_effect then
            return true
        elseif self.args.info.effectSrcType == BattleDefine.EffectSrcType.chip_effect then
            return true
        elseif self.args.info.effectSrcType == BattleDefine.EffectSrcType.hero_effect then
            return true
        end

        LogErrorf("堆叠来源effectSrcType[%s]不存在卡牌Id,不适配", tostring(self.args.info.effectSrcType))
        return false
    end

    return true
end

function AddStackActionAB:ProcessAddStack()
    self.world.HandCardSystem:ClearCardStackState(self.args.info.cardInfo.id)

    local stackInfo = {}
    stackInfo.stackData = self.args.info

    mod.BattleFacade:SendEvent(BattleStackCardView.Event.AddStack, stackInfo)
    self.world.DataSystem:AddStackInfo(self.args.info)

    -- 记录卡牌加入堆叠的时刻（用于首次最短显示计时）
    self.stackStartTime = Time.realtimeSinceStartup
end

-- 若是场上无人机触发的 passive 堆叠，高亮格子并播放卡牌从格子飞出动画
function AddStackActionAB:TryPlayDronePassiveFlyAnim()
    local info = self.args.info
    if info.type ~= BattleDefine.StackType.passive then
        return
    end

    -- 通过 cardInfo.id 溯源格子（仅场上无人机才有效）
    local gridInfo = self.world.DataSystem:GetGridInfoByDeviceUid(info.cardInfo.id)
    if not gridInfo then
        return
    end

    local camp = self.world.DataSystem:GetCamp(info.actor)

    -- 高亮格子
    self.dronePassiveHighLightCamp = camp
    self.dronePassiveHighLightIndex = gridInfo.position
    self.world.SceneSystem:ShowStackHighLight(camp, gridInfo.position, true)

    local gridWorldPos3D = self.world.SceneSystem:GetGridPos(camp, gridInfo.position)
    if not gridWorldPos3D then
        return
    end

    -- 飞到堆叠位
    local stackInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackInfo, info.stackId)
    if not stackInfo or not stackInfo.item then
        self.world.SceneSystem:ShowStackHighLight(camp, gridInfo.position, false)
        self.dronePassiveHighLightCamp = nil
        self.dronePassiveHighLightIndex = nil
        return
    end

    -- 格子 3D 世界坐标 → 屏幕坐标 → 堆叠父节点本地坐标 → UI 世界坐标
    -- 以 stackParent 为参照 rect，绕开 canvasRoot pivot 与 calcPosNode 锚点不一致的偏移问题
    local gridVec = Vector3(gridWorldPos3D.x, gridWorldPos3D.y, gridWorldPos3D.z)
    local screenPos3D = KvData.mainCamera:WorldToScreenPoint(gridVec)
    local stackParent = stackInfo.item.transform.parent
    local _, fromLocalPos = RectTransformUtility.ScreenPointToLocalPointInRectangle(stackParent, Vector2(screenPos3D.x, screenPos3D.y), UIDefine.uiCamera, 0)
    local fromWorldPos = stackParent:TransformPoint(Vector3(fromLocalPos.x, fromLocalPos.y, 0))

    local targetPos = stackInfo.item.transform.position

    -- 接管 doneNum 控制权：取消 HandleNormalMoveAnim 留下的 MoveComplete timer 和 MoveAnim，
    -- 避免 0.4s 后被提前 ActionComplete，也避免 MoveAnim 与 DOTween 同时写 position/scale
    if self.moveTimer then
        self.world.TimerSystem:RemoveTimer(self.moveTimer)
        self.moveTimer = nil
    end
    if self.addAnim then
        self.addAnim:Delete()
        self.addAnim = nil
    end
    -- doneNum 已由 HandleNormalMoveAnim +1，此处不再重复增减，
    -- 改由 OnDronePassiveFlyComplete 调用 CheckComplete 来归还

    local FLY_DURATION = 0.5
    stackInfo.item.transform:DOKill()
    stackInfo.item.transform:SetPosition(fromWorldPos.x, fromWorldPos.y, fromWorldPos.z)
    stackInfo.item.transform:SetLocalScale(0.3, 0.3, 3)

    stackInfo.item.transform:DOMove(targetPos, FLY_DURATION)

    local targetScale = Vector3(BattleDefine.CardScale.stack.x, BattleDefine.CardScale.stack.y, 1)
    stackInfo.item.transform:DOScale(targetScale, FLY_DURATION):OnComplete(self:ToFunc("OnDronePassiveFlyComplete"))

    -- 保底机制：DOTween 若被外部 DOKill 导致 OnComplete 丢失，0.6s 后强制触发
    local FALLBACK_TIME = 0.6
    self.dronePassiveFallbackTimer = self.world.TimerSystem:AddTimer(1, FALLBACK_TIME, self:ToFunc("OnDronePassiveFallback"))
end

-- 保底定时器回调：OnComplete 未在预期时间内触发时手动补发
function AddStackActionAB:OnDronePassiveFallback()
    self.dronePassiveFallbackTimer = nil
    self:OnDronePassiveFlyComplete()
end

-- 飞出动画结束后关闭格子高亮，并归还 doneNum 控制权触发 ActionComplete
function AddStackActionAB:OnDronePassiveFlyComplete()
    -- 取消保底定时器（正常路径触发时）
    if self.dronePassiveFallbackTimer then
        self.world.TimerSystem:RemoveTimer(self.dronePassiveFallbackTimer)
        self.dronePassiveFallbackTimer = nil
    end

    if self.dronePassiveHighLightCamp and self.dronePassiveHighLightIndex then
        self.world.SceneSystem:ShowStackHighLight(self.dronePassiveHighLightCamp, self.dronePassiveHighLightIndex, false)
        self.dronePassiveHighLightCamp = nil
        self.dronePassiveHighLightIndex = nil
    end
    -- 替代被取消的 MoveComplete timer，触发后续 DelayComplete → CheckComplete → ActionComplete
    self.doneTimer = self.world.TimerSystem:AddTimer(1, self.waitTime, self:ToFunc("DelayComplete"))
end

function AddStackActionAB:ProcessStackAnim(camp)
    if camp == BattleDefine.Camp.self then
        local effectSrcType = self.args.info.effectSrcType

        -- 手牌直接使用 -> 只需要延迟等待
        if self:IsDirectUseCardType() then
            self.doneNum = self.doneNum + 1
            self.doneTimer = self.world.TimerSystem:AddTimer(1, self.waitTime, self:ToFunc("DelayComplete"))
        elseif effectSrcType == BattleDefine.EffectSrcType.equip_effect then
            self:HandleEquipEffect()
        else
            self:HandleNormalMoveAnim()
        end
    else
        local area = self.args.info.cardInfo.area
        if area == BattleDefine.CardAreaDef.queueCars then
            self:HandleQueueEffect()
        else
            self:HandleNormalMoveAnim()
        end
    end
end

-- 是否由使用手牌產生的堆叠
function AddStackActionAB:IsDirectUseCardType()
    local camp = self.world.DataSystem:GetCamp(self.args.info.actor)
    if camp == BattleDefine.Camp.enemy then
        return false
    end

    if self.args.info.type == BattleDefine.StackType.card_cmd then
        return true
    end

    if self.args.info.type == BattleDefine.StackType.device_drone then
        return true
    end

    if self.args.info.type == BattleDefine.StackType.device then
        return true
    end

    if self.args.info.type == BattleDefine.StackType.item then
        return true
    end

    if self.args.info.type == BattleDefine.StackType.hero then
        return true
    end

    if self.args.info.effectSrcType == BattleDefine.EffectSrcType.chip_effect then
        return false
    end

    return false
end

function AddStackActionAB:HandleEquipEffect()
    mod.BattleFacade:SendEvent(BattleStackCardView.Event.StopStackAnim, self.args.info.stackId)

    if mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.HasSlotByCardUid, self.args.info.actor, self.args.info.effectSrcValue) then
        local fromPos = self.world.MixedSystem:GetPosBySrcType(self.args.info.actor, self.args.info.effectSrcType, self.args.info.effectSrcValue)
        self:PlayMoveCardAnim(fromPos, self.args.info.stackId, 0.3)
    else
        local stackInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackInfo, self.args.info.stackId)
        local fromPos = stackInfo.item.transform.position
        self:PlayMoveCardAnim(fromPos, self.args.info.stackId, 0.3)
    end

    self:AddMoveCompleteTimer(0.3)
    self.doneNum = self.doneNum + 1
end

function AddStackActionAB:HandleQueueEffect()
    mod.BattleFacade:SendEvent(BattleStackCardView.Event.StopStackAnim, self.args.info.stackId)
    local camp = self.world.DataSystem:GetCamp(self.args.info.actor)
    local areaType = BattleDefine.CardAreaDef.queueCars
    local pos = mod.BattleFacade:SendEvent(BattleTempCardView.Event.GetTempCardPos, camp, areaType)

    self:PlayMoveCardAnim(pos, self.args.info.stackId, 0.3)
    self:AddMoveCompleteTimer(0.3)
    self.doneNum = self.doneNum + 1
end

function AddStackActionAB:HandleNormalMoveAnim()
    mod.BattleFacade:SendEvent(BattleStackCardView.Event.StopStackAnim, self.args.info.stackId)
    local stackInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackInfo, self.args.info.stackId)
    local toPos = stackInfo.item.transform.position
    self:PlayMoveCardAnim(toPos, self.args.info.stackId, 0.3)
    self:AddMoveCompleteTimer(0.3)
    self.doneNum = self.doneNum + 1
end

-- 延迟的理由：等待手牌移动到堆叠位置
-- 隐藏手牌->堆叠的临时显示
function AddStackActionAB:HideHandCard()
    if self.hideTimer then
        TimerManager.Instance:RemoveTimer(self.hideTimer)
        self.hideTimer = nil
    end

    if self.args.info.effectSrcType == BattleDefine.EffectSrcType.item_effect then
        local item = mod.BattleFacade:SendEvent(BattleBattleItemView.Event.GetBattleItemObj,
            self.args.info.effectSrcValue)
        item.tposeTrans.gameObject:SetActive(false)
    else
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.ActiveHandCard, self.args.info.cardInfo.id, false)
    end


    local camp = self.world.DataSystem:GetCamp(self.args.info.actor)
    self:AddStackAndProcess(camp)

    self:CheckComplete()
end

function AddStackActionAB:ClearVirtualEnergy(camp)
    if camp == BattleDefine.Camp.self then
        local cardUid = self.args.info.cardInfo.id
        self.world.DataSystem:ClearVirtualEnergy(cardUid)
    end
end

function AddStackActionAB:PlayMoveCardAnim(fromPos, stackId, time)
    local stackInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackInfo, stackId)
    local toPos = stackInfo.item.transform.position
    local toScale = stackInfo.item.transform.localScale.x

    stackInfo.item.transform:SetPosition(fromPos.x, fromPos.y, fromPos.z)
    stackInfo.item.transform:SetLocalScale(0, 0, 1)

    local moveAnim = MoveAnim.New(stackInfo.item.transform, toPos, time)
    local scaleAnim = ScaleAnim.New(stackInfo.item.transform, toScale, time)

    self.addAnim = ParallelAnim.New({ moveAnim, scaleAnim })
    self.addAnim:Play()
end

-- 获取来源对象（手牌或道具）的世界坐标和缩放，用于堆叠飞行动画起点
function AddStackActionAB:GetDirectUseSourceTransform()
    local fromWorldPos = nil
    local fromScale = Vector3.zero

    if self.args.info.effectSrcType == BattleDefine.EffectSrcType.item_effect then
        local item = mod.BattleFacade:SendEvent(
            BattleBattleItemView.Event.GetBattleItemObj, self.args.info.effectSrcValue)
        if item and not BaseUtils.IsNull(item.tposeTrans) then
            fromWorldPos = item.tposeTrans.position
            fromScale = item.tposeTrans.localScale
        end
    else
        local cardInfo = mod.BattleFacade:SendEvent(
            BattleHandCardView.Event.GetHandCardInfo, self.args.info.cardInfo.id)
        if cardInfo and cardInfo.item then
            fromWorldPos = cardInfo.item.tposeTrans.position
            fromScale = cardInfo.item.tposeTrans.localScale
        end
    end

    return fromWorldPos, fromScale
end

-- 隐藏来源对象（手牌或道具）
function AddStackActionAB:HideDirectUseSource()
    if self.args.info.effectSrcType == BattleDefine.EffectSrcType.item_effect then
        local item = mod.BattleFacade:SendEvent(
            BattleBattleItemView.Event.GetBattleItemObj, self.args.info.effectSrcValue)
        if item and not BaseUtils.IsNull(item.tposeTrans) then
            item.tposeTrans.gameObject:SetActive(false)
        end
    else
        mod.BattleFacade:SendEvent(
            BattleHandCardView.Event.ActiveHandCard, self.args.info.cardInfo.id, false)
    end
end

-- 堆叠项从来源位飞到堆叠目标位（fire-and-forget，不阻塞）
function AddStackActionAB:PlayHandToStackFlyAnim(fromWorldPos, fromScale)
    local stackInfo = mod.BattleFacade:SendEvent(
        BattleStackCardView.Event.GetStackInfo, self.args.info.stackId)
    if not stackInfo or not stackInfo.item then return end

    -- 异常兜底：没有来源位时用 cardUsePos
    if not fromWorldPos then
        fromWorldPos = mod.BattleFacade:SendEvent(
            BattleStackCardView.Event.GetCardUsePosTransform)
    end

    local targetPos = stackInfo.item.transform.position
    local targetScale = stackInfo.item.transform.localScale

    -- Kill 掉 AddStack → RefreshAllCardStackPos 中启动的 DOTween
    stackInfo.item.transform:DOKill()

    -- 从来源位置和缩放出发
    stackInfo.item.transform:SetPosition(fromWorldPos.x, fromWorldPos.y, fromWorldPos.z)
    stackInfo.item.transform:SetLocalScale(fromScale.x, fromScale.y, fromScale.z)

    -- 飞到目标位 + 缩放到目标大小
    local FLY_DURATION = 0.2
    stackInfo.item.transform:DOMove(targetPos, FLY_DURATION)
    stackInfo.item.transform:DOScale(targetScale, FLY_DURATION)
end

function AddStackActionAB:PlayDeviceDroneEffect()
    local info = self.args and self.args.info
    if not info or info.type ~= BattleDefine.StackType.passive then
        return
    end

    local value = info.effectSrcValue
    if not value or value == 0 then
        return
    end

    local cardInfo = self.world.DataSystem:GetCardInfo(value)
    if not cardInfo or cardInfo.area ~= BattleDefine.CardAreaDef.device_drone then
        return
    end

    local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(value)
    if entity and entity.DeviceTopInfoComponent then
        entity.DeviceTopInfoComponent:ShowSkillEffect(info.skillId)
    end
end

function AddStackActionAB:AddMoveCompleteTimer(time)
    self.moveTimer = self.world.TimerSystem:AddTimer(1, time, self:ToFunc("MoveComplete"))
end

function AddStackActionAB:MoveComplete()
    if self.moveTimer then
        self.world.TimerSystem:RemoveTimer(self.moveTimer)
        self.moveTimer = nil
    end

    self.doneTimer = self.world.TimerSystem:AddTimer(1, self.waitTime, self:ToFunc("DelayComplete"))
end

function AddStackActionAB:DelayComplete()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end

    self:CheckComplete()
end

function AddStackActionAB:CheckComplete()
    self.doneNum = self.doneNum - 1
    if self.doneNum <= 0 then
        self:TryCompleteWithDelay()
    end
end

-- 若为首次进入堆叠，等满最短显示时长后再完成；否则立即完成
function AddStackActionAB:TryCompleteWithDelay()
    if not self.isFirstTime then
        self:ActionComplete()
        return
    end

    local elapsed = Time.realtimeSinceStartup - self.stackStartTime
    local remaining = FIRST_TIME_MIN_DISPLAY_SEC - elapsed
    if remaining <= 0 then
        self:ActionComplete()
        return
    end

    self.firstTimeTimer = TimerManager.Instance:AddTimer(1, remaining, self:ToFunc("OnFirstTimeComplete"))
    self.firstTimeTimer:SetScale(false) -- 使用真实时间，无视倍速
end

function AddStackActionAB:OnFirstTimeComplete()
    self.firstTimeTimer = nil
    self:ActionComplete()
end

function AddStackActionAB:OnCancel()
end

function AddStackActionAB:OnUpdate(deltaTime)
    if self.carrierPlayTimeline then
        self.carrierPlayTimeline:Update(deltaTime)
    end
end

function AddStackActionAB:AddStackAndProcess(camp)
    if self.stackAdded then
        return
    end

    self.stackAdded = true
    self:ProcessAddStack()
    self:ProcessStackAnim(camp)
    -- 触发式异能溯源到场上无人机时，在 ProcessStackAnim 之后覆盖动画，避免被 MoveAnim 覆盖
    self:TryPlayDronePassiveFlyAnim()
    self:PlayDeviceDroneEffect()
    self:ProcessUIEffect()
end

function AddStackActionAB:ProcessUIEffect()
    if self.args.info.effectSrcType == BattleDefine.EffectSrcType.chip_effect then
        mod.BattleFacade:SendEvent(BattleCarrierChipView.Event.OnBattleChipEffect, self.args.info.effectSrcValue)
    elseif self.args.info.effectSrcType == BattleDefine.EffectSrcType.hero_effect then
        mod.BattleFacade:SendEvent(BattleHeroView.Event.OnBattleHeroEffect, self.args.info.effectSrcValue)
    end

    mod.BattleFacade:SendEvent(BattleChainQueueView.Event.ShowChainQueueHighlight, self.args.info.cardInfo.id, true)
end
