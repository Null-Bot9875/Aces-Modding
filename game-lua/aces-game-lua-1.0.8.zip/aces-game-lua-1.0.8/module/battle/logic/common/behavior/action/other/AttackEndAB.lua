AttackEndAB = BaseClass("AttackEndAB",ActionBehaviorBase)

function AttackEndAB:__Init()
end

function AttackEndAB:__Delete()

end

function AttackEndAB:OnInit()

end

function AttackEndAB:OnStart()
    LogTable("攻击结束AB",self.args)
    --self.world.DeviceSystem:SetExistAttack(false)
    --self.world.DeviceSystem:ClearLine()
    -- 多重攻击逻辑已移至 BehaviorMerger:ProcessMultiAttack 中处理
    self:ActionComplete()
end


function AttackEndAB:OnCancel()

end

function AttackEndAB:OnUpdate(deltaTime)

end