AttackStartAB = BaseClass("AttackStartAB",ActionBehaviorBase)

function AttackStartAB:__Init()
end

function AttackStartAB:__Delete()
    if self.timer then
        TimerManager.Instance:RemoveTimer(self.timer)
        self.timer = nil
    end
end

function AttackStartAB:OnInit()

end

function AttackStartAB:OnStart()
    LogTable("攻击准备AB",self.args)

    -- optional int32 attker = 1;//发起者uid
    -- optional int32 target = 2;
    -- optional BattleSkillInfo info = 3;
    -- optional int32 srcEquipId = 4; //发起者装备id

    -- if self.world.DataSystem:IsRoleUid(self.args.attker) then
    --     self.world.DeviceSystem:SetExistAttack(true)
    -- end

    --self.world.DeviceSystem:ActiveLine(self.args.attker,self.args.target,self.args.srcEquipId,true)
    --self.world.DeviceSystem:ClearLine()
    -- mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.ClearAtkLine)

    -- 多重攻击逻辑已移至 BehaviorMerger:ProcessMultiAttack 中处理

    self:ActionComplete()
end

function AttackStartAB:DealyComplete()
    if self.timer then
        TimerManager.Instance:RemoveTimer(self.timer)
        self.timer = nil
    end

    self:ActionComplete()    
end


function AttackStartAB:OnCancel()

end

function AttackStartAB:OnUpdate(deltaTime)

end