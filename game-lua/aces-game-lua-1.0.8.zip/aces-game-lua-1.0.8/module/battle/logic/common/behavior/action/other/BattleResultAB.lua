-- 战斗结算 AB：为 action 队列最后一个，无需调用 ActionComplete，否则反而会触发后续逻辑问题
BattleResultAB = BaseClass("BattleResultAB",ActionBehaviorBase)

local BLACK_SCREEN_DURATION = 2 -- 黑屏持续时间（秒）
local FADE_IN_DURATION = 0.3 -- 淡入时长（秒）
local FADE_OUT_DURATION = 0.3 -- 淡出时长（秒）

function BattleResultAB:__Init()
    self.isWin = false
end

function BattleResultAB:__Delete()
    self:ClearAllTimers()
    self:ClearDOTween()
    self:ClearPvResources()
    self:ClearEventListeners()
end

function BattleResultAB:OnInit()
end

function BattleResultAB:OnStart()
    LogTable("战斗结算了",self.args)

    self.world.CameraSystem:EnableFreeCamera(false)
    local isWin = self.world.DataSystem:IsRoleUid(self.args.winner)
    self.world.OperateSystem:ClearOperate()

    ViewManager.Instance:CloseAllWindow()
    ViewManager.Instance:SetOrderLayer(BattleDefine.UILayer.battle_max)

    self.world.StateSystem:ChangeSpeed(false)
    self.world.StateSystem:SetSpeedLock(true)

    local camp = isWin and BattleDefine.Camp.enemy or BattleDefine.Camp.self
    local loseRoleUids = self.world.DataSystem:GetRoleUids(camp)
    for _,roleUid in ipairs(loseRoleUids) do
        local loseCarrierEntity = self.world.EntitySystem:GetCarrierEntity(roleUid)
        if loseCarrierEntity then
            loseCarrierEntity.AnimComponent:PlayAnim("dead")
        end
    end
    self.deadTimer = self.world.TimerSystem:AddTimer(1,1,self:ToFunc("DeadDone"))

    local args = {}
    args.isWin = isWin
    EventManager.Instance:SendEvent(EventDefine.battle_result,args)

    local sectionId = self.world.DataSystem:GetSectionId()
    mod.GuideEventCtrl:Trigger(GuideDefine.Event.battle_result,isWin,sectionId)

    if isWin then
        mod.GuideEventCtrl:Trigger(GuideDefine.Event.battle_win)
    end

    local mode = self.world.DataSystem:GetBattleMatchType()
    local type = self.world.DataSystem:GetBattleType()
    if type == BattleDefine.BattleType.match then
        mod.MatchCtrl:SetAutoReturnMatch(mode)
    end

    self.isWin = isWin
end

function BattleResultAB:OnConfigClick()
    mod.BattleCtrl:ExitBattle(self.world)
end

function BattleResultAB:DeadDone()
    self.deadTimer = nil

    Log("进入结算了")

    self.world.StateSystem:SetIsEndBattle(true)
    mod.BattleFacade:SendEvent(BattleMainPanel.Event.ActiveMainPanel, false)
    self.world.AssetsSystem.rootNode:SetActive(false)

    ViewManager.Instance:CloseAllWindow()

    
    -- 检查是否需要播放PV
    local mode = self.world.DataSystem:GetBattleType()
    if mode == BattleDefine.BattleType.pve and self.isWin then
        local curEpNodeInfo = mod.PveRogueProxy:GetCurrEpNodeInfo()
        if curEpNodeInfo then
            local nodeConf = Config.Get("act_node_def", "config", "id", curEpNodeInfo.nodeId)
            if nodeConf and nodeConf.endTimeline and nodeConf.endTimeline ~= "" then
                self:StartPvSequence(AssetPath.GetPv(nodeConf.endTimeline))
                return
            end
        end
    end

    self:ResultAction()
end

-- ==================== PV播放流程 ====================

-- 开始PV播放流程：黑屏 -> 加载PV -> 播放PV -> 结束黑屏 -> 打开窗口
function BattleResultAB:StartPvSequence(pvPath)
    -- 防护：玩家失败时不应进入PV流程，避免Boss关死亡后黑屏
    if not self.world.DataSystem:IsRoleUid(self.args.winner) then
        self:ResultAction()
        return
    end
    self.pvPath = pvPath
    self.pvLoadComplete = false
    self.startBlackScreenComplete = false
    
    -- 开始黑屏淡入
    self:StartBlackScreenFadeIn()
    
    -- 同时开始加载PV
    self:LoadPv(pvPath)
end

-- 开始黑屏淡入
function BattleResultAB:StartBlackScreenFadeIn()
    local canvasGroup = UIDefine.transBlackMaskCanvasGroup
    canvasGroup.blocksRaycasts = true
    
    -- 使用DOTween淡入到全黑
    if self.startFadeTween then
        self.startFadeTween:Kill()
    end
    self.startFadeTween = canvasGroup:DOFade(1, FADE_IN_DURATION)
    
    -- 等待黑屏保持2秒
    self.startBlackScreenTimer = TimerManager.Instance:AddTimer(1, FADE_IN_DURATION + BLACK_SCREEN_DURATION, self:ToFunc("OnStartBlackScreenComplete"))
end

-- 开始黑屏完成（黑屏保持2秒完成）
function BattleResultAB:OnStartBlackScreenComplete()
    KvData.mainCamera.gameObject:GetComponent(Skybox).material = nil
    KvData.mainCamera.clearFlags = CameraClearFlags.SolidColor

    self.startBlackScreenComplete = true
    self:CheckStartPvReady()
end

-- 加载PV资源
function BattleResultAB:LoadPv(pvPath)
    self:ReleasePendingPvAsset()
    
    self.pvAssetScope = AssetScope()
    self.pvAssetLoader = AssetBatchLoader.New(self.pvAssetScope)
    self.pvAssetLoader:Load({{file = pvPath, type = AssetType.Prefab}}, self:ToFunc("OnPvLoadDone"))
end

-- PV加载完成
function BattleResultAB:OnPvLoadDone(_, hasError)
    if not self.pvAssetLoader or not self.pvPath then
        self:ReleasePendingPvAsset()
        self:OnPvSequenceFailed()
        return
    end
    
    local pvPrefab = hasError and nil or self.pvAssetLoader:Instantiate(self.pvPath)
    if not pvPrefab then
        LogError("PV加载失败: " .. tostring(self.pvPath))
        self.pvPath = nil
        self:ReleasePendingPvAsset()
        -- 加载失败，直接进入结果流程
        self:OnPvSequenceFailed()
        return
    end
    
    pvPrefab:SetActive(false)
    self.pvPrefab = pvPrefab
    self.pvAssetLoader:Destroy()
    self.pvAssetLoader = nil
    
    self.pvLoadComplete = true
    self:CheckStartPvReady()
end

-- 检查是否可以开始播放PV（需要黑屏完成且PV加载完成）
function BattleResultAB:CheckStartPvReady()
    if not self.startBlackScreenComplete or not self.pvLoadComplete then
        return
    end
    
    -- 取消开始黑屏，淡出
    self:StartBlackScreenFadeOut()
end

-- 开始黑屏淡出
function BattleResultAB:StartBlackScreenFadeOut()
    local canvasGroup = UIDefine.transBlackMaskCanvasGroup
    
    if self.startFadeTween then
        self.startFadeTween:Kill()
    end
    self.startFadeTween = canvasGroup:DOFade(0, FADE_OUT_DURATION)
    self.startFadeTween:OnComplete(self:ToFunc("OnStartBlackScreenFadeOutComplete"))

    -- 开始播放PV
    self:PlayPv()
end

-- 开始黑屏淡出完成，开始播放PV
function BattleResultAB:OnStartBlackScreenFadeOutComplete()
    if self.startFadeTween then
        self.startFadeTween = nil
    end
    
    local canvasGroup = UIDefine.transBlackMaskCanvasGroup
    canvasGroup.blocksRaycasts = false
end

-- 播放PV
function BattleResultAB:PlayPv()
    if not self.pvPrefab then
        LogError("PV预制体不存在")
        self:OnPvSequenceFailed()
        return
    end
    
    -- 先保存引用，再清理旧的pvObj
    local pvPrefab = self.pvPrefab
    if self.pvObj then
        GameObject.Destroy(self.pvObj)
        self.pvObj = nil
    end
    
    -- 使用保存的预制体创建PV对象
    self.pvObj = pvPrefab
    self.pvObj:AddComponent(AssetScopeComponent):Adopt(self.pvAssetScope)
    self.pvAssetScope = nil
    self.pvObj:SetActive(true)
    self.pvPrefab = nil
    
    local playableDirector = self.pvObj:GetComponent(PlayableDirector)
    if not playableDirector then
        LogError("PV对象没有PlayableDirector组件")
        self:OnPvSequenceFailed()
        return
    end
    
    -- 静音BGM
    AudioManager.Instance:SetMute(AudioDefine.AudioType.bgm, true)
    
    -- 等待PV播放完成
    local duration = playableDirector.duration
    self.pvTimer = TimerManager.Instance:AddTimer(1, duration - FADE_OUT_DURATION, self:ToFunc("OnPvPlayComplete"))
end

-- PV播放完成
function BattleResultAB:OnPvPlayComplete()
    self.pvTimer = nil
    
    -- 恢复BGM
    AudioManager.Instance:SetMute(AudioDefine.AudioType.bgm, false)
    
    -- 显示结束黑屏
    self:EndBlackScreenFadeIn()
end

-- 结束黑屏淡入
function BattleResultAB:EndBlackScreenFadeIn()    
    local canvasGroup = UIDefine.transBlackMaskCanvasGroup
    canvasGroup.blocksRaycasts = true
    
    if self.endFadeTween then
        self.endFadeTween:Kill()
    end
    self.endFadeTween = canvasGroup:DOFade(1, FADE_IN_DURATION)
    
    -- 等待黑屏保持2秒
    self.endBlackScreenTimer = TimerManager.Instance:AddTimer(1, FADE_IN_DURATION + BLACK_SCREEN_DURATION, self:ToFunc("OnEndBlackScreenComplete"))
end

-- 结束黑屏完成
function BattleResultAB:OnEndBlackScreenComplete()
    if self.pvObj then
        self.pvObj:SetActive(false)
    end

    self.endBlackScreenTimer = nil
    
    -- 清理PV资源
    self:CleanPv()
    self.pvPath = nil
    
    -- 打开窗口（保持黑屏）
    self:ResultAction()
end

-- PV流程失败，直接进入结果流程
function BattleResultAB:OnPvSequenceFailed()
    self:CleanPv()
    self.pvPath = nil
    
    local canvasGroup = UIDefine.transBlackMaskCanvasGroup
    if canvasGroup.alpha > 0 then
        canvasGroup.alpha = 0
        canvasGroup.blocksRaycasts = false
    end
    
    self:ResultAction()
end

-- ==================== 结果流程 ====================

function BattleResultAB:ResultAction()
    -- PVE 模式下，启动退出战斗轮询定时器
    if self.world.DataSystem.enterData.baseInfo.type == BattleDefine.BattleType.pve then
        if mod.PveRogueCtrl then
            mod.PveRogueCtrl:StartCheckExitBattlePolling()
        end
    end

    ViewManager.Instance:CloseAllWindow()
    local args = {}
    args.onConfirmClick = self:ToFunc("OnConfigClick")
    args.isWin = self.world.DataSystem:IsRoleUid(self.args.winner)
    args.resultData = self.args

    -- 监听窗口打开完成事件
    self.waitingWindowOpen = true
    EventManager.Instance:AddEvent(EventDefine.open_window, self:ToFunc("OnWindowOpenComplete"))

    local isWin = self.world.DataSystem:IsRoleUid(self.args.winner)
    local mode = BattleDefine.BattleTypeMap[self.world.DataSystem.enterData.baseInfo.type]
    if mode == BattleDefine.BattleMode.pvp then
        ViewManager.Instance:OpenWindow(PvpStatementWindow, args)
    elseif mode == BattleDefine.BattleMode.pve then
        mod.PveRogueCtrl:OpenNextWindow()
        Log(string.format("战斗结算了，打开下一个窗口: %s", mode))
    else
        self.waitingWindowOpen = false
        EventManager.Instance:RemoveEvent(EventDefine.open_window, self:ToFunc("OnWindowOpenComplete"))
        self.world.StateSystem:SetExit(true)
    end
end

-- 窗口打开完成回调
function BattleResultAB:OnWindowOpenComplete(winName)
    if not self.waitingWindowOpen then
        return
    end
    
    KvData.mainCamera.gameObject:GetComponent(Skybox).material = nil
    KvData.mainCamera.clearFlags = CameraClearFlags.SolidColor

    -- 窗口打开完成，取消黑屏
    self.waitingWindowOpen = false
    EventManager.Instance:RemoveEvent(EventDefine.open_window, self:ToFunc("OnWindowOpenComplete"))
    
    self:EndBlackScreenFadeOut()
end

-- 结束黑屏淡出
function BattleResultAB:EndBlackScreenFadeOut()
    local canvasGroup = UIDefine.transBlackMaskCanvasGroup
    if not canvasGroup or canvasGroup.alpha <= 0 then
        self:OnEndBlackScreenFadeOutComplete()
        return
    end
    
    if self.endFadeTween then
        self.endFadeTween:Kill()
    end
    self.endFadeTween = canvasGroup:DOFade(0, BLACK_SCREEN_DURATION)
    self.endFadeTween:OnComplete(self:ToFunc("OnEndBlackScreenFadeOutComplete"))
end

-- 结束黑屏淡出完成
function BattleResultAB:OnEndBlackScreenFadeOutComplete()
    if self.endFadeTween then
        self.endFadeTween = nil
    end
    
    local canvasGroup = UIDefine.transBlackMaskCanvasGroup
    if canvasGroup then
        canvasGroup.blocksRaycasts = false
    end
end

-- ==================== 清理方法 ====================

function BattleResultAB:ClearAllTimers()
    if self.deadTimer then
        self.world.TimerSystem:RemoveTimer(self.deadTimer)
        self.deadTimer = nil
    end
    if self.pvTimer then
        TimerManager.Instance:RemoveTimer(self.pvTimer)
        self.pvTimer = nil
    end
    if self.startBlackScreenTimer then
        TimerManager.Instance:RemoveTimer(self.startBlackScreenTimer)
        self.startBlackScreenTimer = nil
    end
    if self.endBlackScreenTimer then
        TimerManager.Instance:RemoveTimer(self.endBlackScreenTimer)
        self.endBlackScreenTimer = nil
    end
end

function BattleResultAB:ClearDOTween()
    if self.startFadeTween then
        self.startFadeTween:Kill()
        self.startFadeTween = nil
    end
    if self.endFadeTween then
        self.endFadeTween:Kill()
        self.endFadeTween = nil
    end
end

function BattleResultAB:ClearPvResources()
    self:ReleasePendingPvAsset()
    if self.pvTempObj then
        GameObject.Destroy(self.pvTempObj)
        self.pvTempObj = nil
    end
    self:CleanPv()
end

function BattleResultAB:ReleasePendingPvAsset()
    if self.pvAssetLoader then
        self.pvAssetLoader:Destroy()
        self.pvAssetLoader = nil
    end
    if self.pvAssetScope then
        self.pvAssetScope:Dispose()
        self.pvAssetScope = nil
    end
end

function BattleResultAB:CleanPv()
    if self.pvObj then
        GameObject.Destroy(self.pvObj)
        self.pvObj = nil
    end
    if self.pvPrefab then
        GameObject.Destroy(self.pvPrefab)
        self.pvPrefab = nil
    end
end

function BattleResultAB:ClearEventListeners()
    EventManager.Instance:RemoveEvent(EventDefine.open_window, self:ToFunc("OnWindowOpenComplete"))
end

function BattleResultAB:OnCancel()
    
end

function BattleResultAB:OnUpdate(deltaTime)
    
end
