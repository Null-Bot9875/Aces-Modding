CardLessWarnningAB = BaseClass("CardLessWarnningAB",ActionBehaviorBase)

function CardLessWarnningAB:__Init()
end

function CardLessWarnningAB:__Delete()
end

function CardLessWarnningAB:OnInit()

end


function CardLessWarnningAB:OnStart()
    SystemMessage.Show(TI18N("err_newcard_warning"))
    self:ActionComplete()
end

function CardLessWarnningAB:OnUpdate(deltaTime)
end
