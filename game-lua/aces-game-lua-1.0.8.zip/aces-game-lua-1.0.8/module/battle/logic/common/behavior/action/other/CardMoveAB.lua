--手牌：
--牌库
--弃牌堆：当战术、命令牌被使用、结算后，当设备牌被破坏后，当卡牌被弃置后，都会放置进入弃牌堆
--废弃区：只有当卡牌被标注为[废弃]的事件影响时，会将卡牌置入【废弃区】

--堆叠
CardMoveAB = BaseClass("CardMoveAB", ActionBehaviorBase)
CardMoveAB.BatchHandToDiscardIndex = 51110 -- 手牌到弃牌批处理索引
-- 批处理配置：当且仅当所有移动都满足以下(from,to)时，走对应批处理TB
CardMoveAB.BatchAreaTimelineIndex =
{
    {
        from = BattleDefine.CardAreaDef.hand,
        to = BattleDefine.CardAreaDef.discard,
        index = CardMoveAB.BatchHandToDiscardIndex
    },
}
CardMoveAB.AreaTimelineIndex =
{
    {
        from = BattleDefine.CardAreaDef.equip,
        to = BattleDefine.CardAreaDef.discard,
        index = 51001
    },
    {
        from = BattleDefine.CardAreaDef.equip,
        to = BattleDefine.CardAreaDef.hand,
        index = 51002
    },
    {
        from = BattleDefine.CardAreaDef.equip,
        to = BattleDefine.CardAreaDef.library,
        index = 51003
    },
    {
        from = BattleDefine.CardAreaDef.equip,
        to = BattleDefine.CardAreaDef.consume,
        index = 51004
    },
    {
        from = BattleDefine.CardAreaDef.hand,
        to = BattleDefine.CardAreaDef.discard,
        index = 51101
    },
    {
        from = BattleDefine.CardAreaDef.hand,
        to = BattleDefine.CardAreaDef.stack,
        index = 51102
    },
    {
        from = BattleDefine.CardAreaDef.hand,
        to = BattleDefine.CardAreaDef.consume,
        index = 51103
    },
    {
        from = BattleDefine.CardAreaDef.hand,
        to = BattleDefine.CardAreaDef.library,
        index = 51104
    },
    {
        from = BattleDefine.CardAreaDef.library,
        to = BattleDefine.CardAreaDef.hand,
        index = 51201
    },
    {
        from = BattleDefine.CardAreaDef.library,
        to = BattleDefine.CardAreaDef.newCard,
        index = 51202
    },
    {
        from = BattleDefine.CardAreaDef.library,
        to = BattleDefine.CardAreaDef.discard,
        index = 51203
    },
    {
        from = BattleDefine.CardAreaDef.library,
        to = BattleDefine.CardAreaDef.consume,
        index = 51204
    },
    {
        from = BattleDefine.CardAreaDef.device_drone,
        to = BattleDefine.CardAreaDef.discard,
        index = 51301
    },
    {
        from = BattleDefine.CardAreaDef.device_drone,
        to = BattleDefine.CardAreaDef.consume,
        index = 51302
    },
    {
        from = BattleDefine.CardAreaDef.device_drone,
        to = BattleDefine.CardAreaDef.library,
        index = 51303
    },
    {
        from = BattleDefine.CardAreaDef.device_drone,
        to = BattleDefine.CardAreaDef.hand,
        index = 51304
    },
    {
        from = BattleDefine.CardAreaDef.stack,
        to = BattleDefine.CardAreaDef.discard,
        index = 51401
    },
    {
        from = BattleDefine.CardAreaDef.stack,
        to = BattleDefine.CardAreaDef.equip,
        index = 51402
    },
    {
        from = BattleDefine.CardAreaDef.stack,
        to = BattleDefine.CardAreaDef.hand,
        index = 51403
    },
    {
        from = BattleDefine.CardAreaDef.stack,
        to = BattleDefine.CardAreaDef.consume,
        index = 51404
    },
    {
        from = BattleDefine.CardAreaDef.stack,
        to = BattleDefine.CardAreaDef.grid,
        index = 51405
    },
    {
        from = BattleDefine.CardAreaDef.stack,
        to = BattleDefine.CardAreaDef.device_drone,
        index = 51406
    },
    {
        from = BattleDefine.CardAreaDef.discard,
        to = BattleDefine.CardAreaDef.hand,
        index = 51501
    },
    {
        from = BattleDefine.CardAreaDef.discard,
        to = BattleDefine.CardAreaDef.library,
        index = 51502
    },
    {
        from = BattleDefine.CardAreaDef.discard,
        to = BattleDefine.CardAreaDef.stack,
        index = 51503,
    },
    {
        from = BattleDefine.CardAreaDef.discard,
        to = BattleDefine.CardAreaDef.consume,
        index = 51504,
    },
    {
        from = BattleDefine.CardAreaDef.discard,
        to = BattleDefine.CardAreaDef.device_drone,
        index = 51505,
    },
    {
        from = BattleDefine.CardAreaDef.newCard,
        to = BattleDefine.CardAreaDef.hand,
        index = 51601
    },
    {
        from = BattleDefine.CardAreaDef.newCard,
        to = BattleDefine.CardAreaDef.shuffle,
        index = 51602
    },
    {
        from = BattleDefine.CardAreaDef.shuffle,
        to = BattleDefine.CardAreaDef.library,
        index = 51701
    },
    {
        from = BattleDefine.CardAreaDef.consume,
        to = BattleDefine.CardAreaDef.stack,
        index = 51801
    },
    {
        from = BattleDefine.CardAreaDef.consume,
        to = BattleDefine.CardAreaDef.device_drone,
        index = 51802
    },
    {
        from = BattleDefine.CardAreaDef.areaNone,
        to = BattleDefine.CardAreaDef.hand,
        index = 51901
    },
    {
        from = BattleDefine.CardAreaDef.areaNone,
        to = BattleDefine.CardAreaDef.device_drone,
        index = 51902
    },

    -- TODO：只保留特殊的卡牌移动，特殊处理，其他的走55555
    -- 储卡区，只有在储卡不生效的时候，会直接从储卡区移动到弃牌区
    -- 手牌->储卡区（临时创建一个卡牌在堆叠上，移动到储卡区）
    -- 储卡->弃牌（15-3） 按照被反制的效果来做  相当于储卡没生效
    {
        from = BattleDefine.CardAreaDef.queueCars,
        to = BattleDefine.CardAreaDef.discard,
        index = 52001
    },
--     -- 储卡->堆叠区 （从储卡创建卡牌，移动到堆叠）
--     {
--         from = BattleDefine.CardAreaDef.queueCars,
--         to = BattleDefine.CardAreaDef.stack,
--         index = 52002
--     },
}


function CardMoveAB:__Init()
    self.actionTimeline = nil
end

function CardMoveAB:__Delete()
    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end
end

function CardMoveAB:OnInit()

end

function CardMoveAB:OnCancel()

end

function CardMoveAB:OnUpdate(deltaTime)
    if self.actionTimeline and not self.actionTimeline:IsFinish() then
        self.actionTimeline:Update(deltaTime)
    end
end

function CardMoveAB:OnStart()
    LogTable("执行区域移动AB", self.args)
    mod.BattleFacade:SendEvent(BattleHandCardView.Event.RefreshHandCardCanUse)

    self:ClearHandCardOB()

    -- 先做一次独立批处理检测，满足则直接走批处理并返回
    do
        local allSameFromTo = true
        local batchFrom = nil
        local batchTo = nil
        local batchCards = {}
        local camp = nil
        for _, v in ipairs(self.args.infos) do
            local isSamePair = false
            if batchFrom == nil and batchTo == nil then
                batchFrom = v.oldArea
                batchTo = v.area
                isSamePair = true
                camp = self.world.DataSystem:GetCamp(v.uid)
            else
                isSamePair = (batchFrom == v.oldArea and batchTo == v.area)
            end

            if camp == BattleDefine.Camp.enemy then
                break
            end

            if isSamePair then
                table.insert(batchCards, v)
            else
                allSameFromTo = false
                break
            end
        end

        local batchIndex = self:GetBatchTimelineIndex(batchFrom,batchTo)
        if allSameFromTo and #batchCards >= 2 and batchIndex then
            self.actionTimeline = ActionTimeline.New()
            self.actionTimeline:SetWorld(self.world)
            local batchArgs = { cards = batchCards }
            local actions = { { args = batchArgs, action = { type = batchIndex, time = -1 } } }
            self.actionTimeline:OnInit(_, actions, self.args)
            self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
            self.actionTimeline:Start()
            if self:IsOnlySelfHandToDiscard() then
                self:ActionPreComplete()
            end
            return
        end
    end

    -- 未触发批处理，按原逻辑构建播放列表
    local playActions = {}
    -- 记录敌方无动画移动中被修改的区域，循环后统一刷新UI
    local enemyDirtyAreas = {}
    for _, v in ipairs(self.args.infos) do
        local camp = self.world.DataSystem:GetCamp(v.uid)

        -- local viewRoleUid,_ = self.world.CarrierSystem:GetViewCarrier(camp)
        if v.oldArea == BattleDefine.CardAreaDef.stack 
            or camp == BattleDefine.Camp.self 
            or v.oldArea == BattleDefine.CardAreaDef.queueCars
            or v.area == BattleDefine.CardAreaDef.queueCars then  -- or viewRoleUid == v.uid then
            local args   = {}
            args.data    = v
            args.camp    = camp
            args.oldArea = v.oldArea
            args.toArea  = v.area
            args.areaPos = v.areaPos

            local index  = self:GetTimelineIndex(args)

            table.insert(playActions, { args = args, action = { type = index, time = -1 } })
        else
            --self.world.DataSystem:RemoveCardInfo(v.uid, v.oldArea, v.info.id)
            if v.info.area ~= BattleDefine.CardAreaDef.equip 
                and v.info.area ~= BattleDefine.CardAreaDef.shuffle 
                and v.info.area ~= BattleDefine.CardAreaDef.device_drone then
                self.world.DataSystem:AddCardInfo(v.uid, v.area, v.info)
                -- 记录来源和目标区域，用于后续刷新UI数量
                enemyDirtyAreas[v.oldArea] = true
                enemyDirtyAreas[v.area] = true
            end

            if v.info.area == BattleDefine.CardAreaDef.device_drone then
                self.world.DataSystem:AddCardInfo(v.uid, v.area, v.info)
                self.world.DataSystem:UpdateGridCardInfo(v.uid, v.info)
                self.world.DroneDeviceSystem:RefreshAllDeviceInfo()                
            end
        end
    end

    -- 敌方卡牌无动画移动，Timeline不会触发RefreshSingleAreaUI，这里补发刷新事件
    if enemyDirtyAreas[BattleDefine.CardAreaDef.library] then
        mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardLibraryNum)
    end
    if enemyDirtyAreas[BattleDefine.CardAreaDef.discard] then
        mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardDiscardNum)
    end
    if enemyDirtyAreas[BattleDefine.CardAreaDef.consume] then
        mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardConsumeNum)
    end

    if #playActions > 0 then
        self.actionTimeline = ActionTimeline.New()
        self.actionTimeline:SetWorld(self.world)
        self.actionTimeline:OnInit(_, playActions, self.args)
        self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
        self.actionTimeline:Start()
    else
        self:TimelineDone()
    end

    if self:IsOnlySelfHandToDiscard() then
        self:ActionPreComplete()
    end

    -- self:ActionPreComplete()
end

function CardMoveAB:TimelineDone()
    Log("区域移动AB完成")
    -- 动画完成时再检查一次，防止动画播放期间玩家启动了HandCardOB
    self:ClearHandCardOB()
    self:ActionComplete()
end

-- 是否仅为“我方手牌到弃牌”（回合结束收牌场景，用于提前放行下一批 action）
function CardMoveAB:IsOnlySelfHandToDiscard()
    local infos = self.args and self.args.infos
    if not infos or #infos == 0 then
        return false
    end
    for _, v in ipairs(infos) do
        if v.oldArea ~= BattleDefine.CardAreaDef.hand or v.area ~= BattleDefine.CardAreaDef.discard then
            return false
        end
        local camp = self.world.DataSystem:GetCamp(v.uid)
        if camp ~= BattleDefine.Camp.self then
            return false
        end
    end
    return true
end

function CardMoveAB:GetTimelineIndex(args)
    for _, v in ipairs(CardMoveAB.AreaTimelineIndex) do
        if v.from == args.oldArea and v.to == args.toArea then
            return v.index
        end
    end

    -- LogError(string.format("找不到区域移动AB的索引，from:%s, to:%s", args.oldArea, args.toArea))
    return 55555
end


function CardMoveAB:GetBatchTimelineIndex(fromArea,toArea)
    for _, v in ipairs(CardMoveAB.BatchAreaTimelineIndex) do
        if v.from == fromArea and v.to == toArea then
            return v.index
        end
    end
    return nil
end

function CardMoveAB:ClearHandCardOB()
    local currId = self.world.StateSystem:GetCacheInfo("curr_hand_ob_id")
    for i, v in ipairs(self.args.infos) do
        if v.info.id == currId then
            self.world.OperateSystem:CancelOperate()
        end
    end
end
