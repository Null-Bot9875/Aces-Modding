CardPoolResetAB = BaseClass("CardPoolResetAB",ActionBehaviorBase)

function CardPoolResetAB:__Init()

end

function CardPoolResetAB:__Delete()
    self:RemoveTimer()
end

function CardPoolResetAB:OnInit()

end

function CardPoolResetAB:OnStart()
    LogTable("卡池重置结束AB",self.args)

    local args = {}
    args.isEnd = true
    args.lastTime = 3
    args.info = self.args

    if self.args.result == BattleDefine.ResetCardPoolType.hp then
        self.world.DataSystem:ChangeRoleHpMax(self.args.uid,self.args.hpMaxDiff)
        self.world.DataSystem:ChangeHp(self.args.uid, self.args.hpDiff)

        mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshHpMax,self.args.uid)
        mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshHp, self.args.uid)

        mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowHpFlying,self.args.uid,{value = self.args.hpMaxDiff})
        mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowHpFlying,self.args.uid,{value = self.args.hpDiff})

        self.world.MixedSystem:RefreshCarrierTopHPAndEnergy(self.args.uid)
    end

    self.doneTimer = self.world.TimerSystem:AddTimer(1,args.lastTime,self:ToFunc("OnTimerDone"))
end

function CardPoolResetAB:OnTimerDone()
    self.doneTimer = nil
    self:ActionComplete()
end

function CardPoolResetAB:RemoveTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end