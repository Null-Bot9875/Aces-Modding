CardPoolResetStartAB = BaseClass("CardPoolResetStartAB",ActionBehaviorBase)

function CardPoolResetStartAB:__Init()
    self.doneTimer = nil
end

function CardPoolResetStartAB:__Delete()
    self:RemoveTimer()
end

function CardPoolResetStartAB:OnStart()
    LogTable("卡池重置开始AB",self.args)

    local args = {}
    args.isStart = true
    args.lastTime = 0
    args.info = self.args

    -- if self.args.result == BattleDefine.ResetCardPoolType.hp then
        -- args.lastTime = 4.167
    -- end

    self.doneTimer = self.world.TimerSystem:AddTimer(1,args.lastTime,self:ToFunc("OnTimerDone"))
end

function CardPoolResetStartAB:OnTimerDone()
    self.doneTimer = nil
    self:ActionComplete()
end

function CardPoolResetStartAB:OnCancel()

end

function CardPoolResetStartAB:RemoveTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end