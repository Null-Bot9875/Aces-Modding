ChainUpdateAB = BaseClass("ChainUpdateAB", ActionBehaviorBase)

function ChainUpdateAB:__Init()
    self.lastWaitTime = 2
end

function ChainUpdateAB:__Delete()

end

function ChainUpdateAB:OnInit()

end

function ChainUpdateAB:OnStart()
    LogTable("行为链更新AB", self.args)
    local lastChainDoing = self.world.StateSystem:GetCacheInfo("last_chain_doing")
    local waitTime = 0
    if lastChainDoing then
        local diff = os.time() - lastChainDoing
        if diff < self.lastWaitTime then
            waitTime = self.lastWaitTime - diff
        end
    end

    Logf("行为链更新等待时间[%s]", waitTime)

    self.timer = self.world.TimerSystem:AddTimer(0, waitTime, self:ToFunc("OnChainUpdate"))
end

function ChainUpdateAB:OnChainUpdate()
    if self.timer then
        TimerManager.Instance:RemoveTimer(self.timer)
    end

    local hasDoing = false
    for _, chainInfo in ipairs(self.args.chainInfos) do
        if chainInfo.state == 1 then
            hasDoing = true
            break
        end
    end
    if hasDoing then
        self.world.StateSystem:SetCacheInfo("last_chain_doing", os.time())
    end

    self.world.DataSystem:UpdateChainInfo(self.args.uid, self.args.chainInfos)
    mod.BattleFacade:SendEvent(BattleChainView.Event.RefreshChain)
    mod.GuideEventCtrl:Trigger(GuideDefine.Event.enter_chain_battle)
  
    self:ActionComplete()
end
