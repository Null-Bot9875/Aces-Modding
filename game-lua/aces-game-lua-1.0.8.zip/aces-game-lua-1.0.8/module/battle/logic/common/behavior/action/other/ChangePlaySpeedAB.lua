ChangePlaySpeedAB = BaseClass("ChangePlaySpeedAB",ActionBehaviorBase)

function ChangePlaySpeedAB:__Init()

end

function ChangePlaySpeedAB:__Delete()

end

function ChangePlaySpeedAB:OnInit()

end

-- 档位：1.5 -> 2 -> 1 循环
function ChangePlaySpeedAB:OnStart()
    LogTable("修改播放速度AB", self.args)

    local playSpeed = self.args.speed
    self.world.StateSystem:SetPlaySpeed(playSpeed)

    self.world.ActionSystem:CheckPlaySpeed()

    mod.BattleFacade:SendEvent(BattleFuncBtnView.Event.RefreshPlaySpeed)
    
    self:ActionComplete()
end


function ChangePlaySpeedAB:OnCancel()

end