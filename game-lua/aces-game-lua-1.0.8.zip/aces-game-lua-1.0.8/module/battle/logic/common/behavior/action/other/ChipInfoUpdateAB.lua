ChipInfoUpdateAB = BaseClass("ChipInfoUpdateAB",ActionBehaviorBase)

function ChipInfoUpdateAB:__Init()
end
function ChipInfoUpdateAB:__Delete()

end

function ChipInfoUpdateAB:OnInit()

end

function ChipInfoUpdateAB:OnStart()
    LogTable("晶片更新", self.args)

    local stateList = self.world.DataSystem:UpdateRoleChipInfos(self.args.uid, self.args.infos)
    
    -- 发送事件通知视图更新，传递带状态的数据
    mod.BattleFacade:SendEvent(BattleCarrierChipView.Event.RefreshChipInfoObj, self.args.uid, stateList)
    self:ActionComplete()
end
