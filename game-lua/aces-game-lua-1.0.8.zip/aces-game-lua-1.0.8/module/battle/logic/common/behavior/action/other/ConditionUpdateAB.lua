ConditionUpdateAB = BaseClass("ConditionUpdateAB", ActionBehaviorBase)

function ConditionUpdateAB:__Init()

end

function ConditionUpdateAB:__Delete()

end

function ConditionUpdateAB:OnInit()

end

function ConditionUpdateAB:OnStart()
    LogTable("胜利条件更新AB", self.args)
  
    self.world.DataSystem:UpdateConditionInfo(self.args)
    mod.BattleFacade:SendEvent(BattleFuncBtnView.Event.OnConditionUpdate)

    self:ActionComplete()
    
end
