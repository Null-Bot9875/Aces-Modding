EffectShuffleAB = BaseClass("EffectShuffleAB", ActionBehaviorBase)

function EffectShuffleAB:__Init()
end

function EffectShuffleAB:__Delete()

end

function EffectShuffleAB:OnInit()

end

function EffectShuffleAB:OnStart()
    for _, v in ipairs(self.args.poolCards) do
        self.world.DataSystem:AddCardInfo(self.args.uid, BattleDefine.CardAreaDef.library,v)
    end

    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardDiscardNum)
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardLibraryNum)

    self:ActionComplete()
end
