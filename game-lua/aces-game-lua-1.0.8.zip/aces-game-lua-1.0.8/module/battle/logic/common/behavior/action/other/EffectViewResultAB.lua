EffectViewResultAB = BaseClass("EffectViewResultAB", ActionBehaviorBase)

function EffectViewResultAB:__Init()
end

function EffectViewResultAB:__Delete()

end

function EffectViewResultAB:OnInit()

end

function EffectViewResultAB:OnStart()
    local uid = self.args.uid
    local infos = self.args.infos
    local roleData = self.world.DataSystem:GetRoleData(uid)

    local args = {}
    args.cards = infos
    args.titleKey = nil
    args.onConfirmClick = self:ToFunc("OnConfirm")

    ViewManager.Instance:OpenWindow(BattleSelectCardWindow, args)
end

function EffectViewResultAB:OnConfirm()
    self:ActionComplete()
end

function EffectViewResultAB:OnCancel()

end

function EffectViewResultAB:OnUpdate(deltaTime)

end
