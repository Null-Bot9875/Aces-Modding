ExecEffectAB = BaseClass("ExecEffectAB", ActionBehaviorBase)

function ExecEffectAB:__Init()
    self.actionTimeline = nil
    self.cameraTimer = nil
    self.delayTimer = nil
    self.highlightCamp = nil
    self.highlightIndex = nil
    self.hasCameraSwitch = false
end

function ExecEffectAB:__Delete()
    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end

    if self.cameraTimer then
        self.world.TimerSystem:RemoveTimer(self.cameraTimer)
        self.cameraTimer = nil
    end

    if self.delayTimer then
        TimerManager.Instance:RemoveTimer(self.delayTimer)
        self.delayTimer = nil
    end

    -- 清除高亮
    self:ClearHighLight()
end

function ExecEffectAB:OnInit()

end

function ExecEffectAB:OnStart()
    LogTable("执行效果AB", self.args)
    self.time = Time.time

    self:CameraDone()
end

function ExecEffectAB:CameraDone()
    -- 显示效果来源高亮
    self:ShowEffectSourceHighLight()

    self.actionTimeline = nil
    self.cameraTimer = nil

    -- 堆叠层已触发过表现时，表现层不再重复播 timeline
    if self.args.effectSrcType == BattleDefine.EffectSrcType.stack_effect then
        local stackId = self.args.effectSrcValue
        if stackId and self.world.StateSystem:GetCacheInfo("stack_played_attack_" .. stackId) then
            self:OnExecEffect()
            self:TimelineDone()
            return
        end
    end

    -- 表现的参数，根据这个取表现需要的无人机
    -- 有个隐藏的问题，event被隐藏掉了，一个result里面可能存在多个event，目前没有处理
    local execArgs = {}
    execArgs.info = self.args
    -- 临时放到这里 方便mixed获取
    execArgs.info.stackContext = self.stackContext
    execArgs.targetRoleUids = {}
    execArgs.targetDeviceUids = {}
    execArgs.showDeviceUids = {}
    execArgs.showRoleUids = {}
    execArgs.kvData = self.args.kvData or {}
    execArgs.kvData.stackContext = self.stackContext

    local effectConf = Config.Get("battle_effect_def", "config", "effectId", self.args.effectId)
    if effectConf and effectConf.dontUseCamera then
        execArgs.kvData.dontUseCamera = true
    end

    -- 加速播放时跳过镜头
    if self.world.MixedSystem:ShouldSkipCamera() then
        execArgs.kvData.dontUseCamera = true
    end

    if effectConf and effectConf.extend.dontUseHeavy then
        execArgs.kvData.dontUseHeavy = true
    end

    if effectConf and effectConf.customResultType then
        execArgs.kvData.customResultType = effectConf.customResultType
    end

    -- 检测是否有镜头切换
    self.hasCameraSwitch = self:CheckHasCameraSwitch(effectConf)
    if self.hasCameraSwitch then
        execArgs.kvData.hasCameraSwitch = true
        -- 锁定 action 执行，等镜头切回后再播放结算
        -- self.world.MixedSystem:LockActionExecute(true)
    end

    local targetRoleDicts = {}
    local targetDeviceUids = {}
    for _, v in ipairs(self.args.results) do
        if v.cardUid and v.cardUid ~= 0 and not targetDeviceUids[v.cardUid] then
            targetDeviceUids[v.cardUid] = true
            table.insert(execArgs.targetDeviceUids, v.cardUid)
        elseif v.playerUid and v.playerUid ~= 0 and not targetRoleDicts[v.playerUid] and v.cardUid == 0 then
            targetRoleDicts[v.playerUid] = true
            table.insert(execArgs.targetRoleUids, v.playerUid)
        end
    end

    -- 构建markTargetMap，统一的实体解析数据源
    local markTargetMap = {}
    markTargetMap[BattleDefine.MarkTargetType.src] = {}
    markTargetMap[BattleDefine.MarkTargetType.target] = {}
    local targetUids = {}
    local targetUidDict = {}
    for _, v in ipairs(self.args.results) do
        local uid = (v.cardUid and v.cardUid ~= 0) and v.cardUid
        if uid and uid ~= 0 and not targetUidDict[uid] then
            targetUidDict[uid] = true
            table.insert(targetUids, uid)
        end
    end
    markTargetMap[BattleDefine.MarkTargetType.target] = targetUids
    -- src组：效果源实体uid
    local srcCardUid = self.world.MixedSystem:GetEffectSrcEntityCardUid(execArgs)
    markTargetMap[BattleDefine.MarkTargetType.src] = {srcCardUid }

    if #markTargetMap[BattleDefine.MarkTargetType.src] == 0 then
        local carrierEntity = self.world.EntitySystem:GetCarrierEntity(execArgs.info.srcPlayer)
        if carrierEntity then
            local srcUid = carrierEntity.ObjectDataComponent:GetCardUid()
            table.insert(markTargetMap[BattleDefine.MarkTargetType.src], srcUid)
        end
    end

    if #markTargetMap[BattleDefine.MarkTargetType.target] == 0 then
        local carrierEntity = self.world.EntitySystem:GetCarrierEntity(execArgs.info.targetPlayer)
        if carrierEntity then
            local targetUid = carrierEntity.ObjectDataComponent:GetCardUid()
            table.insert(markTargetMap[BattleDefine.MarkTargetType.target], targetUid)
        end
    end

    execArgs.info.markTargetMap = markTargetMap

    if effectConf and effectConf.extend.showTarget then
        local targetEntitys = self.world.MixedSystem:GetTargetEntityByTargetId(effectConf.extend.showTarget,
            self.args.targetPlayer)
        for _, v in ipairs(targetEntitys) do
            table.insert(execArgs.showDeviceUids, v.ObjectDataComponent.cardUid)
        end
    end

    local playActions = {}

    -- 没有效果源时，直接播放空timeline
    if not effectConf or #markTargetMap[BattleDefine.MarkTargetType.src] == 0 then
        LogTable("没有效果源或无效果配置，不触发表现", self.args)
        table.insert(playActions, { args = nil, action = { type = 10003, time = 0 } })

        self.actionTimeline = ActionTimeline.New()
        self.actionTimeline:SetWorld(self.world)
        self.actionTimeline:OnInit(nil, playActions, execArgs)
        self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
        self.actionTimeline:Start()
        return
    end

    local createInfo = self:GetCreateAttackEntityInfo()

    if createInfo.isCreateEntity then
        -- 区分攻击和其他

        if effectConf.playResultType == BattleDefine.PlayResultType.attack
            or effectConf.playResultType == BattleDefine.PlayResultType.fanAttack
            or effectConf.playResultType == BattleDefine.PlayResultType.penetratAttack
            or effectConf.playResultType == BattleDefine.PlayResultType.backAttack
            or effectConf.playResultType == BattleDefine.PlayResultType.meleeAttack then
            execArgs.createCardId = createInfo.creatCardId
            execArgs.createSourceCardId = createInfo.cardId
            table.insert(playActions, { args = nil, action = { type = 10012, time = 0 } })
        elseif effectConf.playResultType == BattleDefine.PlayResultType.buff then
            -- TODO 不同的创建流程 不放到CreateDeviceDroneAttackEffectTB里面
        elseif effectConf.playResultType == BattleDefine.PlayResultType.debuff then
            -- TODO 不同的创建流程 不放到CreateDeviceDroneAttackEffectTB里面
        end
    else
        -- 堆叠生效
        if effectConf then
            -- 连击逻辑已移至 BehaviorMerger:ProcessMultiAttack 中处理

            --
            -- 1. playResultType对应一个table来决定走到什么tb
            -- 2. tb中判断playResultType来决定走到什么逻辑 背刺/贯穿/扇形/
            -- 3. 被赋予的类型会走到对应effect，所以根据effect的配置来判断赋予的逻辑是不冲突的
            local playResultType = TimelineBehaviorIndex.PlayResultToTB[effectConf.playResultType]
            if playResultType then
                if createInfo.attackUid then
                    execArgs.attackUid = createInfo.attackUid
                    -- 用实际攻击者覆盖src组
                    markTargetMap[BattleDefine.MarkTargetType.src] = {createInfo.attackUid}
                end
                table.insert(playActions, { args = nil, action = { type = playResultType, time = 0 } })
            end

            -- 调整事件触发的tb到最后，因为playResultType中可能会提前处理
            local eventToTB = TimelineBehaviorIndex.EffectEventToTB[effectConf.event]
            if eventToTB and effectConf.playResultType == BattleDefine.PlayResultType.none and #self.args.results > 0 then
                table.insert(playActions, { args = nil, action = { type = eventToTB, time = 0 } })
            end

            -- 直接处理结果事件的tb
            for _, v in ipairs(self.args.results) do
                local resultEventToTB = TimelineBehaviorIndex.ResultEventToTB[v.event]
                if resultEventToTB then
                    local args = {}
                    args.info = self.args
                    args.result = {}
                    for k, v in pairs(v) do
                        args.result[k] = v
                    end
                    args.targetRoleUids = {}
                    args.targetDeviceUids = { v.cardUid }
                    args.showDeviceUids = {}
                    args.showRoleUids = {}
                    table.insert(playActions, { args = args, action = { type = resultEventToTB, time = -1 } })
                end
            end
        end
    end

    if #playActions == 0 then
        table.insert(playActions, { args = nil, action = { type = 10003, time = 0 } })
    end

    -- 如果有镜头切换，在末尾添加一个不带hasCameraSwitch标记的HitResultTB（time=-1）
    -- 它会在前面的CarrierAttackPlayTB完成后执行，此时镜头已切回
    if self.hasCameraSwitch then
        local delayedArgs = {}
        delayedArgs.info = self.args
        delayedArgs.targetRoleUids = {}
        delayedArgs.targetDeviceUids = {}
        delayedArgs.showDeviceUids = {}
        delayedArgs.showRoleUids = {}
        delayedArgs.kvData = {} -- 不传递hasCameraSwitch，确保正常显示

        for _, v in ipairs(self.args.results) do
            if v.cardUid and v.cardUid ~= 0 then
                table.insert(delayedArgs.targetDeviceUids, v.cardUid)
            elseif v.playerUid and v.playerUid ~= 0 then
                table.insert(delayedArgs.targetRoleUids, v.playerUid)
            end
        end

        table.insert(playActions, { args = delayedArgs, action = { type = 10003, time = -1 } })
    end

    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(nil, playActions, execArgs)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()

    self:OnExecEffect()
end

function ExecEffectAB:OnExecEffect()
    if self.args.effectSrcType == BattleDefine.EffectSrcType.chip_effect then
        mod.BattleFacade:SendEvent(BattleCarrierChipView.Event.OnBattleChipEffect, self.args.effectSrcValue)
    elseif self.args.effectSrcType == BattleDefine.EffectSrcType.hero_effect then
        mod.BattleFacade:SendEvent(BattleHeroView.Event.OnBattleHeroEffect, self.args.effectSrcValue)
    end
end

-- 获取效果来源的唯一卡牌UID
function ExecEffectAB:GetUseCardUid()
    local stackInfo = self.world.DataSystem:GetStackInfo(self.args.effectSrcValue)
    local cardUid = nil
    if stackInfo and stackInfo.cardInfo then
        cardUid = stackInfo.cardInfo.id
    elseif self.args.effectSrcType == BattleDefine.EffectSrcType.card_effect then
        cardUid = self.args.effectSrcValue
    end

    return cardUid
end

function ExecEffectAB:GetCreateAttackEntityInfo()
    local creatCardId    = nil
    local stackInfo      = self.world.DataSystem:GetStackInfo(self.args.effectSrcValue)
    local isCreateEntity = false
    local attackUid      = nil
    local cardId         = nil
    local roleUid        = self.world.DataSystem:GetRoleUid()
    if stackInfo and stackInfo.cardInfo then
        cardId = stackInfo.cardInfo.cardId
    elseif self.args.effectSrcType == BattleDefine.EffectSrcType.card_effect then
        cardId = self.args.effectSrcValue
    end

    if cardId then
        local cardCfg = Config.Get("card_def", "config", "cardId", cardId)
        local camp = self.args.srcPlayer == roleUid and BattleDefine.Camp.self or BattleDefine.Camp.enemy
        -- 优先检查 entranceTimeline.timelineMode：直接以 modelId 驱动实体创建，无需 createCard
        local entranceTimeline = cardCfg and cardCfg.extend and cardCfg.extend.entranceTimeline
        if entranceTimeline and entranceTimeline.timelineModel then
            isCreateEntity = true
        elseif cardCfg and cardCfg.extend and cardCfg.extend.createCard then
            creatCardId = cardCfg.extend.createCard
            local gridInfos = self.world.DataSystem:GetGridInfosByCardId(camp, creatCardId)
            isCreateEntity = #gridInfos <= 0
            if not isCreateEntity then --存在无人机
                table.sort(gridInfos, function(a, b)
                    return a.position < b.position
                end)
                local targetGridInfo = gridInfos[1]
                local entity = self.world.EntitySystem:GetDeviceEntity(targetGridInfo.cardInfo.id)
                local deviceUid = entity.ObjectDataComponent.cardUid
                attackUid = deviceUid
            end
        end
    end


    local args = {}
    args.cardId = cardId
    args.creatCardId = creatCardId
    args.isCreateEntity = isCreateEntity
    args.attackUid = attackUid
    return args
end

function ExecEffectAB:OnCancel()
end

function ExecEffectAB:AnimDone()
    self.doneTimer = nil
    self:ActionComplete()
end

function ExecEffectAB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end

function ExecEffectAB:TimelineDone()
    Log(string.format("执行效果AB完成,耗时:%s", Time.time - self.time))
    -- 清除高亮
    self:ClearHighLight()

    local time = 0
    -- 如果有镜头切换，解锁action
    if self.hasCameraSwitch then
        -- self.world.MixedSystem:LockActionExecute(false)
        time = 1
    end

    if self.delayTimer then
        TimerManager.Instance:RemoveTimer(self.delayTimer)
        self.delayTimer = nil
    end

    self.delayTimer = TimerManager.Instance:AddTimer(1, time, self:ToFunc("TimelineDoneComplete"))
end

function ExecEffectAB:TimelineDoneComplete()
    self:ActionComplete()
end

-- 显示效果来源高亮
function ExecEffectAB:ShowEffectSourceHighLight()
    local effectSrcType = self.args.effectSrcType
    local effectSrcValue = self.args.effectSrcValue
    local srcPlayer = self.args.srcPlayer

    local camp = self.world.DataSystem:GetCamp(srcPlayer)

    -- 根据不同的效果来源类型决定高亮对象
    local gridInfo = nil

    -- 堆叠效果：高亮堆叠中卡牌对应的机体格
    if effectSrcType == BattleDefine.EffectSrcType.stack_effect then
        local stackInfo = self.world.DataSystem:GetStackInfo(effectSrcValue)
        if self.world.DataSystem:HasGridCardByCardId(srcPlayer, stackInfo.cardInfo.cardId) then
            -- 场上无人机的触发式异能：高亮改由 AddStackActionAB 在堆叠入栈时驱动，此处不再处理
        else
            -- 没有则视为主将触发
            gridInfo = self:GetCarrierGridInfo(srcPlayer)
        end
        -- 装备效果：高亮对应的装备无人机格
        -- elseif effectSrcType == BattleDefine.EffectSrcType.equip_effect then

        -- 卡牌效果/卡牌消耗
    elseif effectSrcType == BattleDefine.EffectSrcType.card_effect
        or effectSrcType == BattleDefine.EffectSrcType.card_cost then
        if self.world.DataSystem:HasGridCardByCardId(srcPlayer, effectSrcValue) then
            -- 场上无人机的触发式异能
            gridInfo = self.world.DataSystem:GetGridInfoByDeviceUid(effectSrcValue)
        else
            -- 没有则视为主将触发
            gridInfo = self:GetCarrierGridInfo(srcPlayer)
        end

        -- 装备消耗：高亮对应的装备无人机格
        -- elseif effectSrcType == BattleDefine.EffectSrcType.equip_cost then


        -- 玩家效果：高亮主将机体
    elseif effectSrcType == BattleDefine.EffectSrcType.player_effect then
        gridInfo = self:GetCarrierGridInfo(srcPlayer)

        -- 机体攻击：高亮主将机体
        -- elseif effectSrcType == BattleDefine.EffectSrcType.base_attk then
        --     gridInfo = self:GetCarrierGridInfo(srcPlayer)

        -- 卡牌攻击：高亮对应的无人机格
    elseif effectSrcType == BattleDefine.EffectSrcType.card_attk then
        local cardInfo, roleUid = self.world.DataSystem:GetCardInfo(effectSrcValue)
        if cardInfo and cardInfo.cardId ~= 0 then
            gridInfo = self.world.DataSystem:GetGridInfoByDeviceUid(effectSrcValue)
        end

        -- 晶片效果：高亮主将机体
    elseif effectSrcType == BattleDefine.EffectSrcType.chip_effect then
        gridInfo = self:GetCarrierGridInfo(srcPlayer)

        -- 道具效果：高亮主将机体
    elseif effectSrcType == BattleDefine.EffectSrcType.item_effect then
        gridInfo = self:GetCarrierGridInfo(srcPlayer)

        -- 武装效果：高亮主将机体
    elseif effectSrcType == BattleDefine.EffectSrcType.arm_effect then
        gridInfo = self:GetCarrierGridInfo(srcPlayer)

        -- 机师效果：高亮主将机体
    elseif effectSrcType == BattleDefine.EffectSrcType.hero_effect then
        gridInfo = self:GetCarrierGridInfo(srcPlayer)
    end

    -- 如果找到了格子信息，进行高亮
    if gridInfo then
        self.highlightCamp = camp
        self.highlightIndex = gridInfo.position
        self.world.SceneSystem:ShowHighLight(self.highlightCamp, self.highlightIndex, true)
    end
end

-- 获取机体所在格子信息
function ExecEffectAB:GetCarrierGridInfo(roleUid)
    local playerCardInfo = self.world.DataSystem:GetPlayerCardInfo(roleUid)
    if playerCardInfo and playerCardInfo.id then
        -- local camp = roleUid == self.world.DataSystem:GetRoleUid() and BattleDefine.Camp.self or BattleDefine.Camp.enemy
        local gridInfos = self.world.DataSystem:GetGridInfos(roleUid)
        for _, gridInfo in ipairs(gridInfos) do
            if gridInfo.cardUid == playerCardInfo.id then
                return gridInfo
            end
        end
    end
    return nil
end

-- 清除高亮
function ExecEffectAB:ClearHighLight()
    if self.highlightCamp and self.highlightIndex then
        self.world.SceneSystem:ShowHighLight(self.highlightCamp, self.highlightIndex, false)
        self.highlightCamp = nil
        self.highlightIndex = nil
    end
end

-- 检测是否有镜头切换表现
function ExecEffectAB:CheckHasCameraSwitch(effectConf)
    if not effectConf then
        return false
    end

    if effectConf.dontUseCamera then
        return false
    end

    if self.world.MixedSystem:ShouldSkipCamera() then
        return false
    end

    -- 获取攻击来源实体
    local srcEntity = nil
    if self.args.srcPlayer then
        srcEntity = self.world.EntitySystem:GetCarrierEntity(self.args.srcPlayer)
    end

    if not srcEntity then
        return false
    end

    -- 敌人不播放镜头
    if srcEntity.CampComponent:GetCamp() == BattleDefine.Camp.enemy then
        return false
    end

    -- 检查是否有对应的镜头资源
    local modelId = srcEntity.ObjectDataComponent.modelId
    local mode = srcEntity.TposeComponent.mode

    -- 根据playResultType获取可能的动画名
    local animNames = self:GetPossibleAnimNames(effectConf)

    for _, animName in ipairs(animNames) do
        local cameraName = string.format("%s_%s_%s_camera", modelId, mode, animName)
        local cameraFile = string.format("timeline/carrier/%s/camera/%s.prefab", modelId, cameraName)

        if AssetLoader.Instance:IsLocationValid(cameraFile) then
            return true
        end
    end

    return false
end

-- 获取可能的动画名称列表
function ExecEffectAB:GetPossibleAnimNames(effectConf)
    local animNames = {}

    -- 根据 playResultType 推断动画名
    if effectConf.playResultType == BattleDefine.PlayResultType.attack then
        table.insert(animNames, "attack")
    elseif effectConf.playResultType == BattleDefine.PlayResultType.fanAttack then
        table.insert(animNames, "fan_attack")
    elseif effectConf.playResultType == BattleDefine.PlayResultType.penetratAttack then
        table.insert(animNames, "penetrat_attack_1")
    elseif effectConf.playResultType == BattleDefine.PlayResultType.backAttack then
        table.insert(animNames, "back_attack")
    elseif effectConf.playResultType == BattleDefine.PlayResultType.meleeAttack then
        table.insert(animNames, "melee_attack")
    end

    return animNames
end
