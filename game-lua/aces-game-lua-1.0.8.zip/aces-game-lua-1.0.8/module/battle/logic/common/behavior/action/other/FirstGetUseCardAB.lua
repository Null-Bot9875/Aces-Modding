FirstGetUseCardAB = BaseClass("FirstGetUseCardAB", ActionBehaviorBase)

function FirstGetUseCardAB:__Init()
end

function FirstGetUseCardAB:__Delete()

end

function FirstGetUseCardAB:OnInit()

end

function FirstGetUseCardAB:OnStart()
    LogTable("首牌交换", self.args)
    
    local mainStage = self.world.DataSystem:GetMainStage()
    if mainStage == BattleDefine.ServerState.firstCard then

        if #self.args.newCards > 0 then
            ViewManager.Instance:OpenWindow(PvpStartHandCardWindow, self.args)
        end

        mod.BattleFacade:SendEvent(PvpStartHandCardWindow.Event.RefreshWindow, self.args)
    end

    self:ActionComplete()
end

function FirstGetUseCardAB:OnCancel()

end

function FirstGetUseCardAB:OnUpdate(deltaTime)

end
