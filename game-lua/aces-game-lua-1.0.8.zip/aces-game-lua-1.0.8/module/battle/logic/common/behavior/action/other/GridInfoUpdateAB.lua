GridInfoUpdateAB = BaseClass("GridInfoUpdateAB", ActionBehaviorBase)

function GridInfoUpdateAB:__Init()
end

function GridInfoUpdateAB:__Delete()

end

function GridInfoUpdateAB:OnInit()
end

function GridInfoUpdateAB:OnStart()
    LogTable("战场格子更新", self.args)

    -- 记录主将格变更前的静态异能（用于后续 diff）
    local oldLeaderSkills = {}
    local oldLeaderTriggeredSkills = {}
    do
        local leaderGrid = self.world.DataSystem:GetLeaderGridInfo(self.world.DataSystem:GetCamp(self.args.uid))
        if leaderGrid and leaderGrid.cardInfo then
            if leaderGrid.cardInfo.staticSkills then
                for _, v in ipairs(leaderGrid.cardInfo.staticSkills) do
                    table.insert(oldLeaderSkills, v)
                end
            end
            if leaderGrid.cardInfo.skills then
                for _, v in ipairs(leaderGrid.cardInfo.skills) do
                    table.insert(oldLeaderTriggeredSkills, v)
                end
            end
        end
    end

    local infos,oldGridInfos = self.world.DataSystem:UpdateGridInfo(self.args.uid, self.args.infos)

    for i, v in ipairs(self.args.infos) do
        if v.cardInfo then
            self.world.DataSystem:UpdateCardInfo(self.args.uid, v.cardInfo)
        end
    end


    -- for _,v in ipairs(infos.updateCardIdGridInfos) do
    --     local cardId = v.cardInfo.cardId
    --     local cardConf = Config.Get("card_def","config","cardId",cardId)
    --     if cardConf.extend.mode then
    --         self.world.ActionSystem:SetHookInfo(BattleDefine.ActionType.grid_info_update,BattleDefine.ActionType.play_switch_mode,"CheckSwitchModeHook")
    --     end
    -- end

    -- local camp = RunWorld.DataSystem:GetCamp(self.args.uid) 
    -- for _, addHeroCardInfo in ipairs(infos.addHeroCardInfos) do
    --     for k, cardInfo in pairs(addHeroCardInfo.addHeroCardList) do
    --         local heroCardId = cardInfo.cardId 
    --         local cardCfg = Config.Get("card_def","config","cardId",heroCardId)
    --         local isExclusive = false
    --         local heroId 
    --         if cardCfg.extend and cardCfg.extend.heroId then
    --             heroId = cardCfg.extend.heroId 
    --         end

    --         if heroId then
    --            local heroCfg = Config.Get("hero_def","config","id",heroId)
    --            isExclusive = TableUtils.ContainValue(heroCfg.exclusive,addHeroCardInfo.gridInfo.cardInfo.cardId) 
    --         end

    --         local args = {}
    --         args.heroId = heroId
    --         args.camp = camp  
    --         if isExclusive then
    --             mod.DialogueCtrl:OnTriggerDialogueGroup(DialogueDefine.triggerType.battle_entrance_exclusive, args)
    --         else
    --             mod.DialogueCtrl:OnTriggerDialogueGroup(DialogueDefine.triggerType.battle_entrance_non_exclusive,args)
    --         end
    --     end
    -- end

    -- 删除
    local removeDeviceInfos = self.world.MixedSystem:GenerateDeviceInfos(infos.deleteGridInfos)
    for deviceUid, deviceInfo in pairs(removeDeviceInfos) do
        local args = {}
        args.deviceUid = deviceUid
        args.deviceInfo = deviceInfo
        args.uid = self.args.uid
        --2025年9月22日 先这样改 观察下 会不会有移除格子更新后还存在触发对应无人机效果的情况
        self.world.ActionSystem:ParseAction(BattleDefine.ActionType.remove_drone, args, 1)
        -- self.world.ActionSystem:ParseAction(BattleDefine.ActionType.remove_drone, args)
        local camp = self.world.DataSystem:GetCamp(self.args.uid)
        self.world.DroneDeviceSystem:RefreshAllDeviceErrorDir(camp)
    end

    -- for i, gridInfo in pairs(infos.deleteGridInfos) do
    --     for _, heroCardInfo in ipairs(gridInfo.heroCards) do
    --         local cardCfg = Config.Get("card_def","config","cardId",heroCardInfo.cardId)

    --         local heroId 
    --         if cardCfg.extend and cardCfg.extend.heroId then
    --             heroId = cardCfg.extend.heroId 
    --         end

    --         local args = {}
    --         args.heroId = heroId
    --         args.camp = camp  
        
    --         mod.DialogueCtrl:OnTriggerDialogueGroup(DialogueDefine.triggerType.battled_hero_exit,args)
    --     end
    -- end

    -- 新增
    local camp = self.world.DataSystem:GetCamp(self.args.uid)
    local addDeviceInfos = self.world.MixedSystem:GenerateDeviceInfos(infos.addGridInfos)
    local normalDevice = {}
    local armDevice = {}
    for deviceUid, deviceInfo in pairs(addDeviceInfos) do
        local cardInfo = nil
        for i, v in ipairs(deviceInfo) do
            cardInfo = self.world.DataSystem:GetCardInfo(v.cardUid)
        end

        local conf = Config.Get("card_def", "config", "cardId", cardInfo.cardId)

        -- if conf.extend.armList then
        -- 武装配置 屏蔽
        if false then
            if #conf.extend.armList == 1 and conf.extend.armList[1] == 0 then
                armDevice[deviceUid] = { deviceInfo = deviceInfo, armId = 0 }
            else
                local roleUid = self.world.DataSystem:GetRoleUids(camp)[1]
                local armDatas = self.world.DataSystem:GetArmData(roleUid)
                -- 找到装配的是哪个武装
                local armId = nil
                for _, armData in ipairs(armDatas) do
                    for _, id in ipairs(conf.extend.armList) do
                        if id == armData.armId then
                            armId = armData.armId
                            break
                        end
                    end
                end
                if armId then
                    -- deviceInfo.armId = armId
                    armDevice[deviceUid] = { deviceInfo = deviceInfo, armId = armId }
                else
                    normalDevice[deviceUid] = deviceInfo
                end
            end
        else
            normalDevice[deviceUid] = deviceInfo
        end
    end

    -- 正常无人机添加
    if not TableUtils.IsEmpty(normalDevice) then
        for deviceUid, deviceInfo in pairs(normalDevice) do
            local args = {}
            args.camp = camp
            args.deviceUid = deviceUid
            args.deviceInfo = deviceInfo
            self.world.ActionSystem:ParseAction(BattleDefine.ActionType.add_drone, args, 1)
        end
    end

    -- 武装无人机添加
    if not TableUtils.IsEmpty(armDevice) then
        local args = {}
        args.camp = camp
        args.addDeviceInfos = armDevice
        self.world.ActionSystem:ParseAction(BattleDefine.ActionType.add_arm_drone, args, 1)
    end

    -- 更新
    local updateDeviceInfos = self.world.MixedSystem:GenerateDeviceInfos(infos.updateGridInfos)
    for deviceUid, deviceInfo in pairs(updateDeviceInfos) do
        local oldGridInfo = nil
        for i, v in ipairs(oldGridInfos) do
            if v.cardUid == deviceInfo[1].cardUid and v.cardInfo then
                oldGridInfo = v
            end
        end
        self.world.DroneDeviceSystem:UpdateSingleDevice(deviceInfo,oldGridInfo) --更新

        -- 在没有合并的时候，刷新机甲头顶信息
        if not (self.args.kvData and self.args.kvData.isMerge) then
            local isPlayer = self.world.DataSystem:IsPlayerCard(deviceUid)
            if isPlayer then
                local roleUid = self.world.DataSystem:GetRoleUids(camp)[1]
                mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshHpMax,roleUid)
                mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshHp, roleUid)

                local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(deviceUid)
                entity.DeviceTopInfoComponent:RefreshInfo()
            end
        end
    end

    self.world.SceneSystem:RefreshAllGridInfo()
    self.world.DroneDeviceSystem:RefreshDeviceLoopCount(BattleDefine.Camp.self)
    self.world.DroneDeviceSystem:RefreshDeviceLoopCount(BattleDefine.Camp.enemy)
    -- 若主将静态异能发生变化，通知视图刷新
    local leaderSkillList = self.world.DataSystem:UpdateLeaderStaticSkills(camp, oldLeaderSkills)
    if #leaderSkillList > 0 then
        local leaderRoleUid = self.world.DataSystem:GetRoleUids(camp)[1]
        mod.BattleFacade:SendEvent(BattleCarrierSkillView.Event.RefreshStaticSkillItem, leaderRoleUid, leaderSkillList)
    end
    -- 若主将触发式异能发生变化，通知视图刷新
    local leaderTriggeredSkillList = self.world.DataSystem:UpdateLeaderTriggeredSkills(camp, oldLeaderTriggeredSkills)
    if #leaderTriggeredSkillList > 0 then
        local leaderRoleUid = self.world.DataSystem:GetRoleUids(camp)[1]
        mod.BattleFacade:SendEvent(BattleCarrierSkillView.Event.RefreshStaticSkillItem, leaderRoleUid, leaderTriggeredSkillList)
    end
    self:ActionComplete()
end

function GridInfoUpdateAB:OnCancel()

end
