HeroInfoUpdateAB = BaseClass("HeroInfoUpdateAB",ActionBehaviorBase)

function HeroInfoUpdateAB:__Init()
end

function HeroInfoUpdateAB:__Delete()
end

function HeroInfoUpdateAB:OnInit()
end

function HeroInfoUpdateAB:OnStart()
    LogTable("机师更新", self.args)

    local stateList = self.world.DataSystem:UpdateRoleHeroInfos(self.args.uid, self.args.infos)
    
    -- 发送事件通知视图更新，传递带状态的数据
    mod.BattleFacade:SendEvent(BattleHeroView.Event.RefreshHeroInfoObj, self.args.uid, stateList)
    self:ActionComplete()
end
