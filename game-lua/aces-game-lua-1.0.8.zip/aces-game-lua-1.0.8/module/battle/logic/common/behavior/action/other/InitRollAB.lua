InitRollAB = BaseClass("InitRollAB",ActionBehaviorBase)

function InitRollAB:__Init()
end

function InitRollAB:__Delete()

end

function InitRollAB:OnInit()

end

function InitRollAB:OnStart()
    LogTable("决定先手AB",self.args)
    local firstUid = self.args.firstUid
    self.world.DataSystem.isFirstActive = self.world.DataSystem:IsRoleUid(firstUid)
    self:ActionComplete()

end

function InitRollAB:OnCancel()
    
end

function InitRollAB:OnUpdate(deltaTime)

end