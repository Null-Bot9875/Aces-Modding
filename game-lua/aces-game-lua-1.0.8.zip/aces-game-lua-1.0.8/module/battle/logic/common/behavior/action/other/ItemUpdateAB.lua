ItemUpdateAB = BaseClass("ItemUpdateAB",ActionBehaviorBase)

function ItemUpdateAB:__Init()
end
function ItemUpdateAB:__Delete()

end

function ItemUpdateAB:OnInit()

end

function ItemUpdateAB:OnStart()
    LogTable("道具更新",self.args)

    local data = self.world.DataSystem:UpdateBattleItemInfo(self.args.uid, self.args.infos)
    if self.args.uid == self.world.DataSystem:GetRoleUid() then
        mod.BattleFacade:SendEvent(BattleBattleItemView.Event.RefreshItem,data)
    end
    self:ActionComplete()
end
