MainStageChangeAB = BaseClass("MainStageChangeAB", ActionBehaviorBase)

function MainStageChangeAB:__Init()
end

function MainStageChangeAB:__Delete()

end

function MainStageChangeAB:OnInit()

end

function MainStageChangeAB:OnStart()
    LogTable("主要阶段切换", self.args)
    local mainStage = self.args.mainStage
    if mainStage == BattleDefine.ServerState.play then
        ViewManager.Instance:CloseWindow(PvpStartHandCardWindow)
    end
    
    mod.GuideEventCtrl:Trigger(GuideDefine.Event.stage_change,mainStage)       
    self.world.DataSystem:SetMainStage(mainStage)
    self:ActionComplete()
end

function MainStageChangeAB:OnCancel()

end

function MainStageChangeAB:OnUpdate(deltaTime)

end
