NotifyOperationAB = BaseClass("NotifyOperationAB", ActionBehaviorBase)

function NotifyOperationAB:__Init()
    self.targetRoleUid = nil
end

function NotifyOperationAB:__Delete()
    if self.timelineBehavior then
        self.timelineBehavior:Delete()
        self.timelineBehavior = nil
    end
end

function NotifyOperationAB:OnInit()

end

function NotifyOperationAB:OnStart()
    LogTable("通知操作AB", self.args)
    -- mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.ActiveEnemyInfo,{active = false})

    -- local fromEntity = self.world.MixedSystem:GetSrcEntityBySrcType(self.args.effectSrcType, self.args.effectSrcValue)

    if self.args.targetSelectionActor ~= self.world.DataSystem.roleUid then
        self:ActionComplete()
        return
    end

    local selectArgs = {}
    selectArgs.roleUid = self.args.targetSelectionActor
    selectArgs.srcUid = self.args.srcUid
    selectArgs.selInfos = { {
        targetId = self.args.targetSelection,
        effectId = self.args.effect,
        targetSelectionValue = self.args.targetSelectionValue
    }, }
    selectArgs.canCancel = false
    selectArgs.autoConfirm = false
    selectArgs.kvData = {}
    selectArgs.kvData.fromCardEntityUid = self.args.srcValue
    selectArgs.kvData.fromArea = self.world.MixedSystem:GetAreaInfo(self.args.srcType)
    selectArgs.baseInfo = self.world.MixedSystem:GetBaseInfo(self.args.targetSelectionActor,self.args.srcType,self.args.srcValue)
    selectArgs.isNotify = true

    local timelineBehavior = SelectTargetTB.New()
    timelineBehavior:SetWorld(self.world)
    timelineBehavior:SetEntity(self.entity)
    timelineBehavior:SetUid(self.world:GetUid(SECBBehaviorComponent))
    timelineBehavior:SetArgs(selectArgs)
    timelineBehavior:SetComplete(self:ToFunc("BehaviorDone"))
    timelineBehavior:Init()

    self.timelineBehavior = timelineBehavior
    self.timelineBehavior:Start()
end

function NotifyOperationAB:BehaviorDone(_, selectResult)
    Log("通知操作AB完成")
    if selectResult.data then
        local data = {}
        data.targets = selectResult.data
        mod.BattleFacade:SendMsg(4004, 10, { { key = "operation", val = data } })
    end
    self:ActionComplete()
end

function NotifyOperationAB:OnCancel()

end

function NotifyOperationAB:OnUpdate(deltaTime)
    if self.timelineBehavior then
        self.timelineBehavior:Update(deltaTime)
    end
end
