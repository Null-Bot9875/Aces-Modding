RecordUpdateAB = BaseClass("RecordUpdateAB", ActionBehaviorBase)

function RecordUpdateAB:__Init()
end

function RecordUpdateAB:__Delete()
end

function RecordUpdateAB:OnInit()

end

function RecordUpdateAB:OnStart()
    LogTable("记录更新AB", self.args.record)
    self.world.DataSystem:InitRecord(self.args.record)

    mod.BattleFacade:SendEvent(BattleRecordPanel.Event.UpdateRecord, self.args.record)

    local record = self.args.record
    if record.action == BattleDefine.ServerActionType.useHandCard and self.world.DataSystem:IsRoleUid(record.uid) then
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.RefreshHandCardItem, record.uid)
    end

    -- 新增：派发“卡牌完成(camp, cardId)”引导事件
    -- 约定：记录里包含 uid（玩家uid）与 cardId（卡牌模板id）
    if record.action == BattleDefine.ServerActionType.useHandCard and record.uid and record.cardId then
        local camp = self.world.DataSystem:GetCamp(record.uid)
        mod.GuideEventCtrl:Trigger(GuideDefine.Event.card_done, camp, record.cardId)
    end

    self:ActionComplete()
end

function RecordUpdateAB:OnUpdate(deltaTime)
end
