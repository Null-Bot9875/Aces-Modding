RefreshHpBarAB = BaseClass("RefreshHpBarAB", ActionBehaviorBase)

function RefreshHpBarAB:__Init()
end

function RefreshHpBarAB:__Delete()
end

function RefreshHpBarAB:OnInit()
end

function RefreshHpBarAB:OnStart()
    Log(string.format("刷新所有设备信息（包含血条等状态）"))
    -- 刷新所有设备信息（包含血条等状态）
    if self.world and self.world.DroneDeviceSystem then
        self.world.DroneDeviceSystem:RefreshDeviceTopInfo(BattleDefine.Camp.self)
        self.world.DroneDeviceSystem:RefreshDeviceTopInfo(BattleDefine.Camp.enemy)
    end

    self:ActionComplete()
end

function RefreshHpBarAB:OnCancel()
end

function RefreshHpBarAB:OnUpdate(deltaTime)
end

