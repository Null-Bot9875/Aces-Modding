RemoveDeviceDroneAB = BaseClass("RemoveDeviceDroneAB", ActionBehaviorBase)

function RemoveDeviceDroneAB:__Init()
    self.actionTimeline = nil
end

function RemoveDeviceDroneAB:__Delete()
    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end

    if self.preTimer then
        self.world.TimerSystem:RemoveTimer(self.preTimer)
        self.preTimer = nil
    end
end

function RemoveDeviceDroneAB:OnInit()
end

function RemoveDeviceDroneAB:OnStart()
    LogTable("移除无人机AB", self.args)

    local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(self.args.deviceUid)
    -- local entity = self.world.EntitySystem:GetDeviceEntity(self.args.deviceUid)
    local isPreDead = self.world.StateSystem:GetCacheInfo("pre_dead_device_" .. self.args.deviceUid)
    if not entity or isPreDead then
        self:TimelineDone()
        return
    end

    entity.EffectComponent:CleanEffect()
    entity.DeviceTopInfoComponent:SetActive(false)

    local modelId = entity.ObjectDataComponent.modelId
    local mode = entity.TposeComponent.mode
    -- 做出区分，死亡的移除和因为其他效果的移除表现是不一样的
    local confName = nil
    -- local removeType = self.args.removeType
    local removeType = nil
    if not removeType then
        -- 优先检查是否为废弃死亡
        if entity.ObjectDataComponent:GetScrapDead() then
            removeType = 1
        elseif entity.ObjectDataComponent:GetRetreat() then
            removeType = 3
        else
            -- local cardInfo = self.world.DataSystem:GetCardInfo(entity.ObjectDataComponent.cardUid)
            -- if cardInfo.hp > 0 then
            --     removeType = 1
            -- else
            --     removeType = 2
            -- end
            removeType = 2
        end
    end

    local conf = Config.Get("card_def", "config", "cardId", entity.ObjectDataComponent:GetCardId())
    if conf and conf.extend.isExplode then
        removeType = 4
    end

    if removeType == 1 then
        confName = string.format("%s_%s_exeunt", modelId, mode)
        if not Config.HasConf(confName) then
            confName = "common_exeunt"
        end
    elseif removeType == 2 then
        local modelId = entity.ObjectDataComponent.modelId
        local mode = entity.TposeComponent.mode
        -- local index = 1
        confName = string.format("%s_%s_dead", modelId, mode)
        if not Config.HasConf(confName) then
            confName = "common_dead"
        end
    elseif removeType == 3 then
        local modelId = entity.ObjectDataComponent.modelId
        local mode = entity.TposeComponent.mode
        confName = string.format("%s_%s_retreat", modelId, mode)
        if not Config.HasConf(confName) then
            confName = "common_retreat"
        end
    elseif removeType == 4 then
        local modelId = entity.ObjectDataComponent.modelId
        local mode = entity.TposeComponent.mode
        confName = string.format("%s_%s_self_explode_aoe_attack", modelId, mode)
        if not Config.HasConf(confName) then
            confName = "common_self_explode_aoe_attack"
        end
    end

    if not Config.HasConf(confName) then
        confName = "common_dead"
        removeType = 2
    end

    local playDatas = Config.GetLua(confName)
    local playActions = {}
    for _, v in ipairs(playDatas) do
        table.insert(playActions, { args = nil, action = v })
    end

    local execArgs = {}
    execArgs.info = {
        effectSrcValue = self.args.deviceUid,
        effectSrcType = BattleDefine.EffectSrcType.card_attk,
    }
    execArgs.info.markTargetMap = {
        [BattleDefine.MarkTargetType.src] = {self.args.deviceUid},
        [BattleDefine.MarkTargetType.target] = {},
    }
    execArgs.targetRoleUids = {}

    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(entity, playActions, execArgs)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()
    Log(string.format("播放无人机移除表现，配置[%s]，移除类型[%s]", confName, tostring(removeType)))


    entity.EffectComponent:RemoveEffectByGroup("fixed")


    -- AudioManager.Instance:PlayScene("common_dead_1")
    -- 主将（位置5 或 IsMainMecha 标记）死亡不提前完成，等待完整表现；普通无人机允许并行
    local isMainMecha = entity.ObjectDataComponent:IsMainMecha() or entity.ObjectDataComponent:GetCurrPos() == 5
    if not isMainMecha then
        self.startTime = Time.realtimeSinceStartup
        self.preTimer = self.world.TimerSystem:AddTimer(1, 1.0, self:ToFunc("OnPreTimer"))
    else
        self.world.StateSystem:SetPlaySpeed(1)
    end

    -- local deviceInfo = self.args.deviceInfo
    -- local camp = self.world.DataSystem:GetCamp(self.args.uid)
    -- for _, v in ipairs(deviceInfo) do
    --     self.world.SceneSystem:ActiveGridInfo(camp,v.position,false)
    -- end
end

function RemoveDeviceDroneAB:OnPreTimer()
    self.preTimer = nil


    self:ActionPreComplete()
end

function RemoveDeviceDroneAB:OnCancel()
end

function RemoveDeviceDroneAB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end

function RemoveDeviceDroneAB:TimelineDone()
    -- 无人机唯一的清除预死亡标记的地方，避免多次无人机死亡表现
    self.world.StateSystem:SetCacheInfo("pre_dead_device_" .. self.args.deviceUid, nil)
    
    -- 清除废弃死亡标记
    local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(self.args.deviceUid)
    if entity then
        entity.ObjectDataComponent:SetScrapDead(false)
    end
    
    -- 获取阵营信息用于后续刷新
    local camp = nil
    if entity then
        camp = entity.CampComponent:GetCamp()
    end

    if camp and self.args.deviceInfo then
        for _, deviceInfo in ipairs(self.args.deviceInfo) do
            self.world.SceneSystem:CleanElectricGridEffect(camp, deviceInfo.position)
        end
    end
    
    self.world.DroneDeviceSystem:RemoveSingleDevice(self.args.deviceInfo)
    
    -- 击杀无人机后，刷新整个阵营的方向特效（因为异能传递关系可能发生变化）
    if camp then
        self.world.SceneSystem:RefreshCampDirEffects(camp)
    end

    if self.world.DataSystem:IsPlayerCard(self.args.deviceUid) then
        self.world.CarrierSystem:RemoveCarrier(self.args.uid)
        self.world.CameraSystem:ClearCamera(self.args.uid)
    end
    
    self:ActionComplete()
end
