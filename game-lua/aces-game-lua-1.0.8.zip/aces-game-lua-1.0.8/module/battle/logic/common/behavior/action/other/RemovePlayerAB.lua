-- 存在主将移除了没有移除无人机的情况 比如投降
RemovePlayerAB = BaseClass("RemovePlayerAB",ActionBehaviorBase)

function RemovePlayerAB:__Init()
    --self.animTimer = nil
    self.actionTimeline = nil
end

function RemovePlayerAB:__Delete()
    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end

    if self.preTimer then
        self.world.TimerSystem:RemoveTimer(self.preTimer)
        self.preTimer = nil
    end

    --Log(string.format("ab_time ->死亡耗时:%s",Time.realtimeSinceStartup - self.startTime))
end

function RemovePlayerAB:OnInit()
end

function RemovePlayerAB:OnStart()
    LogTable("移除机甲AB",self.args)
    self:ActionComplete()
    do return end
    -- return --

    local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.uid)
    if not carrierEntity then
        self:TimelineDone()
        return
    end

    local camp = self.world.DataSystem:GetCamp(self.args.uid)
    carrierEntity.EffectComponent:CleanEffect()

    local modelId = carrierEntity.ObjectDataComponent.modelId
    local mode = carrierEntity.TposeComponent.mode

    -- 根据卡牌配置判断：该机甲死亡是否需要播放爆炸死亡表现
    local cardId = carrierEntity.ObjectDataComponent:GetCardId()
    local cardConf = cardId and Config.Get("card_def", "config", "cardId", cardId) or nil
    local isExplodeDead = (cardConf and cardConf.extend and cardConf.extend.isExplode or false)
        or carrierEntity.ObjectDataComponent:IsRuntimeExplode()

    local deadConfName = nil
    if isExplodeDead then
        deadConfName = string.format("%s_%s_self_explode_aoe_attack", modelId, mode)
        if not Config.HasConf(deadConfName) then
            deadConfName = "common_self_explode_aoe_attack"
        end
    else
        deadConfName = string.format("%s_%s_dead", modelId, mode)
        if not Config.HasConf(deadConfName) then
            deadConfName = "common_dead"
        end
    end

    local playDatas = Config.GetLua(deadConfName)
    local playActions = {}
    for _,v in ipairs(playDatas) do
        table.insert(playActions,{args = nil,action = v})
    end

    local execArgs = {}
    execArgs.info = {srcPlayer = self.args.uid}
    execArgs.targetRoleUids = {}
    execArgs.info.markTargetMap = {
        [BattleDefine.MarkTargetType.src] = {carrierEntity.ObjectDataComponent:GetCardUid()},
        [BattleDefine.MarkTargetType.target] = {},
    }

    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(carrierEntity,playActions,execArgs)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()

    carrierEntity.DeviceTopInfoComponent:RefreshInfo()
    carrierEntity.EffectComponent:RemoveEffectByGroup("fixed")

    AudioManager.Instance:PlayScene("common_dead_1")

    self.startTime = Time.realtimeSinceStartup
    
    local uids = self.world.DataSystem:GetRoleUids(camp)
    
    if #uids > 1 then
        self.preTimer = self.world.TimerSystem:AddTimer(1,1.0,self:ToFunc("OnPreTimer"))
    end
end

function RemovePlayerAB:OnPreTimer()
    self.preTimer = nil
    
    -- self.world.DataSystem:RemoveRole(self.args.uid)
    self.world.CameraSystem:ClearCamera(self.args.uid)

    self:ActionPreComplete()
end

function RemovePlayerAB:OnCancel()
end

function RemovePlayerAB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end

function RemovePlayerAB:TimelineDone()
    -- self.world.DataSystem:RemoveRole(self.args.uid)
    self.world.CarrierSystem:RemoveCarrier(self.args.uid)

    local removeCarrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.uid)
    if removeCarrierEntity then
        self.world.EntitySystem:RemoveEntity(removeCarrierEntity.uid)
    end

    self.world.CameraSystem:ClearCamera(self.args.uid)
    self:ActionComplete()
end

-- function RemovePlayerAB:DeadAnimTimer()
--     self.animTimer = nil
--     self.world.DataSystem:RemoveRole(self.args.uid)
--     self.world.CarrierSystem:RemoveCarrier(self.args.uid)

--     local removeCarrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.uid)
--     self.world.EntitySystem:RemoveEntity(removeCarrierEntity.uid)

--     self.world.CameraSystem:ClearCamera(self.args.uid)
--     self:ActionComplete()
-- end