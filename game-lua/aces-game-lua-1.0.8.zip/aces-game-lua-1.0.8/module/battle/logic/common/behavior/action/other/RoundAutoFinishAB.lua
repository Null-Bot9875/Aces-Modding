RoundAutoFinishAB = BaseClass("RoundAutoFinishAB",ActionBehaviorBase)

function RoundAutoFinishAB:__Init()
    self.doneTimer = nil
end

function RoundAutoFinishAB:__Delete()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function RoundAutoFinishAB:OnInit()

end


function RoundAutoFinishAB:OnStart()
    -- SystemMessage.Show(TI18N("round_auto_finish"))
    self.doneTimer = self.world.TimerSystem:AddTimer(1,1.5,self:ToFunc("TimerDone"))
end

function RoundAutoFinishAB:OnCancel()
end

function RoundAutoFinishAB:OnUpdate(deltaTime)
end



function RoundAutoFinishAB:TimerDone()
    self.doneTimer = nil
    self:ActionComplete()
end