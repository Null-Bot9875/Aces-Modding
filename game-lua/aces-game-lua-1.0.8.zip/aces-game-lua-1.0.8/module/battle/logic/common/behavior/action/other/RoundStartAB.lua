RoundStartAB = BaseClass("RoundStartAB",ActionBehaviorBase)

function RoundStartAB:__Init()
end

function RoundStartAB:__Delete()

end

function RoundStartAB:OnInit()

end

function RoundStartAB:OnStart()
    LogTable("开始回合AB",self.args)

    -- 回合開始的時候，清理掉当前的优先权
    local beforeActor = self.world.DataSystem:GetCurPriorityRoleUid()
    self.world.DataSystem:SetCurPriorityRoleUid(nil)

    self.world.DataSystem:SetCurActiveRoleUid(self.args.turn)
    self.world.DataSystem:SetRound(self.args.round)

    local roleUid = self.world.DataSystem.roleUid
    local isSelf = self.world.DataSystem:IsCurActiveRole(roleUid)

    self.world.DataSystem:SetRoundStep(BattleDefine.RoundStep.none)

    if isSelf then
        mod.BattleFacade:SendEvent(BattleStateView.Event.StartRound, BattleDefine.RoundType.own)
        mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.ActiveImageCurr, BattleDefine.Camp.self, true)
        mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.ActiveImageCurr, BattleDefine.Camp.enemy, false)
        mod.BattleFacade:SendEvent(BattleFacade.Event.RoundStart, BattleDefine.RoundType.own)

        -- RunWorld.OperateSystem.isSendEndTurn = false
    else
        mod.BattleFacade:SendEvent(BattleStateView.Event.StartRound, BattleDefine.RoundType.opponent)
        mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.ActiveImageCurr, BattleDefine.Camp.self, false)
        mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.ActiveImageCurr, BattleDefine.Camp.enemy, true)
        mod.BattleFacade:SendEvent(BattleFacade.Event.RoundStart, BattleDefine.RoundType.opponent)

        -- 自身回合外，不用虚拟能量，以DataSystem中的GetEnergy为准
        self.world.DataSystem:ResetVirtualEnergy()
    end
    
    mod.GuideEventCtrl:Trigger(GuideDefine.Event.start_round, isSelf)


    -- local lastTime = self.world.CameraSystem:PlayCameraByUid(self.args.turn)
    -- if lastTime and lastTime > 0 then
    --     -- self.cameraTimer = self.world.TimerSystem:AddTimer(1, lastTime, self:ToFunc("RoundStartABDone"))
    --     self:RoundStartABDone()
    -- else
    --     self:RoundStartABDone()
    -- end
    
    -- self.cameraTimer = self.world.TimerSystem:AddTimer(1, 1.5, self:ToFunc("RoundStartABDone"))
    self:RoundStartABDone()
    -- AudioManager.Instance:PlayUI("confirm_1")
    AudioManager.Instance:PlayUI("round_start")

    -- local beforeActorEntity = self.world.EntitySystem:GetCarrierEntity(beforeActor)
    -- if beforeActorEntity then
    --     beforeActorEntity.TopInfoComponent:UpdateDeviceList()
    -- end

    -- local currActorEntity = self.world.EntitySystem:GetCarrierEntity(self.args.turn)
    -- if currActorEntity then
    --     currActorEntity.TopInfoComponent:UpdateDeviceList()
    -- end
    -- RunWorld.StateSystem.playerClickEndButton = false

    -- if self.world.CameraSystem:IsAutoChangeBind() then
    --     local camp = self.world.DataSystem:GetCamp(self.args.turn)
    --     if camp == BattleDefine.Camp.self then
    --         local gridInfo = self.world.DataSystem:GetGridInfoByPosition(camp, 5)
    --         local entity = self.world.EntitySystem:GetDeviceEntity(gridInfo.cardInfo.id)
    --         local gridObj = RunWorld.SceneSystem:GetGridObj(camp, 5)
    --         self.world.CameraSystem:BindFreeCamera(camp, gridObj.gridObj.transform, entity)
    --     else
    --         local gridInfo = self.world.DataSystem:GetGridInfoByPosition(camp, 5)
    --         local entity = self.world.EntitySystem:GetDeviceEntity(gridInfo.cardInfo.id)
    --         local gridObj = RunWorld.SceneSystem:GetGridObj(camp, 5)
    --         self.world.CameraSystem:BindFreeCamera(camp, gridObj.gridObj.transform, entity)
    --     end
    -- end

    mod.BattleFacade:SendEvent(BattleFuncBtnView.Event.RefreshEndBtnState)
end

function RoundStartAB:RoundStartABDone()
    self.cameraTimer = nil
    self:ActionComplete()
end

function RoundStartAB:OnCancel()

end

function RoundStartAB:OnUpdate(deltaTime)

end