ServerUseDeviceAB = BaseClass("ServerUseDeviceAB",ActionBehaviorBase)

function ServerUseDeviceAB:__Init()
    self.doneTimer = nil
end

function ServerUseDeviceAB:__Delete()
    if self.timelineBehavior then
        self.timelineBehavior:Delete()
        self.timelineBehavior = nil
    end

    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function ServerUseDeviceAB:OnInit()

end

function ServerUseDeviceAB:OnUpdate(deltaTime)
    if self.timelineBehavior then
        self.timelineBehavior:Update(deltaTime)
    end
end

function ServerUseDeviceAB:OnStart()
    LogTable("服务器使用设备",self.args)
    self:ActionComplete()
    do return end

    local args = {}
    args.srcUid = self.args.uid
    args.targetInfos = self.args.targets
    args.baseInfo = {}
    args.baseInfo.equipUid = self.args.equipUid
    args.baseInfo.skillId = self.args.skillId
    args.baseInfo.skillUid = self.args.skillUid

    local enemySelectTB = EnemySelectTB.New()
    enemySelectTB:SetWorld(self.world)
    enemySelectTB:SetUid(self.world:GetUid(SECBBehaviorComponent))
    enemySelectTB:SetArgs(args)
    enemySelectTB:SetComplete(self:ToFunc("BehaviorDone"))
    enemySelectTB:Init()

    self.timelineBehavior = enemySelectTB
    self.timelineBehavior:Start()
end

function ServerUseDeviceAB:OnCancel()

end

function ServerUseDeviceAB:BehaviorDone()
    if self.timelineBehavior.isShowSelect then
        self.doneTimer = self.world.TimerSystem:AddTimer(1,1,self:ToFunc("DoneTimer"))
    else
        self:ActionComplete()
    end
end

function ServerUseDeviceAB:DoneTimer()
    self.doneTimer = nil
    self:ActionComplete()
end