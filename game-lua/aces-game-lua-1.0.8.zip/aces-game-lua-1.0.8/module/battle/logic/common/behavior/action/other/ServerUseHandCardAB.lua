ServerUseHandCardAB = BaseClass("ServerUseHandCardAB",ActionBehaviorBase)

function ServerUseHandCardAB:__Init()
    self.stackEntity = nil
    self.doneTimer = nil
end

function ServerUseHandCardAB:__Delete()
    if self.stackEntity then
        self.world.EntitySystem:RemoveEntity(self.stackEntity.uid)
        self.stackEntity = nil
    end

    if self.timelineBehavior then
        self.timelineBehavior:Delete()
        self.timelineBehavior = nil
    end

    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function ServerUseHandCardAB:OnUpdate(deltaTime)
    if self.timelineBehavior then
        self.timelineBehavior:Update(deltaTime)
    end
end

function ServerUseHandCardAB:OnInit()

end

function ServerUseHandCardAB:OnStart()
    LogTable("服务器使用手牌",self.args)
    self:ActionComplete()
    do return end

    local args = {}
    args.srcUid = self.args.uid
    args.targetInfos = self.args.targets
    args.baseInfo = {}
    args.baseInfo.cardId = self.args.cardId
    args.baseInfo.cardUid = self.args.cardUid


    local enemySelectTB = EnemySelectTB.New()
    enemySelectTB:SetWorld(self.world)
    enemySelectTB:SetUid(self.world:GetUid(SECBBehaviorComponent))
    enemySelectTB:SetArgs(args)
    enemySelectTB:SetComplete(self:ToFunc("BehaviorDone"))
    enemySelectTB:Init()

    self.timelineBehavior = enemySelectTB
    self.timelineBehavior:Start()
end

function ServerUseHandCardAB:OnCancel()

end

function ServerUseHandCardAB:BehaviorDone()
    if self.timelineBehavior.isShowSelect then
        self.doneTimer = self.world.TimerSystem:AddTimer(1,1,self:ToFunc("DoneTimer"))
    else
        self:ActionComplete()
    end
end

function ServerUseHandCardAB:DoneTimer()
    self.doneTimer = nil
    self:ActionComplete()
end