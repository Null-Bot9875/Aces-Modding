StageChangeAB = BaseClass("StageChangeAB",ActionBehaviorBase)

function StageChangeAB:__Init()
end

function StageChangeAB:__Delete()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function StageChangeAB:OnInit()

end

function StageChangeAB:OnStart()
    local curStage = self.world.DataSystem:GetRoundStep()
    --TODO 服务器暂有问题 可能同一阶段发送多次
    LogTable("阶段切换AB",self.args)
    if curStage == self.args.roundStage then
        self:ActionComplete()
        return    
    end

    self.world.DataSystem:SetRoundStep(self.args.roundStage)

    self.world.StateSystem:CheckAttackState()

    local mode = BattleDefine.BattleTypeMap[self.world.DataSystem.enterData.baseInfo.type]
    if mode == BattleDefine.BattleType.pve then
        mod.GuideEventCtrl:Trigger(GuideDefine.Event.enter_pve_battle)
        local roleUid = self.world.DataSystem.roleUid

        local chips = self.world.DataSystem:GetRoleInitChipInfos(roleUid)
        if #chips > 0 then
            mod.GuideEventCtrl:Trigger(GuideDefine.Event.enter_battle_with_chip)       
        end

        local items = self.world.DataSystem:GetBattleItemInfos(roleUid)
        if items and #items > 0 then
            mod.GuideEventCtrl:Trigger(GuideDefine.Event.enter_battle_with_battle_item)       
        end

        local enemyRoleUid, _ = self.world.CarrierSystem:GetViewCarrier(BattleDefine.Camp.enemy)
        local enemyRoleData = self.world.DataSystem:GetRoleData(enemyRoleUid)
        local chainList = enemyRoleData.stateInfo.chainInfos
        local queueCards = enemyRoleData.stateInfo.queueCards
        
        if #queueCards > 0 or #chainList > 0 then
            mod.GuideEventCtrl:Trigger(GuideDefine.Event.enter_battle_with_enemy_chain)
        end

        local curEpNodeInfo = mod.PveRogueProxy:GetCurrEpNodeInfo()
        if curEpNodeInfo then
            local nodeConf = Config.Get("act_node_def", "config", "id", curEpNodeInfo.nodeId)
            local robotConf = Config.Get("robot_def", "config", "id", nodeConf.robot)

            if nodeConf.robotChips and #nodeConf.robotChips > 0 then
                mod.GuideEventCtrl:Trigger(GuideDefine.Event.enter_robot_chips_battle)        
            else
                if robotConf and robotConf.groupId ~= 0  then
                    mod.GuideEventCtrl:Trigger(GuideDefine.Event.enter_pve_no_chaim_battle)            
                end
            end
        end
    end

    -- mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.RefreshAllSlotEnable, BattleDefine.Camp.self)

    local roleUid = self.world.DataSystem.roleUid
    if self.args.roundStage == BattleDefine.RoundStep.battle_play then
        self.world.StateSystem.playerClickEndButton = true
    end

    -- 允许刷新结束按钮的特效
    if self.args.roundStage == BattleDefine.RoundStep.main1 and self.world.DataSystem:IsCurActiveRole(roleUid) then
        self.world.StateSystem.playerClickEndButton = false
        self.world.OperateSystem.isSendEndTurn = false
    end

    if self.args.roundStage == BattleDefine.RoundStep.battle_play and self.world.DataSystem:IsCurActiveRole(roleUid) then
        mod.GuideEventCtrl:Trigger(GuideDefine.Event.round_end)
    end

    mod.BattleFacade:SendEvent(BattleFuncBtnView.Event.RefreshEndBtnState)

    if self.args.roundStage == BattleDefine.RoundStep.main1 and self.world.DataSystem:IsCurActiveRole(roleUid) then
        self.world.LatestDataSystem:SetLockActionExecute()
    end

    self:ActionComplete()
end



function StageChangeAB:OnCancel()

end

function StageChangeAB:OnUpdate(deltaTime)

end