TimerOutAB = BaseClass("TimerOutAB", ActionBehaviorBase)

function TimerOutAB:__Init()
end

function TimerOutAB:__Delete()
end

function TimerOutAB:OnInit()

end

function TimerOutAB:OnStart()
    LogTable("倒计时超时AB", self.args)

    self.world.DataSystem:ChangeRoleTimerInfo(self.args.info)
    mod.BattleFacade:SendEvent(BattleTimerView.Event.RefreshTimerView)
    self:ActionComplete()
    --
end

function TimerOutAB:OnCancel()

end

function TimerOutAB:OnUpdate(deltaTime)
end
