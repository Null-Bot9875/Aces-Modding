TimerUpdateAB = BaseClass("TimerUpdateAB", ActionBehaviorBase)

function TimerUpdateAB:__Init()
end

function TimerUpdateAB:__Delete()
end

function TimerUpdateAB:OnInit()

end

function TimerUpdateAB:OnStart()
    LogTable("倒计时更新AB", self.args)

    for i, v in ipairs(self.args.timerInfos) do
        local diff = self.world.DataSystem:ChangeRoleTimerInfo(v)

        local args = {}
        args.uid = v.uid
        args.diff = diff
        mod.BattleFacade:SendEvent(BattleTimerView.Event.ShowTimerViewDiff, args)
    end

    mod.BattleFacade:SendEvent(BattleTimerView.Event.RefreshTimerView)
    self:ActionComplete()
    --
end

function TimerUpdateAB:OnCancel()

end

function TimerUpdateAB:OnUpdate(deltaTime)
end
