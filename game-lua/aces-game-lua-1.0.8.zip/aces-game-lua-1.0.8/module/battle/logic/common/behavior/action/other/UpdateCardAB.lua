UpdateCardAB = BaseClass("UpdateCardAB", ActionBehaviorBase)

function UpdateCardAB:__Init()
end

function UpdateCardAB:__Delete()

end

function UpdateCardAB:OnInit()

end

function UpdateCardAB:OnStart()
    local roleUid = self.args.uid
    local camp = self.world.DataSystem:GetCamp(roleUid)

    for index, value in ipairs(self.args.infos) do
        local cardInfo = value

        if value.area == BattleDefine.CardAreaDef.equip then
            -- self.world.DataSystem:UpdateSlotCardInfo(roleUid, cardInfo)
            -- local slotData = self.world.DataSystem:GetSlotInfoByCardUid(roleUid,cardInfo.id)
            -- if slotData then
            -- mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.RefreshSlotData,self.args.uid,self.args.uid,slotData)
            -- end
        elseif value.area == BattleDefine.CardAreaDef.hand then
            mod.BattleFacade:SendEvent(BattleHandCardView.Event.RefreshHandCardData, cardInfo)
            self.world.DataSystem:AddCardInfo(roleUid, value.area, cardInfo)
        elseif value.area == BattleDefine.CardAreaDef.consume then
            self.world.DataSystem:AddCardInfo(roleUid, value.area, cardInfo)
            mod.BattleFacade:SendEvent(BattleHandCardView.Event.RefreshHandCardData, cardInfo)
        elseif value.area == BattleDefine.CardAreaDef.discard then
            self.world.DataSystem:AddCardInfo(roleUid, value.area, cardInfo)
            mod.BattleFacade:SendEvent(BattleHandCardView.Event.RefreshHandCardData, cardInfo)
        elseif value.area == BattleDefine.CardAreaDef.library then
            self.world.DataSystem:AddCardInfo(roleUid, value.area, cardInfo)
        elseif value.area == BattleDefine.CardAreaDef.newCard then
            self.world.DataSystem:AddCardInfo(roleUid, value.area, cardInfo)
        elseif value.area == BattleDefine.CardAreaDef.stack then
        elseif value.area == BattleDefine.CardAreaDef.queueCars then
            self.world.DataSystem:AddCardInfo(roleUid, value.area, cardInfo)
        elseif value.area == BattleDefine.CardAreaDef.device_drone then
            -- local oldCardInfo = self.world.DataSystem:GetCardInfo(cardInfo.id)
            local oldGridInfo = self.world.DataSystem:GetGridInfoByDeviceUid(cardInfo.id)
            self.world.DataSystem:AddCardInfo(roleUid, BattleDefine.CardAreaDef.device_drone, cardInfo)
            self.world.DataSystem:UpdateGridCardInfo(roleUid, cardInfo)


            -- 更新
            local updateDeviceInfos = self.world.MixedSystem:GenerateDeviceInfosByCardId(cardInfo.id)
            for deviceUid, deviceInfo in pairs(updateDeviceInfos) do
                self.world.DroneDeviceSystem:UpdateSingleDevice(deviceInfo, oldGridInfo) --更新
            end

            self.world.SceneSystem:RefreshAllGridInfo()
            -- self.world.DroneDeviceSystem:RefreshAllDeviceInfo()
            -- 在没有合并的时候，刷新机甲头顶信息
            if not (self.args.kvData and self.args.kvData.isMerge) then
                for deviceUid, deviceInfo in pairs(updateDeviceInfos) do
                    local isPlayer = self.world.DataSystem:IsPlayerCard(deviceUid)
                    if isPlayer then
                        mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshHpMax,roleUid)
                        mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshHp, roleUid)
                    end

                    local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(deviceUid)
                    if entity then
                        entity.DeviceTopInfoComponent:RefreshInfo()
                    end
                end
            end

            -- 异能变动后同步运行时爆炸死亡标记
            local deviceEntity = self.world.MixedSystem:GetGridDroneEntityByCardUid(cardInfo.id)
            if deviceEntity then
                deviceEntity.ObjectDataComponent:RefreshRuntimeExplode(cardInfo)
            end
        else
            LogError(string.format("卡牌刷新未处理的区域类型 area error, area = %s", value.area))
        end

        -- 若卡牌已显示在手牌视图，主动刷新描述
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.RefreshHandCardData, cardInfo)

        -- 若卡牌已显示在堆叠视图，主动刷新描述
        local allStackInfos = self.world.DataSystem:GetAllStackInfos()
        for _, stackInfo in ipairs(allStackInfos) do
            if stackInfo.cardInfo and stackInfo.cardInfo.id == cardInfo.id then
                stackInfo.cardInfo = cardInfo
                mod.BattleFacade:SendEvent(BattleStackCardView.Event.UpdateStack, stackInfo)
                break
            end
        end
    end


    --
    self.world.SceneSystem:RefreshBackLoop(camp)

    self:ActionComplete()
end

function UpdateCardAB:OnCancel()

end

function UpdateCardAB:OnUpdate(deltaTime)

end
