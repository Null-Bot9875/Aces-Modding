UpdateDeviceAB = BaseClass("UpdateDeviceAB",ActionBehaviorBase)

function UpdateDeviceAB:__Init()
    self.tokenTimelines = {}
    self.tokenPlayNum = 0
end

function UpdateDeviceAB:__Delete()
    for _, v in ipairs(self.tokenTimelines) do
        v:Delete()
    end
end

function UpdateDeviceAB:OnInit()

end

function UpdateDeviceAB:OnStart()
    LogTable("更新设备AB",self.args)

    for i, info in ipairs(self.args.infos) do
        local updateInfo = self.world.DataSystem:UpdateDeviceInfo(self.args.uid,info)
        mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.RefreshSlotEnable,self.args.uid,self.args.uid,info)
        mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.RefreshSlotToken,self.args.uid,self.args.uid,info)
        mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.RefreshSlotData,self.args.uid,self.args.uid,info)
    
    
        -- local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.uid)
        -- if carrierEntity then
            -- carrierEntity.TopInfoComponent:UpdateDeviceList()
    
            -- if updateInfo.isNew or updateInfo.isRemove then
                -- carrierEntity.TposeComponent:BindCarrierDeviceEffect()
            -- end
        -- end
    
        -- if updateInfo.isNew then
        --     local cardCfg =  Config.Get("card_def","config","cardId",info.cardInfo.cardId)
        --     if cardCfg.extend.setupPlay then
        --         self.world.ActionSystem:ParseAction(BattleDefine.ActionType.setup_device_play,self.args,1)
        --     end
        -- end
        
        -- if updateInfo.isNew and info.type == KvData.DeviceType.mode then
        --     self.world.ActionSystem:ParseAction(BattleDefine.ActionType.carrier_switch_mode,self.args,1)
        -- end
    end


    self:ActionComplete()
end


function UpdateDeviceAB:OnCancel()

end

function UpdateDeviceAB:OnUpdate(deltaTime)
    for _, v in ipairs(self.tokenTimelines) do
        v:Update(deltaTime)
    end
end

function UpdateDeviceAB:TokenPlayDone()
    self.tokenPlayNum =  self.tokenPlayNum + 1
    if self.tokenPlayNum >= #self.tokenTimelines then
        self:ActionComplete()
    end
end