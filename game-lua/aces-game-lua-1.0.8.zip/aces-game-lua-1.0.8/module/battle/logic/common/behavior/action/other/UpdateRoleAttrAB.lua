UpdateRoleAttrAB = BaseClass("UpdateRoleAttrAB", ActionBehaviorBase)

function UpdateRoleAttrAB:__Init()
    self.waitRunActionTimelines = {}
    self.runActionTimeline = nil
    self.runIndex = 0
end

function UpdateRoleAttrAB:__Delete()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end

    for _,v in ipairs(self.waitRunActionTimelines) do
        v:Delete()
    end
end

function UpdateRoleAttrAB:OnInit()

end

function UpdateRoleAttrAB:OnStart()
    LogTable("更新属性AB", self.args)
    local roleUid = self.args.uid
    local attrMap = self.args.attrMap


    local list = self.world.DataSystem:UpdateRoleAttr(roleUid, attrMap)

    local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.uid)
    -- local time = carrierEntity.TopInfoComponent:UpadteAttrList(list)
    -- carrierEntity.TopInfoComponent:SortAttrAndStatic()

    local mode = self.world.DataSystem:GetCarrierMode(self.args.uid)
    if DEBUG_MODE then
        mode = DEBUG_MODE
    end

    --重连，重新创建属性的timeline，并且执行还原方法
    --重连里，需要把特效都清理掉，现在是机甲重新创建，正常就是清掉了

    if not carrierEntity then
        self:ActionComplete()
        return
    end

    local modelId = carrierEntity.ObjectDataComponent.modelId

    for _, v in ipairs(attrMap) do
        local attr = v.attr
        local value = v.value

        local attrConfName =  string.format("%s_%s_%s_%s",modelId,mode,value,attr)

        if Config.HasConf(attrConfName) then
            local playDatas = Config.GetLua(attrConfName)
            local playActions = {}
            for _,v in ipairs(playDatas) do
                table.insert(playActions,{args = nil,action = v})
            end
            
            local execArgs = {}
            execArgs.info = self.args
            execArgs.info.srcPlayer = self.args.uid
            execArgs.info.markTargetMap = {
                [BattleDefine.MarkTargetType.src] = {carrierEntity.ObjectDataComponent:GetCardUid()},
                [BattleDefine.MarkTargetType.target] = {},
            }
        
            local actionTimeline = ActionTimeline.New()
            actionTimeline:SetWorld(self.world)
            actionTimeline:OnInit(carrierEntity,playActions,execArgs)
            actionTimeline:SetComplete(self:ToFunc("ActionTimelineDone"))
            table.insert(self.waitRunActionTimelines,actionTimeline)
        end
    end

    -- local camp = carrierEntity.CampComponent.camp
    -- self.world.CarrierSystem:RefreshCarrierAttrEffect(camp)

    if #self.waitRunActionTimelines > 0 then
        self:ActionTimelineDone()
    else
        self.doneTimer = self.world.TimerSystem:AddTimer(1, 0, self:ToFunc("OnDoneTimer"))
    end
end

function UpdateRoleAttrAB:ActionTimelineDone()
    self.runIndex = self.runIndex + 1
    self.runActionTimeline = nil

    if self.runIndex > #self.waitRunActionTimelines then
        self:ActionComplete()
    else
        self.runActionTimeline = self.waitRunActionTimelines[self.runIndex]
        self.runActionTimeline:Start()
    end
end

function UpdateRoleAttrAB:OnDoneTimer()
    self.doneTimer = nil
    self:ActionComplete()
end

function UpdateRoleAttrAB:OnCancel()
end

function UpdateRoleAttrAB:OnUpdate(deltaTime)
    if self.runActionTimeline then
        self.runActionTimeline:Update(deltaTime)
    end
end
