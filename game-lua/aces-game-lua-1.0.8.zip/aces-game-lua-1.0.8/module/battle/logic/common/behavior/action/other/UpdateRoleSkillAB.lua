UpdateRoleSkillAB = BaseClass("UpdateRoleSkillAB", ActionBehaviorBase)

function UpdateRoleSkillAB:__Init()
end

function UpdateRoleSkillAB:__Delete()
end

function UpdateRoleSkillAB:OnInit()
end

function UpdateRoleSkillAB:OnStart()
    LogTable("更新异能AB", self.args)
    local roleUid = self.args.uid
    local skills = self.args.skills

    local list = self.world.DataSystem:UpdateRoleStaticSkills(roleUid, skills)
    mod.BattleFacade:SendEvent(BattleCarrierSkillView.Event.RefreshStaticSkillItem, roleUid, list)
    self:ActionComplete()
end

function UpdateRoleSkillAB:OnCancel()

end

function UpdateRoleSkillAB:OnUpdate(deltaTime)
end
