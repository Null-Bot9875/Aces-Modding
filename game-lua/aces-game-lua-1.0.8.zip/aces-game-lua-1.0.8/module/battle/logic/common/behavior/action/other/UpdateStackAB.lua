UpdateStackAB = BaseClass("UpdateStackAB", ActionBehaviorBase)

function UpdateStackAB:__Init()
end

function UpdateStackAB:__Delete()
end

function UpdateStackAB:OnInit()

end

function UpdateStackAB:OnStart()
    LogTable("刷新堆叠", self.args)

    for i, v in ipairs(self.args.infos) do
        mod.BattleFacade:SendEvent(BattleStackCardView.Event.UpdateStack,v)
        self.world.DataSystem:UpdateStackInfo(v)
        -- 若堆叠中的卡牌同时显示在手牌视图，主动刷新描述
        if v.cardInfo then
            mod.BattleFacade:SendEvent(BattleHandCardView.Event.RefreshHandCardData, v.cardInfo)
        end
    end
    
    self:ActionComplete()
    --
end

function UpdateStackAB:OnCancel()

end

function UpdateStackAB:OnUpdate(deltaTime)
end
