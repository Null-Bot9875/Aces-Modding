StackEndResultAB = BaseClass("StackEndResultAB", ActionBehaviorBase)

function StackEndResultAB:__Init()
    self.rtUIObject = nil
    self.endEffect = nil
    self.hideStackCardTimer = nil
    self.doneTimer = nil
    
    self.isDissolve = false
    self.stackData = nil
    self.stackInfo = nil
end

function StackEndResultAB:__Delete()
    if self.endEffect then
        self.endEffect:Delete()
        self.endEffect = nil
    end

    if self.rtUIObject then
        self.rtUIObject:Delete()
        self.rtUIObject = nil
    end

    if self.hideStackCardTimer then
        self.world.TimerSystem:RemoveTimer(self.hideStackCardTimer)
        self.hideStackCardTimer = nil
    end

    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end

    if self.timer then
        self.world.TimerSystem:RemoveTimer(self.timer)
        self.timer = nil
    end

    if self.isDissolve then
        self.world.DataSystem:RemoveStackInfo(self.args.stackId)
    end
end

function StackEndResultAB:OnInit()

end

function StackEndResultAB:OnStart()
    LogTable("堆叠结束结算AB", self.args)
    self._tOnStart = Time.time

    -- 同一 stack 只允许一个溶解 AB 执行（RemoveStackActionAB 或本 AB 二选一）
    if self.world.StateSystem:GetCacheInfo(string.format("stack_dissolve_%s", self.args.stackId)) then
        self:ActionComplete()
        return
    end

    local stackData = self.world.DataSystem:GetStackInfo(self.args.stackId)
    self.stackData = stackData
    if not stackData then
        self:ActionComplete()
        return
    end

    self.stackInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackInfo, self.args.stackId)
    if not self.stackInfo then
        self:ActionComplete()
        return
    end

    self.world.StateSystem:SetCacheInfo(string.format("stack_dissolve_%s", self.args.stackId), true)
    self.isDissolve = true
    
    local startStackTime = self.world.StateSystem:GetCacheInfo(string.format("%s_time", self.args.stackId))
    local waitTime = BattleDefine.ShowTime.StackLeastShowTime
    if startStackTime then
        local diff = Time.time - startStackTime
        local camp = self.world.DataSystem:GetCamp(stackData.actor)
        local leastTime = BattleDefine.ShowTime.DefaultStackLeastShowTime

        if stackData.type == BattleDefine.StackType.passive then
            leastTime = BattleDefine.ShowTime.PassiveStackLeastShowTime
        elseif camp == BattleDefine.Camp.self and (
            stackData.type == BattleDefine.StackType.card_cmd or 
            stackData.type == BattleDefine.StackType.item or 
            stackData.effectSrcType == BattleDefine.EffectSrcType.chip_effect or
            stackData.effectSrcType == BattleDefine.EffectSrcType.item_effect) then
            leastTime = BattleDefine.ShowTime.SelfCmdLeastShowTime
        end
        waitTime = diff > leastTime and 0 or leastTime - diff
        -- Log(string.format("堆叠%s 已存在%s秒，等待%s秒后结束", self.args.stackId, diff, waitTime))
    end

    self.world.StateSystem:SetEnableOp(true)
    self.timer = self.world.TimerSystem:AddTimer(1, waitTime, self:ToFunc("ShowStackComplete"))

    -- self:ActionPreComplete()
end

function StackEndResultAB:ShowStackComplete()
    self.timer = nil
    self.world.ActionSystem:SetExecEventState(BattleDefine.ExecEventState.none)
    self.world.StateSystem:SetCacheInfo("stack_played_attack_" .. self.args.stackId, nil)
    -- local stackData = self.world.DataSystem:GetStackInfo(self.args.stackId)
    local stackData = self.stackData
    if stackData.effectSrcType == BattleDefine.EffectSrcType.item_effect then
        self:HandleStackItem(stackData)
    else
        self:HandleStackCard(stackData)
    end
    self:ActionPreComplete()
end

function StackEndResultAB:HandleStackItem(stackData)
    -- 现在的道具没有添加到堆叠里面，直接取得是移动到堆叠位置的道具
    local item = mod.BattleFacade:SendEvent(BattleBattleItemView.Event.GetBattleItemObj, stackData.effectSrcValue)
    if not item or BaseUtils.IsNull(item.gameObject) then
        self:ActionComplete()
        return
    end
    local cardType = BattleDefine.ItemTypeMap[item.conf.type[1]]

    local stackInfo = self.stackInfo
    if not stackInfo or not stackInfo.item or BaseUtils.IsNull(stackInfo.item.gameObject) then
        self:ActionComplete()
        return
    end

    self:HandleStackEffect(stackInfo.item, cardType)
end

function StackEndResultAB:HandleStackCard(stackData)
    local stackInfo = self.stackInfo
    if not stackInfo or not stackInfo.item or BaseUtils.IsNull(stackInfo.item.gameObject) then
        self:ActionComplete()
        return
    end

    local info = stackInfo.item.data.baseInfo.stackData.cardInfo
    local cardType = self.world.PluginSystem.GetCardAttr:GetCardTypeValue(info)
    self:HandleStackEffect(stackInfo.item, cardType)
end

function StackEndResultAB:HandleStackEffect(item, cardType, forceSetting)
    forceSetting = forceSetting or {}
    if not item or BaseUtils.IsNull(item.gameObject) or BaseUtils.IsNull(item.transform) then
        self:ActionComplete()
        return
    end

    local setting = {}
    setting.textureWidth = 510
    setting.textureHeight = 710 --757.55
    setting.uiObject = item.gameObject

    self.rtUIObject = RTUIObject.New()
    self.rtUIObject:Show(setting)

    if cardType == 0 then cardType = BattleDefine.CardType.white end

    local endEffectSetting = {}
    endEffectSetting.assetId = string.format("ui_battle_card_action_end_%s", AssetPath.EffectColor[cardType])
    endEffectSetting.parent = item.transform
    endEffectSetting.pos = forceSetting.pos or {x = 0, y = 0}
    endEffectSetting.scale = forceSetting.scale or 1000
    endEffectSetting.order = item:GetOrder()
    endEffectSetting.onLoad = self:ToFunc("EffectLoaded")

    self.endEffect = UIEffect.New()
    self.endEffect:Init(endEffectSetting)
    self.endEffect:Play()
end

function StackEndResultAB:EffectLoaded(effect)
    if not self.endEffect or not self.endEffect.effect or not self.rtUIObject or BaseUtils.IsNull(self.endEffect.effect) then
        self:ActionComplete()
        return
    end
    local node = self.endEffect.effect.transform:Find("node")
    if not node or BaseUtils.IsNull(node) then
        self:ActionComplete()
        return
    end
    local child0 = node:GetChild(0)
    if not child0 or BaseUtils.IsNull(child0.gameObject) then
        self:ActionComplete()
        return
    end
    local render = child0.gameObject:GetComponent(Renderer)
    if not render then
        self:ActionComplete()
        return
    end
    render.material:SetTexture("_basecolor", self.rtUIObject.texture)
    render.material:SetTexture("_maintex", self.rtUIObject.texture)

    self.hideStackCardTimer = self.world.TimerSystem:AddTimerByNextFrame(1, 0, self:ToFunc("HideStackCardTimer"))
end

function StackEndResultAB:HideStackCardTimer()
    self.hideStackCardTimer = nil
    local stackData = self.stackData
    local stackInfo = self.stackInfo
    if not stackInfo or not stackInfo.item or BaseUtils.IsNull(stackInfo.item.gameObject) then
        self:ActionComplete()
        return
    end
    local stackItem = stackInfo.item
    local tposeTrans = stackItem:Find("tpose")
    if tposeTrans and not BaseUtils.IsNull(tposeTrans.gameObject) then
        tposeTrans.gameObject:SetActive(false)
    end
    mod.BattleFacade:SendEvent(BattleStackCardView.Event.PlayWaitEffect, self.args.stackId, false)

    if stackData.effectSrcType == BattleDefine.EffectSrcType.item_effect then
        local item = mod.BattleFacade:SendEvent(BattleBattleItemView.Event.GetBattleItemObj, stackData.effectSrcValue)
        if item and not BaseUtils.IsNull(item.tposeTrans) and not BaseUtils.IsNull(item.tposeTrans.gameObject) then
            item.tposeTrans.gameObject:SetActive(false)
        end
    end

    local time = self.endEffect and self.endEffect:GetDuration() and (self.endEffect:GetDuration() * 0.001) or 0
    self.doneTimer = self.world.TimerSystem:AddTimer(1, time, self:ToFunc("TimerDone"))
end

function StackEndResultAB:TimerDone()
    self.doneTimer = nil
    local stackData = self.stackData
    if stackData.effectSrcType == BattleDefine.EffectSrcType.item_effect then
        mod.BattleFacade:SendEvent(BattleBattleItemView.Event.ClearBattleItemObj, stackData.effectSrcValue)
    end

    self.world.StateSystem:SetCacheInfo(string.format("stack_dissolve_%s", self.args.stackId), nil)

    mod.BattleFacade:SendEvent(BattleStackCardView.Event.RemoveStack, self.args.stackId)

    EventManager.Instance:SendEvent(EventDefine.remove_stack_done)
    mod.BattleFacade:SendEvent(BattleChainQueueView.Event.ShowChainQueueHighlight, stackData.cardInfo.id, false)
    self:ActionComplete()
    Log(string.format("StackEndResultAB:TimerDone 耗时:%.3fs", Time.time - self._tOnStart))
end

function StackEndResultAB:OnCancel()
end

function StackEndResultAB:OnUpdate(deltaTime)
end
