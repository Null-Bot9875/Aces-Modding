StackStartResultAB = BaseClass("StackStartResultAB", ActionBehaviorBase)

function StackStartResultAB:__Init()
    self.doneTimer = nil
    self.actionTimeline = nil
    self.useStackLevelPlay = false
end

function StackStartResultAB:__Delete()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end

    if self.timer then
        TimerManager.Instance:RemoveTimer(self.timer)
        self.timer = nil
    end

    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end
end

function StackStartResultAB:OnInit()

end

function StackStartResultAB:OnStart()
    LogTable("堆叠开始结算AB", self.args)

    self.world.ActionSystem:SetExecEventState(BattleDefine.ExecEventState.stack_result)
    mod.BattleFacade:SendEvent(BattleStackCardView.Event.RemoveStackLines, self.args.stackId)

    local stackInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackInfo, self.args.stackId)
    if not stackInfo then
        self:ActionComplete()
        return
    end

    self.stackData = self.world.DataSystem:GetStackInfo(self.args.stackId)

    -- 播放堆叠结算音效
    self:PlayStackResultAudio()

    -- 检查是否使用堆叠级攻击表现
    self.useStackLevelPlay = self:CheckUseStackLevelPlay()

    if self.useStackLevelPlay then
        -- 类似ExecEffectAB的方式，构建timeline并播放堆叠级攻击表现
        self:PlayStackLevelAttack()
    else
        -- 不使用堆叠级表现，走原有逻辑
        self.doneTimer = self.world.TimerSystem:AddTimer(1, 0.1, self:ToFunc("TimerDone"))
        self.timer = TimerManager.Instance:AddTimerByNextFrame(1, 0.1, self:ToFunc("OnActionPreComplete"))
    end
end

-- 播放堆叠结算音效
function StackStartResultAB:PlayStackResultAudio()
    local cardInfo = self.stackData.cardInfo
    local cardId = cardInfo.cardId
    if cardId ~= 0 then
        local cardType = self.world.PluginSystem.GetCardAttr:GetCardTypeValue(self.stackData.cardInfo)
        if cardType == 0 then cardType = BattleDefine.CardType.white end
        local audioId = BattleDefine.StackResultColorToAudio[cardType]
        AudioManager.Instance:PlayScene(audioId)
    else
        AudioManager.Instance:PlayScene(BattleDefine.StackResultColorToAudio[BattleDefine.CardType.white])
    end
end

-- 检查是否使用堆叠级攻击表现（目前只处理攻击类型）
function StackStartResultAB:CheckUseStackLevelPlay()
    local stackData = self.stackData
    if not stackData or not stackData.skillId then
        return false
    end

    local skillConf = Config.Get("battle_skill_def", "config", "skillId", stackData.skillId)
    if not skillConf then
        return false
    end

    local playResultType = skillConf.playResultType
    if not playResultType then
        return false
    end

    -- 目前只处理攻击类型的堆叠级表现
    local ATTACK_RESULT_TYPES = {
        [BattleDefine.PlayResultType.attack] = true,
        [BattleDefine.PlayResultType.backAttack] = true,
        [BattleDefine.PlayResultType.fanAttack] = true,
        [BattleDefine.PlayResultType.penetratAttack] = true,
        [BattleDefine.PlayResultType.selfExplode] = true,
        [BattleDefine.PlayResultType.selfAoeExplode] = true,
        [BattleDefine.PlayResultType.meleeAttack] = true,
    }

    return ATTACK_RESULT_TYPES[playResultType] == true
end

-- 播放堆叠级攻击表现，类似ExecEffectAB的流程
function StackStartResultAB:PlayStackLevelAttack()
    local stackData = self.stackData
    local skillConf = Config.Get("battle_skill_def", "config", "skillId", stackData.skillId)
    if not skillConf or not skillConf.playResultType then
        LogError("堆叠级攻击表现：skillConf无效，回退到原有逻辑")
        self.useStackLevelPlay = false
        self.doneTimer = self.world.TimerSystem:AddTimer(1, 0.1, self:ToFunc("TimerDone"))
        self.timer = TimerManager.Instance:AddTimerByNextFrame(1, 0.1, self:ToFunc("OnActionPreComplete"))
        return
    end

    -- 收集堆叠内所有效果的目标信息
    local markTargetMap = self:BuildMarkTargetMap()
    LogTable("堆叠级markTargetMap", markTargetMap)

    -- 类似ExecEffectAB，构建timeline执行参数
    local execArgs = self:BuildExecArgs(markTargetMap)

    -- 使用PlayResultToTB映射获取对应的TB类型
    local playActions = {}
    local playResultType = skillConf.playResultType
    local tbType = TimelineBehaviorIndex.PlayResultToTB[playResultType]
    if tbType then
        table.insert(playActions, { args = nil, action = { type = tbType, time = 0 } })
    end

    if #playActions == 0 then
        -- 没有对应的TB类型，回退到原有逻辑
        LogError(string.format("堆叠级攻击表现：无法映射playResultType=%s到TB", tostring(playResultType)))
        self.useStackLevelPlay = false
        self.doneTimer = self.world.TimerSystem:AddTimer(1, 0.1, self:ToFunc("TimerDone"))
        self.timer = TimerManager.Instance:AddTimerByNextFrame(1, 0.1, self:ToFunc("OnActionPreComplete"))
        return
    end

    Log(string.format("堆叠级攻击表现：使用TB类型=%s", tostring(tbType)))

    -- 标记该堆叠已在堆叠层触发表现，表现层 ExecEffectAB 将不再重复播
    self.world.StateSystem:SetCacheInfo("stack_played_attack_" .. self.args.stackId, true)

    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(nil, playActions, execArgs)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()

    -- 提前通知预完成，让后续action可以继续处理
    -- self.timer = TimerManager.Instance:AddTimerByNextFrame(1, 0.1, self:ToFunc("OnActionPreComplete"))
end

-- 构建markTargetMap，遍历stackContext中的所有exec_effect，收集目标
function StackStartResultAB:BuildMarkTargetMap()
    local markTargetMap = {}
    markTargetMap[BattleDefine.MarkTargetType.src] = {}
    markTargetMap[BattleDefine.MarkTargetType.target] = {}
    local stackContext = self.stackContext

    if not stackContext or not stackContext.actions then
        return markTargetMap
    end

    for _, actionInfo in ipairs(stackContext.actions) do
        if actionInfo.type == BattleDefine.ActionType.exec_effect then
            local effectData = actionInfo.data
            self:CollectMarkTargets(markTargetMap, effectData)
        end
    end

    return markTargetMap
end

-- 从单个效果数据中收集markTarget目标uid
function StackStartResultAB:CollectMarkTargets(markTargetMap, effectData)
    local effectConf = Config.Get("battle_effect_def", "config", "effectId", effectData.effectId)
    if not effectConf then
        return
    end

    -- 未配置markTarget时默认归入"target"组
    local markTarget = BattleDefine.MarkTargetType.target
    if effectConf.markTarget and effectConf.markTarget ~= "" then
        markTarget = effectConf.markTarget
    end

    if effectConf.playResultType == BattleDefine.PlayResultType.none and effectConf.markTarget == "" then
        return
    end

    if not markTargetMap[markTarget] then
        markTargetMap[markTarget] = {}
    end

    for _, result in ipairs(effectData.results or {}) do
        local uid = nil
        if result.cardUid and result.cardUid ~= 0 then
            uid = result.cardUid
        end
        if uid then
            table.insert(markTargetMap[markTarget], uid)
        end
    end

    if #effectData.results == 0 then
        local carrierEntity = self.world.EntitySystem:GetCarrierEntity(effectData.srcPlayer)
        if carrierEntity then
            local targetUid = carrierEntity.ObjectDataComponent:GetCardUid()
            table.insert(markTargetMap[BattleDefine.MarkTargetType.src], targetUid)
        end

        local carrierEntity = self.world.EntitySystem:GetCarrierEntity(effectData.targetPlayer)
        if carrierEntity then
            local targetUid = carrierEntity.ObjectDataComponent:GetCardUid()
            table.insert(markTargetMap[BattleDefine.MarkTargetType.target], targetUid)
        end
    end
end

-- 构建timeline执行参数，结构与ExecEffectAB中构建的execArgs一致
function StackStartResultAB:BuildExecArgs(markTargetMap)
    local stackData = self.stackData

    -- 汇总所有action的results
    local results = {}
    if self.stackContext and self.stackContext.actions then
        for _, actionInfo in ipairs(self.stackContext.actions) do
            if actionInfo.type == BattleDefine.ActionType.exec_effect then
                for _, result in ipairs(actionInfo.data.results or {}) do
                    table.insert(results, result)
                end
            end
        end
    end

    -- src组：效果源实体uid
    local srcCardUid = self.world.MixedSystem:GetEffectSrcEntityCardUid({info = {
        effectSrcType = BattleDefine.EffectSrcType.stack_effect,
        effectSrcValue = self.args.stackId,
        srcPlayer = stackData.actor,
    }})
    markTargetMap[BattleDefine.MarkTargetType.src] = {srcCardUid }

    local execArgs = {
        info = {
            effectSrcType = BattleDefine.EffectSrcType.stack_effect,
            effectSrcValue = self.args.stackId,
            srcPlayer = stackData.actor,
            results = results,
            skillId = stackData.skillId,
            stackContext = self.stackContext,
            markTargetMap = markTargetMap,
        },
        isStackLevelPlay = true,
        kvData = {
            stackContext = self.stackContext,
        },
    }

    return execArgs
end

function StackStartResultAB:TimelineDone()
    Log("堆叠级攻击表现播放完成")
    self:ActionComplete()
end

function StackStartResultAB:OnActionPreComplete()
    if self.timer then
        TimerManager.Instance:RemoveTimer(self.timer)
        self.timer = nil
    end

    self:ActionPreComplete()
end

function StackStartResultAB:OnCancel()
end

function StackStartResultAB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end

function StackStartResultAB:TimerDone()
    self.doneTimer = nil
    self:ActionComplete()
end
