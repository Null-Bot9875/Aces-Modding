OperateBehaviorBase = BaseClass("OperateBehaviorBase",SECBBehavior)

function OperateBehaviorBase:__Init()
    self.conf = nil
    self.args = nil
    self.onComplete = nil
end

function OperateBehaviorBase:__Delete()
end

function OperateBehaviorBase:SetConf(conf)
    self.conf = conf
end

function OperateBehaviorBase:SetArgs(args)
    self.args = args
end

function OperateBehaviorBase:SetComplete(onComplete)
    self.onComplete = onComplete
end

function OperateBehaviorBase:Start(...)
    self:OnStart(...)
end

function OperateBehaviorBase:Cancel()
    self:OnCancel()
end

function OperateBehaviorBase:OperateComplete()
    if self.onComplete then
        self.onComplete(self)
    end
end

function OperateBehaviorBase:OnStart()
end

function OperateBehaviorBase:OnCancel()
end