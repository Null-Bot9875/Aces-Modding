--------------
-- 1. 先选择目标，然后选择消耗，最后使用卡牌
-- 2. 选择目标的时候，如果目标是格子，无人机，机体，显示目标线，有相关的表现逻辑
-- 3. 没有目标选择则是拖出去就使用的逻辑
-- 4. 使用之后移动到堆叠位置
-- 5. 点击空区域不取消使用 (包括拖拽的情况，点击空区域不取消)
--------------
HandCardOB = BaseClass("HandCardOB", OperateBehaviorBase)

function HandCardOB:__Init()
    self.moveListenId = nil
    self.cancelListenId = nil
    self.pointerId = nil

    -- 是否可以使用卡牌
    self.canUseCard = false
    -- 不能使用卡牌的原因
    self.msg = nil

    -- 是否使用卡牌
    self.isUseCard = false

    -- 是否取消操作
    self.isCancel = false

    -- 是否创建了目标选择
    self.isCreateSelectTarget = false

    -- 是否使用出去了，（往服务器发送了消息）
    self.isCompleteUse = false

    -- 消耗选择数据
    self.costSelectData = {}
    -- 目标选择数据
    self.targetSelectData = {}

    self.isDragCard = false
    self.isComplete = false

    self.isBlockCancel = false

    self.isClickDrag = false

    self.useOnDragEnd = false
end

function HandCardOB:__Delete()
    self:RemoveListen()
    self:RemoveTimelineBehavior()

    if self.moveCompleteTimer then
        self.world.TimerSystem:RemoveTimer(self.moveCompleteTimer)
        self.moveCompleteTimer = nil
    end

    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end

    if self.sendTimer then
        self.world.TimerSystem:RemoveTimer(self.sendTimer)
        self.sendTimer = nil
    end

    if self.isCompleteUse then
        self.world.SimulateSystem:ClearAllSimulateCache(self.args.cardData.id)
    end
    self.world.SimulateSystem:ClearPreview()

    self.world.StateSystem:SetEnableOp(true)
    -- PointerHandler.enablePointer = true

    -- self.world.CameraSystem:PlayCamera(BattleDefine.CameraType.baseShow)
    self.world.CameraSystem:PlayPlayerCamera()

    Log("销毁卡牌操作了, cardId=", self.args and self.args.cardData and self.args.cardData.id or "nil")

    local info = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo, self.args.cardData.id)
    if not self.isCompleteUse then
        if info and info.item then
            local item = info.item
            item:CleanMoveTargetAnim()
            item:SetState(BattleDefine.CardState.normal)
            item.colliderTrans.gameObject:SetActive(true)
            item:ResetAllOrder()
            item:ActiveCanUseRoot(true)
            item.dontRefreshPos = false
            -- item.handOffset.y = 0
            self.world.HandCardSystem:ClearCardStackState(self.args.cardData.id)
        end

        local cost = self.world.PluginSystem.GetCardAttr:GetEnergyVal(self.args.cardData)
        self.world.DataSystem:ClearVirtualEnergy(self.args.cardData.id)
    else

    end

    self.world.StateSystem:SetCacheInfo("curr_hand_ob_id", nil)


    mod.BattleFacade:SendEvent(BattleHandCardView.Event.RefreshAllHandCardPos, BattleDefine.Camp.self, true)
    mod.BattleFacade:SendEvent(BattleHandCardView.Event.PlayHandCardWaitEffect, self.args.cardData.id, false)
    mod.BattleFacade:SendEvent(BattleHandCardView.Event.PlayHandCardActivateEffect, self.args.cardData.id, false)

    mod.BattleFacade:SendEvent(BattleHandCardView.Event.PlayHandCardEffect, "card_using_action", self.args.cardData
        .id, false)

    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.ResetEnergyColor, self.world.DataSystem.roleUid)
    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.ResetNanoColor, self.world.DataSystem.roleUid)

    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshEnergy, self.world.DataSystem.roleUid)
    mod.BattleFacade:SendEvent(BattleFuncBtnView.Event.RefreshRightEnergy)
    mod.BattleFacade:SendEvent(BattleFuncBtnView.Event.RefreshRightEnergyEffect, false)

    mod.BattleFacade:SendEvent(BattleHandCardView.Event.PlayHandCardSelected, self.args.cardData.id, false)
    EventManager.Instance:SendEvent(EventDefine.cancel_card_ob_start, self.isCompleteUse)
end

function HandCardOB:RemoveTimelineBehavior()
    if self.selectCostTb then
        self.selectCostTb:Delete()
        self.selectCostTb = nil
    end

    if self.selectTargetTb then
        self.selectTargetTb:Delete()
        self.selectTargetTb:PreviewSelectableOptions(false)
        self.selectTargetTb = nil
    end
end

function HandCardOB:AddListen()
    self.moveListenId = TouchManager.Instance:AddListen(TouchDefine.TouchEvent.move, self:ToFunc("OnHandCardDrag"),
        self.pointerId)
    self.cancelListenId = TouchManager.Instance:AddListen(TouchDefine.TouchEvent.cancel,
        self:ToFunc("OnHandCardCancel"), self.pointerId)

    EventManager.Instance:AddEvent(EventDefine.on_app_focus, self:ToFunc("OnAppFocus"))
end

function HandCardOB:RemoveListen()
    if self.moveListenId then
        TouchManager.Instance:RemoveListen(self.moveListenId)
    end

    if self.cancelListenId then
        TouchManager.Instance:RemoveListen(self.cancelListenId)
    end

    EventManager.Instance:RemoveEvent(EventDefine.on_app_focus, self:ToFunc("OnAppFocus"))
end

function HandCardOB:OnStart()
    Log("启动行动牌操作了, cardId=", self.args.cardData.id)
    AudioManager.Instance:PlayUI("use_card_ob")

    local eventData = self.args.eventData
    self.pointerId = eventData.pointerId
    self:AddListen()

    -- Log(string.format("HandCardOB:OnStart() frame = %d", Time.frameCount))

    self.beginPos = eventData.position

    local checkArgs = {}
    checkArgs.cardData = self.args.cardData
    checkArgs.ShowLog = true
    checkArgs.useLatestData = true

    self.canUseCard, self.msg = self.world.PluginSystem.CheckUse:CheckHandCard(checkArgs)
    if self.msg == "" then
        self.msg = TI18N("battle_consume_common")
    end

    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo, self.args.cardData.id)
    -- 记录拖拽开始时 tpose 的世界坐标 Y，用于判断是否“拖出使用”（避免视口坐标不一致）
    local tposeRect = cardInfo.item.tposeTrans.gameObject:GetComponent(RectTransform)
    self.beginTposeY = tposeRect.anchoredPosition.y
    -- 记录卡牌 tpose 相对触摸点的世界坐标偏移，防止拖拽时卡牌跳位（粘滞感）
    local beginTouchPos = eventData.position
    local _, beginWorldPos = RectTransformUtility.ScreenPointToWorldPointInRectangle(
        cardInfo.item.tposeTrans.parent, beginTouchPos, UIDefine.uiCamera)
    local cardWorldPos = cardInfo.item.tposeTrans.position
    self.dragOffset = Vector3(cardWorldPos.x - beginWorldPos.x, cardWorldPos.y - beginWorldPos.y, 0)
    cardInfo.item:SetState(BattleDefine.CardState.drag, {})
    cardInfo.item:ActiveCanUseRoot(false)

    -- PointerHandler.enablePointer = false

    self.world.MixedSystem.clickCardTime = Time.time

    -- 如果操作的起始位置在屏幕下方，那么不会立刻取消操作，等下次到达屏幕下方的时候才会取消操作
    if self.world.MixedSystem:IsMouseInBottom() then
        self.isBlockCancel = true
    end

    local cost = self.world.PluginSystem.GetCardAttr:GetEnergyVal(self.args.cardData)
    -- local currEnergy = self.world.LatestDataSystem:GetEnergy(self.world.DataSystem.roleUid)
    self.world.DataSystem:AddVirtualEnergy(self.args.cardData.id, cost)

    self.world.StateSystem:SetCacheInfo("curr_hand_ob_id", self.args.cardData.id)

    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.PreReduceEnergy, self.world.DataSystem.roleUid, cost)

    -- 预扣星核：若该手牌有星核消耗，高亮星核显示
    local nanoCost = self.world.PluginSystem.GetCardAttr:GetNanoCost(self.args.cardData)
    if nanoCost > 0 then
        mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.PreReduceNano, self.world.DataSystem.roleUid, nanoCost)
    end

    mod.BattleFacade:SendEvent(BattleFuncBtnView.Event.RefreshRightEnergy)
    mod.BattleFacade:SendEvent(BattleFuncBtnView.Event.RefreshRightEnergyEffect, true)
    mod.BattleFacade:SendEvent(BattleHandCardView.Event.PlayHandCardSelected, self.args.cardData.id, true)

    EventManager.Instance:SendEvent(EventDefine.hand_card_ob_start)
end

function HandCardOB:OnCancel()
end

function HandCardOB:OnAppFocus(flag)
end

function HandCardOB:OnUpdate(deltaTime)
    local isPlayerInputBlocked = GameInput.IsBlocked()

    -- 卡牌可能被其他行为(如CardMoveAB)移走，此时应主动取消操作
    local checkInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo, self.args.cardData.id)
    if not checkInfo or not checkInfo.item then
        self.isComplete = true
    end

    if self.selectCostTb and not isPlayerInputBlocked then
        self.selectCostTb:Update(deltaTime)
    end

    if self.selectTargetTb and not isPlayerInputBlocked then
        self.selectTargetTb:Update(deltaTime)
    end

    if self.isComplete then
        self:OperateComplete()
        return
    end

    if isPlayerInputBlocked then
        return
    end

    if self.isUseCard and self.canUseCard then
        local conf = Config.Get("card_def", "config", "cardId", self.args.cardData.cardId)
        if conf.targetIds and conf.targetIds[1] ~= 0 then
            self:OnCreateSelectTarget()
        else
            self.selectTargetEnd = true
            self.useOnDragEnd = true

            self:RequestSimulate({})
        end
    end

    -- if (not self.selectTargetTb and not self.selectCostTb) or not self.selectTargetTb.isStart then
    if not self.isCreateSelectTarget then
        if self.isDragCard and self.world.MixedSystem:IsMouseInBottom() and not self.isBlockCancel then
            self.isComplete = true
            -- self:OperateComplete()
            -- return
        end

        -- 右键取消操作
        if (self.isDragCard or self.isClickDrag) and GameInput.GetMouseButtonUp(1) then
            self.isComplete = true
            -- self:OperateComplete()
        end
    end

    -- 拖出去就使用的情况
    if self.useOnDragEnd and (not self.selectTargetTb or not self.selectTargetTb.isStart) then
        local flag = self.isUseCard and self.canUseCard
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.PlayHandCardEffect, "card_using_action",
            self.args.cardData.id, flag)
        if self.selectTargetTb then
            self.selectTargetTb:PreviewSelectableOptions(flag)
        end

        if flag then
            self:RequestSimulate({})
        end
    end

    if self.isClickDrag and (not self.selectTargetTb or not self.selectTargetTb.isStart) then
        self:OnHandCardDrag()
    end

    if self.isBlockCancel and not self.world.MixedSystem:IsMouseInBottom() then
        self.isBlockCancel = false
    end

    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo, self.args.cardData.id)
    if cardInfo and cardInfo.item then
        local tposeRect = cardInfo.item.tposeTrans.gameObject:GetComponent(RectTransform)
        local disY = tposeRect.anchoredPosition.y - self.beginTposeY
        self.isUseCard = disY >= BattleDefine.DragUseTposeYDis
    end
end

function HandCardOB:OnCreateSelectTarget()
    if not self.isCreateSelectTarget then
        self:CreateSelectTargetTb()
        self:MoveCardOnSelectTarget()
        self.isDragCard = false
    end
end

function HandCardOB:MoveCardOnComplete()
    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end

    local camp = self.world.DataSystem:GetCamp(self.world.DataSystem.roleUid)
    -- local worldPos = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackTopTransform)
    local posInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackExtraPos, 1)
    local worldPos = posInfo.worldPos

    local item = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo, self.args.cardData.id).item
    --
    item:SetState(BattleDefine.CardState.control)
    item:SetAllOrder(BattleDefine.UILayer.battle_max)
    item.colliderTrans.gameObject:SetActive(false)
    item.dontRefreshPos = true


    self.world.HandCardSystem:AddCardStackState(self.args.cardData.id)

    mod.BattleFacade:SendEvent(BattleHandCardView.Event.RefreshAllHandCardPos, BattleDefine.Camp.self, true)
    mod.BattleFacade:SendEvent(BattleStackCardView.Event.RefreshAllCardStackPos)

    self.world.StateSystem:SetEnableOp(false)

    mod.BattleFacade:SendEvent(BattleHandCardView.Event.PlayHandCardEffect, "card_using_action", self.args.cardData.id,
        true)
    Log("移动到堆叠位置, cardId=", self.args.cardData.id)
end

function HandCardOB:MoveCardOnSelectTarget()
    if not self.selectTargetTb or not self.selectTargetTb:IsDrawLine() then
        return
    end

    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end

    local camp = self.world.DataSystem:GetCamp(self.world.DataSystem.roleUid)
    local item = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo, self.args.cardData.id).item
    local index = item.index

    local anim = {}
    anim.tbScaleAnim = ScaleAnim.New(item.tposeTrans, BattleDefine.CardScale.handHover.x , 0.2)
    anim.tbRotationAnim = RotationZAnim.New(item.tposeTrans, 0, 0.2)
    anim.tbMoveAnim = MoveAnchorAnim.New(item.tposeTrans, Vector2(0, 210), 0.2)
    anim.tbAnim = ParallelAnim.New({ anim.tbScaleAnim, anim.tbRotationAnim, anim.tbMoveAnim })

    -- anim.tbAnim:SetComplete(self:ToFunc("MoveComplete"))
    anim.tbAnim:Play()

    self.moveAnim = anim.tbAnim

    --
    local item = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo, self.args.cardData.id).item
    item:SetState(BattleDefine.CardState.control)
    item:SetAllOrder(BattleDefine.UILayer.battle_max)
    item.colliderTrans.gameObject:SetActive(false)
    item.dontRefreshPos = false
    mod.BattleFacade:SendEvent(BattleHandCardView.Event.RefreshAllHandCardPos, BattleDefine.Camp.self, true)
    self.world.StateSystem:SetEnableOp(false)

    mod.BattleFacade:SendEvent(BattleHandCardView.Event.PlayHandCardEffect, "card_using_action",
        self.args.cardData.id, true)

    Log("移动到目标选择位置, cardId=", self.args.cardData.id)
end

function HandCardOB:OnHandCardDrag(touchData)
    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo, self.args.cardData.id)
    if not cardInfo or not cardInfo.item then
        return
    end
    if cardInfo.item:IsState(BattleDefine.CardState.control) then
        return
    end

    local touchPos = TouchManager.Instance:GetPos(-1)
    if touchPos then
        local _, pos = RectTransformUtility.ScreenPointToWorldPointInRectangle(cardInfo.item.tposeTrans.parent, touchPos,
            UIDefine.uiCamera)
        local offset = self.dragOffset or Vector3.zero
        cardInfo.item.tposeTrans.position = Vector3(pos.x + offset.x, pos.y + offset.y, 0)
        cardInfo.item.tposeTrans.localScale = Vector3(BattleDefine.CardScale.handHover.x,
            BattleDefine.CardScale.handHover.y, 1)

        cardInfo.item.dontRefreshPos = true
        EventManager.Instance:SendEvent(EventDefine.start_drag_card)
        self.isDragCard = true
    end
end

function HandCardOB:OnHandCardCancel(touchData, args)
    -- if not self.isUseCard then
    --     self.isComplete = true
    --     -- self:OperateComplete()
    --     return
    -- end

    -- 拖出去就使用的情况（不画线）
    if self.useOnDragEnd then
        if not self.isUseCard then
            self.isComplete = true
            return
        end

        local conf = Config.Get("card_def", "config", "cardId", self.args.cardData.cardId)
        if conf.targetIds[1] ~= 0 and self.selectTargetTb and not self.selectTargetTb.isStart then
            self.selectTargetTb:Start()
        elseif #conf.targetIds == 1 and conf.targetIds[1] == 0 then
            self:CreateSelectCostTb()
        end

        self:MoveCardOnComplete()
        return
    end

    if not self.canUseCard and self.isUseCard then
        SystemMessage.Show(self.msg)
        AudioManager.Instance:PlayScene("hand_card_1")
        self.isComplete = true
        -- self:OperateComplete()
        return
    end

    -- 点击时间小于0.5秒，进入点击拖拽状态
    -- if Time.time - self.world.MixedSystem.clickCardTime < 0.5 and not self.isDragCard then
    if Time.time - self.world.MixedSystem.clickCardTime < 0.5 then
        -- self.isDragCard = false
        self.isClickDrag = true
        return
    end

    --

    if self.isDragCard and not self.selectTargetTb and not self.selectCostTb then
        self.isComplete = true
    end

    self.isHold = false
end

-- 选择流程
function HandCardOB:CreateSelectTargetTb()
    if self.isCreateSelectTarget then
        return
    end

    Log("创建目标选择, cardId=", self.args.cardData.id, ", frame = ", Time.frameCount)
    local conf = Config.Get("card_def", "config", "cardId", self.args.cardData.cardId)
    -- 支持多次选择目标
    local selInfos = {}
    for _, targetId in ipairs(conf.targetIds) do
        local targetInfo = {}
        targetInfo.targetId = targetId
        targetInfo.effectId = conf.effectId
        table.insert(selInfos, targetInfo)
    end

    local args = {}
    args.roleUid = self.world.DataSystem.roleUid
    args.srcUid = self.world.DataSystem.roleUid
    args.selInfos = selInfos
    args.canCancel = true
    args.autoConfirm = self.world.MixedSystem:CheckCardAutoConfirm(conf.cardId)
    args.kvData = {}
    args.kvData.fromArea = BattleDefine.CardAreaDef.cardLine
    -- 保证监听的PointerId是正确的
    args.kvData.pointerId = self.pointerId
    -- 区分手牌操作的选择和服务器通知的选择，表现不同
    args.kvData.isHandOB = true
    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo, self.args.cardData.id)
    args.kvData.srcNode = cardInfo.item.topNode
    args.kvData.isClickDrag = self.isClickDrag
    if conf.tagMap[BattleDefine.CardTagType.drone_device] then
        args.kvData.droneId = self.args.cardData.cardId
    elseif conf.tagMap[BattleDefine.CardTagType.hero] then
        args.kvData.heroId = self.args.cardData.cardId
    end
    args.kvData.useLatestData = true

    args.baseInfo = self.args.cardData

    local timelineBehavior = SelectTargetTB.New()
    timelineBehavior:SetWorld(self.world)
    timelineBehavior:SetUid(self.world:GetUid(SECBBehaviorComponent))
    timelineBehavior:SetArgs(args)
    timelineBehavior:SetComplete(self:ToFunc("OnSelectTargetTbDone"))
    timelineBehavior:SetOnTargetChange(self:ToFunc("OnTargetSelecting"))
    timelineBehavior:Init()

    if timelineBehavior:IsDrawLine() then
        self.useOnDragEnd = false
        timelineBehavior:Start()
    else
        timelineBehavior:NotifyTargetChange()
        self.useOnDragEnd = true
    end

    self.selectTargetTb = timelineBehavior
    self.isCreateSelectTarget = true
end

function HandCardOB:OnSelectTargetTbDone(_, selectResult)
    -- 取消选择
    local isCancel = selectResult.isCancel
    local isCanSelect = selectResult.isCanSelect
    if not isCanSelect or isCancel then
        self.isComplete = true
        return
    end

    self.targetSelectData = selectResult.data or {}
    self.selectTargetEnd = true

    LogTable("目标选择完成数据", selectResult.data)

    if self.selectTargetTb then
        self.selectTargetTb:Delete()
        self.selectTargetTb = nil
    end

    self:CreateSelectCostTb()
end

-- 目标选择中的回调（模拟请求与防重复由 SimulateSystem 内部处理）
function HandCardOB:OnTargetSelecting(currentTargets)
    if not self.selectTargetTb then
        return
    end
    if not currentTargets or #currentTargets == 0 then
        self.world.SimulateSystem:ClearPreview()
        return
    end
    self:RequestSimulate(currentTargets)
end

function HandCardOB:CreateSelectCostTb()
    self:MoveCardOnComplete()
    Log("创建消耗选择, cardId=", self.args.cardData.id)
    local conf = Config.Get("card_def", "config", "cardId", self.args.cardData.cardId)

    local _, cost = self.world.MixedSystem:GetCardCost(self.args.cardData)

    local args = {}
    args.roleUid = self.world.DataSystem.roleUid
    args.kvData = {}
    args.kvData.fromArea = BattleDefine.CardAreaDef.stack
    args.baseInfo = self.args.cardData

    args.cost = cost
    args.autoConfirm = self.world.MixedSystem:CheckCardAutoConfirm(conf.cardId)

    local timelineBehavior = CostSelectTB.New()
    timelineBehavior:SetWorld(self.world)
    timelineBehavior:SetUid(self.world:GetUid(SECBBehaviorComponent))
    timelineBehavior:SetArgs(args)
    timelineBehavior:SetComplete(self:ToFunc("CostSelectDone"))

    self.selectCostTb = timelineBehavior
    self.selectCostTb:Start()

    EventManager.Instance:SendEvent(EventDefine.ready_use_card)
end

function HandCardOB:CostSelectDone(_, selectResult)
    -- Log("消耗选择完成", tostring(selectResult.isCancel), tostring(selectResult.selectIndex))

    if self.selectCostTb then
        self.selectCostTb:Delete()
        self.selectCostTb = nil
    end

    -- 取消选择
    if selectResult.isCancel then
        self.isComplete = true
        -- self:OperateComplete()
        return
    end
    self.selectCostEnd = true
    LogTable("消耗选择完成数据", selectResult.data)

    self.costSelectData = selectResult.data or {}
    self:SelectComplete()
    -- self.isComplete = true
end

-- 目标和消耗选择完成
function HandCardOB:SelectComplete()
    local finalTargets = {}
    for _, data in ipairs(self.targetSelectData) do
        if data.targetId then
            table.insert(finalTargets, data)
        end
    end

    for _, data in ipairs(self.costSelectData) do
        if data.targetId then
            table.insert(finalTargets, data)
        end
    end

    if #finalTargets == 0 then
        finalTargets = nil
    end

    self.finalTargets = finalTargets

    -- 已提前发送过（autoConfirm 无目标卡提前发请求）则跳过
    if self.isCompleteUse then
        self.isComplete = true
        return
    end

    -- self:RemoveTimelineBehavior()

    -- self.sendTimer = self.world.TimerSystem:AddTimer(1, BattleDefine.ShowTime.MoveToStackTime, self:ToFunc("SendUseCardMsg"))
    
    local entitys = self.world.DroneDeviceSystem:GetAllDeviceEntitys()
    for _, entity in ipairs(entitys) do
        if entity and entity.DynamicEffectComponent then
            entity.DynamicEffectComponent:PlayPreviewDeathEffect()
        end
    end

    self:SendUseCardMsg()
end

-- 往服务器发送使用卡牌的消息
function HandCardOB:SendUseCardMsg()
    mod.BattleFacade:SendEvent(BattleHandCardView.Event.SwitchHandCardState, self.args.cardData.id,
        BattleDefine.CardState.control)

    local data = {}
    data.cardUid = self.args.cardData.id
    data.targets = self.finalTargets
    -- data.targets = {}
    --
    data.costType = 0

    mod.BattleFacade:SendMsg(4004, 1, { {
        key = "handCard",
        val = data
    } })

    -- 发送卡牌使用消息（传包）事件，传递卡牌信息
    EventManager.Instance:SendEvent(EventDefine.send_use_card_msg,
        { cardId = self.args.cardData.cardId, uid = self.args.cardData.id })

    -- 锁屏逻辑已移除，改为事件驱动
    -- mod.GuideProxy.kvData["useCardId"].val = self.args.cardData.cardId
    -- RunWorld.OperateSystem:SetHasCardOperate(self.args.cardData.id, true)

    self.isCompleteUse = true
    self.isComplete = true
    -- AudioManager.Instance:PlayScene("hand_card_1")
    AudioManager.Instance:PlayUI("use_card_ob_complete")
    -- self.world.PvpHandCardSystem:AddTempStackCardId(self.args.cardData.id)

    local cardInfo = self.args.cardData
    mod.GuideProxy.lastUsedCardInfo = { cardId = cardInfo.cardId, uid = cardInfo.id }
end

-- 请求模拟预览（仅校验配置并转发给 SimulateSystem，不缓存任何模拟状态）
function HandCardOB:RequestSimulate(targets)
    local conf = Config.Get("card_def", "config", "cardId", self.args.cardData.cardId)
    if not conf or not conf.targetIds or #conf.targetIds == 0 then
        return
    end
    if not targets then
        targets = {}
    end
    if #targets == 0 and conf.targetIds[1] ~= 0 then
        return
    end
    self.world.SimulateSystem:RequestPreview(self.args.cardData.id, targets, 100)
end
