ClickDeviceOB = BaseClass("ClickDeviceOB",OperateBehaviorBase)

function ClickDeviceOB:__Init()
    self.costBehavior = nil
    self.selectBehavior = nil
    self.beginPos = nil
    self.conf = nil
    self.selectIndex = nil
    self.sendInfo = {}

    -- 如果在extraCost中触发了的选择，在targetIds中就不需要选择了
    self.selectedMap = {}
end

function ClickDeviceOB:__Delete()
    self:RemoveTimelineBehavior()
    self:RemoveListen()
    
    EventManager.Instance:RemoveEvent(EventDefine.on_app_focus, self:ToFunc("OnAppFocus"))
    -- mod.BattleFacade:SendEvent(PvpMainDetailCardView.Event.HideCardDetail)
end

function ClickDeviceOB:RemoveListen()
    if self.moveListenId then
        TouchManager.Instance:RemoveListen(self.moveListenId)
        self.moveListenId = nil
    end

    if self.cancelListenId then
        TouchManager.Instance:RemoveListen(self.cancelListenId)
        self.cancelListenId = nil
    end
end

function ClickDeviceOB:OnStart()
    LogTable("启动点击设备操作了",self.args)

    mod.BattleFacade:SendEvent(BattleSlotItem.Event.HideSlotDetailView)

    self:OnUseDevice()
    self:OnDeviceClick()
    -- local eventParam = {}
    -- self:AddEvent(BattleEvent.hook_device_click,self:ToFunc("OnDeviceClick"),eventParam)

    EventManager.Instance:AddEvent(EventDefine.on_app_focus, self:ToFunc("OnAppFocus"))

    local eventData = self.args.eventData
    self.beginPos = eventData.position
    self.pointerId = eventData.pointerId

    -- self.needSelectTarget = self.world.PluginSystem.CheckUse:CheckDeviceHandleSelect(self.sendInfo.skillId) 
    -- if self.needSelectTarget then
    --     self.moveListenId = TouchManager.Instance:AddListen(TouchDefine.TouchEvent.move,self:ToFunc("OnDeviceDrag"),self.pointerId)
    -- else
    --     self.cancelListenId = TouchManager.Instance:AddListen(TouchDefine.TouchEvent.cancel,self:ToFunc("OnDeviceCancel"),self.pointerId)
    -- end
end

function ClickDeviceOB:OnDeviceCancel(touchData)
    if Vector2.Distance(self.beginPos, touchData.pos) > 15 then
        self:OperateComplete()
        return
    end
    -- local disY = math.abs(self.beginPos.y - touchData.pos.y)
    -- if self.isDrag and (disY >= BattleDefine.DragUseDis) then

-- end
end

function ClickDeviceOB:ShowCardDetail()
end

function ClickDeviceOB:OnAppFocus(flag)
    -- self:RemoveTimelineBehavior()
    
    -- self:OperateComplete()
    -- self:OnCancel()
end
function ClickDeviceOB:OnDeviceDrag(touchData)
     local disY = math.abs(self.beginPos.y - touchData.pos.y)
    --or disX >= BattleDefine.DragUseDis
    if not self.isDrag and (disY >= BattleDefine.DragUseDis) then
        self.isDrag = true
        self:CreateSelectTargetTb(false)
    end

end

function ClickDeviceOB:OnDeviceClick()
    if not self.isDrag then
        self:RemoveListen()
        self:CreateSelectTargetTb(true)
    end
end


function ClickDeviceOB:CreateSelectTargetTb(isClick)
    --self:ShowCardDetail()
   

    
    local flag,msg,skillInfos = self.world.PluginSystem.CheckUse:CheckDevice(self.args.slotData)
    if not flag then
        SystemMessage.Show(msg)
        AudioManager.Instance:PlayUI("invalid_click_1")
        self:OperateComplete()
        return
    end



    
    local skillConf = Config.Get("battle_skill_def","config","skillId",self.sendInfo.skillId)
    if not skillConf then
        LogError("技能配置不存在",self.sendInfo.skillId)
        return
    end
    -- 判断是否需要选择目标
    if not (#skillConf.targetIds == 1 and skillConf.targetIds[1] == 0) then
        local selInfos = {}
        for _, targetId in ipairs(skillConf.targetIds) do
            if not self.selectedMap[targetId] then
                local targetInfo = {}
                targetInfo.targetId = targetId
                targetInfo.effectId = nil
                table.insert(selInfos, targetInfo)
            end
        end

        local args = {}
        args.roleUid = self.world.DataSystem.roleUid
        args.srcUid = self.world.DataSystem.roleUid
        args.selInfos = selInfos
        args.canCancel = true
        -- args.autoConfirm = self.world.MixedSystem:CheckSkillAutoConfirm(self.sendInfo.skillId)
        args.kvData = {}
        args.kvData.fromArea = BattleDefine.CardAreaDef.equip
        args.kvData.isClick = isClick
        args.baseInfo = self.args.slotData
    
        local timelineBehavior = SelectTargetTB.New()
        timelineBehavior:SetWorld(self.world)
        timelineBehavior:SetUid(self.world:GetUid(SECBBehaviorComponent))
        timelineBehavior:SetArgs(args)
        timelineBehavior:SetComplete(self:ToFunc("OnSelectTargetDone"))
        timelineBehavior:Init()
        self.selectBehavior = timelineBehavior
    
        timelineBehavior:Start()
    else
        self:OnCreateCostSelectTb()
    end
end

function ClickDeviceOB:OnSelectTargetDone(_,selectResult)
    self.sendInfo.targetData = selectResult.data
    if selectResult.isCancel then
        self:OperateComplete()
        return
    end
    self:OnCreateCostSelectTb()
end

function ClickDeviceOB:OnUseDevice()
    if not self.world.StateSystem.enableOp then
        self:OperateComplete()
        return
    end

    if self.args.camp == BattleDefine.Camp.enemy then
        self:OperateComplete()
        return
    end

    local slotData = self.args.slotData

    -- if self.world.DeviceSystem:ExistWaitUseDevice(slotData.cardInfo.id) then
    --     local useInfo = self.world.DeviceSystem:GetWaitUseDeviceInfo(slotData.cardInfo.id)

    --     local selfRoleUid = self.world.DataSystem.roleUid
    --     local targetRoleUid = useInfo.targetData[1].playerUids[1]

       
    --     self.world.DeviceSystem:RemoveWaitUseDeviceInfo(slotData.cardInfo.id)

    --     local skillConf = Config.Get("battle_skill_def","config","skillId",useInfo.skillId)

    --     local costArgs = {}
    --     costArgs.selectIndex = useInfo.costIndex
    --     costArgs.selectData = useInfo.costData
    --     costArgs.isCancel = true


    --     -- mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.ActiveAtkLine,selfRoleUid,selfRoleUid,targetRoleUid,slotData,false,BattleDefine.UILayer.preview_attack_line)

    --     local costEnergy,cost = self.world.MixedSystem:GetSkillCost(useInfo.deviceInfo,skillConf)
    --     self.world.PluginSystem.CheckConsume:ConfVirtualConsume(costEnergy,{},skillConf.optionCostEffect,costArgs)
    --     --self.world.PluginSystem.CheckConsume:ConfVirtualConsume(costEnergy,cost,skillConf.optionCostEffect,costArgs)

    --     mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.ActiveCanAttackDeviceLayer,self.args.roleUid,self.args.carrierUid,self.args.slotData,true)
    --     -- mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.ActiveSlotCanAttack,self.args.roleUid,self.args.carrierUid,self.args.slotData,true)
    --     -- mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.RefreshSlotState,self.args.roleUid,self.args.carrierUid,self.args.slotData)

    --     mod.BattleFacade:SendEvent(PvpStateView.Event.RefreshState)

    --     self:OperateComplete()
    --     return
    -- end


    local flag,msg,skillInfos = self.world.PluginSystem.CheckUse:CheckDevice(slotData)
    SystemMessage.Show(msg)
    if not flag then
        -- SystemMessage.Show(msg)
        AudioManager.Instance:PlayUI("invalid_click_1")
        self:OperateComplete()
        return
    end

    -- if slotData.type ~= KvData.DeviceType.mode then
        -- AudioManager.Instance:PlayScene("switch_mode")
        AudioManager.Instance:PlayUI("click_1")
    -- end

    self.sendInfo.deviceInfo = slotData

    if #skillInfos > 1 then
        -- local args = {}
        -- args.skill = skillInfos
        -- args.canClose = true
        -- args.onCancelClick = self:ToFunc("OnCancel")
        -- args.onConfirmClick = self:ToFunc("OnClickConfirm")
        -- args.data = slotData
        -- args.minNum = 1
        -- args.maxNum = 1
        -- ViewManager.Instance:OpenWindow(PvpSkillSelectWindow,args)

        LogError(string.format("cardId 有多个技能，暂无多异能选择流程，cardId:%s",slotData.cardInfo.id))
    else
        -- 如果这个阶段只能做出一种选择，那么就自动选择
        --TODO 目前都是自动选择，根据skillId确定选择信息
        self:OnClickConfirm(skillInfos)
    end
end


function ClickDeviceOB:OnClickConfirm(selectedSkill)
    local roleUid = self.world.DataSystem.roleUid
    self.selectedSkill = selectedSkill
    local skill = selectedSkill[1].info
    self.selectIndex = selectedSkill[1].index

    self.sendInfo.skillId = skill.skillId
    self.sendInfo.skillUid = skill.id
end

function ClickDeviceOB:OnCreateCostSelectTb()
    local skill = self.selectedSkill[1].info
    local conf = Config.Get("battle_skill_def","config","skillId",skill.skillId)

    local args = {}
    args.roleUid = self.args.roleUid
    args.kvData = {}

    args.kvData.fromArea = BattleDefine.CardAreaDef.equip

    args.cost = conf.extraCost
    args.baseInfo =  self.args.slotData

    args.autoConfirm = self.world.MixedSystem:CheckSkillAutoConfirm(self.sendInfo.skillId)

    local timelineBehavior = CostSelectTB.New()
    timelineBehavior:SetWorld(self.world)
    timelineBehavior:SetUid(self.world:GetUid(SECBBehaviorComponent))
    timelineBehavior:SetArgs(args)
    timelineBehavior:SetComplete(self:ToFunc("CostSelectDone"))
    
    self.costBehavior = timelineBehavior
    self.costBehavior:Start()
end

function ClickDeviceOB:CostSelectDone(_,selectResult)
    if self.costBehavior then
        self.costBehavior:Delete()
        self.costBehavior = nil
    end
    

    if selectResult.isCancel then
        self:OperateComplete()
    else
        for _, v in ipairs(selectResult.data) do
            self.selectedMap[v.targetId] = true
        end

        self.sendInfo.costData = selectResult.data
        self.sendInfo.costIndex = selectResult.selectIndex or 0

        -- local skillConf = Config.Get("battle_skill_def","config","skillId",self.sendInfo.skillId)

        -- 判断是否需要选择目标
        -- if not (#skillConf.targetIds == 1 and skillConf.targetIds[1] == 0) then
        --     local selInfos = {}
        --     for _, targetId in ipairs(skillConf.targetIds) do
        --         if not self.selectedMap[targetId] then
        --             local targetInfo = {}
        --             targetInfo.targetId = targetId
        --             targetInfo.effectId = nil
        --             table.insert(selInfos, targetInfo)
        --         end
        --     end

        --     if #selInfos > 0 then
        --         local args = {}
        --         args.roleUid = self.world.DataSystem.roleUid
        --         args.srcUid = self.world.DataSystem.roleUid
        --         args.selInfos = selInfos
        --         args.canCancel = true
        --         args.autoConfirm = self.world.MixedSystem:CheckSkillAutoConfirm(self.sendInfo.skillId)
        --         args.kvData = {}
        --         args.kvData.fromArea = BattleDefine.CardAreaDef.equip
        --         args.baseInfo = self.args.slotData
    
        --         local timelineBehavior = SelectTargetTB.New()
        --         timelineBehavior:SetWorld(self.world)
        --         timelineBehavior:SetUid(self.world:GetUid(SECBBehaviorComponent))
        --         timelineBehavior:SetArgs(args)
        --         timelineBehavior:SetComplete(self:ToFunc("TargetSelectDone"))
        --         timelineBehavior:Init()
        --         self.selectBehavior = timelineBehavior

        --         timelineBehavior:Start()
        --     else
        --         self:DeviceUseDone()
        --     end
        -- else
        --     self:DeviceUseDone()
        -- end
        self:DeviceUseDone()
    end
end

--选择完调用senduse
-- function ClickDeviceOB:TargetSelectDone(_,selectResult)
--     self.sendInfo.targetData = selectResult.data
--     if selectResult.isCancel then
--         self:OperateComplete()
--         return
--     end
--     self:DeviceUseDone()
-- end

function ClickDeviceOB:OnCancel()
    self:OperateComplete()
end

function ClickDeviceOB:DeviceUseDone()
    -- local skillConf = Config.Get("battle_skill_def","config","skillId",self.sendInfo.skillId)
    -- local costArgs = {}
    -- costArgs.selectIndex = self.sendInfo.costIndex
    -- costArgs.selectData = self.sendInfo.costData
    -- costArgs.isCancel = false

    --    
    -- self.world.DeviceSystem:AddWaitUseDeviceInfo(self.sendInfo)

    --local selfRoleUid = self.world.DataSystem.roleUid

    -- self.world.DeviceSystem:SendAllDeviceUsages(false)

    -- self.world.DeviceSystem:ClearWaitUseDeviceInfo()

    local data = {}
    data.equipUid = self.sendInfo.deviceInfo.id
    data.skillUid = self.sendInfo.skillUid
    data.skillId = self.sendInfo.skillId
    data.costType = self.sendInfo.costIndex

    -- 合并
    local finalTargets = {}
    local targetData = self.sendInfo.targetData or {}
    for _, data in ipairs(targetData) do
        table.insert(finalTargets, data)
    end

    local costData = self.sendInfo.costData or {}
    for _, data in ipairs(costData) do
        table.insert(finalTargets, data)
    end
    data.targets = finalTargets

    mod.BattleFacade:SendMsg(4004, 3, { { key = "equipUse", val = data } })
    -- RunWorld.OperateSystem:SetHasCardOperate(self.sendInfo.deviceInfo.cardInfo.id,true)

    mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.RefreshSlotEnable,self.args.roleUid,self.args.carrierUid,self.args.slotData)
    mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.ActiveSlotUsedEffect,self.args.roleUid,self.args.carrierUid,self.args.slotData)


    self:OperateComplete()
end

function ClickDeviceOB:RemoveTimelineBehavior()
    if self.costBehavior then
        self.costBehavior:Delete()
        self.costBehavior = nil
    end
    if self.selectBehavior then
        self.selectBehavior:Delete()
        self.selectBehavior = nil
    end
end

function ClickDeviceOB:OnUpdate(deltaTime)
    if self.costBehavior then
        self.costBehavior:Update(deltaTime)
    end

    if self.selectBehavior then
        self.selectBehavior:Update(deltaTime)
    end
end
