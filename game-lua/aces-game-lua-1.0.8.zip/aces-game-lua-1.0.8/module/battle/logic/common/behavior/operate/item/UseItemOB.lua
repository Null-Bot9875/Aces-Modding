UseItemOB = BaseClass("UseItemOB", OperateBehaviorBase)

function UseItemOB:__Init()
    -- 状态标志
    self.isComplete = false
    self.isCompleteUse = false
    self.isUseCard = false
    self.isDragCard = false
    self.isClickDrag = false
    self.selectOnDragEnd = false
    self.isBlockCancel = false
    self.isMoveStack = false
    self.isMoveOnSelect = false
    self.dontSelectTarget = false
    self.hasCreateSelectTarget = false

    -- 计时器和监听器
    self.moveListenId = nil
    self.cancelListenId = nil
    self.sendTimer = nil

    -- 数据存储
    self.pointerId = nil
    self.beginPos = nil
    self.clickCardTime = nil
    self.selectTargetTb = nil
    self.initParent = nil
    self.targetSelectData = nil
    self.finalTargets = nil
    
    -- 常量定义
    self.moveduration = 0.2 -- 移动动画持续时间
    self.clicktimethreshold = 0.5 -- 点击时间阈值
end

function UseItemOB:__Delete()
    self:CleanupSelectTarget()
    self:RemoveEvent()
    self:ResetItemState()
    self:CleanupTimer()
    -- 道具使用完成后清理该道具的模拟缓存与预览（与 HandCardOB 一致，按 id 清理）
    if self.isCompleteUse and self.world and self.world.SimulateSystem then
        self.world.SimulateSystem:ClearSimulateCache(self.args.id)
    end
    if self.world and self.world.SimulateSystem then
        self.world.SimulateSystem:ClearPreview()
    end
end

function UseItemOB:CleanupSelectTarget()
    if self.selectTargetTb then
        self.selectTargetTb:Delete()
        self.selectTargetTb = nil
    end
end

function UseItemOB:ResetItemState()
    local item = mod.BattleFacade:SendEvent(BattleBattleItemView.Event.GetBattleItemObj, self.args.id)
    if self.isCompleteUse then
        item.isUsed = true
    else
        item.gameObject.transform:DOKill()
        item.tposeTrans:DOKill()
        item.gameObject.transform:DOScale(Vector3.one, self.moveduration)
        item.tposeTrans:DOScale(Vector3.one * self.cardscale, self.moveduration)
        item.tposeTrans:DOAnchorPos(Vector2(0, self.cardposy), self.moveduration)
    
        item:SetCanUse(false)
        item.isUsed = false
    
        if self.initParent then
            item.transform:SetParent(self.initParent)
        end
    end

    -- mod.BattleFacade:SendEvent(BattleBattleItemView.Event.ActiveExpandGroup, true)
    mod.BattleFacade:SendEvent(BattleBattleItemView.Event.ResetBattleItemOrder)
    mod.BattleFacade:SendEvent(BattleBattleItemView.Event.RefreshBattleItemPos,true)
end

function UseItemOB:CleanupTimer()
    if self.sendTimer then
        self.world.TimerSystem:RemoveTimer(self.sendTimer)
        self.sendTimer = nil
    end
end

function UseItemOB:AddEvent()
    self.moveListenId = TouchManager.Instance:AddListen(TouchDefine.TouchEvent.move, self:ToFunc("OnItemDrag"), self.pointerId)
    self.cancelListenId = TouchManager.Instance:AddListen(TouchDefine.TouchEvent.cancel, self:ToFunc("OnItemDragCancel"), self.pointerId)
    EventManager.Instance:AddEvent(EventDefine.on_app_focus, self:ToFunc("OnAppFocus"))
end

function UseItemOB:RemoveEvent()
    if self.moveListenId then
        TouchManager.Instance:RemoveListen(self.moveListenId)
        self.moveListenId = nil
    end

    if self.cancelListenId then
        TouchManager.Instance:RemoveListen(self.cancelListenId)
        self.cancelListenId = nil
    end

    EventManager.Instance:RemoveEvent(EventDefine.on_app_focus, self:ToFunc("OnAppFocus"))
end

function UseItemOB:OnStart()
    Log("启动使用道具操作")
    -- 道具使用开始时清理模拟预览，避免与后续战术牌预览叠加导致血量/颜色错误
    if self.world and self.world.SimulateSystem then
        self.world.SimulateSystem:ClearAllSimulateCache()
        self.world.SimulateSystem:ClearPreview()
    end
    self:AddEvent()
    self:InitializeStartState()
end

function UseItemOB:InitializeStartState()
    self.beginPos = self.args.eventData.position
    self.pointerId = self.args.eventData.pointerId
    self.clickCardTime = Time.time

    if self.world.MixedSystem:IsMouseInBottom() then
        self.isBlockCancel = true
    end

    local item = mod.BattleFacade:SendEvent(BattleBattleItemView.Event.GetBattleItemObj, self.args.id)
    item:SetOrder(BattleDefine.UILayer.battle_max)
    item.isUsed = true
    self.initParent = item.transform.parent

    local tmpParent = mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.GetStackParent)
    item.transform:SetParent(tmpParent)
    
    -- 依赖item的常量，保持不变
    self.cardscale = item.tposeInitScale
    self.cardposy = item.tposeInitPos.y
    -- 记录拖拽开始时 tpose 的世界坐标 Y，用于判断是否“拖出使用”（避免视口坐标不一致）
    local tposeRect = item.tposeTrans.gameObject:GetComponent(RectTransform)
    self.beginTposeY = tposeRect.anchoredPosition.y
    -- 记录道具 tpose 相对触摸点的世界坐标偏移，防止拖拽时道具跳位（粘滞感）
    local beginTouchPos = self.args.eventData.position
    local _, beginWorldPos = RectTransformUtility.ScreenPointToWorldPointInRectangle(
        item.tposeTrans.parent, beginTouchPos, UIDefine.uiCamera)
    local itemWorldPos = item.tposeTrans.position
    self.dragOffset = Vector3(itemWorldPos.x - beginWorldPos.x, itemWorldPos.y - beginWorldPos.y, 0)end

function UseItemOB:OnUpdate(deltaTime)
    local isPlayerInputBlocked = GameInput.IsBlocked()
    if self.selectTargetTb and not isPlayerInputBlocked then
        self.selectTargetTb:Update(deltaTime)
    end

    if self.isComplete then
        self:OperateComplete()
        return
    end

    if isPlayerInputBlocked then
        return
    end

    self:HandleUseCardState()
    self:HandleDragState()
    self:UpdateUseCardState()
end

function UseItemOB:HandleUseCardState()
    if self.isUseCard and not self.hasCreateSelectTarget then
        self.hasCreateSelectTarget = true
        self:OnCreateSelectTarget()
    end

    if self.dontSelectTarget then
        local item = mod.BattleFacade:SendEvent(BattleBattleItemView.Event.GetBattleItemObj, self.args.id)
        local flag = self.isUseCard and not self.isMoveStack
        item:SetCanUse(flag)
    end
end

function UseItemOB:HandleDragState()
    if not self.selectTargetTb or not self.selectTargetTb.isStart then
        if self:ShouldCancelOperation() then
            self.isComplete = true
        end
    end

    if self.isClickDrag and (not self.selectTargetTb or not self.selectTargetTb.isStart) then
        self:OnItemDrag()
    end

    if self.isBlockCancel and not self.world.MixedSystem:IsMouseInBottom() then
        self.isBlockCancel = false
    end
end

function UseItemOB:ShouldCancelOperation()
    return (self.isDragCard and self.world.MixedSystem:IsMouseInBottom() and not self.isBlockCancel) or
           GameInput.GetMouseButtonUp(1) or
           (not self.isDragCard and self.world.MixedSystem:IsMouseInBottom())
end

function UseItemOB:UpdateUseCardState()
    local item = mod.BattleFacade:SendEvent(BattleBattleItemView.Event.GetBattleItemObj, self.args.id)
    local tposeRect = item.tposeTrans.gameObject:GetComponent(RectTransform)
    local disY = tposeRect.anchoredPosition.y - self.beginTposeY
    self.isUseCard = disY >= BattleDefine.DragUseTposeYDis
end

function UseItemOB:OnSelectTargetTbDone(_, selectResult)
    self:CleanupSelectTarget()

    if not self:ValidateSelectResult(selectResult) then
        return
    end

    self:ProcessSelectResult(selectResult)
end

-- 目标选择中的回调：道具参与模拟，与手牌一致请求预览
function UseItemOB:OnItemTargetSelecting(currentTargets)
    if not self.selectTargetTb then
        return
    end
    if not currentTargets or #currentTargets == 0 then
        if self.world and self.world.SimulateSystem then
            self.world.SimulateSystem:ClearPreview()
        end
        return
    end
    self:RequestItemSimulate(currentTargets)
end

-- 请求道具使用模拟预览（校验配置后转发给 SimulateSystem）
function UseItemOB:RequestItemSimulate(targets)
    if not self.world or not self.world.SimulateSystem then
        return
    end
    local conf = Config.Get("battle_item_def", "config", "id", self.args.itemId)
    if not conf or not conf.useSkillId or conf.useSkillId == 0 then
        return
    end
    local skillConf = Config.Get("battle_skill_def", "config", "skillId", conf.useSkillId)
    if not skillConf or not skillConf.targetIds or #skillConf.targetIds == 0 then
        return
    end
    if not targets then
        targets = {}
    end
    if #targets == 0 and skillConf.targetIds[1] ~= 0 then
        return
    end
    self.world.SimulateSystem:RequestPreview(self.args.id, targets, 100, true)
end

function UseItemOB:ValidateSelectResult(selectResult)
    if not selectResult.isCanSelect or selectResult.isCancel then
        EventManager.Instance:SendEvent(EventDefine.cancel_use_item)
        self.isComplete = true
        return false
    end
    return true
end

function UseItemOB:ProcessSelectResult(selectResult)
    LogTable("目标选择完成数据", selectResult.data)
    self.targetSelectData = selectResult.data or {}
    local finalTargets = {}
    for _, data in ipairs(self.targetSelectData) do
        table.insert(finalTargets, data)
    end
    self.finalTargets = finalTargets
    self:MoveCardOnComplete()
end

function UseItemOB:OnCreateSelectTarget()
    if not self.selectTargetTb then
        self:CreateSelectTargetTb()
        self:MoveCardOnSelectTarget()
        self.isDragCard = false
    end
end

function UseItemOB:MoveCardOnSelectTarget()
    if self.selectOnDragEnd or self.dontSelectTarget then
        return
    end

    local item = mod.BattleFacade:SendEvent(BattleBattleItemView.Event.GetBattleItemObj, self.args.id)
    item.tposeTrans:DOKill()
    item.tposeTrans:DOAnchorPos(Vector2(0, self.cardposy), self.moveduration)
    item.tposeTrans:DOScale(Vector3.one * self.cardscale, self.moveduration)
    item:SetCanUse(self.isUseCard)

    self.isMoveOnSelect = true
    Log("移动到目标选择位置")
end

function UseItemOB:MoveCardOnComplete()
    local worldPos = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackTopTransform)
    local item = mod.BattleFacade:SendEvent(BattleBattleItemView.Event.GetBattleItemObj, self.args.id)
    
    item.tposeTrans:DOKill()
    item.tposeTrans:DOMove(worldPos, BattleDefine.ShowTime.MoveToStackTime)
    item.tposeTrans:DOScale(Vector3.one * BattleDefine.CardScale.stack.x, self.moveduration)

    self.isMoveStack = true
    Log("移动到堆叠位置")
    self.sendTimer = self.world.TimerSystem:AddTimer(1, BattleDefine.ShowTime.MoveToStackTime, self:ToFunc("SendUseItemMsg"))
end

function UseItemOB:CreateSelectTargetTb()
    local conf = Config.Get("battle_item_def", "config", "id", self.args.itemId)
    local skillId = conf.useSkillId
    if skillId == 0 then
        LogError("道具没有配置技能")
        self.isComplete = true
        return
    end

    local selInfos = self:GetSelectInfos(skillId)
    if not selInfos then
        return
    end

    self:InitializeSelectTarget(selInfos)
end

function UseItemOB:GetSelectInfos(skillId)
    local skillConf = Config.Get("battle_skill_def", "config", "skillId", skillId)
    if not skillConf then
        LogError("技能配置不存在: " .. skillId)
        self.isComplete = true
        return nil
    end

    local selInfos = {}
    for _, targetId in ipairs(skillConf.targetIds) do
        table.insert(selInfos, { targetId = targetId })
    end

    if #selInfos == 0 or (#selInfos == 1 and selInfos[1].targetId == 0) then
        self.dontSelectTarget = true
        return nil
    end

    return selInfos
end

function UseItemOB:InitializeSelectTarget(selInfos)
    local args = {
        roleUid = self.world.DataSystem.roleUid,
        srcUid = self.world.DataSystem.roleUid,
        selInfos = selInfos,
        canCancel = true,
        autoConfirm = true,
        kvData = {
            fromArea = BattleDefine.CardAreaDef.cardLine,
            pointerId = self.pointerId,
            isHandOB = true,
            srcNode = mod.BattleFacade:SendEvent(BattleBattleItemView.Event.GetBattleItemObj, self.args.id).gameObject
        },
        baseInfo = { id = self.args.id }
    }

    local timelineBehavior = SelectTargetTB.New()
    timelineBehavior:SetWorld(self.world)
    timelineBehavior:SetUid(self.world:GetUid(SECBBehaviorComponent))
    timelineBehavior:SetArgs(args)
    timelineBehavior:SetComplete(self:ToFunc("OnSelectTargetTbDone"))
    timelineBehavior:SetOnTargetChange(self:ToFunc("OnItemTargetSelecting"))
    timelineBehavior:Init()

    if timelineBehavior:IsDrawLine() then
        self.selectOnDragEnd = false
        timelineBehavior:Start()
    else
        self.selectOnDragEnd = true
    end

    self.selectTargetTb = timelineBehavior
end

function UseItemOB:SendUseItemMsg()
    if self.isCompleteUse then
        return
    end
    self.isCompleteUse = true

    local data = {
        itemUid = self.args.id,
        targets = self.finalTargets
    }

    mod.BattleFacade:SendMsg(4004, 6, { { key = "item", val = data } })
    self.isComplete = true
    AudioManager.Instance:PlayScene("hand_card_1")
end

function UseItemOB:OnItemDrag(touchData)
    if self.isMoveStack or self.isMoveOnSelect then
        return
    end

    local item = mod.BattleFacade:SendEvent(BattleBattleItemView.Event.GetBattleItemObj, self.args.id)
    local touchPos = TouchManager.Instance:GetPos(-1)
    if touchPos then
        local _, pos = RectTransformUtility.ScreenPointToWorldPointInRectangle(item.transform, touchPos, UIDefine.uiCamera)
        local offset = self.dragOffset or Vector3.zero
        item.tposeTrans.position = Vector3(pos.x + offset.x, pos.y + offset.y, 0)
        item.tposeTrans.localScale = Vector3(BattleDefine.CardScale.itemHover.x * self.cardscale, 
            BattleDefine.CardScale.itemHover.y * self.cardscale, 1)
    end

    self.isDragCard = true
end

function UseItemOB:OnItemDragCancel(touchData)
    if self.selectOnDragEnd then
        self:HandleSelectOnDragEnd()
        return
    end

    if self.dontSelectTarget and self.isUseCard then
        self:HandleDontSelectTarget()
        return
    end
    
    if Time.time - self.clickCardTime < self.clicktimethreshold then
        self.isClickDrag = true
        return
    end

    if self.isDragCard and not self.selectTargetTb and not self.dontSelectTarget then
        self.isComplete = true
    end

    if self.dontSelectTarget then
        self:HandleDontSelectTarget()
    end
end

function UseItemOB:HandleSelectOnDragEnd()
    if self.selectTargetTb and self.isUseCard then
        self.selectTargetTb:Start()
    else
        self.isComplete = true
    end
end

function UseItemOB:HandleDontSelectTarget()
    if self.isUseCard then
        self:MoveCardOnComplete()
    else
        self.isComplete = true
    end
end

function UseItemOB:OnCancel()
end

function UseItemOB:OnAppFocus(flag)
    self.isComplete = true
end
