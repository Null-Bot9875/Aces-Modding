ActionTimeline = BaseClass("ActionTimeline",SECBTimeline)
local timelineBehaviors = {}

function ActionTimeline:__Init()
    self.entity = nil
    self.skill = nil
    self.cacheData = {}
end

function ActionTimeline:__Delete()
end

function ActionTimeline:OnInit(entity,actions,args)
    self.entity = entity
    self.actions = actions

    local nodes = {}

    for _, v in ipairs(actions) do
        local class  = _G[v.action.type]
        if not class and TimelineBehaviorIndex.Index[v.action.type] then
            class = _G[TimelineBehaviorIndex.Index[v.action.type].class]
        end

        if not class and TimelineBehaviorIndex.TempIndex[v.action.type] then
            class = _G[TimelineBehaviorIndex.TempIndex[v.action.type].class]
        end


        if not class then
            --assert(false,string.format("创建行为异常，未知的行为类型[行为类型:%s]",tostring(v.action.type)))
            LogError(string.format("创建行为异常，未知的行为类型[行为类型:%s]",tostring(v.action.type)))
        else
            local node = {}
            local timelineBehavior = class.New()
            local uid = self.world:GetUid(SECBBehaviorComponent)
            timelineBehavior:SetWorld(self.world)
            timelineBehavior:SetEntity(self.entity)
            timelineBehavior:SetUid(uid)
            timelineBehavior:SetExecuteActionTimeline(self)
            timelineBehavior:SetConf(v.action)
            timelineBehavior:SetArgs(v.args or args)
            timelineBehavior:SetHookComplete(self:ToFunc("TimelineBehaviorComplete"))
            node.behavior = timelineBehavior
            node.time = v.action.time
            table.insert(nodes,node)

            timelineBehaviors[uid] = timelineBehavior
        end
    end
    self:SetNodes(nodes)
end

function ActionTimeline:TimelineBehaviorComplete(behavior)
    timelineBehaviors[behavior.uid] = nil
end

function ActionTimeline:Recover()
    for _,v in ipairs(self.nodes) do
        if v.behavior.OnRecover then
            v.behavior:OnRecover()
        end
    end
end

function ActionTimeline.PrintTimelineBehavior()
    local printTimelineBehaviors = {}
    for k,v in pairs(timelineBehaviors) do
        table.insert(printTimelineBehaviors,v.__className)
    end

    Log("运行中的行为:\n" .. table.concat(printTimelineBehaviors, "\n") .. "\n---------------------------------------")
end

function ActionTimeline.ClearDebug()
    timelineBehaviors = {}
end

function ActionTimeline:OnStart()
end

function ActionTimeline:Log(params)
--     Log(params.msg)
end

function ActionTimeline:OnAbort()
end

function ActionTimeline:OnFinish()
end

function ActionTimeline:GetDuration()
    local duration = 0

    for _, v in ipairs(self.actions) do
        if v.action.duration > 0 then
            duration = duration + v.action.duration
        end
    end

    return duration / 1000
end
