TimelineBehaviorBase = BaseClass("TimelineBehaviorBase",SECBBehavior)

function TimelineBehaviorBase:__Init()
    self.conf = nil
    self.args = nil
    self.onComplete = nil
    self.executeActionTimeline = nil
    self.onHookComplete = nil
    self.isStart = false
    self.isComplete = false
    self.durationTimer = nil
end

function TimelineBehaviorBase:__Delete()
    self:RemoveDurationTimer()
    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end
end

function TimelineBehaviorBase:SetExecuteActionTimeline(timeline)
    self.executeActionTimeline = timeline
end

function TimelineBehaviorBase:SetComplete(onComplete)
    self.onComplete = onComplete
end

function TimelineBehaviorBase:SetHookComplete(onComplete)
    self.onHookComplete = onComplete
end

function TimelineBehaviorBase:SetConf(conf)
    self.conf = conf
end

function TimelineBehaviorBase:SetArgs(args)
    self.args = args
end

function TimelineBehaviorBase:Start()
    if not self:CheckCondValid() then
        -- LogTable("条件不满足，行为不执行",self.args)
        self:BehaviorComplete()
        return
    end

    self.isStart = true
    self:OnStart()
    self:TryStartDurationTimer()
end

function TimelineBehaviorBase:CheckCondValid()
    if self.conf and self.conf.checkCond then
        local checkCond = self.conf.checkCond
        local checkArgs = {}
        checkArgs.args = self.args
        checkArgs.conf = self.conf
        local flag = self.world.PluginSystem.CheckTimelineCond:CheckCond(checkCond, checkArgs)
        if not flag then
            return false
        end
    end
    
    return true
end


function TimelineBehaviorBase:BehaviorComplete(...)
    if self.isComplete then
        return
    end
    self.isComplete = true
    self:RemoveDurationTimer()

    if self.onHookComplete then
        self.onHookComplete(self,...)
    end
    if self.onComplete then
        self.onComplete(self,...)
    end
end


--
function TimelineBehaviorBase:OnStart()
end

function TimelineBehaviorBase:TryStartDurationTimer()
    if self.isComplete or not self.conf then
        return
    end

    -- 显式配置 dontUseDuration 时跳过基础超时规则
    if self.conf.dontUseDuration then
        return
    end

    local duration = self.conf.duration
    if not duration or duration <= 0 then
        return
    end

    self:RemoveDurationTimer()
    self.durationTimer = self.world.TimerSystem:AddTimer(1, duration * 0.001, self:ToFunc("OnDurationTimeout"))
    self.durationTimer:SetScale(true)
end

function TimelineBehaviorBase:OnDurationTimeout()
    self.durationTimer = nil
    self:BehaviorComplete()
end

function TimelineBehaviorBase:RemoveDurationTimer()
    if self.durationTimer then
        self.world.TimerSystem:RemoveTimer(self.durationTimer)
        self.durationTimer = nil
    end
end