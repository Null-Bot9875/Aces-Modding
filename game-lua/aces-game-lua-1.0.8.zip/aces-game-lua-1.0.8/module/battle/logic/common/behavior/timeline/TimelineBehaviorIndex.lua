TimelineBehaviorIndex = StaticClass("TimelineBehaviorIndex")

TimelineBehaviorIndex.Index =
{
    [12]    = { class = "DiscardHandCardTB" },         --弃牌
    [13]    = { class = "ShuffleHandCardTB" },         --洗牌
    [18]    = { class = "TokenResultTB" },             --Token变化
    [51]    = { class = "RollDiceTB" },                --扔骰子
    [60]    = { class = "AddStaticSkillTB" },          --添加静态异能
    [61]    = { class = "ReduceStaticSkillTB" },       --减少静态异能TB
    [100]   = { class = "EnergyResultTB" },            --能量变化
    [101]   = { class = "ShieldResultTB" },            --护盾变化
    [102]   = { class = "EnergyMaxResultTB" },         --能量上限变化
    [103]   = { class = "HpResultTB" },                --伤害
    [104]   = { class = "HpMaxResultTB" },             --血量上限变化

    [2001]  = { class = "DeviceBrokenTB" },            --设备破坏
    [2002]  = { class = "DeviceResetTB" },             --设备重置
    [10001] = { class = "PlayMechaAnimTB" },           --机体播放动画
    [10002] = { class = "ShakeScreenTB" },             --震屏
    [10003] = { class = "HitResultTB" },               --命中结算
    [10004] = { class = "CarrierAttackPlayTB" },       --机体攻击播放
    [10005] = { class = "ConsumeResultTB" },           --消耗结算
    [10006] = { class = "PlayAudioTB" },               --播放音效
    [10007] = { class = "PlayDestoryMechaTB" },        --破坏机体
    [10008] = { class = "BuffResultTB" },              --增益表现
    [10009] = { class = "DeBuffResultTB" },            --减益表现
    [10010] = { class = "SwitchModeResultTB" },        --变身表现
    -- [10010] = { class = "CarrierAttackPlayTB" },       --设备攻击播放 现在设备和机体一样
    [10011] = { class = "RemoveDeviceDroneShiledTB" }, --移除机体圣盾特效
    [10012] = { class = "CreateDeviceDroneAttackEffectTB"}, --指定目标播放攻击
    [10013] = { class = "CarrierRemovePlayTB" },      --无人机被摧毁
    [10014] = { class = "ChangeMoneyTB" },            --增加金币
    [10015] = { class = "DeviceSplitTB" },            -- 无人机解体
    [10016] = { class = "DeviceMoveBySplitTB" },      -- 无人机被解体后移动到格子
    [10017] = { class = "SwitchDisplayResultTB" },    --切换表现（换卡：exeunt->switch_entrance）

    [20001] = { class = "NotifyDiscardHandCardTB" },   --通知弃牌

    -- [30001] = { class = "SelectDiscardHandCardTB" }, --选择丢弃手牌

    [40000] = { class = "SelectTargetTB" },      --选择目标
    [40001] = { class = "SelectHandCardTB" },    --选择手牌
    [40002] = { class = "SelectDiscardCardTB" }, --选择弃牌堆
    [40003] = { class = "SelectConsumeCardTB" }, --选择废弃区
    [40004] = { class = "SelectStackCardTB" },   --选择堆叠
    [40005] = { class = "SelectLibraryCardTB" }, --选择牌库
    -- [40006] = { class = "SelectCarrierTB" },         --选择机体
    [40007] = { class = "SelectPlayerTB" },      --选择机师
    [40008] = { class = "SelectDeviceTB" },      --选择设备
    [40009] = { class = "SelectReuseTB" },       --再利用
    [40010] = { class = "SelectSlotTB" },        --选择槽位
    [40011] = { class = "SelectGridTB" },        --选择格子
    [40012] = { class = "SelectDeviceDroneTB" }, -- 选择无人机

    -- multi
    -- [41001] = { class = "SelectGridAndPlayerTB" },        --选择格子和机体
    [41002] = { class = "SelectDeviceDroneAndPlayerTB" }, --选择无人机和机体

    --卡牌移动
    -- equip
    [51001] = { class = "CardMoveEquipToDiscardTB" },
    [51002] = { class = "CardMoveEquipToHandTB" },
    [51003] = { class = "CardMoveEquipToLibraryTB" },
    [51004] = { class = "CardMoveEquipToConsumeTB" },
    -- hand
    [51101] = { class = "CardMoveHandToDiscardTB" },
    [51110] = { class = "CardMoveHandToDiscardBatchTB" }, -- 手牌到弃牌批量
    [51102] = { class = "CardMoveHandToStackTB" },
    [51103] = { class = "CardMoveHandToConsume" },
    [51104] = { class = "CardMoveHandToLibraryTB" },
    -- library
    [51201] = { class = "CardMoveLibraryToHandTB" },
    [51202] = { class = "CardMoveLibraryToNewCardTB" },
    [51203] = { class = "CardMoveLibraryToDiscardTB" },
    [51204] = { class = "CardMoveLibraryToConsumeTB" },
    -- device_drone
    [51301] = { class = "CardMoveDeviceToDiscardTB" },
    [51302] = { class = "CardMoveDeviceToConsumeTB" },
    [51303] = { class = "CardMoveDeviceToLibraryTB" },
    [51304] = { class = "CardMoveDeviceToHandTB" },
    -- stack
    [51401] = { class = "CardMoveStackToDiscardTB" },
    [51402] = { class = "CardMoveStackToEquipTB" },
    [51403] = { class = "CardMoveStackToHandTB" },
    [51404] = { class = "CardMoveStackToConsumeTB" },
    [51405] = { class = "CardMoveStackToBattlefiledTB" },
    [51406] = { class = "CardMoveStackToDeviceDroneTB" },
    -- discard
    [51501] = { class = "CardMoveDiscardToHandTB" },
    [51502] = { class = "CardMoveDiscardToLibraryTB" },
    [51503] = { class = "CardMoveDiscardToStackTB" },
    [51504] = { class = "CardMoveDiscardToConsume" },
    [51505] = { class = "CardMoveDiscardToDeviceDroneTB" },
    -- newCard
    [51601] = { class = "CardMoveNewCardToHandTB" },
    [51602] = { class = "CardMoveNewCardToShuffleTB" },
    -- shuffle
    [51701] = { class = "CardMoveShuffleToLibraryTB" },
    -- consume
    [51801] = { class = "CardMoveConsumeToStackTB" },
    [51802] = { class = "CardMoveConsumeToDeviceDroneTB" },
    -- none
    [51901] = { class = "CardMoveNoneToHandTB" },
    [51902] = { class = "CardMoveNoneToDeviceDroneTB" },
    -- queueCars
    [52001] = { class = "CardMoveQueueCarsToDiscardTB" },
    [52002] = { class = "CardMoveQueueCarsToStackTB" },
    [55555] = { class = "CardMoveAnyToAnyTB" },


    --基础
    [60001] = { class = "ActiveNodeTB" },
    [60002] = { class = "PlayUIEffectTB" },
    [60003] = { class = "PlayAnimTB" },
    [60004] = { class = "PlayFlyUIEffectTB" },
    [60005] = { class = "MoveAnchorTB" },
    [60006] = { class = "TransformScaleTB" },

    [61001] = { class = "PlayEffectCarrierTB" }, -- 机体播放特效
    [61003] = { class = "ChangeHpTB" },          -- 血量变化
    [61004] = { class = "ChangeHpMaxTB" },       -- 血量上限变化
    [61005] = { class = "ChangeEnergyTB" },      -- 能量变化
    [61006] = { class = "ChangeEnergyMaxTB" },   -- 能量上限变化
    [61007] = { class = "ChangeShiledTB" },      -- 护盾变化
    [61008] = { class = "DeviceChangeHpTB" },    -- 设备血量变化


    --showtime
    [70001] = { class = "ActiveBattleMainPanelTB" }, --显隐战斗主界面
    [70002] = { class = "ActiveShowtimeSceneTB" },   --激活表演场景
    [70003] = { class = "ActiveTargetMechaTB" },     --激活目标机甲
    -- [70004] = { class = "ActiveVirtualCameraTB" },   --加载虚拟相机
    [70005] = { class = "ActiveLightTB" },           --加载灯光
    [70006] = { class = "PlayMechaEffectTB" },       --播放机甲特效
    [70007] = { class = "PlaySceneEffectTB" },       --播放场景特效
    [70008] = { class = "PlayFlyEffectTB" },         --播放飞行特效
    [70009] = { class = "PlayStretchEffectTB" },     --播放伸缩特效
    [70010] = { class = "ActiveTimelineSceneTB" },   --激活Timeline场景环境
    [70011] = { class = "PlayEntityCameraTB" },      --激活带实体相机
    [70012] = { class = "PlayMoveMechaTB" },         --播放机体移动
    -- [70013] = { class = "PlayMoveBoneTB" },          --播放骨骼移动
    -- [70014] = { class = "ActiveGridTB" },            --激活对应格子的无人机
    -- [70015] = { class = "SetMechaPositionTB" },      --设置机甲位置


    -- enemeySelect
    [80001] = { class = "EnemySelectStackTB" },   -- 敌人选择堆叠
    [80002] = { class = "EnemySelectDeviceTB" },  -- 敌人选择设备
    [80003] = { class = "EnemySelectSlotTB" },    -- 敌人选择槽位
    [80004] = { class = "EnemySelectCarrierTB" }, -- 敌人选择机体
}

TimelineBehaviorIndex.TempIndex =
{
    ["PlayAudioTB"] = { class = "PlayAudioTB" },                   --播放音效
    ["PlayMechaEffectTB"] = { class = "PlayMechaEffectTB" },       --播放机甲特效
    ["PlayStretchEffectTB"] = { class = "PlayStretchEffectTB" },   --播放伸缩特效
    ["PlaySceneEffectTB"] = { class = "PlaySceneEffectTB" },       --播放场景特效
    ["PlayFlyEffectTB"] = { class = "PlayFlyEffectTB" },           --播放飞行特效
    ["PlayMechaAnimTB"] = { class = "PlayMechaAnimTB" },           --机体播放动画
    ["HitResultTB"] = { class = "HitResultTB" },                   --命中结算   10003
    ["PlayDisperseEffectTB"] = { class = "PlayDisperseEffectTB" }, --播放散射导弹特效
    ["ActiveEntityCameraTB"] = { class = "ActiveEntityCameraTB" }, --激活带实体相机
    ["PlayMoveMechaTB"] = { class = "PlayMoveMechaTB" },           --播放机体移动
    ["IncreaseMaterialTB"] = { class = "IncreaseMaterialTB" },     --新增材质
    ["RemoveMaterialTB"] = { class = "RemoveMaterialTB" },         --移除材质
    ["ChangeMaterialPropertyTB"] = {class = "ChangeMaterialPropertyTB"}, --材质属性变化
    ["PlayEntityCameraTB"] = { class = "PlayEntityCameraTB" },     --激活带实体相机
    ["PlayHitReactionTB"] = { class = "PlayHitReactionTB" },        --受击反应（preview）
}


TimelineBehaviorIndex.ResultToIndex =
{
    [100] = 61005,
    [103] = 61003,
    [102] = 61006,
    [104] = 61004,
    [101] = 61007,
}


TimelineBehaviorIndex.DeviceResultToIndex =
{
    [103] = 61008,
    [BattleDefine.EffectType.attack_shiled_end] = 10011,
}


-- TimelineBehaviorIndex.EffectEventToTB =
-- {
--     [1000] = 10004,
--     [1001] = 10004,
--     [999] = 10007,
-- }


TimelineBehaviorIndex.EffectEventToTB = {
    -- [BattleDefine.PlayResultType.attack] = 10004,
    -- [BattleDefine.PlayResultType.buff] = 10008,
    -- [BattleDefine.PlayResultType.debuff] = 10009,

    [BattleDefine.EffectType.destroy_drone] = 10013,
    [BattleDefine.EffectType.remove_player] = 10007,
    [BattleDefine.EffectType.attack_shiled_end] = 10011,
    [BattleDefine.EffectType.change_money] = 10014,
}

TimelineBehaviorIndex.PlayResultToTB =
{
    [BattleDefine.PlayResultType.attack] = 10004,
    [BattleDefine.PlayResultType.backAttack] = 10004,
    [BattleDefine.PlayResultType.fanAttack] = 10004,
    [BattleDefine.PlayResultType.penetratAttack] = 10004,
    [BattleDefine.PlayResultType.selfExplode] = 10004,
    [BattleDefine.PlayResultType.selfAoeExplode] = 10004,
    [BattleDefine.PlayResultType.meleeAttack] = 10004,
    [BattleDefine.PlayResultType.buff] = 10008,
    [BattleDefine.PlayResultType.debuff] = 10009,
    [BattleDefine.PlayResultType.switchMode] = 10010,
    [BattleDefine.PlayResultType.carrierRemove] = 10013,
    [BattleDefine.PlayResultType.switchDisplay] = 10017,
}

TimelineBehaviorIndex.ResultEventToTB = {
    [BattleDefine.EffectType.split_target] = 10015,
    [BattleDefine.EffectType.move_card_to_grid] = 10016,
}