ActiveNodeTB = BaseClass("ActiveNodeTB",TimelineBehaviorBase)

function ActiveNodeTB:__Init()

end

function ActiveNodeTB:__Delete()

end

function ActiveNodeTB:OnInit()

end

function ActiveNodeTB:OnStart()
    if self.args.node then
        self.args.node:SetActive(self.args.flag)
    end
    self:BehaviorComplete()
end