MoveAnchorTB = BaseClass("MoveAnchorTB",TimelineBehaviorBase)

function MoveAnchorTB:__Init()
    self.anim = nil
end

function MoveAnchorTB:__Delete()
    if self.anim then
        self.anim:Delete()
        self.anim = nil
    end
end

function MoveAnchorTB:OnInit()

end

function MoveAnchorTB:OnStart()
    self.anim = MoveAnchorAnim.New(self.conf.transform, Vector2(self.conf.x,self.conf.y), self.conf.moveTime * 0.001)
    self.anim:SetComplete(self:ToFunc("AnimComplete"))
    self.anim:Play()
end

function MoveAnchorTB:AnimComplete()
    self:BehaviorComplete()
end