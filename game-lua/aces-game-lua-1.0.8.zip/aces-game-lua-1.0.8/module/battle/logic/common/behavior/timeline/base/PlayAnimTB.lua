PlayAnimTB = BaseClass("PlayAnimTB",TimelineBehaviorBase)

function PlayAnimTB:__Init()
    self.timer = nil
end

function PlayAnimTB:__Delete()
    if self.timer then
        self.world.TimerSystem:RemoveTimer(self.timer)
        self.timer = nil
    end
end

function PlayAnimTB:OnInit()

end

function PlayAnimTB:OnStart()
    if not self.args.anim then
        self:BehaviorComplete()
        return
    end

    self.args.anim:Play(self.args.animName)
    local time = BaseUtils.GetAnimatorClipTime(self.args.anim,self.args.animName)
    self.timer = self.world.TimerSystem:AddTimer(1,time,self:ToFunc("AnimDone"))
    self.timer:SetScale(true)
end

function PlayAnimTB:AnimDone()
    self.timer = nil
    self:BehaviorComplete()
end