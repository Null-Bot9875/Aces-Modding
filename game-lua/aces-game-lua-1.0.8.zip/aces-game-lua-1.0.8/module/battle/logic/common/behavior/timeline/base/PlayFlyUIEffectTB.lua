PlayFlyUIEffectTB = BaseClass("PlayFlyUIEffectTB", TimelineBehaviorBase)

function PlayFlyUIEffectTB:__Init()
    self.effect = nil
end

function PlayFlyUIEffectTB:__Delete()
    self:RemoveEffect()
    if self.effectAnim then
        self.effectAnim:Delete()
        self.effectAnim = nil
    end
end

function PlayFlyUIEffectTB:OnInit()

end

function PlayFlyUIEffectTB:OnStart()
    local setting = {}
    setting.assetId = self.conf.effectId
    setting.parent = self.args.parent
    setting.pos = self.args.pos
    setting.scale = self.conf.scale
    setting.order = ViewManager.Instance:GetMaxOrderLayer()

    self.effect = UIEffect.New()
    self.effect:Init(setting)
    self.effect:Play()

    if self.conf.isWorld then
        self.effect:SetWorldPos(self.args.startPos.x, self.args.startPos.y, 0)
    else
        self.effect:SetPos(self.args.startPos.x, self.args.startPos.y, 0)
    end

    local endPos         = self.args.endPos
    local time           = self.conf.flyTime

    local transform      = self.effect.transform
    local effectAnim     = {}
    effectAnim.moveXAnim = MoveXAnim.New(transform, endPos.x, time)
    effectAnim.moveYAnim = MoveYAnim.New(transform, endPos.y, time)
    effectAnim.anim      = ParallelAnim.New({ effectAnim.moveXAnim, effectAnim.moveYAnim, effectAnim.scaleAnim,
        effectAnim.rotationAnim })

    effectAnim.anim:SetComplete(self:ToFunc("AnimComplete"))
    effectAnim.anim:Play()

    self.effectAnim = effectAnim.anim
end

function PlayFlyUIEffectTB:AnimComplete()
    self:RemoveEffect()
    self:BehaviorComplete()
end

function PlayFlyUIEffectTB:RemoveEffect()
    if self.effect then
        self.effect:Delete()
        self.effect = nil
    end
end

---------------------------------------------

-- function PlayFlyUIEffectTB:OldFunc()
--     local targetCamp = self.world.DataSystem:GetCamp(self.args.targetPlayer)

--     local posInfo = {}
--     mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.GetEnergyWorldPos, targetCamp, posInfo)

--     if self.args.effectSrcType == BattleDefine.EffectSrcType.stack_effect
--         or self.args.effectSrcType == BattleDefine.EffectSrcType.card_effect
--         or self.args.effectSrcType == BattleDefine.EffectSrcType.card_cost then
--         if self.args.data.value > 0 then
--             self.startPos = Vector3(0, 0, BattleDefine.SceneLayer.effect)
--             self.endPos = Vector3(posInfo.pos.x, posInfo.pos.y, BattleDefine.SceneLayer.effect)

--             local effectSetting = {}
--             effectSetting.assetId = 1001
--             effectSetting.pos = {x = self.startPos.x,y = self.startPos.y,z = self.startPos.z}
--             self.world.AssetsSystem:PlaySceneEffect(effectSetting)
--         elseif self.args.data.value < 0 then
--             self.world.DataSystem:ChangeEnergy(self.args.targetPlayer, self.args.data.value)
--             mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshEnergy, self.args.targetPlayer)
--             self.startPos = Vector3(posInfo.pos.x, posInfo.pos.y, BattleDefine.SceneLayer.effect) --能量UI位置
--             self.endPos = Vector3(0, 0, BattleDefine.SceneLayer.effect)

--             local effectSetting = {}
--             effectSetting.assetId = 1002
--             effectSetting.pos = {x = self.startPos.x,y = self.startPos.y,z = self.startPos.z}
--             self.world.AssetsSystem:PlaySceneEffect(effectSetting)

--             self.world.MixedSystem:RefreshCarrierTop(self.args.targetPlayer)
--         end
--     elseif self.args.effectSrcType == BattleDefine.EffectSrcType.equip_cost
--         or self.args.effectSrcType == BattleDefine.EffectSrcType.equip_effect then
--         local devicePos = self.world.MixedSystem:GetPosBySrcType(self.args.srcPlayer,self.args.effectSrcType,self.args.effectSrcValue)
--         if self.args.data.value > 0 then
--             self.startPos = Vector3(devicePos.x, devicePos.y, BattleDefine.SceneLayer.effect)
--             self.endPos = Vector3(posInfo.pos.x, posInfo.pos.y, BattleDefine.SceneLayer.effect)

--             local effectSetting = {}
--             effectSetting.assetId = 1001
--             effectSetting.pos = {x = self.startPos.x,y = self.startPos.y,z = self.startPos.z}
--             self.world.AssetsSystem:PlaySceneEffect(effectSetting)
--         elseif self.args.data.value < 0 then
--             self.world.DataSystem:ChangeEnergy(self.args.targetPlayer, self.args.data.value)
--             mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshEnergy, self.args.targetPlayer)
--             self.world.MixedSystem:RefreshCarrierTop(self.args.targetPlayer)
--             self.startPos = Vector3(posInfo.pos.x, posInfo.pos.y, BattleDefine.SceneLayer.effect) --能量UI位置
--             self.endPos = Vector3(devicePos.x, devicePos.y, BattleDefine.SceneLayer.effect)

--             local effectSetting = {}
--             effectSetting.assetId = 1002
--             effectSetting.pos = {x = self.startPos.x,y = self.startPos.y,z = self.startPos.z}
--             self.world.AssetsSystem:PlaySceneEffect(effectSetting)
--         end
--     end

--     local effectSetting = {}
--     effectSetting.assetId = 1003
--     effectSetting.pos = {x = self.startPos.x,y = self.startPos.y,z = self.startPos.z}
--     self.flyEffect = self.world.AssetsSystem:PlaySceneEffect(effectSetting)
    
--     self.flyAnim = MoveLocalAnim.New(self.flyEffect.transform, self.endPos, 0.3)
--     if self.args.data.value > 0 then
--         self.flyAnim:SetComplete(self:ToFunc("AddFlyEffectDone"))
--     else
--         self.flyAnim:SetComplete(self:ToFunc("SubFlyEffectDone"))
--     end
--     self.flyAnim:Play()


--     if self.args.effectSrcType == 3 and self.args.value < 0 then
--         self.world.DataSystem:ChangeEnergy(self.args.targetPlayer, self.args.value)
--         mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshEnergy, self.args.targetPlayer)
--         self.world.MixedSystem:RefreshCarrierTop(self.args.targetPlayer)
--         self:EffectDone()
--     else
--         local effectSetting = {}
--         effectSetting.assetId = 1003
--         effectSetting.pos = {x = self.startPos.x,y = self.startPos.y,z = self.startPos.z}
--         self.flyEffect = self.world.AssetsSystem:PlaySceneEffect(effectSetting)
--         self.flyAnim = MoveLocalAnim.New(self.flyEffect.transform, self.endPos, 0.3)
--         if self.args.value > 0 then
--             self.flyAnim:SetComplete(self:ToFunc("AddFlyEffectDone"))
--         else
--             self.flyAnim:SetComplete(self:ToFunc("SubFlyEffectDone"))
--         end
--         self.flyAnim:Play()
--     end
-- end

-- function PlayFlyUIEffectTB:AddFlyEffectDone()
--     --Log("飞行特效完成了")
--     self.world.DataSystem:ChangeEnergy(self.args.targetPlayer, self.args.data.value)

--     mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshEnergy, self.args.targetPlayer)
--     self.world.MixedSystem:RefreshCarrierTop(self.args.targetPlayer)

--     local effectSetting = {}
--     effectSetting.assetId = 1002
--     effectSetting.pos = {x = self.endPos.x,y = self.endPos.y,z = self.endPos.z}
--     self.world.AssetsSystem:PlaySceneEffect(effectSetting)
--     self:EffectDone()
-- end

-- function PlayFlyUIEffectTB:SubFlyEffectDone()
--     --Log("飞行特效完成了")
--     local effectSetting = {}
--     effectSetting.assetId = 1001
--     effectSetting.pos = {x = self.endPos.x,y = self.endPos.y,z = self.endPos.z}
--     self.world.AssetsSystem:PlaySceneEffect(effectSetting)
--     self:EffectDone()
-- end

-- --能量点爆炸完成
-- function PlayFlyUIEffectTB:EffectDone()
--     if self.flyEffect then
--         self.world.AssetsSystem:RemoveEffect(self.flyEffect.uid)
--     end
--     self:BehaviorComplete()
-- end
