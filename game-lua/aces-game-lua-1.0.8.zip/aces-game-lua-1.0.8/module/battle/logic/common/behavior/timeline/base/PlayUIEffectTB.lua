PlayUIEffectTB = BaseClass("PlayUIEffectTB",TimelineBehaviorBase)

function PlayUIEffectTB:__Init()
    self.effect = nil
end

function PlayUIEffectTB:__Delete()
    self:RemoveDoneTimer()
    self:RemoveEffect()
end

function PlayUIEffectTB:OnInit()

end

function PlayUIEffectTB:OnStart()
    local setting = {}
    setting.assetId = self.conf.effectId
    setting.parent =self.args.parent
    setting.pos = self.args.pos
    setting.scale = self.conf.scale
    setting.onComplete = self:ToFunc("EffectDone")
    setting.order = ViewManager.Instance:GetMaxOrderLayer()

    self.effect = UIEffect.New()
    self.effect:Init(setting)
    
    if self.args.pos then
        if self.conf.isWorld then
            self.effect:SetWorldPos(self.args.pos.x,self.args.pos.y,0)
        else
            self.effect:SetPos(self.args.pos.x,self.args.pos.y,0)
        end
    end

    self.effect:Play()

    if self.conf.duration and self.conf.duration > 0 then
        self.doneTimer = self.world.TimerSystem:AddTimer(1,self.conf.duration * 0.001,self:ToFunc("TimerDone"))
        self.doneTimer:SetScale(true)
    end
end

function PlayUIEffectTB:TimerDone()
    self.doneTimer = nil
    self:EffectDone()
end

function PlayUIEffectTB:EffectDone()
    self:RemoveDoneTimer()
    self:RemoveEffect()
    self:BehaviorComplete()
end

function PlayUIEffectTB:RemoveEffect()
    if self.effect then
        self.effect:Delete()
        self.effect = nil
    end
end

function PlayUIEffectTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end