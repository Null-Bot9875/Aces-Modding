TransformScaleTB = BaseClass("TransformScaleTB",TimelineBehaviorBase)

function TransformScaleTB:__Init()
    self.moveAnim = nil
end

function TransformScaleTB:__Delete()
    if self.moveAnim then
        self.moveAnim:Delete()
        self.moveAnim = nil
    end
end

function TransformScaleTB:OnInit()

end

function TransformScaleTB:OnStart()
    self.moveAnim = ScaleAnim.New(self.conf.transform, self.conf.scale * 0.001, self.conf.scaleTime * 0.001)
    self.moveAnim:SetComplete(self:ToFunc("AnimComplete"))
    self.moveAnim:Play()
end

function TransformScaleTB:AnimComplete()
    self:BehaviorComplete()
end