-- 缺省处理，仅刷新数据
CardMoveAnyToAnyTB = BaseClass("CardMoveAnyToAnyTB", TimelineBehaviorBase)

function CardMoveAnyToAnyTB:__Init()
    self.completeCb = self:ToFunc("OnMoveComplete")
end

function CardMoveAnyToAnyTB:__Delete()
end

function CardMoveAnyToAnyTB:OnStart()
--     LogTable(string.format("卡牌移动，from:%s to:%s", self.args.oldArea, self.args.toArea))

    local data = self.args.data
    if data.area == BattleDefine.CardAreaDef.device_drone then
        self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)
        self.world.DataSystem:UpdateGridCardInfo(data.uid, data.info)
        self.world.DroneDeviceSystem:RefreshAllDeviceInfo()
    else
        self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)
    end

    if data.oldArea == BattleDefine.CardAreaDef.queueCars or data.area == BattleDefine.CardAreaDef.queueCars then
        mod.BattleFacade:SendEvent(BattleChainQueueView.Event.RefreshChainQueue)
    end

    -- if data.oldArea == BattleDefine.CardAreaDef.queueCars then
    --     mod.BattleFacade:SendEvent(BattleChainQueueView.Event.ShowChainQueueHighlight, data.info.id, false)
    -- end

    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardLibraryNum)
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardDiscardNum)
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardHandNum)
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardConsumeNum)
    self:BehaviorComplete()
end

function CardMoveAnyToAnyTB:OnMoveComplete()
    self:BehaviorComplete()
end

function CardMoveAnyToAnyTB:OnUpdate(deltaTime)
end
