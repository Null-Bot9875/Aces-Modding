CardMoveConsumeToDeviceDroneTB = BaseClass("CardMoveConsumeToDeviceDroneTB", TimelineBehaviorBase)

function CardMoveConsumeToDeviceDroneTB:__Init()
end

function CardMoveConsumeToDeviceDroneTB:__Delete()

end

function CardMoveConsumeToDeviceDroneTB:OnStart()
    -- LogTable("卡牌移动，废弃区=>无人机", self.args)

    local data = self.args.data
    -- local conf = Config.Get("card_def", "config", "cardId", data.info.cardId)
    -- mod.BattleFacade:SendEvent(BattleStackCardView.Event.RemoveStack,data.oldPos)
    -- self.world.DataSystem:RemoveStackInfo(data.oldPos)
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    -- if conf.extend[BattleDefine.CardExtendType.deskCost] ~= nil then
        -- mod.BattleFacade:SendEvent(BattleHandCardView.Event.AddHandCard,data.uid,data.info,true,false)
    -- end
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardConsumeNum)
    self:BehaviorComplete()
end

function CardMoveConsumeToDeviceDroneTB:OnUpdate(deltaTime)
end
