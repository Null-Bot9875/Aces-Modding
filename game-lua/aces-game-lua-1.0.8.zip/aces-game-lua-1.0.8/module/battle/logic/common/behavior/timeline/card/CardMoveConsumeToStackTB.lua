CardMoveConsumeToStackTB = BaseClass("CardMoveConsumeToStackTB", TimelineBehaviorBase)

function CardMoveConsumeToStackTB:__Init()
end

function CardMoveConsumeToStackTB:__Delete()

end

function CardMoveConsumeToStackTB:OnStart()
    local data = self.args.data
    local camp = self.world.DataSystem:GetCamp(data.uid)

    -- 先移除闪回，再刷新数据
    --self.world.DataSystem:RemoveCardInfo(data.uid, data.oldArea, data.info.id)

    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)
    mod.BattleFacade:SendEvent(BattleHandCardView.Event.RemoveHandCard,data.uid,data.info.id)
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardConsumeNum)
    
    -- 新增堆叠走单独的协议
    self:BehaviorComplete()
end

function CardMoveConsumeToStackTB:OnUpdate(deltaTime)
end
