CardMoveDeviceToConsumeTB = BaseClass("CardMoveDeviceToConsumeTB", TimelineBehaviorBase)

function CardMoveDeviceToConsumeTB:__Init()
end

function CardMoveDeviceToConsumeTB:__Delete()
 
end

function CardMoveDeviceToConsumeTB:OnStart()
    -- LogTable("卡牌无人机移动到消耗区", self.args)
    local data = self.args.data
    
    -- 如果是从无人机区域移动到消耗区，标记为废弃死亡
    if data.oldArea == BattleDefine.CardAreaDef.device_drone then
        local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(data.info.id)
        if entity then
            entity.ObjectDataComponent:SetScrapDead(true)
        end
    end

    -- TODO 无人机从战场移到废弃区表现
    -- 数据刷新
    --self.world.DataSystem:RemoveCardInfo(data.uid, data.oldArea, data.info.id)
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardConsumeNum)
    self:BehaviorComplete()
end


function CardMoveDeviceToConsumeTB:OnUpdate(deltaTime)
end
