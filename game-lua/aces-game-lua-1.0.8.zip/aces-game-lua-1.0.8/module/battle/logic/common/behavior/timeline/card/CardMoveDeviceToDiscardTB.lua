CardMoveDeviceToDiscardTB = BaseClass("CardMoveDeviceToDiscardTB", TimelineBehaviorBase)

function CardMoveDeviceToDiscardTB:__Init()
end

function CardMoveDeviceToDiscardTB:__Delete()
 
end

function CardMoveDeviceToDiscardTB:OnStart()
--     LogTable("卡牌移动，无人机=>弃牌堆", self.args)
    local data = self.args.data

    -- TODO 无人机从战场移到弃牌区表现
    -- 数据刷新
    --self.world.DataSystem:RemoveCardInfo(data.uid, data.oldArea, data.info.id)
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)
    

    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardDiscardNum)
    self:BehaviorComplete()
end


function CardMoveDeviceToDiscardTB:OnUpdate(deltaTime)
end
