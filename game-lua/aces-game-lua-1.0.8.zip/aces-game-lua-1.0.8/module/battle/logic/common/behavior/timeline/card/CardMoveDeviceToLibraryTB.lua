CardMoveDeviceToLibraryTB = BaseClass("CardMoveDeviceToLibraryTB", TimelineBehaviorBase)

function CardMoveDeviceToLibraryTB:__Init()
end

function CardMoveDeviceToLibraryTB:__Delete()
 
end

function CardMoveDeviceToLibraryTB:OnStart()
--     LogTable("卡牌移动，无人机=>牌库", self.args)
    local data = self.args.data

    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardLibraryNum)
    self:BehaviorComplete()
end


function CardMoveDeviceToLibraryTB:OnUpdate(deltaTime)
end
