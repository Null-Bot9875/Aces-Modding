CardMoveDiscardToDeviceDroneTB = BaseClass("CardMoveDiscardToDeviceDroneTB", TimelineBehaviorBase)

function CardMoveDiscardToDeviceDroneTB:__Init()
end

function CardMoveDiscardToDeviceDroneTB:__Delete()

end

function CardMoveDiscardToDeviceDroneTB:OnStart()
--     LogTable("卡牌移动，弃牌=>无人机", self.args)

    local data = self.args.data
    -- local conf = Config.Get("card_def", "config", "cardId", data.info.cardId)
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    self:BehaviorComplete()
end

function CardMoveDiscardToDeviceDroneTB:OnUpdate(deltaTime)
end
