-- 先移除绝境，再刷新数据
CardMoveDiscardToLibraryTB = BaseClass("CardMoveDiscardToLibraryTB", TimelineBehaviorBase)

function CardMoveDiscardToLibraryTB:__Init()
end

function CardMoveDiscardToLibraryTB:__Delete()

end

function CardMoveDiscardToLibraryTB:OnStart()
--     LogTable("卡牌移动，弃牌堆=>牌库", self.args)
    local data = self.args.data
    --local camp   = self.world.DataSystem:GetCamp(data.uid)

    mod.BattleFacade:SendEvent(BattleHandCardView.Event.RemoveHandCard,data.uid,data.info.id)
    --self.world.DataSystem:RemoveCardInfo(data.uid, data.oldArea, data.info.id)
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardDiscardNum)
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardLibraryNum)
    self:BehaviorComplete()
end

function CardMoveDiscardToLibraryTB:OnUpdate(deltaTime)
end
