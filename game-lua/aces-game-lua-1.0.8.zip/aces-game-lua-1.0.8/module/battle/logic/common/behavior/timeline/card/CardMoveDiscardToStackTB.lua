CardMoveDiscardToStackTB = BaseClass("CardMoveDiscardToStackTB", TimelineBehaviorBase)

function CardMoveDiscardToStackTB:__Init()
end

function CardMoveDiscardToStackTB:__Delete()

end

function CardMoveDiscardToStackTB:OnStart()
    local data = self.args.data
    local camp = self.world.DataSystem:GetCamp(data.uid)

    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)
    mod.BattleFacade:SendEvent(BattleHandCardView.Event.RemoveHandCard,data.uid,data.info.id)
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardDiscardNum)
    -- 新增堆叠走单独的协议
    self:BehaviorComplete()
end

function CardMoveDiscardToStackTB:OnUpdate(deltaTime)
end
