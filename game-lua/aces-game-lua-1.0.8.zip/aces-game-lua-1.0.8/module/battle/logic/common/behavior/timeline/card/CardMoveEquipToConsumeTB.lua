CardMoveEquipToConsumeTB = BaseClass("CardMoveEquipToConsumeTB", TimelineBehaviorBase)

function CardMoveEquipToConsumeTB:__Init()
    self.moveAnim = nil
    self.tempCardItem = nil
    -- 使用统一的时间配置
    local config = CardMoveTiming.GetMoveTimeConfig(BattleDefine.CardAreaDef.consume)
    self.moveTime = config.moveTime
    self.scaleTime = config.scaleTime
    self.rotateTime = config.rotateTime
    self.easeType = CardMoveTiming.GetEaseType(BattleDefine.CardAreaDef.consume)
end

function CardMoveEquipToConsumeTB:__Delete()
    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end
end

function CardMoveEquipToConsumeTB:OnStart()
    local data   = self.args.data
    local camp = self.world.DataSystem:GetCamp(data.uid)
    --local isSelf = data.uid == self.world.DataSystem.roleUid
    --local camp   = isSelf and BattleDefine.Camp.self or BattleDefine.Camp.enemy

    local conf = Config.Get("card_def", "config", "cardId", data.info.cardId)


    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    local startPos = mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.GetSlotPosBySlotUid,data.uid, data.oldPos)

    if conf.extend[BattleDefine.CardExtendType.scrapCost] ~= nil then
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.AddHandCard,data.uid,data.info,true,false)
        local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo,data.info.id)
        local item = cardInfo.item
        item:SetState(BattleDefine.CardState.control)

        item.tposeTrans:SetPosition(startPos.x, startPos.y, startPos.z)
        item.tposeTrans:SetLocalScale(0, 0, 0)

        local posInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardTrans,camp,cardInfo.item.index)
        --local endPos = Vector2(posInfo.x,posInfo.y)

        -- 使用统一的时间配置

        local anim          = {}
        anim.tbScaleAnim    = ScaleAnim.New(cardInfo.item.tposeTrans, BattleDefine.CardScale.scene.x, self.scaleTime)
        anim.tbRotationAnim = RotationZAnim.New(cardInfo.item.tposeTrans, posInfo.angle, self.rotateTime)
        anim.tbMoveAnim = MoveAnchorAnim.New(cardInfo.item.tposeTrans, Vector2(0,0), self.moveTime)
        anim.tbScaleAnim:SetTimeScale(true)
        anim.tbRotationAnim:SetTimeScale(true)
        anim.tbMoveAnim:SetTimeScale(true)
        anim.tbAnim         = ParallelAnim.New({ anim.tbScaleAnim, anim.tbRotationAnim, anim.tbMoveAnim })
        anim.tbAnim:SetEase(self.easeType)

        anim.tbAnim:SetComplete(self:ToFunc("MoveComplete"))
        anim.tbAnim:Play()

        self.moveAnim = anim.tbAnim
    else
        local item = mod.BattleFacade:SendEvent(BattleHandCardView.Event.CreateHandCardItem,data.uid,data.info)
        local endPos = mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.GetConsumeNodePos,camp)
        item.transform:SetPosition(startPos.x, startPos.y, startPos.z)

        self.tempCardItem = item

        -- 使用统一的时间配置

        local anim          = {}
        anim.tbScaleAnim    = ScaleAnim.New(item.transform, 0, self.scaleTime)
        anim.tbRotationAnim = RotationZAnim.New(item.transform, 0, self.rotateTime)
        anim.tbMoveXAnim    = MoveXAnim.New(item.transform, endPos.x, self.moveTime)
        anim.tbMoveYAnim    = MoveYAnim.New(item.transform, endPos.y, self.moveTime)
        anim.tbScaleAnim:SetTimeScale(true)
        anim.tbRotationAnim:SetTimeScale(true)
        anim.tbMoveXAnim:SetTimeScale(true)
        anim.tbMoveYAnim:SetTimeScale(true)
        anim.tbAnim         = ParallelAnim.New({ anim.tbScaleAnim, anim.tbRotationAnim, anim.tbMoveXAnim, anim.tbMoveYAnim })
        anim.tbAnim:SetEase(self.easeType)

        anim.tbAnim:SetComplete(self:ToFunc("MoveComplete"))
        anim.tbAnim:Play()

        self.moveAnim = anim.tbAnim
    end
end

function CardMoveEquipToConsumeTB:MoveComplete(args)
    if self.tempCardItem then
        self.tempCardItem:Destroy()
        self.tempCardItem = nil
    end

    local data = self.args.data

    local conf = Config.Get("card_def", "config", "cardId", data.info.cardId)

    if conf.extend[BattleDefine.CardExtendType.scrapCost] ~= nil then
        local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo,data.info.id)
        cardInfo.item:SetState(BattleDefine.CardState.normal)
    end

    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardConsumeNum)
    self:BehaviorComplete()
end

function CardMoveEquipToConsumeTB:OnUpdate(deltaTime)
end
