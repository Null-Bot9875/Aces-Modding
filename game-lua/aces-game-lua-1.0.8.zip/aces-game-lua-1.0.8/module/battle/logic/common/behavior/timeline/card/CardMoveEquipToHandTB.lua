CardMoveEquipToHandTB = BaseClass("CardMoveEquipToHandTB", TimelineBehaviorBase)

function CardMoveEquipToHandTB:__Init()
    self.moveAnim = nil
    -- 使用统一的时间配置
    local config = CardMoveTiming.GetMoveTimeConfig(BattleDefine.CardAreaDef.hand)
    self.moveTime = config.moveTime
    self.scaleTime = config.scaleTime
    self.rotateTime = config.rotateTime
    self.easeType = CardMoveTiming.GetEaseType(BattleDefine.CardAreaDef.hand)
end

function CardMoveEquipToHandTB:__Delete()
    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end
end

function CardMoveEquipToHandTB:OnStart()
    local data   = self.args.data
    local camp = self.world.DataSystem:GetCamp(data.uid)


    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    mod.BattleFacade:SendEvent(BattleHandCardView.Event.AddHandCard,data.uid,data.info,true,false)
    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo,data.info.id)
    

    local startPos = mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.GetSlotPosBySlotUid,data.uid, data.oldPos)

    cardInfo.item.tposeTrans:SetPosition(startPos.x, startPos.y, startPos.z)
    cardInfo.item:SetState(BattleDefine.CardState.control)

    local posInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardTrans,camp,cardInfo.item.index)
    local endPos = Vector2(posInfo.x,posInfo.y)

    cardInfo.item.tposeTrans:SetLocalScale(0, 0, 0)


    local anim = {}
    anim.tbScaleAnim = ScaleAnim.New(cardInfo.item.tposeTrans, BattleDefine.CardScale.scene.x, self.scaleTime)
    anim.tbRotationAnim = RotationZAnim.New(cardInfo.item.tposeTrans, posInfo.angle, self.rotateTime)
    anim.tbMoveAnim = MoveAnchorAnim.New(cardInfo.item.tposeTrans, Vector2(0,0), self.moveTime)
    anim.tbScaleAnim:SetTimeScale(true)
    anim.tbRotationAnim:SetTimeScale(true)
    anim.tbMoveAnim:SetTimeScale(true)
    anim.tbAnim = ParallelAnim.New({ anim.tbScaleAnim, anim.tbRotationAnim, anim.tbMoveAnim })
    anim.tbAnim:SetEase(self.easeType)

    anim.tbAnim:SetComplete(self:ToFunc("MoveComplete"), {})
    anim.tbAnim:Play()

    self.moveAnim = anim.tbAnim
end

function CardMoveEquipToHandTB:MoveComplete(args)
    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo,self.args.data.info.id)
    cardInfo.item:SetState(BattleDefine.CardState.normal)

    -- mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshCardHandNum)
    self:BehaviorComplete()
end

function CardMoveEquipToHandTB:OnUpdate(deltaTime)
end
