CardMoveEquipToLibraryTB = BaseClass("CardMoveEquipToLibraryTB", TimelineBehaviorBase)

function CardMoveEquipToLibraryTB:__Init()
    self.moveAnim = nil
    self.moveCardItem = nil
    -- 使用统一的时间配置
    local config = CardMoveTiming.GetMoveTimeConfig(BattleDefine.CardAreaDef.library)
    self.moveTime = config.moveTime
    self.scaleTime = config.scaleTime
    self.rotateTime = config.rotateTime
    self.easeType = CardMoveTiming.GetEaseType(BattleDefine.CardAreaDef.library)
end

function CardMoveEquipToLibraryTB:__Delete()
    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end
end

function CardMoveEquipToLibraryTB:OnStart()
    local data   = self.args.data
    local camp = self.world.DataSystem:GetCamp(data.uid)


    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    local item = mod.BattleFacade:SendEvent(BattleHandCardView.Event.CreateHandCardItem,data.uid,data.info)
    self.moveCardItem = item

    item.transform:SetLocalScale(BattleDefine.CardScale.scene.x, BattleDefine.CardScale.scene.y, BattleDefine.CardScale.scene.z)

    local startPos = mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.GetSlotPosBySlotUid,data.uid, data.oldPos)
    item.transform:SetPosition(startPos.x, startPos.y, startPos.z)
    item.transform:SetLocalScale(1, 1, 1)

    local endPos = mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.GetCardLibNodePos,camp)


    -- 使用统一的时间配置

    local anim          = {}
    anim.tbScaleAnim    = ScaleAnim.New(item.transform, 0, self.scaleTime)
    anim.tbRotationAnim = RotationZAnim.New(item.transform, 0, self.rotateTime)
    anim.tbMoveXAnim    = MoveXAnim.New(item.transform, endPos.x, self.moveTime)
    anim.tbMoveYAnim    = MoveYAnim.New(item.transform, endPos.y, self.moveTime)
    anim.tbAnim         = ParallelAnim.New({ anim.tbScaleAnim, anim.tbRotationAnim, anim.tbMoveXAnim, anim.tbMoveYAnim })
    anim.tbAnim:SetEase(self.easeType)

    anim.tbAnim:SetComplete(self:ToFunc("MoveComplete"))
    anim.tbAnim:Play()

    self.moveAnim = anim.tbAnim
end

function CardMoveEquipToLibraryTB:MoveComplete(args)
    if self.moveCardItem then
        self.moveCardItem:Destroy()
        self.moveCardItem = nil
    end

    --self.world.EntitySystem:RemoveEntity(self.entityUid)

    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardLibraryNum)
    self:BehaviorComplete()
end

function CardMoveEquipToLibraryTB:OnUpdate(deltaTime)
end
