CardMoveHandToConsume = BaseClass("CardMoveHandToConsume", TimelineBehaviorBase)

-- trail 飞行常量
local TRAIL_FLY_DURATION = 0.45
local TRAIL_UPDATE_INTERVAL = 0.016
local TRAIL_UPDATE_MAX_COUNT = 100

function CardMoveHandToConsume:__Init()
    local config = CardMoveTiming.GetMoveTimeConfig(BattleDefine.CardAreaDef.consume)
    self.moveTime = config.moveTime
    self.moveToCenterAnim = nil
    self.rtUIObject = nil
    self.counterEffect = nil
    self.hideTimer = nil
    self.doneTimer = nil
end

function CardMoveHandToConsume:__Delete()
    if self.moveToCenterAnim then
        self.moveToCenterAnim:Destroy()
        self.moveToCenterAnim = nil
    end
    if self.counterEffect then
        self.counterEffect:Delete()
        self.counterEffect = nil
    end
    if self.rtUIObject then
        self.rtUIObject:Delete()
        self.rtUIObject = nil
    end
    if self.hideTimer then
        self.world.TimerSystem:RemoveTimer(self.hideTimer)
        self.hideTimer = nil
    end
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
    if self.trailTimer then
        self.world.TimerSystem:RemoveTimer(self.trailTimer)
        self.trailTimer = nil
    end
end

function CardMoveHandToConsume:OnStart()
    local data = self.args.data
    local camp = self.world.DataSystem:GetCamp(data.uid)

    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo, data.info.id)
    cardInfo.item:SetState(BattleDefine.CardState.control)

    self.cardItem = cardInfo.item
    self.camp = camp

    -- 移动到屏幕中心
    local centerWorld = mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.GetCenterNodePos)
    self.centerPos = centerWorld

    local moveX = MoveXAnim.New(self.cardItem.transform, centerWorld.x, self.moveTime)
    local moveY = MoveYAnim.New(self.cardItem.transform, centerWorld.y, self.moveTime)
    self.moveToCenterAnim = ParallelAnim.New({ moveX, moveY })
    self.moveToCenterAnim:SetComplete(self:ToFunc("OnMoveToCenterDone"))
    self.moveToCenterAnim:Play()
end

-- 到达屏幕中心后，截图 + 播放反制特效
function CardMoveHandToConsume:OnMoveToCenterDone()
    if self.moveToCenterAnim then
        self.moveToCenterAnim:Destroy()
        self.moveToCenterAnim = nil
    end

    local tpose = self.cardItem:Find("tpose")
    tpose.transform.localScale = Vector3.one * 0.52

    local rtSetting = {}
    rtSetting.textureWidth = 510
    rtSetting.textureHeight = 710
    rtSetting.uiObject = tpose.gameObject
    self.rtUIObject = RTUIObject.New()
    self.rtUIObject:Show(rtSetting)

    local effectSetting = {}
    effectSetting.assetId = "ui_battle_card_be_counter"
    effectSetting.parent = tpose.transform
    effectSetting.pos = Vector2(0, 0)
    effectSetting.scale = 1000
    effectSetting.order = ViewManager.Instance:GetCurOrderLayer()
    effectSetting.onLoad = self:ToFunc("OnCounterEffectLoaded")

    self.counterEffect = UIEffect.New()
    self.counterEffect:Init(effectSetting)
    self.counterEffect:Play()

    AudioManager.Instance:PlayUI("cancel_1")
end

function CardMoveHandToConsume:OnCounterEffectLoaded(effect)
    local render = self.counterEffect.effect.transform:Find("node"):GetChild(0).gameObject:GetComponent(Renderer)
    render.material:SetTexture("_Maintex", self.rtUIObject.texture)
    self.hideTimer = self.world.TimerSystem:AddTimerByNextFrame(1, 0, self:ToFunc("OnHideCard"))
end

function CardMoveHandToConsume:OnHideCard()
    self.hideTimer = nil
    -- local tpose = self.cardItem:Find("tpose")
    local tpose = self.cardItem:GetCardItem()
    if tpose then
        tpose.gameObject:SetActive(false)
    end

    local duration = self.counterEffect:GetDuration() * 0.001
    self.doneTimer = self.world.TimerSystem:AddTimer(1, duration, self:ToFunc("OnCounterEffectDone"))
    self.doneTimer:SetScale(true)
    self.trailTimer = self.world.TimerSystem:AddTimerByNextFrame(1, duration / 2, self:ToFunc("StartConsumeTrail"))
    self.trailTimer:SetScale(true)
end

-- 反制特效播完：清理资源、更新数据、启动 trail、完成 TB
function CardMoveHandToConsume:OnCounterEffectDone()
    self.doneTimer = nil

    -- 先清理特效资源（挂在 cardItem 上，需在 RemoveHandCard 前清理）
    if self.counterEffect then
        self.counterEffect:Delete()
        self.counterEffect = nil
    end
    if self.rtUIObject then
        self.rtUIObject:Delete()
        self.rtUIObject = nil
    end

    local data = self.args.data
    local conf = Config.Get("card_def", "config", "cardId", data.info.cardId)

    mod.BattleFacade:SendEvent(BattleHandCardView.Event.RemoveHandCard, data.uid, data.info.id)
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    if conf.extend[BattleDefine.CardExtendType.scrapCost] ~= nil then
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.AddHandCard, data.uid, data.info, true, false)
    end

    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardConsumeNum)

    self:BehaviorComplete()
end

-- 反制特效播放时发射 trail，沿弧线飞向废弃区图标
function CardMoveHandToConsume:StartConsumeTrail()
    local endPos = mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.GetConsumeNodePos, self.camp)
    local startPos = self.centerPos

    -- 用中点垂直偏移生成简单弧线控制点
    local midPoint = (startPos + endPos) * 0.5
    local dir = (endPos - startPos).normalized
    local perpendicular = Vector3(-dir.y, dir.x, 0)
    local arcHeight = (endPos - startPos).magnitude * 0.3
    local controlPoint = midPoint + perpendicular * arcHeight

    local trailEffect = UIEffect.New()
    local setting = {}
    setting.assetId = "ui_common_trail_01"
    setting.parent = UIDefine.canvasRoot
    setting.worldPos = { x = startPos.x, y = startPos.y, z = startPos.z }
    setting.scale = 1000
    setting.order = ViewManager.Instance:GetCurOrderLayer() + 1
    setting.notAutoHide = true
    trailEffect:Init(setting)
    trailEffect:Play()

    -- 全局定时器驱动二次贝塞尔弧线飞行，与 TB 生命周期解耦
    local flyStartTime = Time.time
    local timer = nil
    timer = TimerManager.Instance:AddTimer(TRAIL_UPDATE_MAX_COUNT, TRAIL_UPDATE_INTERVAL,
        function()
            local elapsed = Time.time - flyStartTime
            local t = math.min(elapsed / TRAIL_FLY_DURATION, 1.0)
            local easedT = t * t * (3 - 2 * t)
            local pos = CurveUtils.Curve1(startPos, controlPoint, endPos, easedT)
            trailEffect:SetWorldPos(pos.x, pos.y, pos.z)
            if t >= 1.0 then
                trailEffect:Delete()
                TimerManager.Instance:RemoveTimer(timer)
            end
        end)
end

function CardMoveHandToConsume:OnUpdate(deltaTime)
end
