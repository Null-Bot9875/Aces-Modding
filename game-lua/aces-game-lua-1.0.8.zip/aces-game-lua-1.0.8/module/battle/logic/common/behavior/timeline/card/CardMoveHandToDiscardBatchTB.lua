CardMoveHandToDiscardBatchTB = BaseClass("CardMoveHandToDiscardBatchTB", TimelineBehaviorBase)

function CardMoveHandToDiscardBatchTB:__Init()
    -- 批量动画容器
    self.batchAnim = nil

    -- 自适应时间配置
    self.MAX_TOTAL_DURATION = 0.6        -- 最大总时长
    self.MIN_STAGGER_STEP = 0.015        -- 最小延迟步进（卡牌很多时）
    self.MAX_STAGGER_STEP = 0.06         -- 最大延迟步进（卡牌很少时）
    self.STAGGER_RANDOM_RANGE = 0.02     -- 随机延迟范围
    
    -- 直线飞行配置
    self.BASE_FLY_TIME = 0.22            -- 基础飞行时间
    self.MIN_FLY_TIME = 0.15             -- 最小飞行时间（卡牌多时）
    self.SCALE_RATIO = 0.95              -- 缩放动画占飞行时间的比例
    
    -- 缓动曲线
    self.MOVE_EASE = DG.Tweening.Ease.InQuad      -- 移动缓动（加速）
    self.SCALE_EASE = DG.Tweening.Ease.InCubic    -- 缩放缓动（快速缩小）
end

function CardMoveHandToDiscardBatchTB:__Delete()
    if self.batchAnim then
        self.batchAnim:Destroy()
        self.batchAnim = nil
    end
end

function CardMoveHandToDiscardBatchTB:OnStart()
    local cards = self.args.cards or {}
    assert(#cards > 0, "批量弃牌行为参数为空")

    local cardCount = #cards
    
    -- 自适应计算延迟步进和飞行时间
    local staggerStep = self:CalculateStaggerStep(cardCount)
    local flyTime = self:CalculateFlyTime(cardCount)
    local scaleTime = flyTime * self.SCALE_RATIO
    
    local flyAll = {}

    for i, v in ipairs(cards) do
        local v = cards[i]
        local camp = self.world.DataSystem:GetCamp(v.uid)
        local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo, v.info.id)
        assert(cardInfo ~= nil and cardInfo.item ~= nil, "找不到手牌项，无法播放批量弃牌动画")
        cardInfo.item:SetState(BattleDefine.CardState.control)

        local endPos = mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.GetDiscardNodePos, camp)
        
        -- 直线移动到弃牌堆
        local moveAnim = MoveAnim.New(cardInfo.item.transform, endPos, flyTime)
        moveAnim:SetEase(self.MOVE_EASE)
        
        -- 快速缩小到0
        local scaleAnim = ScaleAnim.New(cardInfo.item.transform, Vector3.zero, scaleTime)
        scaleAnim:SetEase(self.SCALE_EASE)
        moveAnim:SetTimeScale(true)
        scaleAnim:SetTimeScale(true)

        local parallelAnim = ParallelAnim.New({ moveAnim, scaleAnim })

        -- 自适应延迟：基础延迟 + 随机抖动
        local baseDelay = (#cards - i) * staggerStep
        local randomJitter = self:RandomRange(-self.STAGGER_RANDOM_RANGE, self.STAGGER_RANDOM_RANGE)
        local totalDelay = math.max(0, baseDelay + randomJitter)
        
        local delayAnim = DelayAnim.New(totalDelay)
        delayAnim:SetTimeScale(true)
        local seq = SequenceAnim.New({ delayAnim, parallelAnim })
        table.insert(flyAll, seq)
    end

    self.batchAnim = ParallelAnim.New(flyAll)
    self.batchAnim:SetComplete(self:ToFunc("OnBatchComplete"))
    self.batchAnim:Play()
end

function CardMoveHandToDiscardBatchTB:OnBatchComplete()
    local cards = self.args.cards or {}

    -- 动画完成后统一处理数据与UI
    for _, v in ipairs(cards) do
        local conf = Config.Get("card_def", "config", "cardId", v.info.cardId)

        mod.BattleFacade:SendEvent(BattleHandCardView.Event.RemoveHandCard, v.uid, v.info.id)
        self.world.DataSystem:AddCardInfo(v.uid, v.area, v.info)

        if conf and conf.extend and conf.extend[BattleDefine.CardExtendType.deskCost] ~= nil then
            mod.BattleFacade:SendEvent(BattleHandCardView.Event.AddHandCard, v.uid, v.info, true, false)
        end
    end

    -- 批量刷新一次弃牌数量
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardDiscardNum)

    self:BehaviorComplete()
end

function CardMoveHandToDiscardBatchTB:OnUpdate(deltaTime)
end

-- 根据卡牌数量自适应计算延迟步进
function CardMoveHandToDiscardBatchTB:CalculateStaggerStep(cardCount)
    if cardCount <= 1 then
        return 0
    end
    
    -- 计算理想的步进：确保总延迟不超过最大总时长的一半
    local maxStaggerDuration = self.MAX_TOTAL_DURATION * 0.5
    local idealStep = maxStaggerDuration / (cardCount - 1)
    
    -- 限制在最小和最大步进范围内
    return math.max(self.MIN_STAGGER_STEP, math.min(self.MAX_STAGGER_STEP, idealStep))
end

-- 根据卡牌数量自适应计算飞行时间
function CardMoveHandToDiscardBatchTB:CalculateFlyTime(cardCount)
    if cardCount <= 3 then
        return self.BASE_FLY_TIME
    end
    
    -- 卡牌越多，飞行时间越短
    local timeFactor = 1 - (cardCount - 3) * 0.015
    timeFactor = math.max(0.68, timeFactor)
    
    return math.max(self.MIN_FLY_TIME, self.BASE_FLY_TIME * timeFactor)
end

function CardMoveHandToDiscardBatchTB:RandomRange(minVal, maxVal)
    assert(type(minVal) == "number" and type(maxVal) == "number" and maxVal >= minVal, "RandomRange参数非法")
    local r = math.random()
    return minVal + (maxVal - minVal) * r
end


