CardMoveHandToDiscardTB = BaseClass("CardMoveHandToDiscardTB", TimelineBehaviorBase)

function CardMoveHandToDiscardTB:__Init()
    -- 使用统一的时间配置
    local config = CardMoveTiming.GetMoveTimeConfig(BattleDefine.CardAreaDef.discard)
    self.moveTime = config.moveTime
    self.scaleTime = config.scaleTime
    self.rotateTime = config.rotateTime
    self.easeType = CardMoveTiming.GetEaseType(BattleDefine.CardAreaDef.discard)
end

function CardMoveHandToDiscardTB:__Delete()
    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end
end

function CardMoveHandToDiscardTB:OnStart()
    local data          = self.args.data
    local camp          = self.world.DataSystem:GetCamp(data.uid)


    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo,data.info.id)
    cardInfo.item:SetState(BattleDefine.CardState.control)

    local endPos = mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.GetDiscardNodePos,camp)

    local anim          = {}
    anim.tbScaleAnim    = ScaleAnim.New(cardInfo.item.transform, 0, self.scaleTime)
    anim.tbRotationAnim = RotationZAnim.New(cardInfo.item.transform, 0, self.rotateTime)
    anim.tbMoveXAnim    = MoveXAnim.New(cardInfo.item.transform, endPos.x, self.moveTime)
    anim.tbMoveYAnim    = MoveYAnim.New(cardInfo.item.transform, endPos.y, self.moveTime)
    -- 受战斗倍速影响：AnimBaseTween 默认 SetUpdate(true) 为 Unscaled，不随 Time.timeScale 变化；设为 true 后使用 Scaled 更新
    anim.tbScaleAnim:SetTimeScale(true)
    anim.tbRotationAnim:SetTimeScale(true)
    anim.tbMoveXAnim:SetTimeScale(true)
    anim.tbMoveYAnim:SetTimeScale(true)
    anim.tbAnim         = ParallelAnim.New({ anim.tbScaleAnim, anim.tbRotationAnim, anim.tbMoveXAnim, anim.tbMoveYAnim })
    anim.tbAnim:SetEase(self.easeType)

    anim.tbAnim:SetComplete(self:ToFunc("MoveComplete"))
    anim.tbAnim:Play()

    self.moveAnim = anim.tbAnim
end

function CardMoveHandToDiscardTB:MoveComplete(args)
    local data = self.args.data

    local conf = Config.Get("card_def", "config", "cardId", data.info.cardId)

    mod.BattleFacade:SendEvent(BattleHandCardView.Event.RemoveHandCard,data.uid,data.info.id)

    -- 数据刷新
    --self.world.DataSystem:RemoveCardInfo(data.uid, data.oldArea, data.info.id)
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)
    


    if conf.extend[BattleDefine.CardExtendType.deskCost] ~= nil then
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.AddHandCard,data.uid,data.info,true,false)
    end

    -- mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshCardHandNum)
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardDiscardNum)
    self:BehaviorComplete()
end

function CardMoveHandToDiscardTB:OnUpdate(deltaTime)
end
