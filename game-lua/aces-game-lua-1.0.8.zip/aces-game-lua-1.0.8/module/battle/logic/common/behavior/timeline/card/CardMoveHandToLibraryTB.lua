CardMoveHandToLibraryTB = BaseClass("CardMoveHandToLibraryTB", TimelineBehaviorBase)

function CardMoveHandToLibraryTB:__Init()
    self.moveAnim = nil
    -- 使用统一的时间配置
    local config = CardMoveTiming.GetMoveTimeConfig(BattleDefine.CardAreaDef.library)
    self.moveTime = config.moveTime
    self.scaleTime = config.scaleTime
    self.rotateTime = config.rotateTime
    self.easeType = CardMoveTiming.GetEaseType(BattleDefine.CardAreaDef.library)
end

function CardMoveHandToLibraryTB:__Delete()
    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end
end

function CardMoveHandToLibraryTB:OnStart()
    local data   = self.args.data
    local camp = self.world.DataSystem:GetCamp(data.uid)


    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo,data.info.id)
    cardInfo.item:SetState(BattleDefine.CardState.control)

    local endPos = mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.GetCardLibNodePos,camp)

    local anim = {}
    anim.tbScaleAnim = ScaleAnim.New(cardInfo.item.transform, 0, self.scaleTime)
    anim.tbRotationAnim = RotationZAnim.New(cardInfo.item.transform, 0, self.rotateTime)
    anim.tbMoveXAnim    = MoveXAnim.New(cardInfo.item.transform, endPos.x, self.moveTime)
    anim.tbMoveYAnim    = MoveYAnim.New(cardInfo.item.transform, endPos.y, self.moveTime)

    anim.tbAnim = ParallelAnim.New({ anim.tbScaleAnim, anim.tbRotationAnim, anim.tbMoveXAnim, anim.tbMoveYAnim })
    anim.tbAnim:SetEase(self.easeType)

    anim.tbAnim:SetComplete(self:ToFunc("MoveComplete"))
    anim.tbAnim:Play()


   -- cardInfo.item.transform:SetPosition(endPos.x, endPos.y, endPos.z)

    self.moveAnim = anim.tbAnim
end

function CardMoveHandToLibraryTB:MoveComplete(args)
    local data = self.args.data

    mod.BattleFacade:SendEvent(BattleHandCardView.Event.RemoveHandCard,data.uid,data.info.id)

    -- 数据刷新
    --self.world.DataSystem:RemoveCardInfo(data.uid, data.oldArea, data.info.id)
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    -- mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshCardHandNum)
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardLibraryNum)
    self:BehaviorComplete()
end

function CardMoveHandToLibraryTB:OnUpdate(deltaTime)
end
