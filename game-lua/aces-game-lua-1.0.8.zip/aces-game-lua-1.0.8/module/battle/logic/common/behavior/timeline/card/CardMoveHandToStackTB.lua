CardMoveHandToStackTB = BaseClass("CardMoveHandToStackTB", TimelineBehaviorBase)

function CardMoveHandToStackTB:__Init()
end

function CardMoveHandToStackTB:__Delete()

end

function CardMoveHandToStackTB:OnStart()
--     LogTable("手牌移动到堆叠区", self.args)
    local data   = self.args.data

    mod.BattleFacade:SendEvent(BattleHandCardView.Event.RemoveHandCard,data.uid,data.info.id)


    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    -- mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshCardHandNum)
    -- 新增堆叠走单独的协议
    self:BehaviorComplete()
end

function CardMoveHandToStackTB:OnUpdate(deltaTime)
end
