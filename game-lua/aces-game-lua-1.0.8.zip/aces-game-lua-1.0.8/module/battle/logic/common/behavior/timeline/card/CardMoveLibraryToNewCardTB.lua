CardMoveLibraryToNewCardTB = BaseClass("CardMoveLibraryToNewCardTB ", TimelineBehaviorBase)

function CardMoveLibraryToNewCardTB:__Init()
end

function CardMoveLibraryToNewCardTB:__Delete()
end

function CardMoveLibraryToNewCardTB:OnStart()
    local data   = self.args.data
    --local camp   = isSelf and BattleDefine.Camp.self or BattleDefine.Camp.enemy

    -- 数据刷新
    --self.world.DataSystem:RemoveCardInfo(data.uid, data.oldArea, data.info.id)
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardLibraryNum)
    self:BehaviorComplete()
end

function CardMoveLibraryToNewCardTB:OnUpdate(deltaTime)

end
