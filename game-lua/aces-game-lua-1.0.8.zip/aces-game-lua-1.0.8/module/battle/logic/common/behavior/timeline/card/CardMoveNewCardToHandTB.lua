CardMoveNewCardToHandTB = BaseClass("CardMoveNewCardToHandTB ", TimelineBehaviorBase)

function CardMoveNewCardToHandTB:__Init()
    -- 使用统一的时间配置
    local config = CardMoveTiming.GetMoveTimeConfig(BattleDefine.CardAreaDef.hand)
    self.moveTime = config.moveTime
    self.scaleTime = config.scaleTime
    self.rotateTime = config.rotateTime
    self.easeType = CardMoveTiming.GetEaseType(BattleDefine.CardAreaDef.hand)
end

function CardMoveNewCardToHandTB:__Delete()
    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end
end

function CardMoveNewCardToHandTB:OnStart()
    local data   = self.args.data
    local camp = self.world.DataSystem:GetCamp(data.uid)

    -- 数据刷新
    --self.world.DataSystem:RemoveCardInfo(data.uid, data.oldArea, data.info.id)
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    mod.BattleFacade:SendEvent(BattleHandCardView.Event.AddHandCard,data.uid,data.info,false,false)
 

    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo,data.info.id)



    -- TODO 准备区现在没有位置，所以暂时用牌库的位置
    local startPos = mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.GetCardLibNodePos,camp)
    cardInfo.item.tposeTrans:SetPosition(startPos.x, startPos.y, startPos.z)
    cardInfo.item:SetState(BattleDefine.CardState.control)

    local transInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardTrans,camp,cardInfo.item.index)

    local endPos = Vector2(transInfo.x, transInfo.y)

    cardInfo.item.tposeTrans:SetLocalScale(0, 0, 0)

    local anim = {}
    anim.tbScaleAnim = ScaleAnim.New(cardInfo.item.tposeTrans, BattleDefine.CardScale.scene.x, self.scaleTime)
    anim.tbRotationAnim = RotationZAnim.New(cardInfo.item.tposeTrans, transInfo.angle, self.rotateTime)
    anim.tbMoveAnim = MoveAnchorAnim.New(cardInfo.item.tposeTrans, Vector2(0,0), self.moveTime)
    anim.tbScaleAnim:SetTimeScale(true)
    anim.tbRotationAnim:SetTimeScale(true)
    anim.tbMoveAnim:SetTimeScale(true)
    anim.tbAnim = ParallelAnim.New({ anim.tbScaleAnim, anim.tbRotationAnim, anim.tbMoveAnim })
    anim.tbAnim:SetEase(self.easeType)

    anim.tbAnim:SetComplete(self:ToFunc("MoveComplete"), { cardData = cardInfo.item.data})
    anim.tbAnim:Play()

    self.moveAnim = anim.tbAnim
end

function CardMoveNewCardToHandTB:MoveComplete(args)
    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo,self.args.data.info.id)
    cardInfo.item:SetState(BattleDefine.CardState.normal)

    -- mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshCardHandNum)
    self:BehaviorComplete()
end
function CardMoveNewCardToHandTB:OnUpdate(deltaTime)

end
