CardMoveNewCardToShuffleTB = BaseClass("CardMoveNewCardToShuffleTB ", TimelineBehaviorBase)

function CardMoveNewCardToShuffleTB:__Init()
end

function CardMoveNewCardToShuffleTB:__Delete()
end

function CardMoveNewCardToShuffleTB:OnStart()
    local data   = self.args.data
    --local camp   = isSelf and BattleDefine.Camp.self or BattleDefine.Camp.enemy

    -- 数据刷新
    --self.world.DataSystem:RemoveCardInfo(data.uid, data.oldArea, data.info.id)
    --self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)
    self:BehaviorComplete()
end

function CardMoveNewCardToShuffleTB:OnUpdate(deltaTime)

end
