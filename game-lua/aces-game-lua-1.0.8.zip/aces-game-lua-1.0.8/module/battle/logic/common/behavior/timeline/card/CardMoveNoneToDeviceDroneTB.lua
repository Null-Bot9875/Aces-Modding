CardMoveNoneToDeviceDroneTB = BaseClass("CardMoveNoneToDeviceDroneTB", TimelineBehaviorBase)

function CardMoveNoneToDeviceDroneTB:__Init()
end

function CardMoveNoneToDeviceDroneTB:__Delete()

end

function CardMoveNoneToDeviceDroneTB:OnStart()
--     LogTable("卡牌移动，无=>无人机", self.args)
    local data = self.args.data
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)
    self:BehaviorComplete()
end

function CardMoveNoneToDeviceDroneTB:OnUpdate(deltaTime)
end
