CardMoveNoneToHandTB = BaseClass("CardMoveNoneToHandTB", TimelineBehaviorBase)

function CardMoveNoneToHandTB:__Init()
    -- 创造卡牌表现配置
    self.burstTime = 0.12      -- 爆发放大时间（更短更爆）
    self.settleTime = 0.18     -- 稳定缩回时间
    self.initScale = 0.5       -- 初始缩放（足够可见）
    self.burstScale = 1.3      -- 爆发缩放（有力）
    self.burstEase = DG.Tweening.Ease.OutQuad       -- 爆发缓动（快速有力）
    self.settleEase = DG.Tweening.Ease.OutQuart     -- 稳定缓动（干脆落定，无软塌）
end

function CardMoveNoneToHandTB:__Delete()
    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end
end

function CardMoveNoneToHandTB:OnStart()
    local data = self.args.data
    local camp = self.world.DataSystem:GetCamp(data.uid)

    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    if self.world.DataSystem:IsRoleUid(data.uid) then
        AudioManager.Instance:PlayScene("hand_card_1")
    end

    -- 添加手牌到视图
    mod.BattleFacade:SendEvent(BattleHandCardView.Event.AddHandCard, data.uid, data.info, true, false)
    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo, data.info.id)
    cardInfo.item:SetState(BattleDefine.CardState.control)

    -- 获取手牌最终位置和角度
    local transInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardTrans, camp, cardInfo.item.index)

    -- 设置初始状态：直接在手牌位置，小缩放，立即可见
    cardInfo.item.tposeTrans:SetLocalEulerAngles(0, 0, transInfo.angle)
    cardInfo.item.tposeTrans:SetAnchoredPosition(0, 0)
    
    local normalScale = BattleDefine.CardScale.scene.x
    cardInfo.item.tposeTrans:SetLocalScale(
        normalScale * self.initScale,
        normalScale * self.initScale,
        normalScale * self.initScale
    )
    local anim = {}

    -- 第一阶段：爆发放大（卡牌立即可见，快速弹出）
    anim.burstScaleAnim = ScaleAnim.New(cardInfo.item.tposeTrans, normalScale * self.burstScale, self.burstTime)
    anim.burstScaleAnim:SetEase(self.burstEase)
    anim.burstScaleAnim:SetTimeScale(true)

    -- 第二阶段：干脆落定到正常大小（无软塌）
    anim.settleAnim = ScaleAnim.New(cardInfo.item.tposeTrans, normalScale, self.settleTime)
    anim.settleAnim:SetEase(self.settleEase)
    anim.settleAnim:SetTimeScale(true)

    -- 组合两阶段动画
    anim.fullAnim = SequenceAnim.New({ anim.burstScaleAnim, anim.settleAnim })
    anim.fullAnim:SetComplete(self:ToFunc("MoveComplete"))
    anim.fullAnim:Play()

    self.moveAnim = anim.fullAnim
end

function CardMoveNoneToHandTB:MoveComplete(args)
    local cardInfo = mod.BattleFacade:SendEvent(BattleHandCardView.Event.GetHandCardInfo,self.args.data.info.id)
    cardInfo.item:SetState(BattleDefine.CardState.normal)

    -- mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshCardHandNum)
    self:BehaviorComplete()
end

function CardMoveNoneToHandTB:OnUpdate(deltaTime)
end
