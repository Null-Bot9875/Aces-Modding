CardMoveQueueCarsToDiscardTB = BaseClass("CardMoveQueueCarsToDiscardTB", CardMoveTBBase)

function CardMoveQueueCarsToDiscardTB:__Init()
    self.tempStackItem = nil
    self.rtUIObject = nil
    self.counterEffect = nil
    self.hideStackCardTimer = nil
    self.doneTimer = nil
end

function CardMoveQueueCarsToDiscardTB:__Delete()
    mod.BattleFacade:SendEvent(BattleTempCardView.Event.RemoveTempCard, self.tempStackItemId)
    if self.tempStackItem then
        self.tempStackItem:Destroy()
        self.tempStackItem = nil
    end

    if self.counterEffect then
        self.counterEffect:Delete()
        self.counterEffect = nil
    end

    if self.rtUIObject then
        self.rtUIObject:Delete()
        self.rtUIObject = nil
    end

    if self.hideStackCardTimer then
        self.world.TimerSystem:RemoveTimer(self.hideStackCardTimer)
        self.hideStackCardTimer = nil
    end

    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end

    if self.moveAnim then
        self.moveAnim:Delete()
        self.moveAnim = nil
    end

    if self.delayTimer then
        self.world.TimerSystem:RemoveTimer(self.delayTimer)
        self.delayTimer = nil
    end
end

function CardMoveQueueCarsToDiscardTB:OnStart()
--     LogTable("卡牌移动，储卡=>弃牌", self.args)
    local data = self.args.data
    
    -- 创建临时堆叠卡牌用于显示反制特效
    local camp = self.world.DataSystem:GetCamp(data.uid)
    local cardInfo = data.info
    self.tempStackItem,self.tempStackItemId = mod.BattleFacade:SendEvent(BattleTempCardView.Event.AddTempCard, camp, BattleDefine.CardAreaDef.queueCars, cardInfo.cardId)
    self.tempStackItem.transform.localScale = Vector3.one * BattleDefine.CardScale.stack.x

    local endPos = mod.BattleFacade:SendEvent(BattleTempCardView.Event.GetTempCardPos, camp, BattleDefine.CardAreaDef.stack)
    local anim = self:CreateMoveAnimation(self.tempStackItem,endPos,Vector3.one * BattleDefine.CardScale.stack.x)
    anim:SetComplete(self:ToFunc("StartCounterEffect"))
    anim:Play()
    self.moveAnim = anim
    -- 开始反制溶解流程
    -- self:StartCounterEffect()
end

function CardMoveQueueCarsToDiscardTB:StartCounterEffect()
    if self.delayTimer then
        self.world.TimerSystem:RemoveTimer(self.delayTimer)
        self.delayTimer = nil
    end

    self.delayTimer = self.world.TimerSystem:AddTimer(1, 0.3, self:ToFunc("OnStartCounterEffect"))
    self.delayTimer:SetScale(true)
end

function CardMoveQueueCarsToDiscardTB:OnStartCounterEffect()
    -- 创建RT纹理对象
    local setting = {}
    setting.textureWidth = 510
    setting.textureHeight = 710
    setting.uiObject = self.tempStackItem.gameObject

    self.rtUIObject = RTUIObject.New()
    self.rtUIObject:Show(setting)

    -- 创建反制特效
    local counterEffectSetting = {}
    counterEffectSetting.assetId = "ui_battle_card_be_counter"
    counterEffectSetting.parent = self.tempStackItem.transform
    counterEffectSetting.pos = Vector2(0, 0)
    counterEffectSetting.scale = 1000
    counterEffectSetting.order = self.tempStackItem:GetOrder()
    counterEffectSetting.onLoad = self:ToFunc("EffectLoaded")

    self.counterEffect = UIEffect.New()
    self.counterEffect:Init(counterEffectSetting)
    self.counterEffect:Play()

    -- 播放反制音效
    AudioManager.Instance:PlayUI("cancel_1")
end

function CardMoveQueueCarsToDiscardTB:EffectLoaded(effect)
    -- 将卡牌纹理应用到反制特效材质上
    local render = self.counterEffect.effect.transform:Find("node"):GetChild(0).gameObject:GetComponent(Renderer)
    render.material:SetTexture("_Maintex", self.rtUIObject.texture)

    -- 下一帧隐藏原始卡牌显示
    self.hideStackCardTimer = self.world.TimerSystem:AddTimerByNextFrame(1, 0, self:ToFunc("HideStackCardTimer"))
end

function CardMoveQueueCarsToDiscardTB:HideStackCardTimer()
    self.hideStackCardTimer = nil
    
    -- 隐藏临时堆叠卡牌的原始显示
    if self.tempStackItem then
        self.tempStackItem:Find("tpose").gameObject:SetActive(false)
    end

    -- 等待反制特效播放完成
    self.doneTimer = self.world.TimerSystem:AddTimer(1, self.counterEffect:GetDuration() * 0.001, self:ToFunc("TimerDone"))
    self.doneTimer:SetScale(true)
end

function CardMoveQueueCarsToDiscardTB:TimerDone()
    self.doneTimer = nil
    self:MoveComplete()
end

function CardMoveQueueCarsToDiscardTB:MoveComplete()
    local data = self.args.data
    local conf = Config.Get("card_def", "config", "cardId", data.info.cardId)

    -- 将卡牌添加到弃牌区
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    -- 如果卡牌有桌面费用，需要添加到手牌
    if conf.extend[BattleDefine.CardExtendType.deskCost] ~= nil then
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.AddHandCard, data.uid, data.info, true, false)
    end

    -- 刷新弃牌区数量显示
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardDiscardNum)
    
    self:BehaviorComplete()
end

function CardMoveQueueCarsToDiscardTB:OnUpdate(deltaTime)
end
