CardMoveQueueCarsToStackTB = BaseClass("CardMoveQueueCarsToStackTB", CardMoveTBBase)

function CardMoveQueueCarsToStackTB:__Init()
    self.completeCb = self:ToFunc("OnMoveComplete")
end

function CardMoveQueueCarsToStackTB:__Delete()

end

function CardMoveQueueCarsToStackTB:OnStart()
--     Log(string.format("卡牌移动，储卡 -> 堆叠"))

    local data = self.args.data
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)
    mod.BattleFacade:SendEvent(BattleChainQueueView.Event.RefreshChainQueue)
    self:ExecuteTempMove(data.oldArea, data.area)
end

function CardMoveQueueCarsToStackTB:OnMoveComplete()
    self:BehaviorComplete()
end


function CardMoveQueueCarsToStackTB:OnUpdate(deltaTime)
end
