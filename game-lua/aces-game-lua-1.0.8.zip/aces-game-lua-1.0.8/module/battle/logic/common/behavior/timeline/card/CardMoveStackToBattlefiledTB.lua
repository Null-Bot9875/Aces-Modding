CardMoveStackToBattlefiledTB = BaseClass("CardMoveStackToBattlefiledTB", TimelineBehaviorBase)

function CardMoveStackToBattlefiledTB:__Init()
end

function CardMoveStackToBattlefiledTB:__Delete()

end

function CardMoveStackToBattlefiledTB:OnStart()
    -- TODO 堆叠到战场的卡牌表现
    self:BehaviorComplete()
end

function CardMoveStackToBattlefiledTB:OnUpdate(deltaTime)
end
