CardMoveStackToConsumeTB = BaseClass("CardMoveStackToConsumeTB", TimelineBehaviorBase)

function CardMoveStackToConsumeTB:__Init()
    self.moveAnim = nil
end

function CardMoveStackToConsumeTB:__Delete()
    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end
end

function CardMoveStackToConsumeTB:OnStart()
    local data = self.args.data
--     LogTable("卡牌移动，堆叠=>废弃",data)


    --已溶解，无需移动
    -- local camp = self.world.DataSystem:GetCamp(data.uid)

    -- local stackInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackInfo,data.oldPos)

    -- local endPos = mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.GetConsumeNodePos,camp)
    
    -- local scalePosAnim = ScaleAnim.New(stackInfo.item.transform,0,0.3)
    -- local movePosXAnim  = MoveXAnim.New(stackInfo.item.transform,endPos.x,0.3)
    -- local movePosYAnim  = MoveYAnim.New(stackInfo.item.transform,endPos.y,0.3)

    -- self.moveAnim = ParallelAnim.New({scalePosAnim,movePosXAnim,movePosYAnim})
    -- self.moveAnim:SetComplete(self:ToFunc("MoveComplete"))
    -- self.moveAnim:Play()
    --end

    mod.BattleFacade:SendEvent(BattleStackCardView.Event.RemoveStackLines,data.oldPos)
    self:MoveComplete()
end

function CardMoveStackToConsumeTB:MoveComplete()
    local data = self.args.data
    local conf = Config.Get("card_def", "config", "cardId", data.info.cardId)

    --local camp = self.world.DataSystem:GetCamp(data.uid)
    -- Stack 只有在堆叠是卡牌的时候才会有信息，其他时候走RemoveStackActionAB
    -- mod.BattleFacade:SendEvent(BattleStackCardView.Event.RemoveStack,data.oldPos)
    --self.world.StackSystem:RemoveStack(data.oldPos)
    -- self.world.DataSystem:RemoveStackInfo(data.oldPos)
    --self.world.MixedSystem:CheckEnemyRoleInfo()

    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)


    if conf.extend[BattleDefine.CardExtendType.scrapCost] ~= nil then
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.AddHandCard,data.uid,data.info,true,false)
    end
    
    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardConsumeNum)
    self:BehaviorComplete()
end

function CardMoveStackToConsumeTB:OnUpdate(deltaTime)
end
