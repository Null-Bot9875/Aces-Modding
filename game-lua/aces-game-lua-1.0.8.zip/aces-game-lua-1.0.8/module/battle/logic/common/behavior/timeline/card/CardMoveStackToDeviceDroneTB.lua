CardMoveStackToDeviceDroneTB = BaseClass("CardMoveStackToDeviceDroneTB", TimelineBehaviorBase)

function CardMoveStackToDeviceDroneTB:__Init()
end

function CardMoveStackToDeviceDroneTB:__Delete()

end

function CardMoveStackToDeviceDroneTB:OnStart()
--     LogTable("卡牌移动，堆叠=>无人机", self.args)
    
    local data = self.args.data
    -- 表现上的堆叠卡牌的移除会在结束特效之后，数据上的依赖卡牌移动的包
    local conf = Config.Get("card_def", "config", "cardId", data.info.cardId)
    -- mod.BattleFacade:SendEvent(BattleStackCardView.Event.RemoveStack,data.oldPos)
    -- self.world.DataSystem:RemoveStackInfo(data.oldPos)
    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    if conf.extend[BattleDefine.CardExtendType.deskCost] ~= nil then
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.AddHandCard,data.uid,data.info,true,false)
    end

    self:BehaviorComplete()
end

function CardMoveStackToDeviceDroneTB:OnUpdate(deltaTime)
end
