CardMoveStackToDiscardTB = BaseClass("CardMoveStackToDiscardTB", TimelineBehaviorBase)

function CardMoveStackToDiscardTB:__Init()
    self.moveAnim = nil

    self.rtUIObject = nil
    self.counterEffect = nil
    self.hideStackCardTimer = nil
    self.doneTimer = nil
end

function CardMoveStackToDiscardTB:__Delete()
    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end

    if self.counterEffect then
        self.counterEffect:Delete()
        self.counterEffect = nil
    end

    if self.rtUIObject then
        self.rtUIObject:Delete()
        self.rtUIObject = nil
    end

    if self.hideStackCardTimer then
        self.world.TimerSystem:RemoveTimer(self.hideStackCardTimer)
        self.hideStackCardTimer = nil
    end

    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function CardMoveStackToDiscardTB:OnStart()
    local data = self.args.data
--     LogTable("卡牌移动，堆叠=>弃牌", data)

    local stackInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackInfo,data.oldPos)

    mod.BattleFacade:SendEvent(BattleStackCardView.Event.RemoveStackLines,data.oldPos)
    if data.reason == BattleDefine.ReasonType.counter then
        --stackInfo.item:PlayDissolve(self:ToFunc("MoveComplete"))
        local setting = {}
        setting.textureWidth = 510
        setting.textureHeight = 710--757.55
        setting.uiObject = stackInfo.item.gameObject

        self.rtUIObject = RTUIObject.New()
        self.rtUIObject:Show(setting)


        local counterEffectSetting = {}
        counterEffectSetting.assetId = "ui_battle_card_be_counter"
        counterEffectSetting.parent = stackInfo.item.transform
        counterEffectSetting.pos = Vector2(0,0)
        counterEffectSetting.scale = 1000
        counterEffectSetting.order = stackInfo.item:GetOrder()
        counterEffectSetting.onLoad = self:ToFunc("EffectLoaded")

        self.counterEffect = UIEffect.New()
        self.counterEffect:Init(counterEffectSetting)
        self.counterEffect:Play()

        AudioManager.Instance:PlayUI("cancel_1")
    else
        --已溶解，无需移动
        -- local endPos = mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.GetDiscardNodePos,camp)

        -- local scalePosAnim = ScaleAnim.New(stackInfo.item.transform, 0, 0.3)
        -- local movePosXAnim = MoveXAnim.New(stackInfo.item.transform, endPos.x, 0.3)
        -- local movePosYAnim = MoveYAnim.New(stackInfo.item.transform, endPos.y, 0.3)

        -- self.moveAnim      = ParallelAnim.New({ scalePosAnim, movePosXAnim, movePosYAnim })
        -- self.moveAnim:SetComplete(self:ToFunc("MoveComplete"))
        -- self.moveAnim:Play()
        --end

        self:MoveComplete()
    end
end

function CardMoveStackToDiscardTB:EffectLoaded(effect)
    local render = self.counterEffect.effect.transform:Find("node"):GetChild(0).gameObject:GetComponent(Renderer)
    render.material:SetTexture("_Maintex",self.rtUIObject.texture)

    self.hideStackCardTimer = self.world.TimerSystem:AddTimerByNextFrame(1,0,self:ToFunc("HideStackCardTimer"))
end

function CardMoveStackToDiscardTB:HideStackCardTimer()
    self.hideStackCardTimer = nil
    local stackInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackInfo,self.args.data.oldPos)
    stackInfo.item:Find("tpose").gameObject:SetActive(false)

    self.doneTimer = self.world.TimerSystem:AddTimer(1,self.counterEffect:GetDuration() * 0.001,self:ToFunc("TimerDone"))
    self.doneTimer:SetScale(true)
end

function CardMoveStackToDiscardTB:TimerDone()
    self.doneTimer = nil
    self:MoveComplete()
end

function CardMoveStackToDiscardTB:MoveComplete()
    local data = self.args.data
    local conf = Config.Get("card_def", "config", "cardId", data.info.cardId)

    -- 若该堆叠正在由溶解 AB（StackEndResultAB/RemoveStackActionAB）处理，不在此处移除，由溶解 AB 在 TimerDone 时统一移除，避免溶解未播完就被移掉
    local isDissolving = self.world.StateSystem:GetCacheInfo(string.format("stack_dissolve_%s", data.oldPos))
    local stackInfo = self.world.DataSystem:GetStackInfo(data.oldPos)
    if stackInfo and not isDissolving then
        mod.BattleFacade:SendEvent(BattleStackCardView.Event.RemoveStack, data.oldPos)
        self.world.DataSystem:RemoveStackInfo(data.oldPos)
    end

    self.world.DataSystem:AddCardInfo(data.uid, data.area, data.info)

    if conf.extend[BattleDefine.CardExtendType.deskCost] ~= nil then
        mod.BattleFacade:SendEvent(BattleHandCardView.Event.AddHandCard,data.uid,data.info,true,false)
    end

    mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardDiscardNum)
    self:BehaviorComplete()
end

function CardMoveStackToDiscardTB:OnUpdate(deltaTime)
end
