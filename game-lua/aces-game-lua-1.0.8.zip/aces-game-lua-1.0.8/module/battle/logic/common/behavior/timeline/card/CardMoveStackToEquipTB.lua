CardMoveStackToEquipTB = BaseClass("CardMoveStackToEquipTB", TimelineBehaviorBase)

function CardMoveStackToEquipTB:__Init()
    self.moveAnim = nil
end

function CardMoveStackToEquipTB:__Delete()
    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end
end

function CardMoveStackToEquipTB:OnStart()
    local data = self.args.data
--     LogTable("卡牌移动，堆叠=>装备槽",data)

    --已溶解，无需移动
    -- local stackInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackInfo,data.oldPos)

    -- local pos = mod.BattleFacade:SendEvent(BattleSlotInfoView.Event.GetSlotPosBySlotUid,data.uid, data.areaPos)


    -- local scalePosAnim = ScaleAnim.New(stackInfo.item.transform,0,0.3)
    -- local movePosXAnim  = MoveXAnim.New(stackInfo.item.transform,pos.x,0.3)
    -- local movePosYAnim  = MoveYAnim.New(stackInfo.item.transform,pos.y,0.3)

    -- self.moveAnim = ParallelAnim.New({scalePosAnim,movePosXAnim,movePosYAnim})
    -- self.moveAnim:SetComplete(self:ToFunc("MoveComplete"))
    -- self.moveAnim:Play()
    --end

    mod.BattleFacade:SendEvent(BattleStackCardView.Event.RemoveStackLines,data.oldPos)
    self:MoveComplete()
end

function CardMoveStackToEquipTB:MoveComplete()
    local data = self.args.data
    -- Stack 只有在堆叠是卡牌的时候才会有信息，其他时候走RemoveStackActionAB
    -- mod.BattleFacade:SendEvent(BattleStackCardView.Event.RemoveStack,data.oldPos)
    -- self.world.DataSystem:RemoveStackInfo(data.oldPos)
    --self.world.MixedSystem:CheckEnemyRoleInfo()

    self:BehaviorComplete()
end

function CardMoveStackToEquipTB:OnUpdate(deltaTime)
end
