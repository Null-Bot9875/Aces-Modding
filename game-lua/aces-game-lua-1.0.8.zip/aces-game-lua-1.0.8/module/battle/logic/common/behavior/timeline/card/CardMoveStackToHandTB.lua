CardMoveStackToHandTB = BaseClass("CardMoveStackToHandTB", TimelineBehaviorBase)

function CardMoveStackToHandTB:__Init()
end

function CardMoveStackToHandTB:__Delete()

end

function CardMoveStackToHandTB:OnStart()
    -- TODO 堆叠回到手上
    self:BehaviorComplete()
end

function CardMoveStackToHandTB:OnUpdate(deltaTime)
end
