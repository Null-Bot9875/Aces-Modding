-- 卡牌移动行为基类，封装各种卡牌区域移动的共同功能
CardMoveTBBase = BaseClass("CardMoveTBBase", TimelineBehaviorBase)

function CardMoveTBBase:__Init()
    -- 使用统一的时间配置
    self.moveTime = CardMoveTiming.MOVE_TIME.NORMAL
    self.scaleTime = CardMoveTiming.SCALE_TIME.NORMAL
    self.rotateTime = CardMoveTiming.ROTATE_TIME.NORMAL
    -- 移动的卡片对象
    self.moveCardItem = nil
    -- 动画对象
    self.moveAnim = nil
    -- 缓动类型
    self.easeType = Ease.EaseOutQuart

    self.completeCb = nil
end

function CardMoveTBBase:__Delete()
    -- 清理动画资源
    if self.moveAnim then
        self.moveAnim:Destroy()
        self.moveAnim = nil
    end

    -- 清理临时创建的卡牌对象
    mod.BattleFacade:SendEvent(BattleTempCardView.Event.RemoveTempCard, self.moveCardItem)
end

-- 刷新单个区域UI的函数
function CardMoveTBBase:RefreshSingleAreaUI(areaType)
    if areaType == BattleDefine.CardAreaDef.library then
        mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardLibraryNum)
    elseif areaType == BattleDefine.CardAreaDef.consume then
        mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardConsumeNum)
    elseif areaType == BattleDefine.CardAreaDef.discard then
        mod.BattleFacade:SendEvent(BattleCarrierCardAreaView.Event.RefreshCardDiscardNum)
    end
end

-- 根据区域类型获取位置
function CardMoveTBBase:GetPositionByAreaType(camp, areaType)
    -- 获取区域位置
    local pos = mod.BattleFacade:SendEvent(BattleTempCardView.Event.GetTempCardPos, camp, areaType)

    if pos then
        return pos
    end

    return Vector3.zero
end

-- 创建临时卡牌项目
function CardMoveTBBase:CreateTempCardItem(uid, cardInfo, startPos)
    local camp = self.world.DataSystem:GetCamp(uid)
    local item = mod.BattleFacade:SendEvent(BattleTempCardView.Event.AddTempCard, camp, cardInfo.area, cardInfo.cardId)
    if item then
        item.transform:SetPosition(startPos.x, startPos.y, startPos.z)
        item.transform:SetLocalScale(BattleDefine.CardScale.scene.x, BattleDefine.CardScale.scene.y,
            BattleDefine.CardScale.scene.z)
        self.moveCardItem = item
    end
    return item
end

-- 创建移动动画
function CardMoveTBBase:CreateMoveAnimation(cardItem, endPos, endScale)
    local anim = {}

    -- 使用统一的时间配置创建动画
    anim.tbScaleAnim = ScaleAnim.New(cardItem.transform, endScale, self.scaleTime)
    anim.tbRotationAnim = RotationZAnim.New(cardItem.transform, 0, self.rotateTime)
    anim.tbMoveXAnim = MoveXAnim.New(cardItem.transform, endPos.x, self.moveTime)
    anim.tbMoveYAnim = MoveYAnim.New(cardItem.transform, endPos.y, self.moveTime)
    -- 受战斗倍速影响
    anim.tbScaleAnim:SetTimeScale(true)
    anim.tbRotationAnim:SetTimeScale(true)
    anim.tbMoveXAnim:SetTimeScale(true)
    anim.tbMoveYAnim:SetTimeScale(true)
    anim.tbAnim = ParallelAnim.New({ anim.tbScaleAnim, anim.tbRotationAnim, anim.tbMoveXAnim, anim.tbMoveYAnim })
    anim.tbAnim:SetEase(self.easeType)

    return anim.tbAnim
end

-- 动画移动完成后的基础处理
function CardMoveTBBase:OnMoveAnimComplete()
    self:RefreshSingleAreaUI(self.args.data.area)

    if self.completeCb then
        self.completeCb()
        self.completeCb = nil
    end
end

-- 根据移动类型设置时间配置
function CardMoveTBBase:SetTimingByMoveType(fromArea, toArea)
    local config = CardMoveTiming.GetMoveTimeConfig(toArea)
    
    self.moveTime = config.moveTime
    self.scaleTime = config.scaleTime
    self.rotateTime = config.rotateTime
    self.easeType = CardMoveTiming.GetEaseType(toArea)
end

-- 执行标准移动流程 (创建临时卡牌并设置动画)
function CardMoveTBBase:ExecuteTempMove(fromAreaType, toAreaType)
    local data = self.args.data
    local uid = data.uid
    local camp = self.world.DataSystem:GetCamp(uid)

    -- 根据移动类型设置时间配置
    self:SetTimingByMoveType(fromAreaType, toAreaType)

    -- 获取起始位置和目标位置
    local startPos = self:GetPositionByAreaType(camp, fromAreaType)
    local endPos = self:GetPositionByAreaType(camp, toAreaType)

    -- 创建临时卡牌并设置动画
    local item = self:CreateTempCardItem(uid, data.info, startPos)
    local anim = self:CreateMoveAnimation(item, endPos)
    anim:SetComplete(self:ToFunc("OnMoveAnimComplete"))
    anim:Play()
    self.moveAnim = anim
end

function CardMoveTBBase:OnStart()
    -- 基类默认不做任何处理
end

function CardMoveTBBase:OnUpdate(deltaTime)
    -- 基类默认不做任何处理
end
