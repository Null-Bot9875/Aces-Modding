-- 卡牌移动动画时间常量定义
-- 统一管理所有卡牌移动相关的时间配置，确保节奏一致

CardMoveTiming = {}

-- 基础移动时间配置
CardMoveTiming.MOVE_TIME = {
    -- 快速移动（如新卡到手牌、装备到手牌等）
    FAST = 0.15,
    -- 标准移动（大部分卡牌移动）
    NORMAL = 0.25,
    -- 慢速移动（如长距离移动、特殊效果等）
    SLOW = 0.35,
    -- 极慢移动（如溶解、反制等特殊效果）
    VERY_SLOW = 0.5
}

-- 缩放动画时间配置
CardMoveTiming.SCALE_TIME = {
    -- 快速缩放（如新卡出现）
    FAST = 0.1,
    -- 标准缩放
    NORMAL = 0.2,
    -- 慢速缩放（如溶解效果）
    SLOW = 0.3
}

-- 旋转动画时间配置
CardMoveTiming.ROTATE_TIME = {
    -- 快速旋转
    FAST = 0.15,
    -- 标准旋转
    NORMAL = 0.25,
    -- 慢速旋转
    SLOW = 0.35
}

-- 延迟时间配置
CardMoveTiming.DELAY_TIME = {
    -- 短延迟
    SHORT = 0.1,
    -- 标准延迟
    NORMAL = 0.2,
    -- 长延迟
    LONG = 0.3
}

-- 根据移动类型获取时间配置
function CardMoveTiming.GetMoveTimeConfig(moveType)
    local configs = {
        -- 手牌相关移动
        [BattleDefine.CardAreaDef.hand] = {
            moveTime = CardMoveTiming.MOVE_TIME.NORMAL,
            scaleTime = CardMoveTiming.SCALE_TIME.NORMAL,
            rotateTime = CardMoveTiming.ROTATE_TIME.NORMAL
        },
        -- 牌库相关移动
        [BattleDefine.CardAreaDef.library] = {
            moveTime = CardMoveTiming.MOVE_TIME.NORMAL,
            scaleTime = CardMoveTiming.SCALE_TIME.NORMAL,
            rotateTime = CardMoveTiming.ROTATE_TIME.NORMAL
        },
        -- 弃牌区相关移动
        [BattleDefine.CardAreaDef.discard] = {
            moveTime = CardMoveTiming.MOVE_TIME.NORMAL,
            scaleTime = CardMoveTiming.SCALE_TIME.NORMAL,
            rotateTime = CardMoveTiming.ROTATE_TIME.NORMAL
        },
        -- 废弃区相关移动
        [BattleDefine.CardAreaDef.consume] = {
            moveTime = CardMoveTiming.MOVE_TIME.FAST,
            scaleTime = CardMoveTiming.SCALE_TIME.FAST,
            rotateTime = CardMoveTiming.ROTATE_TIME.FAST
        },
        -- 装备槽相关移动
        [BattleDefine.CardAreaDef.equip] = {
            moveTime = CardMoveTiming.MOVE_TIME.NORMAL,
            scaleTime = CardMoveTiming.SCALE_TIME.NORMAL,
            rotateTime = CardMoveTiming.ROTATE_TIME.NORMAL
        },
        -- 无人机相关移动
        [BattleDefine.CardAreaDef.device_drone] = {
            moveTime = CardMoveTiming.MOVE_TIME.NORMAL,
            scaleTime = CardMoveTiming.SCALE_TIME.NORMAL,
            rotateTime = CardMoveTiming.ROTATE_TIME.NORMAL
        },
        -- 堆叠相关移动
        [BattleDefine.CardAreaDef.stack] = {
            moveTime = CardMoveTiming.MOVE_TIME.SLOW,
            scaleTime = CardMoveTiming.SCALE_TIME.SLOW,
            rotateTime = CardMoveTiming.ROTATE_TIME.SLOW
        },
        -- 储卡区相关移动
        [BattleDefine.CardAreaDef.queueCars] = {
            moveTime = CardMoveTiming.MOVE_TIME.SLOW,
            scaleTime = CardMoveTiming.SCALE_TIME.SLOW,
            rotateTime = CardMoveTiming.ROTATE_TIME.SLOW
        }
    }
    
    return configs[moveType] or {
        moveTime = CardMoveTiming.MOVE_TIME.NORMAL,
        scaleTime = CardMoveTiming.SCALE_TIME.NORMAL,
        rotateTime = CardMoveTiming.ROTATE_TIME.NORMAL
    }
end

-- 根据移动类型获取移动时间（简化接口）
function CardMoveTiming.GetMoveTime(moveType)
    local config = CardMoveTiming.GetMoveTimeConfig(moveType)
    return config.moveTime
end


-- 获取缓动类型
function CardMoveTiming.GetEaseType(moveType)
    local easeMap = {
        [BattleDefine.CardAreaDef.hand] = Ease.EaseOutQuart,
        [BattleDefine.CardAreaDef.library] = Ease.EaseOutQuart,
        [BattleDefine.CardAreaDef.discard] = Ease.EaseOutCubic,
        [BattleDefine.CardAreaDef.consume] = Ease.EaseOutCubic,
        [BattleDefine.CardAreaDef.equip] = Ease.EaseOutQuart,
        [BattleDefine.CardAreaDef.device_drone] = Ease.EaseOutQuart,
        [BattleDefine.CardAreaDef.stack] = Ease.EaseInOutQuart,
        [BattleDefine.CardAreaDef.queueCars] = Ease.EaseInOutQuart
    }
    
    return easeMap[moveType] or Ease.EaseOutQuart
end
