CostSelectTB = BaseClass("CostSelectTB", TimelineBehaviorBase)

function CostSelectTB:__Init()
    self.timelineBehavior = nil

    self.waitSelectCostInfos = nil
    self.selectIndex = nil

    self.infoIndex = 1
    self.result = {}
    self.result.data = {}
end

function CostSelectTB:__Delete()
    if self.timelineBehavior then
        self.timelineBehavior:Delete()
    end
end

function CostSelectTB:OnInit()
end

function CostSelectTB:OnStart()
--     LogTable("消耗选择TB",self.args)

    if #self.args.cost <= 0 then
        self:BehaviorComplete({isCancel = false,selectIndex = 0,data = {}})
    else
        self.waitSelectCostInfos = {}
        if #self.args.cost > 0 then
            table.insert(self.waitSelectCostInfos,{})
            for _,effectId in ipairs(self.args.cost) do
                local effectConf = Config.Get("battle_effect_def","config","effectId",effectId)
                if not BattleDefine.NotOpCostType[effectConf.event] then
                    table.insert(self.waitSelectCostInfos[1],effectId)
                end
            end
        end
        
        if #self.waitSelectCostInfos == 1 and #self.waitSelectCostInfos[1] <= 0 then --没有任何需要选择的消耗
            self:BehaviorComplete({isCancel = false,selectIndex = 0,data = {}})
        elseif #self.waitSelectCostInfos == 1 then --单选项
            --直接打开操作流程
            self.selectIndex = 1
            self:InvokeCostTimeLine(1)
        else
            --打开消耗选项界面
        end
    end
end

function CostSelectTB:SelectOptionDone(index)
    self.selectIndex = index
    self:InvokeCostTimeLine(index)
end

function CostSelectTB:InvokeCostTimeLine(selIndex)
    local effectId = self.waitSelectCostInfos[selIndex][self.infoIndex]
    local effectConf = Config.Get("battle_effect_def", "config", "effectId", effectId)

    local selectTargetArgs = {}
    selectTargetArgs.roleUid = self.world.DataSystem.roleUid
    selectTargetArgs.srcUid = self.world.DataSystem.roleUid
    selectTargetArgs.selInfos = {{targetId = effectConf.targetId,effectId = effectId}}
    selectTargetArgs.canCancel = true
    selectTargetArgs.autoConfirm = self.args.autoConfirm or false
    selectTargetArgs.isCostSelect = true
    selectTargetArgs.kvData = self.args.kvData
    selectTargetArgs.baseInfo = self.args.baseInfo

    -- 新建tb之前，保证之前的tb已经被删除
    if self.timelineBehavior then
        self.timelineBehavior:Delete()
        self.timelineBehavior = nil
    end

    self.timelineBehavior = SelectTargetTB.New()
    self.timelineBehavior:SetWorld(self.world)
    self.timelineBehavior:SetEntity(self.entity)
    self.timelineBehavior:SetUid(self.world:GetUid(SECBBehaviorComponent))
    self.timelineBehavior:SetArgs(selectTargetArgs)
    self.timelineBehavior:SetComplete(self:ToFunc("BehaviorDone"))
    self.timelineBehavior:Init()

    self.timelineBehavior:Start()
end

function CostSelectTB:OnUpdate(deltaTime)
    if self.timelineBehavior then
        self.timelineBehavior:Update(deltaTime)
    end
end

function CostSelectTB:BehaviorDone(_, selectResult)
--     Log("消耗选择完成")
    self.infoIndex = self.infoIndex + 1

    if selectResult.isCancel then
        self.result.isCancel = true
        self:BehaviorComplete(self.result)
        return
    end

    for _, data in ipairs(selectResult.data) do
        table.insert(self.result.data, data)
    end
    
    if self.infoIndex > #self.waitSelectCostInfos[self.selectIndex] then
        self:BehaviorComplete(self.result)
    else
        self:InvokeCostTimeLine(self.selectIndex)
    end
end
