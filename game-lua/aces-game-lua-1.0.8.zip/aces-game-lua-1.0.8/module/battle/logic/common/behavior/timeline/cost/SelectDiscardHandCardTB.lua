-- SelectDiscardHandCardTB = BaseClass("SelectDiscardHandCardTB",TimelineBehaviorBase)

-- function SelectDiscardHandCardTB:__Init()
-- end

-- function SelectDiscardHandCardTB:__Delete()
--     ViewManager.Instance:CloseWindow(BattleSelectCardWindow)
-- end

-- function SelectDiscardHandCardTB:OnInit()
    
-- end

-- function SelectDiscardHandCardTB:OnStart()
--     LogTable("选择丢弃手牌TB",self.args)

--     local openArgs = {}
--     openArgs.num = self.args.conf.val

--     openArgs.cards = self.world.HandCardSystem:GetHandCardIdList(self.args.roleUid,self.args.kvData.fromCardEntityUid)
--     openArgs.onConfirmClick = self:ToFunc("OnSelectDiscardCard")
--     openArgs.canClose = true
--     openArgs.onCancelClick = self:ToFunc("OnCancelClick")
--     openArgs.titleKey = "select_card_window_title_6"
--     --openArgs.baseInfo = self.args.baseInfo

--     self:AddEvent(BattleEvent.hook_device_click, self:ToFunc("HookDeviceClick"),{})
--     self:AddEvent(BattleEvent.hook_use_card_down, self:ToFunc("HookUseCardDown"),{})

--     ViewManager.Instance:OpenWindow(BattleSelectCardWindow,openArgs)
-- end

-- function SelectDiscardHandCardTB:HookDeviceClick(args)
--     return true
-- end

-- function SelectDiscardHandCardTB:HookUseCardDown(args)
--     return true
-- end

-- function SelectDiscardHandCardTB:OnCancelClick()
--     self:BehaviorComplete(true)
-- end

-- function SelectDiscardHandCardTB:OnSelectDiscardCard(selectInfos)
--     local selectCards = {}
--     for _, v in ipairs(selectInfos) do
--         table.insert(selectCards,v.id)
--     end

--     local data = {}
--     data.costCardUids = selectCards

--     self:BehaviorComplete(false,data)
-- end