ChangeEnergyMaxTB = BaseClass("ChangeEnergyMaxTB", TimelineBehaviorBase)

function ChangeEnergyMaxTB:__Init()
end

function ChangeEnergyMaxTB:__Delete()

end

function ChangeEnergyMaxTB:OnInit()

end

function ChangeEnergyMaxTB:OnStart()
--     LogTable("改变能量上限TB", self.args)

    self.world.DataSystem:ChangeRoleEnergyMax(self.args.targetPlayer, self.args.value)
    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshEnergyMax, self.args.targetPlayer)
    mod.BattleFacade:SendEvent(BattleFuncBtnView.Event.RefreshRightEnergy)
    self.world.MixedSystem:RefreshCarrierTopHPAndEnergy(self.args.targetPlayer)
    mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowEnergyMaxFlying, self.args.targetPlayer, {value = self.args.value})

    self:BehaviorComplete()
end
