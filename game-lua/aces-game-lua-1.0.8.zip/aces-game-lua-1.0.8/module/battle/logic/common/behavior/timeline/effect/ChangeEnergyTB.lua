ChangeEnergyTB = BaseClass("ChangeEnergyTB", TimelineBehaviorBase)

function ChangeEnergyTB:__Init()
end

function ChangeEnergyTB:__Delete()

end

function ChangeEnergyTB:OnInit()

end

function ChangeEnergyTB:OnStart()
--     LogTable("改变能量TB", self.args)

    self.world.DataSystem:ChangeEnergy(self.args.targetPlayer,self.args.value)
    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshEnergy,self.args.targetPlayer)
    mod.BattleFacade:SendEvent(BattleEnemyCarrierInfoView.Event.RefreshEnemyEnergy)
    mod.BattleFacade:SendEvent(BattleFuncBtnView.Event.RefreshRightEnergy)
    self.world.MixedSystem:RefreshCarrierTopHPAndEnergy(self.args.targetPlayer)
    
    mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowEnergyFlying,self.args.targetPlayer,{value = self.args.value})


    if self.args.value > 0 then
        AudioManager.Instance:PlayScene("buff_1")
    end


    self:BehaviorComplete()
end
