ChangeHpMaxTB = BaseClass("ChangeHpMaxTB",TimelineBehaviorBase)

function ChangeHpMaxTB:__Init()
end

function ChangeHpMaxTB:__Delete()

end

function ChangeHpMaxTB:OnInit()

end

function ChangeHpMaxTB:OnStart()
--     LogTable("改变血量上限TB",self.args)

    self.world.DataSystem:ChangeRoleHpMax(self.args.targetPlayer,self.args.value)
    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshHpMax,self.args.targetPlayer)
    -- mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowHpFlying,self.args.targetPlayer,{value = self.args.value})
    local cardInfo = self.world.DataSystem:GetPlayerCardInfo(self.args.targetPlayer)
    mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowDeviceHpFlying,cardInfo.id,{value = self.args.value})

    self.world.MixedSystem:RefreshCarrierTopHPAndEnergy(self.args.targetPlayer)
    
    self:BehaviorComplete()
end
