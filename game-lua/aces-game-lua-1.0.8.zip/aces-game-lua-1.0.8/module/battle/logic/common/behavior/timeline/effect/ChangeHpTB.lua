ChangeHpTB = BaseClass("ChangeHpTB",TimelineBehaviorBase)

function ChangeHpTB:__Init()
end

function ChangeHpTB:__Delete()

end

function ChangeHpTB:OnInit()

end

function ChangeHpTB:OnStart()
--     LogTable("改变血量TB",self.args)

    --
    local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.targetPlayer)
    if not carrierEntity then
        -- LogError("没有找到对应的实体")
        self:BehaviorComplete()
        return
    end

    -- if carrierEntity then
        -- carrierEntity.TopInfoComponent:PlayReduceHpEffect()
    -- end

    self.world.DataSystem:ChangeHp(self.args.targetPlayer, self.args.value)
    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshHp, self.args.targetPlayer)
    local isHeavy = self.args.kvData and self.args.kvData.isHeavy or false

    local cardInfo = self.world.DataSystem:GetPlayerCardInfo(self.args.targetPlayer)
    mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowDeviceHpFlying,cardInfo.id,{value = self.args.value, isHeavy = isHeavy})

    self.world.MixedSystem:RefreshCarrierTopHPAndEnergy(self.args.targetPlayer)


    
    
    self:BehaviorComplete()
end
