ChangeShiledTB = BaseClass("ChangeShiledTB",TimelineBehaviorBase)

function ChangeShiledTB:__Init()
end

function ChangeShiledTB:__Delete()

end

function ChangeShiledTB:OnInit()

end

function ChangeShiledTB:OnStart()
--     LogTable("改变护盾TB",self.args)

    self.world.DataSystem:ChangeShield(self.args.targetPlayer,self.args.value)
    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshShield, self.args.targetPlayer)
    mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowShieldFlying,self.args.targetPlayer,{value = self.args.value})

    -- self.world.MixedSystem:RefreshCarrierTopHPAndEnergy(self.args.targetPlayer)
    
    self:BehaviorComplete()
end
