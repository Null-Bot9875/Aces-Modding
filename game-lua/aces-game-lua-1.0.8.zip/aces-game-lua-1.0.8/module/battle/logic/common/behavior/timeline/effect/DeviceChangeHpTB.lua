DeviceChangeHpTB = BaseClass("DeviceChangeHpTB", TimelineBehaviorBase)

function DeviceChangeHpTB:__Init()
    self.flyingTimers = {}
end

function DeviceChangeHpTB:__Delete()
    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end

    if self.preTimer then
        self.world.TimerSystem:RemoveTimer(self.preTimer)
        self.preTimer = nil
    end

    if self.flyingTimers then
        for _, timer in ipairs(self.flyingTimers) do
            self.world.TimerSystem:RemoveTimer(timer)
        end
        self.flyingTimers = nil
    end
end

function DeviceChangeHpTB:OnInit()

end

function DeviceChangeHpTB:OnStart()
--     LogTable("设备改变血量TB", self.args)

    --
    -- local deviceEntity = self.world.EntitySystem:GetDeviceEntity(self.args.targetDeviceUid)
    -- if deviceEntity then
    --     deviceEntity.TopInfoComponent:PlayReduceHpEffect()
    -- end

    local multiAttackNum = self.args.kvData and self.args.kvData.multiAttackNum
    if multiAttackNum and multiAttackNum > 1 then
        -- 连击合并伤害：拆分为多段飘字，总时长控制在 0.4 秒内
        local MAX_TOTAL_DURATION = 0.4
        local interval = math.min(0.15, MAX_TOTAL_DURATION / (multiAttackNum - 1))
        local singleValue = math.floor(self.args.value / multiAttackNum)
        local isHeavy = self.args.kvData.isHeavy or false
        local targetDevice = self.args.targetDevice
        -- 第一段立即显示
        mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowDeviceHpFlying, targetDevice,
            { value = singleValue, isHeavy = isHeavy })
        -- 后续段定时延迟显示
        for i = 2, multiAttackNum do
            local delay = (i - 1) * interval
            local timer = self.world.TimerSystem:AddTimer(1, delay, function()
                mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowDeviceHpFlying, targetDevice,
                    { value = singleValue, isHeavy = false })
            end)
            table.insert(self.flyingTimers, timer)
        end
    else
        mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowDeviceHpFlying, self.args.targetDevice,
            {
                value = self.args.value,
                isHeavy = self.args.kvData and self.args.kvData.isHeavy or false,
            })
    end

    -- 在合并攻击的时候 血量已经在格子更新中刷新了，不需要手动刷新
    -- 但如果是顺序处理的话，在处理该tb的时候 血量还没有刷新，需要手动刷新
    if not (self.args.kvData and self.args.kvData.isMerge) then
        self.world.DataSystem:ChangeDeviceHp(self.args.targetDevice, self.args.value)
    end


    -- 刷新机甲头顶信息
    -- self.world.MixedSystem:RefreshCarrierTopHPAndEnergy(self.args.targetPlayer)

    -- local entity = self.world.EntitySystem:GetDeviceEntity(self.args.targetDevice)
    -- entity.DeviceTopInfoComponent:RefreshHp()

    local cardInfo, roleUid = self.world.DataSystem:GetCardInfo(self.args.targetDevice)
    local playerCardInfo = self.world.DataSystem:GetPlayerCardInfo(roleUid)
    if playerCardInfo and playerCardInfo.id == self.args.targetDevice then
        --     self.world.DataSystem:ChangeHp(roleUid, self.args.value)
        -- mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshHp, roleUid)
        --     mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowHpFlying, roleUid, { value = self.args.value })

        -- 同步刷新机甲头顶信息（当设备即为玩家机体时）
        self.world.MixedSystem:RefreshCarrierTopHPAndEnergy(roleUid)
    end

    if self.args.value <= 0 then
        local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(self.args.targetDevice)
        if entity then
            entity.DynamicEffectComponent:PlayDamageReduceHit()
        end
    end

    -- local hp = cardInfo.hp + self.args.value
    -- local gridInfo = self.world.DataSystem:GetGridInfoByDeviceUid(cardInfo.id)
    -- local latestGridInfo = self.world.LatestDataSystem:GetGridInfo(gridInfo.id)

    -- local currCardInfo = self.world.DataSystem:GetCardInfo(cardInfo.id)
    -- local reliveValue = self.world.PluginSystem.GetCardAttr:GetAttrValue(currCardInfo,
    -- BattleDefine.CardAttrType.relive)
    if self.args.value < 0 then
        AudioManager.Instance:PlayUI("hurt_1")
    end

    if cardInfo.hp <= 0 then
        if not self:CheckNeedRemoveDrone() then
            -- 即使无需移除，也要等飘字全部播完再结束
            if multiAttackNum and multiAttackNum > 1 then
                local totalDelay = math.min(0.15, 0.4 / (multiAttackNum - 1)) * (multiAttackNum - 1)
                local timer = self.world.TimerSystem:AddTimer(1, totalDelay, self:ToFunc("BehaviorComplete"))
                table.insert(self.flyingTimers, timer)
            else
                self:BehaviorComplete()
            end
            return
        end

--         Log("攻击直接移除无人机")
        self.isKilled = true
        local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(self.args.targetDevice)
        self.world.StateSystem:SetCacheInfo("pre_dead_device_" .. self.args.targetDevice, true)

        entity.EffectComponent:CleanEffect()
        entity.DeviceTopInfoComponent:SetActive(false)
        entity.DynamicEffectComponent:SetIsHide(true)


        local confName = nil
        local modelId = entity.ObjectDataComponent.modelId
        local mode = entity.TposeComponent.mode
        local cardUid = entity.ObjectDataComponent:GetCardUid()
        local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
        mode = self.world.MixedSystem:GetTimelineMode(cardInfo and cardInfo.cardId, mode)

        -- 根据卡牌配置判断：该设备死亡是否需要播放爆炸死亡表现
        local cardId = entity.ObjectDataComponent:GetCardId()
        local cardConf = cardId and Config.Get("card_def", "config", "cardId", cardId) or nil
        local isExplodeDead = (cardConf and cardConf.extend and cardConf.extend.isExplode or false)
            or entity.ObjectDataComponent:IsRuntimeExplode()

        if isExplodeDead then
            confName = string.format("%s_%s_self_explode_aoe_attack", modelId, mode)
            if not Config.HasConf(confName) then
                confName = "common_self_explode_aoe_attack"
            end
        else
            confName = string.format("%s_%s_dead", modelId, mode)
            if not Config.HasConf(confName) then
                confName = "common_dead"
            end
        end

        local playDatas = Config.GetLua(confName)
        local playActions = {}
        for _, v in ipairs(playDatas) do
            table.insert(playActions, { args = nil, action = v })
        end

        local execArgs = {}
        execArgs.info = {
            effectSrcValue = self.args.targetDevice,
            effectSrcType = BattleDefine.EffectSrcType.card_attk,
        }
        execArgs.info.markTargetMap = {
            [BattleDefine.MarkTargetType.src] = {self.args.targetDevice},
            [BattleDefine.MarkTargetType.target] = {},
        }
        execArgs.info.results = {}
        execArgs.targetRoleUids = {}

        self.actionTimeline = ActionTimeline.New()
        self.actionTimeline:SetWorld(self.world)
        self.actionTimeline:OnInit(entity, playActions, execArgs)
        self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
        self.actionTimeline:Start()

        entity.EffectComponent:RemoveEffectByGroup("fixed")

        AudioManager.Instance:PlayScene("common_dead_1")

        self.startTime = Time.realtimeSinceStartup
        -- self.preTimer = self.world.TimerSystem:AddTimer(1, 1.0, self:ToFunc("OnPreTimer"))
    else
        -- 等最后一段飘字定时器结束后再完成，避免 BehaviorComplete → __Delete 提前 RemoveTimer
        if multiAttackNum and multiAttackNum > 1 then
            local totalDelay = math.min(0.15, 0.4 / (multiAttackNum - 1)) * (multiAttackNum - 1)
            local timer = self.world.TimerSystem:AddTimer(1, totalDelay, self:ToFunc("BehaviorComplete"))
            table.insert(self.flyingTimers, timer)
        else
            self:BehaviorComplete()
        end
    end
end

-- 检查是否需要移除无人机
function DeviceChangeHpTB:CheckNeedRemoveDrone()
    -- 检查是否存在无人机
    local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(self.args.targetDevice)
    if not entity then
        return false
    end

    -- 主将不走这个流程
    if entity.ObjectDataComponent:IsMainMecha() then
        return false
    end

    local cardInfo = entity.ObjectDataComponent:GetCardInfo()
    -- 如果存在自爆表现，则不移除
    local effects = {}
    local skills = cardInfo.skills
    for _, skill in ipairs(skills) do
        local skillConf = Config.Get("battle_skill_def", "config", "skillId", skill.skillId)
        for _, effect in ipairs(skillConf.effect) do
            table.insert(effects, effect)
        end
    end

    for _, effectId in ipairs(effects) do
        local effectConf = Config.Get("battle_effect_def", "config", "effectId", effectId)
        local resultType = effectConf.playResultType
        if resultType == BattleDefine.PlayResultType.selfExplode or resultType == BattleDefine.PlayResultType.selfAoeExplode then
            return false
        end
    end


    return true
end

function DeviceChangeHpTB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end

-- function DeviceChangeHpTB:OnPreTimer()
-- self.world.TimerSystem:RemoveTimer(self.preTimer)
-- self.preTimer = nil

-- self:TimelineDone()
-- end

function DeviceChangeHpTB:TimelineDone()
--     Log("攻击直接移除无人机完成")
    if self.isKilled then
        local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(self.args.targetDevice)
        if entity then
            entity.TposeComponent.tpose.gameObject:SetActive(false)
        end
    end

    self:BehaviorComplete()
end
