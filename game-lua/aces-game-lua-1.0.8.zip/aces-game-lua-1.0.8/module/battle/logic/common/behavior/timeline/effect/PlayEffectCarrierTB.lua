PlayEffectCarrierTB = BaseClass("PlayEffectCarrierTB", TimelineBehaviorBase)

function PlayEffectCarrierTB:__Init()
    self.localPosMap =
    {
        ["1004"] =
        {
            [BattleDefine.Camp.enemy] = { x = -3.71, y = 5.41, z = 0 },
            [BattleDefine.Camp.self]  = { x = 2.26, y = 7.58, z = -5.42 },
        }
    }
end

function PlayEffectCarrierTB:__Delete()

end

function PlayEffectCarrierTB:OnInit()
end

function PlayEffectCarrierTB:OnStart()
--     LogTable("机体特效TB", self.args)
    if self.args.effectId == 0 then
        self:BehaviorComplete()
        return
    end
    local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.targetPlayer)
    local carrierTrans = carrierEntity.TransformComponent.transform
    local effectId = self.args.effectId

    local camp = self.world.DataSystem:GetCamp(self.args.targetPlayer)
    local localPos = self.localPosMap[effectId][camp]

    local effectSetting = {}
    effectSetting.assetId = effectId
    effectSetting.pos = {x = localPos.x,y = localPos.y,z = localPos.z}
    effectSetting.parent = carrierTrans
    local effect = self.world.AssetsSystem:PlaySceneEffect(effectSetting)
    effect.transform.rotation = Quaternion.Euler(0, 0, 0)
    self:BehaviorComplete()
end

function PlayEffectCarrierTB:OnUpdate(deltaTime)
end
