PlayScreenUIPopupTB = BaseClass("PlayScreenUIPopup",TimelineBehaviorBase)

function PlayScreenUIPopupTB:__Init()
end

function PlayScreenUIPopupTB:__Delete()

end

function PlayScreenUIPopupTB:OnInit()
end

function PlayScreenUIPopupTB:OnStart()
--     LogTable("字体飘字TB",self.args)
    --mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowHpFlying,self.args.targetPlayer,{value = self.args.data.value})

    self:BehaviorComplete()
end

function PlayScreenUIPopupTB:OnUpdate(deltaTime)
end
