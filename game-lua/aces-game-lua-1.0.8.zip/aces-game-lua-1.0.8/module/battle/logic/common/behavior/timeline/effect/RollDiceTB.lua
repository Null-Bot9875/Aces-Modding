RollDiceTB = BaseClass("RollDiceTB", TimelineBehaviorBase)

function RollDiceTB:__Init()
end

function RollDiceTB:__Delete()

end

function RollDiceTB:OnUpdate(deltaTime)
end

function RollDiceTB:OnInit()
end

function RollDiceTB:OnStart()
--     LogTable("扔骰子TB", self.args)

    local dicesValue = {}    
    for _, v in ipairs(self.args.extends) do
        if v.key == BattleDefine.ExtendKey.rollValue then
            table.insert(dicesValue, v.value)
        end
    end

    local args = {}
    args.dicesValue = dicesValue
    args.confirmFunc = self:ToFunc("OnConfirm")

    ViewManager.Instance:OpenWindow(PvpRollDiceWindow, args)
end

function RollDiceTB:OnConfirm()
    self:BehaviorComplete()
end

