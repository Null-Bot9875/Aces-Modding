AddStaticSkillTB = BaseClass("AddStaticSkillTB", TimelineBehaviorBase)

function AddStaticSkillTB:__Init()
end

function AddStaticSkillTB:__Delete()

end

function AddStaticSkillTB:OnUpdate(deltaTime)
end

function AddStaticSkillTB:OnInit()
end

function AddStaticSkillTB:OnStart()
--     LogTable("添加静态异能TB", self.args)
    self:BehaviorComplete()
end
