CarrierRemovePlayTB = BaseClass("CarrierRemovePlayTB", TimelineBehaviorBase)

function CarrierRemovePlayTB:__Init()
    self.actionTimelines = {} -- 改为数组存储多个时间线
    self.completedCount = 0 -- 完成计数器
    self.totalCount = 0 -- 总数量
end

function CarrierRemovePlayTB:__Delete()
    -- 清理所有时间线
    for _, timeline in pairs(self.actionTimelines) do
        if timeline then
            timeline:Delete()
        end
    end
    self.actionTimelines = {}

    if self.preTimer then
        self.world.TimerSystem:RemoveTimer(self.preTimer)
        self.preTimer = nil
    end
end

function CarrierRemovePlayTB:OnInit()
end

function CarrierRemovePlayTB:OnStart()
--     LogTable("移除无人机TB", self.args)
    self:PrepareEffectData()

    local markTargetMap = self.args.info and self.args.info.markTargetMap
    local targetDeviceUids = markTargetMap and markTargetMap[BattleDefine.MarkTargetType.target] or {}
    local deviceInfos = {}

    -- 从info.results中提取设备信息
    if self.args.info and self.args.info.results then
        for _, result in ipairs(self.args.info.results) do
            deviceInfos[result.cardUid] = result
        end
    end

    self.totalCount = #targetDeviceUids
    self.completedCount = 0

    -- 如果没有无人机需要处理，直接完成
    if self.totalCount == 0 then
        self:AllTimelinesDone()
        return
    end

    -- 遍历处理每个无人机
    for i, deviceUid in ipairs(targetDeviceUids) do
        self:ProcessSingleDevice(deviceUid, deviceInfos[deviceUid], i)
    end

    self.startTime = Time.realtimeSinceStartup
end

function CarrierRemovePlayTB:PrepareEffectData()
    local result = self.args.info and self.args.info.results
    if not result or #result == 0 then
        return
    end

    -- TODO 预处理数据
    for _, v in ipairs(result) do
        if v.event == BattleDefine.EffectType.move_card and v.value == BattleDefine.CardAreaDef.consume then
            local uid = v.cardUid
            local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(uid)
            if entity then
                entity.ObjectDataComponent:SetScrapDead(true)
            end
        end
    end
end


--- 处理单个无人机
-- @param deviceUid : 无人机ID
-- @param deviceInfo : 无人机信息
-- @param index : 索引
function CarrierRemovePlayTB:ProcessSingleDevice(deviceUid, deviceInfo, index)
    local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(deviceUid)
    local isPreDead = self.world.StateSystem:GetCacheInfo("pre_dead_device_" .. deviceUid)
    
    -- 如果实体不存在或已预死亡，直接标记为完成
    if not entity or isPreDead then
        self:SingleDeviceComplete(deviceUid)
        return
    end

    self.world.StateSystem:SetCacheInfo("pre_dead_device_" .. deviceUid, true)

    entity.EffectComponent:CleanEffect()
    entity.DeviceTopInfoComponent:SetActive(false)

    local modelId = entity.ObjectDataComponent.modelId
    local mode = entity.TposeComponent.mode
    local cardUid = entity.ObjectDataComponent:GetCardUid()
    local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
    mode = self.world.MixedSystem:GetTimelineMode(cardInfo and cardInfo.cardId, mode)
    
    -- 确定移除类型（死亡移除或其他移除）
    local confName = nil
    local removeType = self.args.removeType
    if not removeType then
        -- 优先检查是否为废弃死亡
        if entity.ObjectDataComponent:GetScrapDead() then
            removeType = 1
        else
            -- local cardInfo = self.world.DataSystem:GetCardInfo(entity.ObjectDataComponent.cardUid)
            -- if cardInfo.hp > 0 then
            --     removeType = 1
            -- else
            removeType = 2
            -- end
        end
    end

    -- 根据卡牌配置判断：该机甲死亡是否需要播放爆炸死亡表现
    local cardId = entity.ObjectDataComponent:GetCardId()
    local cardConf = cardId and Config.Get("card_def", "config", "cardId", cardId) or nil
    if (cardConf and cardConf.extend and cardConf.extend.isExplode) or entity.ObjectDataComponent:IsRuntimeExplode() then
        removeType = 4
    end

    -- 根据移除类型选择动画配置
    if removeType == 1 then
        confName = string.format("%s_%s_exeunt", modelId, mode)
        if not Config.HasConf(confName) then
            confName = "common_exeunt"
        end
    elseif removeType == 2 then
        confName = string.format("%s_%s_dead", modelId, mode)
        if not Config.HasConf(confName) then
            confName = "common_dead"
        end
    elseif removeType == 4 then
        confName = string.format("%s_%s_self_explode_aoe_attack", modelId, mode)
        if not Config.HasConf(confName) then
            confName = "common_self_explode_aoe_attack"
        end
    end

    local playDatas = Config.GetLua(confName)
    local playActions = {}
    for _, v in ipairs(playDatas) do
        table.insert(playActions, { args = nil, action = v })
    end

    local execArgs = {}
    execArgs.info = {
        effectSrcValue = deviceUid,
        effectSrcType = BattleDefine.EffectSrcType.card_attk,
        markTargetMap = {
            [BattleDefine.MarkTargetType.src] = {deviceUid},
            [BattleDefine.MarkTargetType.target] = {deviceUid},
        },
        results = {},
    }

    -- 为每个无人机创建独立的时间线
    local actionTimeline = ActionTimeline.New()
    actionTimeline:SetWorld(self.world)
    actionTimeline:OnInit(entity, playActions, execArgs)
    actionTimeline:SetComplete(function()
        self:SingleDeviceComplete(deviceUid)
    end)
    actionTimeline:Start()

    self.actionTimelines[deviceUid] = actionTimeline

    entity.EffectComponent:RemoveEffectByGroup("fixed")

    -- 只播放一次音效，避免多个无人机同时播放
    if index == 1 then
        AudioManager.Instance:PlayScene("common_dead_1")
    end
end

--- 单个无人机处理完成
-- @param deviceUid : 完成的无人机ID
function CarrierRemovePlayTB:SingleDeviceComplete(deviceUid)
    self.completedCount = self.completedCount + 1
        
    -- 检查是否所有无人机都处理完成
    if self.completedCount >= self.totalCount then
        self:AllTimelinesDone()
    end
end

function CarrierRemovePlayTB:OnCancel()
end

function CarrierRemovePlayTB:OnUpdate(deltaTime)
    -- 更新所有活跃的时间线
    for _, timeline in pairs(self.actionTimelines) do
        if timeline then
            timeline:Update(deltaTime)
        end
    end
end

--- 所有无人机处理完成
function CarrierRemovePlayTB:AllTimelinesDone()
    self:BehaviorComplete()
end
