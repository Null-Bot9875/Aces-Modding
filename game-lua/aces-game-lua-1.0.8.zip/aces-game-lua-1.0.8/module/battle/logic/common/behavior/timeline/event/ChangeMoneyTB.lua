ChangeMoneyTB = BaseClass("ChangeMoneyTB", TimelineBehaviorBase)

function ChangeMoneyTB:__Init()
end

function ChangeMoneyTB:__Delete()

end

function ChangeMoneyTB:OnUpdate(deltaTime)
end

function ChangeMoneyTB:OnInit()
end

function ChangeMoneyTB:OnStart()
--     LogTable("修改金币TB", self.args)
    local val = 0
    for _, v in ipairs(self.args.info.results) do
        if v.event == BattleDefine.EffectType.change_money then
            val = val + v.value
        end
    end

    -- 更新战斗内数据源（stateInfo.gold 是协议字段，作为战斗内星核的权威来源）
    local roleUid = self.world.DataSystem.roleUid
    local roleData = self.world.DataSystem:GetRoleData(roleUid)
    if roleData and roleData.stateInfo then
        roleData.stateInfo.gold = (roleData.stateInfo.gold or 0) + val
    end

    mod.PveRogueProxy:AddGold(val)

    -- 刷新战斗主界面的星核显示
    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshNano, roleUid)

    self:BehaviorComplete()
end
