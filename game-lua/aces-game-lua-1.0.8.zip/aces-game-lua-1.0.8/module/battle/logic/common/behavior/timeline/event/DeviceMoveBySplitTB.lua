DeviceMoveBySplitTB = BaseClass("DeviceMoveBySplitTB", TimelineBehaviorBase)

function DeviceMoveBySplitTB:__Init()
    -- 当前处理的移动数据
    self.moveData = nil

    -- 当前处理的堆叠和动画
    self.currentStackId = nil
    self.entranceTimeline = nil
    self.removeStackEffect = nil
    self.rtUIObject = nil

    -- 定时器
    self.stackTimer = nil
    self.removeTimer = nil
end

function DeviceMoveBySplitTB:__Delete()
    self:CleanupCurrentMove()

    if self.stackTimer then
        self.world.TimerSystem:RemoveTimer(self.stackTimer)
        self.stackTimer = nil
    end

    if self.removeTimer then
        self.world.TimerSystem:RemoveTimer(self.removeTimer)
        self.removeTimer = nil
    end
end

function DeviceMoveBySplitTB:CleanupCurrentMove()
    if self.entranceTimeline then
        self.entranceTimeline:Delete()
        self.entranceTimeline = nil
    end

    if self.removeStackEffect then
        self.removeStackEffect:Delete()
        self.removeStackEffect = nil
    end

    if self.rtUIObject then
        self.rtUIObject:Delete()
        self.rtUIObject = nil
    end
end

function DeviceMoveBySplitTB:OnInit()
end

function DeviceMoveBySplitTB:OnStart()
--     LogTable("无人机解体移动", self.args)

    -- 从 args.result 中获取单个移动事件
    local result = self.args.result
    if not result or result.event ~= BattleDefine.EffectType.move_card_to_grid then
        LogError("无人机解体移动: 没有找到有效的移动事件")
        self:BehaviorComplete()
        return
    end

    self.moveData = {
        cardUid = result.cardUid,
        gridUid = result.gridUid,
        playerUid = result.playerUid,
    }

    -- 如果目标为 0，表示进入弃牌区
    local isToDiscard = (self.moveData.gridUid == 0)

    -- 获取卡牌信息
    local srcCardUid = nil
    for i, v in ipairs(self.args.info.results) do
        if v.event == BattleDefine.EffectType.split_target then
            srcCardUid = v.cardUid
            break
        end        
    end
    local srcCardInfo = self.world.DataSystem:GetCardInfo(srcCardUid)
    local gridInfo = self.world.DataSystem:GetGridInfoByDeviceUid(srcCardUid)
    if not gridInfo then
        LogError(string.format("无人机解体移动: 找不到格子信息 deviceUid=%s", tostring(srcCardUid)))
        self:BehaviorComplete()
        return
    end

    local cardInfo = nil
    for i, v in ipairs(gridInfo.stackcards) do
        if v.id == self.moveData.cardUid then
            cardInfo = v
            break
        end
    end
    self.moveData.cardInfo = cardInfo
    
--     Log(string.format("无人机解体移动: 开始处理移动 cardUid=%s, gridUid=%s", 
        -- tostring(srcCardUid), tostring(gridInfo.id)))

    if isToDiscard then
        -- 直接进入弃牌区，不需要堆叠流程
        self:HandleMoveToDiscard()
    else
        -- 移动到格子：执行完整的堆叠+入场+移除流程
        self:HandleMoveToGrid()
    end
end

-- 处理卡牌移动到弃牌区
function DeviceMoveBySplitTB:HandleMoveToDiscard()
    if self.stackTimer then
        self.world.TimerSystem:RemoveTimer(self.stackTimer)
        self.stackTimer = nil
    end

--     Log(string.format("无人机解体移动: 卡牌移动到弃牌区 cardUid=%s", tostring(self.moveData.cardInfo.id)))
    
    -- 延迟一小段时间后完成
    self.stackTimer = self.world.TimerSystem:AddTimer(1, 0.1, self:ToFunc("BehaviorComplete"))
    self.stackTimer:SetScale(true)
end

-- 处理卡牌移动到格子（完整流程）
function DeviceMoveBySplitTB:HandleMoveToGrid()
    -- 生成唯一的 stackId
    self.currentStackId = mod.BattleFacade:SendEvent(BattleStackCardView.Event.AddTempStack, self.moveData.cardInfo.cardId)

    -- 延迟一帧后进入步骤1.5（创建实体）
    -- self.stackTimer = self.world.TimerSystem:AddTimerByNextFrame(1, 0, self:ToFunc("Step1_5_CreateEntity"))
    self.stackTimer = self.world.TimerSystem:AddTimerByNextFrame(1, 2, self:ToFunc("Step3_RemoveStack"))
    self.stackTimer:SetScale(true)
end

-- 步骤1.5: 预创建无人机实体
function DeviceMoveBySplitTB:Step1_5_CreateEntity()
    self.stackTimer = nil

    local cardUid = self.moveData.cardUid

    -- 检查实体是否已经存在
    local existEntity = self.world.MixedSystem:GetGridDroneEntityByCardUid(cardUid)
    if existEntity then
        -- 实体已存在，直接进入步骤2
--         Log(string.format("步骤1.5: 实体已存在 cardUid=%s，跳过创建", tostring(cardUid)))
        self:Step2_PlayEntranceAnim()
        return
    end

--     Log(string.format("步骤1.5: 预创建无人机实体 cardUid=%s", tostring(cardUid)))

    -- 获取格子信息
    local gridInfo = self.world.DataSystem:GetGridInfoByDeviceUid(cardUid)

    -- 构造设备信息
    local camp = self.world.DataSystem:GetCamp(self.moveData.playerUid)
    local deviceInfo = { {
        cardUid = cardUid,
        position = gridInfo.position,
        state = gridInfo.state or 0,
    } }

    -- 创建实体
    local entity = self.world.DroneDeviceSystem:CreateSingleDevice(camp, deviceInfo, true)
    if not entity then
        LogError(string.format("步骤1.5: 创建实体失败 cardUid=%s", tostring(cardUid)))
        self:Step2_PlayEntranceAnim()
        return
    end

    -- 标记为预创建状态，供后续AddDeviceDroneAB识别
    self.world.StateSystem:SetCacheInfo(string.format("pre_created_device_%s", cardUid), true)

--     Log(string.format("步骤1.5完成: 实体已预创建 cardUid=%s", tostring(cardUid)))

    -- 进入步骤2
    self:Step2_PlayEntranceAnim()
end

-- 步骤2: 播放入场动画
function DeviceMoveBySplitTB:Step2_PlayEntranceAnim()
    -- 获取实体（此时应该已经在步骤1.5创建好了）
    local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(self.moveData.cardUid)

    if not entity then
        LogError(string.format("步骤2: 找不到目标实体 cardUid=%s", tostring(self.moveData.cardUid)))
        -- 跳过入场动画，直接移除堆叠
        self:Step3_RemoveStack()
        return
    end

--     Log(string.format("步骤2: 准备播放入场动画 cardUid=%s", tostring(self.moveData.cardUid)))

    -- 等待 Tpose 加载完成
    if not entity.TposeComponent:ExistTpose() then
        entity.TposeComponent:AddTposeListener(self:ToFunc("OnTposeLoaded"))
        return
    end

    self:OnTposeLoaded()
end

-- Tpose 加载完成
function DeviceMoveBySplitTB:OnTposeLoaded()
    local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(self.moveData.cardUid)

    if not entity then
        self:Step3_RemoveStack()
        return
    end

    entity.TposeComponent:RemoveTposeListener()

    local modelId = entity.ObjectDataComponent.modelId
    local mode = entity.TposeComponent.mode
    local cardUid = entity.ObjectDataComponent:GetCardUid()
    local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
    mode = self.world.MixedSystem:GetTimelineMode(cardInfo and cardInfo.cardId, mode)

    -- 构造入场动画配置
    local confName = string.format("%s_%s_entrance", modelId, mode)
    if not Config.HasConf(confName) then
        confName = "common_1_entrance"
    end

--     Log(string.format("步骤2: 播放入场动画 %s", confName))

    local playDatas = Config.GetLua(confName)
    if not playDatas then
        LogError(string.format("无人机解体移动: 找不到入场配置 %s", confName))
        self:Step3_RemoveStack()
        return
    end

    local playActions = {}
    for _, v in ipairs(playDatas) do
        table.insert(playActions, { args = nil, action = v })
    end

    local execArgs = {}
    execArgs.info = {
        effectSrcValue = self.moveData.cardUid,
        effectSrcType = BattleDefine.EffectSrcType.card_attk,
    }
    execArgs.info.markTargetMap = {
        [BattleDefine.MarkTargetType.src] = {self.moveData.cardUid},
        [BattleDefine.MarkTargetType.target] = {},
    }
    execArgs.targetRoleUids = {}

    self.entranceTimeline = ActionTimeline.New()
    self.entranceTimeline:SetWorld(self.world)
    self.entranceTimeline:OnInit(entity, playActions, execArgs)
    self.entranceTimeline:SetComplete(self:ToFunc("OnEntranceAnimComplete"))
    self.entranceTimeline:Start()
end

-- 入场动画完成
function DeviceMoveBySplitTB:OnEntranceAnimComplete()
--     Log("步骤2完成: 入场动画播放完成")

    local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(self.moveData.cardUid)
    if entity then
        entity.DynamicEffectComponent:SetIsHide(false)
        entity.DynamicEffectComponent:RefreshEffect()
    end

    -- 清除预创建标记（此时后续的数据包更新应该只更新数据）
    -- 注意：不在这里清除，而是在收到真正的数据包更新后清除，见 AddDeviceDroneAB

    -- 进入步骤3
    self:Step3_RemoveStack()
end

-- 步骤3: 移除堆叠
function DeviceMoveBySplitTB:Step3_RemoveStack()
    self:CleanupCurrentMove()

    if not self.currentStackId then
        -- 没有堆叠，直接完成
        self:BehaviorComplete()
        return
    end

--     Log(string.format("步骤3: 移除堆叠 stackId=%s", self.currentStackId))

    -- 获取堆叠 UI
    local stackInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetTempStackInfo, self.currentStackId)
    if not stackInfo then
        -- 清理数据
        self.currentStackId = nil
        self:BehaviorComplete()
        return
    end

    -- 播放堆叠移除特效
    local cardType = self.world.PluginSystem.GetCardAttr:GetCardTypeValue(self.moveData.cardInfo)
    if cardType == 0 then
        cardType = BattleDefine.CardType.white
    end

    -- 创建 RT 纹理
    local setting = {}
    setting.textureWidth = 510
    setting.textureHeight = 710
    setting.uiObject = stackInfo.item.gameObject

    self.rtUIObject = RTUIObject.New()
    self.rtUIObject:Show(setting)

    -- 创建结束特效
    local endEffectSetting = {}
    endEffectSetting.assetId = string.format("ui_battle_card_action_end_%s", AssetPath.EffectColor[cardType])
    endEffectSetting.parent = stackInfo.item.transform
    endEffectSetting.pos = { x = 0, y = 0 }
    endEffectSetting.scale = 1000
    endEffectSetting.order = stackInfo.item:GetOrder()
    endEffectSetting.onLoad = self:ToFunc("OnRemoveEffectLoaded")

    self.removeStackEffect = UIEffect.New()
    self.removeStackEffect:Init(endEffectSetting)
    self.removeStackEffect:Play()
end

-- 移除特效加载完成
function DeviceMoveBySplitTB:OnRemoveEffectLoaded()
    if not self.removeStackEffect or not self.rtUIObject then
        self:OnRemoveStackComplete()
        return
    end

    local render = self.removeStackEffect.effect.transform:Find("node"):GetChild(0).gameObject:GetComponent(Renderer)
    render.material:SetTexture("_basecolor", self.rtUIObject.texture)
    render.material:SetTexture("_maintex", self.rtUIObject.texture)

    -- 隐藏堆叠卡牌
    local stackInfo = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetTempStackInfo, self.currentStackId)
    if stackInfo then
        stackInfo.item:Find("tpose").gameObject:SetActive(false)
        mod.BattleFacade:SendEvent(BattleStackCardView.Event.PlayWaitEffect, self.currentStackId, false)
    end

    -- 等待特效播放完成
    local time = self.removeStackEffect:GetDuration() * 0.001
    self.removeTimer = self.world.TimerSystem:AddTimer(1, time, self:ToFunc("OnRemoveStackComplete"))
    self.removeTimer:SetScale(true)
end

-- 移除堆叠完成
function DeviceMoveBySplitTB:OnRemoveStackComplete()
    self.removeTimer = nil

    if self.currentStackId then
        -- 移除堆叠 UI
        mod.BattleFacade:SendEvent(BattleStackCardView.Event.RemoveTempStack, self.currentStackId)
--         Log(string.format("步骤3完成: 堆叠已移除 stackId=%s", self.currentStackId))
        self.currentStackId = nil
    end

    -- 清理资源
    self:CleanupCurrentMove()

    -- 完成当前移动
--     Log("无人机解体移动: 单个移动完成")
    self:BehaviorComplete()
end

function DeviceMoveBySplitTB:OnUpdate(deltaTime)
    if self.entranceTimeline then
        self.entranceTimeline:Update(deltaTime)
    end
end
