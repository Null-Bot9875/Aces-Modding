DeviceSplitTB = BaseClass("DeviceSplitTB", TimelineBehaviorBase)

function DeviceSplitTB:__Init()
end

function DeviceSplitTB:__Delete()
end

function DeviceSplitTB:OnInit()
end

function DeviceSplitTB:OnStart()
--     LogTable("无人机解体TB", self.args)
    local roleUid = self.args.result.playerUid
    -- local entity  = self.world.MixedSystem:GetGridDroneEntityByCardUid(self.args.result.cardUid)
    local entity = self.world.EntitySystem:GetCarrierEntity(roleUid)
    local cardId  = nil
    local modelId = entity.ObjectDataComponent.modelId
    local mode    = entity.TposeComponent.mode
    local entityCardUid = entity.ObjectDataComponent:GetCardUid()
    local entityCardInfo = self.world.DataSystem:GetCardInfo(entityCardUid)
    mode = self.world.MixedSystem:GetTimelineMode(entityCardInfo and entityCardInfo.cardId, mode)
    
    local cardUid = self.args.result.cardUid
    local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
    cardId = cardInfo.cardId

    local playConfName = nil
    if Config.HasConf(string.format("%s_%s_debuff", modelId, mode)) then
        playConfName = string.format("%s_%s_debuff", modelId, mode)
    end

    if Config.HasConf(string.format("%s_%s_%s_debuff", modelId, mode, cardId)) then
        playConfName = string.format("%s_%s_%s_debuff", modelId, mode, cardId)
    end

    if not Config.HasConf(playConfName) then
        playConfName = "common_debuff"
    end

    local playDatas = Config.GetLua(playConfName)
    if not playDatas then
        LogError(string.format("不存在timeline文件%s", playConfName))
        self:TimelineDone();
        return
    end

--     Log(string.format("减益结算TB开始%s", playConfName))

    local playActions = {}

    for _, v in ipairs(playDatas) do
        table.insert(playActions, { args = nil, action = v })
    end

    local carrierEntity = self.world.MixedSystem:GetGridDroneEntityByCardUid(cardUid)
    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(carrierEntity, playActions, self.args)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()
end

function DeviceSplitTB:TimelineDone()
--     Log("无人机解体TB完成")
    self:BehaviorComplete()
end

function DeviceSplitTB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end
