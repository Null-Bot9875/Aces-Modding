ReduceStaticSkillTB = BaseClass("ReduceStaticSkillTB", TimelineBehaviorBase)

function ReduceStaticSkillTB:__Init()
end

function ReduceStaticSkillTB:__Delete()

end

function ReduceStaticSkillTB:OnUpdate(deltaTime)
end

function ReduceStaticSkillTB:OnInit()
end

function ReduceStaticSkillTB:OnStart()
--     LogTable("减少静态异能TB", self.args)
    self:BehaviorComplete()
end
