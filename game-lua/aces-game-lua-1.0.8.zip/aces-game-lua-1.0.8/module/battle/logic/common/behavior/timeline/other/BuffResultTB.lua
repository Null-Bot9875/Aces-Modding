BuffResultTB = BaseClass("BuffResultTB", TimelineBehaviorBase)

function BuffResultTB:__Init()
end

function BuffResultTB:__Delete()
end

function BuffResultTB:OnInit()
end

function BuffResultTB:OnStart()
--     LogTable("增益结算 TB", self.args)

    local entity  = self.world.MixedSystem:GetMarkMapEntity(self.args.info.markTargetMap, BattleDefine.MarkTargetType.src, 1)
    if not entity then
        self:TimelineDone()
        return
    end

    local cardId  = nil
    local modelId = entity.ObjectDataComponent.modelId
    local mode    = entity.TposeComponent.mode
    local entityCardUid = entity.ObjectDataComponent:GetCardUid()
    local entityCardInfo = self.world.DataSystem:GetCardInfo(entityCardUid)
    mode = self.world.MixedSystem:GetTimelineMode(entityCardInfo and entityCardInfo.cardId, mode)

    local cardUid = self.world.MixedSystem:GetEffectSrcCardUid(self.args)
    if cardUid then
        local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
        cardId = cardInfo.cardId
    end

    local playConfName = nil
    local customResultType = self.args.kvData and self.args.kvData.customResultType

    if customResultType then
        if Config.HasConf(string.format("%s_%s_%s", modelId, mode, customResultType)) then
            playConfName = string.format("%s_%s_%s", modelId, mode, customResultType)
        elseif Config.HasConf(customResultType) then
            playConfName = customResultType
        else
            playConfName = nil
        end
    end

    if not playConfName and self.args.info.effectSrcType == BattleDefine.EffectSrcType.chip_effect then
        local chipUid = self.args.info.effectSrcValue
        local playerId = self.args.info.srcPlayer
        local chipInfo = self.world.DataSystem:GetChipInfoByUid(chipUid)
        if chipInfo then
            local chipId = chipInfo.chipId
            playConfName = string.format("%s_%s_%s_chip_buff", modelId, mode, chipId)
        end

        if not Config.HasConf(playConfName) then
            playConfName = string.format("%s_%s_chip_buff", modelId, mode)
        end

        if not Config.HasConf(playConfName) then
            playConfName = "common_chip_buff"
        end
    elseif not playConfName then
        if Config.HasConf(string.format("%s_%s_buff", modelId, mode)) then
            playConfName = string.format("%s_%s_buff", modelId, mode)
        end

        if Config.HasConf(string.format("%s_%s_%s_buff", modelId, mode, cardId)) then
            playConfName = string.format("%s_%s_%s_buff", modelId, mode, cardId)
        end

        if not Config.HasConf(playConfName) then
            playConfName = "common_buff"
        end
    end

    self:PlayTimeline(playConfName)
end

function BuffResultTB:PlayTimeline(playConfName)
    local playDatas = Config.GetLua(playConfName)
    if not playDatas then
        LogError(string.format("不存在timeline文件%s", playConfName))
        self:TimelineDone();
        return
    end

--     Log(string.format("增益结算TB开始%s", playConfName))

    local playActions = {}
    local hasHitResult = false

    for _, v in ipairs(playDatas) do
        table.insert(playActions, { args = nil, action = v })
        if v.type == "HitResultTB" or v.type == 10003 then
            hasHitResult = true
        end
    end

    if not hasHitResult then
        table.insert(playActions, { args = nil, action = { type = 10003, time = -1 } })
    end

    local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.info.srcPlayer)
    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(carrierEntity, playActions, self.args)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()
end

function BuffResultTB:TimelineDone()
--     Log("增益结算TB完成")
    self:BehaviorComplete()
end

function BuffResultTB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end
