CarrierAttackPlayTB = BaseClass("CarrierAttackPlayTB", TimelineBehaviorBase)

function CarrierAttackPlayTB:__Init()
    self.actionTimeline = nil

    self.isRotate = false

    self.rotateSpeed = 180 --每秒旋转180度
    self.rotateTime = 0.3
    self.curRotateTime = 0
    self.srcRotate = nil
    self.targetRotate = nil
    self.isRotateing = false
    self.isRecoverRotateing = false
    self.baseRotate = nil

    self.playConfName = nil
    self.isAoe = false

    -- 效果来源的卡牌uid
    self.srcCardUid = nil
    -- 效果来源的卡牌id 有这个值的话，优先使用这个值
    self.srcCardId = nil
end

function CarrierAttackPlayTB:__Delete()
    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end

    local carrierEntity = self.deviceEntity
    if carrierEntity and self.baseRotate then
        local tc = carrierEntity.TransformComponent
        if tc and tc.transform then
            tc.transform.rotation = self.baseRotate
        end
    end

    -- 异常情况下清理攻击状态（如重连、强制删除等）
    if carrierEntity then
        local cardUid = carrierEntity.ObjectDataComponent:GetCardUid()
        self.world.StateSystem:SetCacheInfo("carrier_attacking_" .. cardUid, nil)
    end
end

function CarrierAttackPlayTB:OnInit()

end

function CarrierAttackPlayTB:OnStart()
--     LogTable("机体攻击播放TB", self.args)

    if #self.args.info.results == 0 then
--         Log("无目标，取消设备攻击播放TB")
        self:BehaviorComplete()
        return
    end

    -- 缓存本 TB 用到的实体
    local markTargetMap = self.args.info.markTargetMap
    self.deviceEntity = self.world.MixedSystem:GetMarkMapEntity(markTargetMap, BattleDefine.MarkTargetType.src, 1)
    self.targetEntity = self.world.MixedSystem:GetMarkMapEntity(markTargetMap, BattleDefine.MarkTargetType.target, 1)

    self.srcCardUid = self.world.MixedSystem:GetEffectSrcCardUid(self.args)
    if self.args.info.effectSrcType == BattleDefine.EffectSrcType.stack_effect then
        local stackInfo = self.world.DataSystem:GetStackInfo(self.args.info.effectSrcValue)
        if stackInfo and stackInfo.cardInfo then
            self.srcCardId = stackInfo.cardInfo.cardId
        end
    elseif self.args.info.effectSrcType == BattleDefine.EffectSrcType.card_effect then
        self.srcCardId = self.args.info.effectSrcValue
    end

    -- 合法性判断
    if not self.deviceEntity or not self.targetEntity then
--         Log("无人机设备攻击播放失败，无法获取无人机实体")
        self:BehaviorComplete()
        return
    end

    if not self.deviceEntity.TposeComponent:HasTpose() or not self.targetEntity.TposeComponent:HasTpose() then
        self:BehaviorComplete()
        return
    end

    self.playConfName = self:GetAttackConfName()
--     Log(string.format("机体攻击播放TB[playConfName:%s]", self.playConfName))

    --如果是堆叠结算，正常播放攻击动画

    --如果是自己给自己加血，播放加血通用表现
    --如果是自己扣自己血，播放扣血通用表现
    --如果是打击目标，并且是堆叠结算，则播放攻击表现
    --如果是打击目标，但不是堆叠结算，播放扣血通用表现


    --不可能每个resut播放一个TB流程


    if self.isRotate then
        self.baseRotate = self.deviceEntity.TransformComponent.transform.rotation
        self.srcRotate = self.deviceEntity.TransformComponent.transform.rotation

        local x = self.targetEntity.TransformComponent.transform.position.x -
            self.deviceEntity.TransformComponent.transform.position.x
        local z = self.targetEntity.TransformComponent.transform.position.z -
            self.deviceEntity.TransformComponent.transform.position.z
        local rotate = Quaternion.LookRotation(Vector3(x, 0, z))
        self.targetRotate = rotate

        local angle = Quaternion.Angle(self.srcRotate, self.targetRotate)

        self.rotateTime = angle * (1 / self.rotateSpeed) * 1000

        if self.rotateTime <= 0 then
            self:LookTargetDone()
        else
            self.isRotateing = true
        end
    else
        self:LookTargetDone()
    end
end


-- 大伤害判定：与 fallback 块一致，用 battle_attk_diff_heavy 的 diff 区间
function CarrierAttackPlayTB:IsHeavyDamage()
    if self.args.kvData.dontUseHeavy then
        return false
    end

    local DEFAULT_THRESHOLD = 0 -- 配置缺失时默认阈值
    local conf = Config.Get("kv_data", "const", "key", "battle_hurt_fixed_heavy")
    local heavySingle = DEFAULT_THRESHOLD
    if conf then
        heavySingle = conf.value
    end

    local conf = Config.Get("kv_data", "const", "key", "battle_hurt_fixed_aoe_heavy")
    local heavyAoe = DEFAULT_THRESHOLD
    if conf then
        heavyAoe = conf.value
    end

    local results = self.args and self.args.info and self.args.info.results
    if not results or #results <= 0 then
        return false
    end

    if self:IsSingleAttack() then
        -- 单体：单发造成配置以上伤害才触发
        local v = results[1]
        local val = math.abs(v and v.value or DEFAULT_THRESHOLD)
        return val >= heavySingle
    end

    -- AOE：机体死亡时无法继续承伤导致“溢出”不成立，因此只看本次 AOE 中最大单段伤害是否达标
    local maxVal = DEFAULT_THRESHOLD
    for _, v in ipairs(results) do
        local val = math.abs(v and v.value or DEFAULT_THRESHOLD)
        if val > maxVal then
            maxVal = val
        end
    end
    return maxVal >= heavyAoe
end

function CarrierAttackPlayTB:GetChipAttackConfName()
    local name 
    local chipUid = self.args.info.effectSrcValue
    local chipId
    local modelId = self.deviceEntity.ObjectDataComponent.modelId
    local mode = self.deviceEntity.TposeComponent.mode
    local cardUid = self.deviceEntity.ObjectDataComponent:GetCardUid()
    local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
    mode = self.world.MixedSystem:GetTimelineMode(cardInfo and cardInfo.cardId, mode)

    if self.args.info.effectSrcType == BattleDefine.EffectSrcType.chip_effect then
        local roleUid = self.args.info.srcPlayer
        local chipInfo = self.world.DataSystem:GetChipInfoByUid(chipUid)
        if not chipInfo then
           LogError(string.format("CarrierAttackPlayTB:无法获取芯片信息[roleUid:%s][chipUid:%s]", tostring(roleUid), tostring(chipUid)))
            return "common_chip_attk"
        end
        chipId = chipInfo.chipId
        name = string.format("%s_%s_%s_chip_attk", modelId, mode, chipId)
    end

    
    if not name or not Config.HasConf(name) then
        if self:IsSingleAttack() then
            name = string.format("%s_%s_chip_single_attk", modelId, mode)
        else
            name = string.format("%s_%s_chip_aoe_attk", modelId, mode)
        end
    end

    if not name or not Config.HasConf(name) then
        name = "common_chip_attk"
    end

    return name
end

function CarrierAttackPlayTB:GetAttackConfName()
    local name = nil
    local modelId = self.deviceEntity.ObjectDataComponent.modelId
    local mode = self.deviceEntity.TposeComponent.mode
    local cardUid = self.deviceEntity.ObjectDataComponent:GetCardUid()
    local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
    mode = self.world.MixedSystem:GetTimelineMode(cardInfo and cardInfo.cardId, mode)

    self.isAoe = false

    local confName = nil
    local useConfName = nil
    local commonName = self:IsSingleAttack()
        and "common_normal_single_attack"
        or "common_normal_aoe_attack"

    -- 根据触发来源获取表现类型
    local effectConf = nil
    local playResultType = nil

    if self.args.isStackLevelPlay then
        -- 堆叠级：从skill配置获取playResultType
        local skillConf = Config.Get("battle_skill_def", "config", "skillId", self.args.info.skillId)
        if skillConf then
            playResultType = skillConf.playResultType
        end
    else
        -- 效果级：从effect配置获取playResultType
        effectConf = Config.Get("battle_effect_def", "config", "effectId", self.args.info.effectId)
        if effectConf then
            playResultType = effectConf.playResultType
        end
    end

    local customResultType = self.args.kvData and self.args.kvData.customResultType
    
    if customResultType then
        if Config.HasConf(string.format("%s_%s_%s", modelId, mode, customResultType)) then
            useConfName = string.format("%s_%s_%s", modelId, mode, customResultType)
        elseif Config.HasConf(customResultType) then
            useConfName = customResultType
        else
            useConfName = nil
        end
    end
    
    if not useConfName and self.args.info.multiAttackNum and self.args.info.multiAttackNum >= 2 and self.args.info.multiAttackNum <= 3 then
        useConfName = string.format("%s_%s_multi_attack1_single_attack", modelId, mode)
        commonName = "common_normal_aoe_attack"
    elseif not useConfName and self.args.info.multiAttackNum and self.args.info.multiAttackNum >= 4 then
        useConfName = string.format("%s_%s_multi_attack2_single_attack", modelId, mode)
        commonName = "common_normal_aoe_attack"
    elseif not useConfName and playResultType == BattleDefine.PlayResultType.backAttack and self:IsSingleAttack() then
        useConfName = string.format("%s_%s_back_single_attack", modelId, mode)
        self.isAoe = false
    elseif not useConfName and playResultType == BattleDefine.PlayResultType.fanAttack then
        useConfName = string.format("%s_%s_fan_aoe_attack", modelId, mode)
        commonName = "common_normal_aoe_attack"
        self.isAoe = true
    elseif not useConfName and playResultType == BattleDefine.PlayResultType.penetratAttack then
        useConfName = string.format("%s_%s_penetrat_aoe_attack", modelId, mode)
        commonName = "common_normal_aoe_attack"
        self.isAoe = true
    elseif not useConfName and playResultType == BattleDefine.PlayResultType.meleeAttack then
        useConfName = string.format("%s_%s_melee_single_attack", modelId, mode)
        self.isAoe = false
    elseif not useConfName and self.args.info.effectSrcType == BattleDefine.EffectSrcType.chip_effect then
        useConfName = self:GetChipAttackConfName()
        commonName = "common_chip_attk"
    elseif not useConfName and playResultType == BattleDefine.PlayResultType.selfExplode then
        useConfName = string.format("%s_%s_self_explode_single_attack", modelId, mode)
        commonName = "common_self_explode_single_attack"
        self.isSelfExplode = true
    elseif not useConfName and playResultType == BattleDefine.PlayResultType.selfAoeExplode then
        useConfName = string.format("%s_%s_self_explode_aoe_attack", modelId, mode)
        commonName = "common_self_explode_aoe_attack"
        self.isAoe = true
    elseif not useConfName and playResultType == BattleDefine.PlayResultType.attack then
        --普通攻击下，表现可以被贯穿覆盖（仅在攻击准备/攻击结束括号内才生效）
        -- 在有custom的时候 不触发贯穿覆盖的逻辑作者X
        local isAttkAll = false

        local isMerge = self.args.kvData and self.args.kvData.isMerge
        if isMerge then
            local cardUid = self.deviceEntity.ObjectDataComponent:GetCardUid()
            local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
            local tagMap = self.world.PluginSystem.GetCardAttr:GetTagMap(cardInfo)
            if tagMap[BattleDefine.CardTagType.attkAll] then
                isAttkAll = true
            end
        end

        if isAttkAll or not self:IsSingleAttack() then
            useConfName = string.format("%s_%s_penetrat_aoe_attack", modelId, mode)
            commonName = "common_normal_aoe_attack"
            self.isAoe = true
        else
            useConfName = string.format("%s_%s_normal_single_attack", modelId, mode)
            commonName = "common_normal_single_attack"
        end
    end

    if useConfName and Config.HasConf(useConfName) then
        confName = useConfName
    end

    if not confName then
        -- local normal = Config.Get("kv_data", "const", "key", "battle_attk_diff_normal")
        -- local normalMin = normal.value[1]
        -- local normalMax = normal.value[2]

        -- local middle = Config.Get("kv_data", "const", "key", "battle_attk_diff_middle")
        -- local middleMin = middle.value[1]
        -- local middleMax = middle.value[2]


        -- local heavy = Config.Get("kv_data", "const", "key", "battle_attk_diff_heavy")
        -- local heavyMin = heavy.value[1]
        -- local heavyMax = heavy.value[2]

        -- -- 获取当前攻击能造成多少伤害
        -- local val = 0
        -- for _, v in ipairs(self.args.info.results) do
        --     val = val + v.value
        -- end

        -- local currAttk = 0

        -- -- 如果是堆叠结算，则去找对应战术牌的攻击力
        -- if self.args.info.effectSrcType == BattleDefine.EffectSrcType.stack_effect then
        --     local stackInfo = self.world.DataSystem:GetStackInfo(self.args.info.effectSrcValue)
        --     local cardId = stackInfo.cardInfo.cardId
        --     currAttk = self.world.MixedSystem:GetTacticCardAttk(cardId)
        -- else
        --     local cardUid = self.deviceEntity.ObjectDataComponent:GetCardUid()
        --     local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
        --     if cardInfo then
        --         currAttk = cardInfo.attk
        --     end
        -- end


        if not self:IsSingleAttack() then
            self.isAoe = true
            -- local diff = math.abs(val) / #self.args.info.results - currAttk
            -- if diff >= normalMin and diff <= normalMax then
            --     useConfName = string.format("%s_%s_normal_aoe_attack", modelId, mode)
            -- elseif diff >= middleMin and diff <= middleMax then
            --     useConfName = string.format("%s_%s_middle_aoe_attack", modelId, mode)
            -- elseif diff >= heavyMin and (diff <= heavyMax or heavyMax == -1) then
            --     useConfName = string.format("%s_%s_heavy_aoe_attack", modelId, mode)
            -- else
            --     useConfName = string.format("%s_%s_normal_aoe_attack", modelId, mode)
            -- end
            useConfName = string.format("%s_%s_normal_aoe_attack", modelId, mode)
        else
            self.isAoe = false
            -- local diff = math.abs(val) - currAttk
            -- if diff >= normalMin and diff <= normalMax then
            --     useConfName = string.format("%s_%s_normal_single_attack", modelId, mode)
            -- elseif diff >= middleMin and diff <= middleMax then
            --     useConfName = string.format("%s_%s_middle_single_attack", modelId, mode)
            -- elseif diff >= heavyMin and (diff <= heavyMax or heavyMax == -1) then
            --     useConfName = string.format("%s_%s_heavy_single_attack", modelId, mode)
            -- else
            --     useConfName = string.format("%s_%s_normal_single_attack", modelId, mode)
            -- end
            useConfName = string.format("%s_%s_normal_single_attack", modelId, mode)
        end
        if Config.HasConf(useConfName) then
            confName = useConfName
        end
    end

    -- 优先级第二高的情况：针对某一卡牌制作的特殊攻击动作
    local useCardTimeline = true
    if effectConf and effectConf.dontUseCardTimeline then
        useCardTimeline = false
    end

    if self.srcCardId then
        if Config.HasConf(string.format("%s_%s_%s_attack", modelId, mode, self.srcCardId)) and useCardTimeline then
            confName = string.format("%s_%s_%s_attack", modelId, mode, self.srcCardId)
        end
    elseif self.srcCardUid then
        local cardInfo = self.world.DataSystem:GetCardInfo(self.srcCardUid)
        if cardInfo and Config.HasConf(string.format("%s_%s_%s_attack", modelId, mode, cardInfo.cardId)) and useCardTimeline then
            confName = string.format("%s_%s_%s_attack", modelId, mode, cardInfo.cardId)
        end
    end

    -- 优先级最高的情况：大伤害
    -- 大伤害的表现
    local isHeavy = self:IsHeavyDamage()
    if isHeavy then
    -- if true then
        if self:IsSingleAttack() then
            useConfName = string.format("%s_%s_heavy_single_attack", modelId, mode)
            -- commonName = "common_heavy_single_attack"
        else
            useConfName = string.format("%s_%s_heavy_aoe_attack", modelId, mode)
            -- commonName = "common_heavy_aoe_attack"
        end

        if Config.HasConf(useConfName) then
            confName = useConfName
        end
    end

    if Config.HasConf(confName) then
        name = confName
    end

    if not name then
        name = commonName
    end

    -- Logf("攻击信息[是否治疗:%s][是否攻击:%s][播放配置:%s]", tostring(isHeal), tostring(isAttack), tostring(name))
--     Log(string.format("攻击信息[isAoe:%s][播放配置:%s]", tostring(self.isAoe), tostring(name)))

    if DEBUG_ATTACK and IS_DEBUG then
        name = DEBUG_ATTACK
    end

    self.isRotate = not self.isAoe

    -- 当有移动的时候，不进行旋转
    local playDatas = Config.GetLua(name)
    for _, v in ipairs(playDatas) do
        if v.type == "PlayMoveMechaTB" then
            self.isRotate = false
            break
        end
    end

    -- 对己方目标做表现时不旋转（己方打己方/给己方加血等）
    if self.isRotate and self.targetEntity and self.targetEntity.CampComponent then
        local srcCamp = self.deviceEntity.CampComponent:GetCamp()
        local targetCamp = self.targetEntity.CampComponent:GetCamp()
        if srcCamp == targetCamp then
            self.isRotate = false
        end
    end

    return name
end

function CarrierAttackPlayTB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end

    if self.isRotateing or self.isRecoverRotateing then
        self.curRotateTime = self.curRotateTime + deltaTime
        local carrierEntity = self.deviceEntity
        local t = self.curRotateTime / self.rotateTime

        if t > 1 then t = 1 end
        local rotation = Quaternion.Slerp(self.srcRotate, self.targetRotate, t)
        local tc = carrierEntity.TransformComponent
        if tc and tc.transform then
            tc.transform.rotation = rotation
        end
        if t >= 1 then
            -- 必须先清标志位，再调用回调
            -- 原因：LookTargetDone() → actionTimeline:Start() → SECBTimeline:Update(0) 可能
            -- 同步触发 TimelineDone()，将 isRecoverRotateing 置为 true；
            -- 若在回调之后才清零，会把 TimelineDone 设置的 true 覆盖掉，导致回正旋转丢失。
            local wasRotateing = self.isRotateing
            self.isRotateing = false
            self.isRecoverRotateing = false
            if wasRotateing then
                self:LookTargetDone()
            else
                self:RecoverLookTargetDone()
            end
        end
    end
end

function CarrierAttackPlayTB:LookTargetDone()
    local carrierEntity = self.deviceEntity
    if not Config.HasConf(self.playConfName) then
        LogError("找不到播放配置", self.playConfName)
        self:RecoverLookTargetDone()
        return
    end

    local playDatas = Config.GetLua(self.playConfName)

    local playActions = {}
    for _, v in ipairs(playDatas) do
        table.insert(playActions, { args = nil, action = v })
    end

    -- 重攻击下会覆盖相机逻辑
    local isHeavy = self:IsHeavyDamage()
    self.args.kvData.isHeavy = isHeavy

    -- 标记机体进入攻击状态
    local cardUid = carrierEntity.ObjectDataComponent:GetCardUid()
    self.world.StateSystem:SetCacheInfo("carrier_attacking_" .. cardUid, true)
    self.args.kvData.isAttacking = true

    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(carrierEntity, playActions, self.args)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()
end

function CarrierAttackPlayTB:RecoverLookTargetDone()
--     Log("机体攻击播放完成")

    -- 清除机体攻击状态
    if self.deviceEntity then
        local cardUid = self.deviceEntity.ObjectDataComponent:GetCardUid()
        self.world.StateSystem:SetCacheInfo("carrier_attacking_" .. cardUid, nil)
    end

    EventManager.Instance:SendEvent(EventDefine.attack_play_finish)
    mod.GuideEventCtrl:Trigger(GuideDefine.Event.attack_play_finish)
    self:BehaviorComplete()
end

function CarrierAttackPlayTB:TimelineDone()
    if self.isRotate then
        local carrierEntity = self.deviceEntity
        self.curRotateTime = 0
        self.targetRotate = self.srcRotate
        self.srcRotate = carrierEntity.TransformComponent.transform.rotation

        if self.rotateTime <= 0 then
            self:RecoverLookTargetDone()
        else
            self.isRecoverRotateing = true
        end
    else
        self:RecoverLookTargetDone()
    end

    if self.isSelfExplode and self.deviceEntity then
        self.world.StateSystem:SetCacheInfo("pre_dead_device_" .. self.deviceEntity.ObjectDataComponent:GetCardUid(), true)

        self.deviceEntity.EffectComponent:CleanEffect()
        self.deviceEntity.DeviceTopInfoComponent:SetActive(false)
        self.deviceEntity.DynamicEffectComponent:SetIsHide(true)
        self.deviceEntity.TposeComponent.tpose.gameObject:SetActive(false)
    end
end

-- 判断是否单体攻击：markTargetMap["target"]中只有1个实体
function CarrierAttackPlayTB:IsSingleAttack()
    local markTargetMap = self.args.info.markTargetMap
    if not markTargetMap then
        return true
    end
    local targetUids = markTargetMap[BattleDefine.MarkTargetType.target]
    if not targetUids then
        return true
    end
    return #targetUids <= 1
end
