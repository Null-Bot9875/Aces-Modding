ConsumeResultTB = BaseClass("ConsumeResultTB",TimelineBehaviorBase)

function ConsumeResultTB:__Init()
    self.startPos = nil
    self.endPos = nil

    self.flyEffect = nil
    self.flyAnim = nil
end

function ConsumeResultTB:__Delete()

end

function ConsumeResultTB:OnInit()

end

function ConsumeResultTB:OnStart()
--     LogTable("消耗结算TB",self.args)

    local targetCamp = self.world.DataSystem:GetCamp(self.args.targetPlayer)

    if self.args.effectId == 100 then --能量增加
        self.world.DataSystem:ChangeEnergy(self.args.targetPlayer,self.args.data.value)
        mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshEnergy,self.args.targetPlayer)
        self.world.MixedSystem:RefreshCarrierTopHPAndEnergy(self.args.targetPlayer)
        self:BehaviorComplete()

    elseif self.args.effectId == 101 then --护盾增加
        self.world.DataSystem:ChangeShield(self.args.targetPlayer,self.args.data.value)
        mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshShield,self.args.targetPlayer)
        self:BehaviorComplete()
    end
end

function ConsumeResultTB:AddFlyEffectDone()
    --Log("飞行特效完成了")
    self.world.DataSystem:ChangeEnergy(self.args.targetPlayer,self.args.data.value)
    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshEnergy,self.args.targetPlayer)
    self.world.MixedSystem:RefreshCarrierTopHPAndEnergy(self.args.targetPlayer)

    local effectSetting = {}
    effectSetting.assetId = 1002
    effectSetting.pos = {x = self.endPos.x,y = self.endPos.y,z = self.endPos.z}
    self.world.AssetsSystem:PlaySceneEffect(effectSetting)
    self:EffectDone()
end

function ConsumeResultTB:SubFlyEffectDone()
   --Log("飞行特效完成了")
   local effectSetting = {}
    effectSetting.assetId = 1001
    effectSetting.pos = {x = self.endPos.x,y = self.endPos.y,z = self.endPos.z}
    self.world.AssetsSystem:PlaySceneEffect(effectSetting)
    self:EffectDone()
end

--能量点爆炸完成
function ConsumeResultTB:EffectDone()
    if self.flyEffect then
        self.world.AssetsSystem:RemoveEffect(self.flyEffect.uid)
    end
    self:BehaviorComplete()
end

function ConsumeResultTB:OnUpdate(deltaTime)
end
