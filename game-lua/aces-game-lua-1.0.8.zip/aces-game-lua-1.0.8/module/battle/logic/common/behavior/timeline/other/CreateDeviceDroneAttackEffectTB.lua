CreateDeviceDroneAttackEffectTB = BaseClass("CreateDeviceDroneAttackEffectTB",TimelineBehaviorBase)

function CreateDeviceDroneAttackEffectTB:__Init()
end

function CreateDeviceDroneAttackEffectTB:__Delete()
    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end

    if self.entranceActionTimeline then
        self.entranceActionTimeline:Delete()
        self.entranceActionTimeline = nil
    end
end

function CreateDeviceDroneAttackEffectTB:OnInit()
end

function CreateDeviceDroneAttackEffectTB:OnStart()
--     LogTable("CreateDeviceDroneAttackEffectTB",self.args)

    -- 读取源卡牌直接配置的入场 timeline（优先于动态拼接）
    local sourceConf = Config.Get("card_def", "config", "cardId", self.args.createSourceCardId)
    self._entranceTimeline = sourceConf and sourceConf.extend and sourceConf.extend.entranceTimeline or nil
    -- timelineModel 透传给 args，供后续 timeline action 使用
    if self._entranceTimeline and self._entranceTimeline.timelineModel then
        self.args.timelineModel = self._entranceTimeline.timelineModel
    end

    local playName = self:GetPlayName()
--     Log("播放入场动效############"..playName)

    if not Config.HasConf(playName) then
        LogError("播放入场动效失败，找不到配置："..playName)
        self:BehaviorComplete()
        return 
    end

    
    local camp = self.world.DataSystem:GetCamp(self.args.info.srcPlayer)



    local cardId = self.args.createCardId

    local data = {}
    data.deviceInfo = {}
    data.deviceInfo.cardId = cardId or 0
    data.deviceInfo.cardUid = 1
    data.camp = camp
    data.pos = Vector3(0,5,0)
    -- timelineMode路径：以 modelId 直接驱动实体，无需 createCard
    if self.args.timelineModel then
        data.timelineModel = self.args.timelineModel
    end
    -- entity.ObjectDataComponent:SetDeviceId(deviceInfo.cardUid)
    local entity = self.world.EntityCreateSystem:CreateClientDeviceEntity(data)
    entity.ObjectDataComponent:SetIsClient(true)
    self.clientEntity = entity
    if not entity.TposeComponent:ExistTpose() then
        entity.TposeComponent:AddTposeListener(self:ToFunc("OnTposeLoaded"))
    else
        self:OnTposeLoaded()
    end

end


function CreateDeviceDroneAttackEffectTB:OnTposeLoaded()
    self.clientEntity.TposeComponent:RemoveTposeListener()
    self:PlayEntranceEffect()
end


function CreateDeviceDroneAttackEffectTB:PlayEntranceEffect()
    local modelId = self.clientEntity.ObjectDataComponent.modelId

    


    local playName = self:GetPlayName()
--     Log("播放入场动效############"..playName)

    if not Config.HasConf(playName) then
        LogError("播放入场动效失败，找不到配置："..playName)
        self:BehaviorComplete()
        return 
    end

    local playDatas = Config.GetLua(playName)

    if not playDatas then
        LogError("播放入场动效失败，找不到配置："..playName)
        self:BehaviorComplete()
        return
    end

    local playActions = {}
    for _, v in ipairs(playDatas) do
        table.insert(playActions, { args = nil, action = v })
    end

    self.args.isClientEntity = true
    -- self.args.attackUid = 1
    local uid = self.clientEntity.ObjectDataComponent:GetCardUid()
    -- 覆盖默认的markTargetMap
    self.args.info.markTargetMap[BattleDefine.MarkTargetType.src] = {uid}
    self.entranceActionTimeline = ActionTimeline.New()
    self.entranceActionTimeline:SetWorld(self.world)
    self.entranceActionTimeline:OnInit(self.clientEntity, playActions, self.args)
    self.entranceActionTimeline:SetComplete(self:ToFunc("OnEntranceTimelineDone"))
    self.entranceActionTimeline:Start()
end

function CreateDeviceDroneAttackEffectTB:OnEntranceTimelineDone()

    self:AttackTimelineDone()
end

-- function CreateDeviceDroneAttackEffectTB:PlayAttackEffect()
--     Log("攻击中###############")
--     local playActions = {}

--     self.args.isClientEntity = true
--     self.args.attackUid = 1
--     table.insert(playActions,{args = nil,action = {type = 10004 ,time = 0}})
--     self.actionTimeline = ActionTimeline.New()
--     self.actionTimeline:SetWorld(self.world)
--     self.actionTimeline:OnInit(nil, playActions, self.args)
--     self.actionTimeline:SetComplete(self:ToFunc("AttackTimelineDone"))
--     self.actionTimeline:Start()
-- end


function CreateDeviceDroneAttackEffectTB:OnUpdate(deltaTime)

    if self.entranceActionTimeline then
        self.entranceActionTimeline:Update(deltaTime)
    end
end

function CreateDeviceDroneAttackEffectTB:AttackTimelineDone()
    if self.clientEntity then
        self.world.EntitySystem:RemoveEntity(self.clientEntity.uid) 
        self.clientEntity = nil
    end
    self:BehaviorComplete()
end


function CreateDeviceDroneAttackEffectTB:GetPlayName()
    -- 优先使用源卡牌直接配置的 useTimeline
    if self._entranceTimeline and self._entranceTimeline.useTimeline then
        return self._entranceTimeline.useTimeline
    end

    -- 回退：按 modelId + camp 动态生成
    local camp = self.world.DataSystem:GetCamp(self.args.info.srcPlayer)
    local conf = Config.Get("card_def", "config", "cardId", self.args.createCardId)
    if camp == BattleDefine.Camp.self then
        return string.format("%s_%s_enter_%d_attack", conf.extend.modelId, 1, self.args.createSourceCardId)
    elseif camp == BattleDefine.Camp.enemy then
        return string.format("%s_%s_enemy_enter_%d_attack", conf.extend.modelId, 1, self.args.createSourceCardId)
    end
end
