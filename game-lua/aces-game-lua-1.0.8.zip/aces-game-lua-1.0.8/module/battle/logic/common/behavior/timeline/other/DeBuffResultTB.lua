DeBuffResultTB = BaseClass("DeBuffResultTB", TimelineBehaviorBase)

function DeBuffResultTB:__Init()
end

function DeBuffResultTB:__Delete()
end

function DeBuffResultTB:OnInit()
end

function DeBuffResultTB:OnStart()
--     LogTable("减益结算 TB", self.args)

    local entity  = self.world.MixedSystem:GetMarkMapEntity(self.args.info.markTargetMap, BattleDefine.MarkTargetType.src, 1)
    if not entity then
        self:TimelineDone()
        return
    end

    local cardId  = nil
    local modelId = entity.ObjectDataComponent.modelId
    local mode    = entity.TposeComponent.mode
    local entityCardUid = entity.ObjectDataComponent:GetCardUid()
    local entityCardInfo = self.world.DataSystem:GetCardInfo(entityCardUid)
    mode = self.world.MixedSystem:GetTimelineMode(entityCardInfo and entityCardInfo.cardId, mode)

    local cardUid = self.world.MixedSystem:GetEffectSrcCardUid(self.args)
    if cardUid then
        local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
        cardId = cardInfo.cardId
    end

    local playConfName = nil
    local customResultType = self.args.kvData and self.args.kvData.customResultType
    
    if customResultType then
        if Config.HasConf(string.format("%s_%s_%s", modelId, mode, customResultType)) then
            playConfName = string.format("%s_%s_%s", modelId, mode, customResultType)
        elseif Config.HasConf(customResultType) then
            playConfName = customResultType
        else
            playConfName = nil
        end
    end

    if not playConfName and self.args.info.effectSrcType == BattleDefine.EffectSrcType.chip_effect then
        local chipUid = self.args.info.effectSrcValue
        local playerId = self.args.info.srcPlayer
        local chipInfo = self.world.DataSystem:GetChipInfoByUid(chipUid)
        -- 与 BuffResultTB 一致：晶片已移除或 UID 不匹配时走通用 chip_debuff 配置
        if chipInfo and chipInfo.chipId then
            local chipId = chipInfo.chipId
            playConfName = string.format("%s_%s_%s_chip_debuff", modelId, mode, chipId)
--             Log(string.format("减益 TB 找到晶片信息：chipUid=%s, chipId=%s", chipUid, chipId))
        else
            LogError(string.format("减益结算 TB 获取晶片信息失败，chipUid=%s, chipInfo=%s", 
                chipUid, chipInfo and "exists but no chipId" or "nil"))
        end

        if not Config.HasConf(playConfName) then
            playConfName = string.format("%s_%s_chip_debuff", modelId, mode)
        end

        if not Config.HasConf(playConfName) then
            playConfName = "common_chip_debuff"
        end
    elseif not playConfName then
        if Config.HasConf(string.format("%s_%s_debuff", modelId, mode)) then
            playConfName = string.format("%s_%s_debuff", modelId, mode)
        end

        if Config.HasConf(string.format("%s_%s_%s_debuff", modelId, mode, cardId)) then
            playConfName = string.format("%s_%s_%s_debuff", modelId, mode, cardId)
        end

        if Config.HasConf(string.format("%s_%s_aoe_debuff", modelId, mode)) then
            playConfName = string.format("%s_%s_aoe_debuff", modelId, mode)
        end

        if not Config.HasConf(playConfName) then
            playConfName = "common_debuff"
        end
    end

    self:PlayTimeline(playConfName)
end

function DeBuffResultTB:PlayTimeline(playConfName)
    local playDatas = Config.GetLua(playConfName)
    if not playDatas then
        LogError(string.format("不存在timeline文件%s", playConfName))
        self:TimelineDone()
        return
    end

--     Log(string.format("减益结算TB开始%s", playConfName))

    local playActions = {}
    local hasHitResult = false

    for _, v in ipairs(playDatas) do
        table.insert(playActions, { args = nil, action = v })
        if v.type == "HitResultTB" or v.type == 10003 then
            hasHitResult = true
        end
    end

    if not hasHitResult then
        table.insert(playActions, { args = nil, action = { type = 10003, time = -1 } })
    end

    local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.info.srcPlayer)
    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(carrierEntity, playActions, self.args)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()
end

function DeBuffResultTB:TimelineDone()
--     Log("减益结算TB完成")
    self:BehaviorComplete()
end

function DeBuffResultTB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end
