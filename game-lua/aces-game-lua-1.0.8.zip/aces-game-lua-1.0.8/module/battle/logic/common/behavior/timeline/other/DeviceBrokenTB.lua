DeviceBrokenTB = BaseClass("DeviceBrokenTB",TimelineBehaviorBase)

function DeviceBrokenTB:__Init()
end

function DeviceBrokenTB:__Delete()

end

function DeviceBrokenTB:OnInit()

end

function DeviceBrokenTB:OnStart()
--     LogTable("设备破坏动画",self.args)
    self:BehaviorComplete()
    SystemMessage.Show("***酷炫的设备破坏动画***")
    -- local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.srcPlayer)
    -- carrierEntity.AnimComponent:PlayAnim(self.conf.animName)
    -- self.animMaxTime = carrierEntity.AnimComponent:GetClipTime(self.conf.animName)
end

function DeviceBrokenTB:OnUpdate(deltaTime)
    -- self.animCurTime = self.animCurTime + deltaTime
    -- if self.animCurTime >= self.animMaxTime then
    --     self:BehaviorComplete()
    -- end
end
