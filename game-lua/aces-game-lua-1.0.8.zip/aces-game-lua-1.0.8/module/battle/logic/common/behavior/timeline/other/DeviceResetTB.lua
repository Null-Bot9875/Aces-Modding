DeviceResetTB = BaseClass("DeviceResetTB",TimelineBehaviorBase)

function DeviceResetTB:__Init()
end

function DeviceResetTB:__Delete()

end

function DeviceResetTB:OnInit()

end

function DeviceResetTB:OnStart()
--     LogTable("设备重置动画",self.args)
    self:BehaviorComplete()
    SystemMessage.Show("***酷炫的设备重置动画***")
    -- local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.srcPlayer)
    -- carrierEntity.AnimComponent:PlayAnim(self.conf.animName)
    -- self.animMaxTime = carrierEntity.AnimComponent:GetClipTime(self.conf.animName)
end

function DeviceResetTB:OnUpdate(deltaTime)
    -- self.animCurTime = self.animCurTime + deltaTime
    -- if self.animCurTime >= self.animMaxTime then
    --     self:BehaviorComplete()
    -- end
end
