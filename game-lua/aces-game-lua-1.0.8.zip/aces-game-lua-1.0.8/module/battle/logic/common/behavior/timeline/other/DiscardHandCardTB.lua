DiscardHandCardTB = BaseClass("DiscardHandCardTB",TimelineBehaviorBase)

function DiscardHandCardTB:__Init()
end

function DiscardHandCardTB:__Delete()

end

function DiscardHandCardTB:OnInit()
end

function DiscardHandCardTB:OnStart()
--     LogTable("弃牌TB",self.args)

    self:BehaviorComplete()
end

function DiscardHandCardTB:OnUpdate(deltaTime)
end
