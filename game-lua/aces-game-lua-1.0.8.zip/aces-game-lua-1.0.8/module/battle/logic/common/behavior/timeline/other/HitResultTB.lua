HitResultTB = BaseClass("HitResultTB",TimelineBehaviorBase)

function HitResultTB:__Init()
end

function HitResultTB:__Delete()

end

function HitResultTB:OnInit()
end

function HitResultTB:OnStart()
--     LogTable("命中结算TB",self.args)

    -- 如果有镜头切换标记，跳过结算显示（镜头期间不飘字）
    if self.args.kvData and self.args.kvData.hasCameraSwitch then
--         Log("命中结算TB：检测到镜头切换，跳过结算显示")
        self:BehaviorComplete()
        return
    end

    -- 防御性检查：results 为空时跳过结算，防止崩溃踢玩家下线
    if not self.args.info or not self.args.info.results then
        LogError("命中结算TB：info.results 为空，跳过结算显示")
        self:BehaviorComplete()
        return
    end

    -- local effectConf = Config.Get("battle_effect_def","config","effectId",self.args.info.effectId)
    -- if effectConf and effectConf.event == BattleDefine.EffectType.hurt then
    --     AudioManager.Instance:PlayScene("common_hit_1")

    --     local val = nil
    --     if self.args.info.results[1] then
    --         val = self.args.info.results[1].value
    --     end
    --     if val and effectConf.playResultType == BattleDefine.PlayResultType.none then
    --         mod.BattleFacade:SendEvent(FlyingTextView.Event.ShowHpFlying,self.args.info.targetPlayer,{value = val})
    --     end
    -- end

    --local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.info.targetPlayer)
    --carrierEntity.AnimComponent:PlayAnim("hit")
    --local carrierPos = carrierEntity.TransformComponent:GetPos()

    --local effectSetting = {}
    --effectSetting.assetId = 1004
    --effectSetting.pos = {x = carrierPos.x,y = carrierPos.y,z = BattleDefine.SceneLayer.effect}
    --self.world.AssetsSystem:PlaySceneEffect(effectSetting)


    local playActions = {}
    for _, v in ipairs(self.args.info.results) do
        -- local args = {}
        -- args.effectSrcType = self.args.effectSrcType
        -- args.effectSrcValue = self.args.effectSrcValue
        -- args.data = v
        -- args.skillId = self.args.skillId
        -- args.srcPlayer = self.args.srcPlayer
        -- args.targetPlayer = self.args.targetPlayer
        local resultIndex 
        if v.cardUid and v.cardUid ~= 0 then
            resultIndex = TimelineBehaviorIndex.DeviceResultToIndex[v.event]
        else
            resultIndex = TimelineBehaviorIndex.ResultToIndex[v.event]
        end

        local args = {}
        if resultIndex then
            args.targetPlayer = v.playerUid
            args.targetDevice = v.cardUid
            args.value = v.value
            local baseKvData = self.args.kvData or {}
            -- 若本次为连击合并攻击，将连击次数透传给 DeviceChangeHpTB 以实现多段飘字
            local multiAttackNum = self.args.info and self.args.info.multiAttackNum
            if multiAttackNum and multiAttackNum > 1 then
                local newKvData = {}
                for k, kv in pairs(baseKvData) do
                    newKvData[k] = kv
                end
                newKvData.multiAttackNum = multiAttackNum
                args.kvData = newKvData
            else
                args.kvData = baseKvData
            end
            table.insert(playActions,{args = args,action = {type = resultIndex or v.event ,time = 0}})
        else
            --LogErrorf("未知的命中结算类型[%s]",v.event)
            -- args.effectSrcType = self.args.effectSrcType
            -- args.effectSrcValue = self.args.effectSrcValue
            -- args.data = v
            -- args.skillId = self.args.skillId
            -- args.srcPlayer = self.args.srcPlayer
            -- args.targetPlayer = v.playerUid
        end
    end

    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(self.entity,playActions,self.args)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()
end

function HitResultTB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end

function HitResultTB:TimelineDone()
--     Log("命中结算TB完成")
    self:BehaviorComplete()
end

function HitResultTB:DiscardHandCardDone()
    self:BehaviorComplete()
end
