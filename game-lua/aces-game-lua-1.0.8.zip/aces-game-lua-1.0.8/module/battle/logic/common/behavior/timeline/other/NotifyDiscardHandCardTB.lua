NotifyDiscardHandCardTB = BaseClass("NotifyDiscardHandCardTB", TimelineBehaviorBase)

function NotifyDiscardHandCardTB:__Init()
end

function NotifyDiscardHandCardTB:__Delete()
    ViewManager.Instance:CloseWindow(PvpCardSelectWindow)
end

function NotifyDiscardHandCardTB:OnInit()
end

function NotifyDiscardHandCardTB:OnStart()
--     LogTable("通知弃牌TB", self.args)

    local openArgs = {}
    openArgs.num = self.args.value
    openArgs.cards = self.world.HandCardSystem:GetHandCardIdList()
    openArgs.onConfirmClick = self:ToFunc("OnSelectDiscardCard")
    openArgs.canClose = false
    openArgs.titleKey = "select_card_window_title_6"

    self:AddEvent(BattleEvent.hook_device_click, self:ToFunc("HookDeviceClick"),{})
    self:AddEvent(BattleEvent.hook_use_card_down, self:ToFunc("HookUseCardDown"),{})

    ViewManager.Instance:OpenWindow(PvpCardSelectWindow, openArgs)
end

function NotifyDiscardHandCardTB:HookDeviceClick(args)
    return true
end

function NotifyDiscardHandCardTB:HookUseCardDown(args)
    return true
end

function NotifyDiscardHandCardTB:OnSelectDiscardCard(selectInfos)
--     LogTable("选择废弃卡牌回调", selectInfos)
    local ids = {}
    for i, v in ipairs(selectInfos) do
        table.insert(ids, v.info.cardUid)
    end

    local data = {}
    data.costCardUids = ids

    mod.BattleFacade:SendMsg(4004, 10, {{key = "operation",val = data}})

    self:BehaviorComplete()
end

function NotifyDiscardHandCardTB:OnUpdate(deltaTime)
end
