PlayAudioTB = BaseClass("PlayAudioTB",TimelineBehaviorBase)

function PlayAudioTB:__Init()
    self.doneTimer = nil
    self.audioUid = nil
end

function PlayAudioTB:__Delete()
    self:RemoveAudio()
    self:RemoveDoneTimer()
end

function PlayAudioTB:OnInit()
end

function PlayAudioTB:OnStart()
--     LogTable("播放音效TB",self.conf.audioId)
    if self.conf.audioId then
        self.audioUid = AudioManager.Instance:PlayCarrier(self.conf.audioId)
    end

    local lastTime = nil
    if self.conf.isWaitAudioEnd and self.conf.duration > 0 then
        lastTime = self.conf.duration
    end

    if lastTime then
        self.doneTimer = self.world.TimerSystem:AddTimer(1,lastTime * 0.001,self:ToFunc("DoneTimer"))
        self.doneTimer:SetScale(true)
    else
        self:BehaviorComplete()
    end
end

function PlayAudioTB:DoneTimer()
    self.doneTimer = nil
    self:RemoveAudio()
    self:BehaviorComplete()
end

function PlayAudioTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function PlayAudioTB:RemoveAudio()
    if self.audioUid and self.conf.isWaitAudioEnd then
        AudioManager.Instance:StopCarrier(self.audioUid)
        self.audioUid = nil
    end
end
