PlayBgmAudioTB = BaseClass("PlayBgmAudioTB",TimelineBehaviorBase)

function PlayBgmAudioTB:__Init()
end

function PlayBgmAudioTB:__Delete()
end

function PlayBgmAudioTB:OnInit()
end

function PlayBgmAudioTB:OnRecover()
    if self.conf.unProgress and self.conf.audioId then
        AudioManager.Instance:PlayBgm(self.conf.audioId,self.conf.delayTime * 0.001)
    end
end

function PlayBgmAudioTB:OnStart()
--     LogTable("播放Bgm音乐TB",self.conf.audioId)

    AudioManager.Instance:PlayBgm(self.conf.audioId,self.conf.delayTime * 0.001)

    self:BehaviorComplete()
end
