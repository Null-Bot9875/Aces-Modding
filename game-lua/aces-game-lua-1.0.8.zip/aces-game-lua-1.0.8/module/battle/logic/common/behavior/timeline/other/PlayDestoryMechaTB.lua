PlayDestoryMechaTB = BaseClass("PlayDestoryMechaTB", TimelineBehaviorBase)

function PlayDestoryMechaTB:__Init()
    self.actionTimeline = nil
end

function PlayDestoryMechaTB:__Delete()
    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end
end

function PlayDestoryMechaTB:OnInit()

end

function PlayDestoryMechaTB:OnStart()
--     LogTable("效果ID_999，移除机甲TB", self.args)
    --local lastTime = self.conf.duration

    -- 防御性检查：results 为空时跳过
    if not self.args.info or not self.args.info.results then
        LogError("PlayDestoryMechaTB：info.results 为空，跳过移除机甲")
        self:BehaviorComplete()
        return
    end

    local targetPlayers = {}
    for _,v in ipairs(self.args.info.results) do
        table.insert(targetPlayers,v.playerUid)
    end

    for _,v in ipairs(targetPlayers) do
        local carrierEntity = self.world.EntitySystem:GetCarrierEntity(v)
        -- carrierEntity.TopInfoComponent:SetActive(false)
        carrierEntity.EffectComponent:CleanEffect()
    
        local modelId = carrierEntity.ObjectDataComponent.modelId
        local mode = carrierEntity.TposeComponent.mode
        local cardUid = carrierEntity.ObjectDataComponent:GetCardUid()
        local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
        mode = self.world.MixedSystem:GetTimelineMode(cardInfo and cardInfo.cardId, mode)
    
        -- local index = 1
    
        -- 根据卡牌配置判断：该机甲死亡是否需要播放爆炸死亡表现
        local cardId = carrierEntity.ObjectDataComponent:GetCardId()
        local cardConf = cardId and Config.Get("card_def", "config", "cardId", cardId) or nil
        local isExplodeDead = (cardConf and cardConf.extend and cardConf.extend.isExplode or false)
            or carrierEntity.ObjectDataComponent:IsRuntimeExplode()

        local deadConfName = nil
        if isExplodeDead then
            deadConfName = string.format("%s_%s_self_explode_aoe_attack", modelId, mode)
            if not Config.HasConf(deadConfName) then
                deadConfName = "common_self_explode_aoe_attack"
            end
        else
            deadConfName = string.format("%s_%s_dead", modelId, mode)
            if not Config.HasConf(deadConfName) then
                deadConfName = "common_dead"
            end
        end
    
        local playDatas = Config.GetLua(deadConfName)
        local playActions = {}
        for _,v in ipairs(playDatas) do
            table.insert(playActions,{args = nil,action = v})
        end
    
        local execArgs = {}
        execArgs.info = {srcPlayer = self.args.info.targetPlayer}
        execArgs.targetRoleUids = {}
        execArgs.info.markTargetMap = {
            [BattleDefine.MarkTargetType.src] = {carrierEntity.ObjectDataComponent:GetCardUid()},
            [BattleDefine.MarkTargetType.target] = {},
        }
    
        self.actionTimeline = ActionTimeline.New()
        self.actionTimeline:SetWorld(self.world)
        self.actionTimeline:OnInit(carrierEntity,playActions,execArgs)
        self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
        self.actionTimeline:Start()

        
        carrierEntity.EffectComponent:RemoveEffectByGroup("fixed")
    end


    AudioManager.Instance:PlayScene("dead_1")
end

function PlayDestoryMechaTB:OnCancel()
end

function PlayDestoryMechaTB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end

function PlayDestoryMechaTB:TimelineDone()
    local removeCarrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.info.targetPlayer)
    self.world.CarrierSystem:RemoveCarrier(self.args.info.targetPlayer)
    
    self.world.EntitySystem:RemoveEntity(removeCarrierEntity.uid)

    self.world.CameraSystem:ClearCamera(self.args.info.targetPlayer)
    self:BehaviorComplete()
end
