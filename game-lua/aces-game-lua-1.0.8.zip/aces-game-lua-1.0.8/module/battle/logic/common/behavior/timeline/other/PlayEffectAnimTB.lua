PlayEffectAnimTB = BaseClass("PlayEffectAnimTB", TimelineBehaviorBase)

function PlayEffectAnimTB:__Init()
    self.currentEffect = nil
    self.doneTimer = nil
    self.isAsyncLoading = false -- 标记是否正在异步加载特效
end

function PlayEffectAnimTB:__Delete()
    self:RemoveDoneTimer()
end

function PlayEffectAnimTB:OnInit()

end

function PlayEffectAnimTB:OnStart()
--     LogTable("播放特效动画TB", self.args)
    local animMaxTime = 0
    local animName = self:GetAnimName()
    if not animName then
        self:BehaviorComplete()
        return
    end

    local entity = self:GetEntity()
    if not entity then
        self:BehaviorComplete()
        return
    end

    self.entity = entity

    self:PlayAnim()
end

function PlayEffectAnimTB:GetAnimName()
    return self.conf.stateName
end

function PlayEffectAnimTB:GetEntity()
    local markTargetMap = self.args.info.markTargetMap
    local markTarget = self.conf.markTarget or BattleDefine.MarkTargetType.target
    -- 指定了有效targetIndex时取单个实体，否则取第一个
    -- return self.world.MixedSystem:GetMarkMapEntity(markTargetMap, markTarget, self.conf.targetIndex)
    return self.world.MixedSystem:GetTargetEntity(markTargetMap, self.conf)
end

function PlayEffectAnimTB:PlayAnim()
    --[[
    1. 使用CreateOrGetFixedEffect获取或创建固定特效
    2. 通过UnitEffect的PlayAnimation方法播放动画
    3. 处理异步加载情况
    --]]

    local entity = self.entity
    local animName = self:GetAnimName()
    -- 生成固定特效名称，需要确保有assetId配置
    if not self.conf.assetId or self.conf.assetId == "" then
        self:BehaviorComplete()
        return 0
    end

    local fixedEffectName = string.format("fixed_%s_%s", self.conf.assetId, self.conf.bindBone)
    
    -- 构建特效设置
    local setting = {}
    setting.assetId = self.conf.assetId
    setting.bone = KvData.Bone.custom
    setting.customBone = self.conf.bindBone
    setting.entity = entity
    setting.group = "fixed"
    
    -- 创建或获取固定特效
    local fixedEffect = entity.DynamicEffectComponent:CreateOrGetEffect(fixedEffectName, setting)
    if not fixedEffect then
        self:BehaviorComplete()
        return 0
    end

    self.currentEffect = fixedEffect
    self.isAsyncLoading = false

    -- 使用UnitEffect的动画播放接口
    local animDuration = fixedEffect:PlayAnimation(animName, self:ToFunc("DoneTimer"))
    
    return animDuration
end

function PlayEffectAnimTB:DoneTimer()
    self.doneTimer = nil
    if self.conf.isDelete and self.currentEffect then
        local name = string.format("fixed_%s_%s", self.conf.assetId, self.conf.bindBone)
        local entity = self.entity
        entity.DynamicEffectComponent:RemoveFixedEffect(name)
        self.currentEffect = nil
    end
    self:BehaviorComplete()
end

function PlayEffectAnimTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function PlayEffectAnimTB:OnUpdate(deltaTime)
end
