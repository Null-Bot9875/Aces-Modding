PlayMechaAnimTB = BaseClass("PlayMechaAnimTB", TimelineBehaviorBase)

function PlayMechaAnimTB:__Init()
    self.doneTimer = nil
    -- 变体镜头相关
    self.assetLoader = nil
    self.assetScope = nil
    self.camera = nil
    self.blendTimer = nil
    self.fromParent = nil
    self.fromPos = nil
    self.fromRotate = nil
    -- 运行时约束引用：便于在复位时统一销毁
    self.cameraFollowConstraint = nil
    self.entityFollowConstraint = nil
    -- 延迟启动相关：等待异步镜头加载完成后再播放动画
    self.pendingAnimName = nil
    self.pendingEntity = nil
    self.hasStartedAnim = false

    self.fromInfos = {}

    -- 镜头变化事件监听
    self.cameraChangedEventUid = nil
end

function PlayMechaAnimTB:__Delete()
    self:RemoveDoneTimer()
    self:RemoveCameraChangedListener()
    self:ResetCamera()
    self:RemoveCameraLoader()
    self:ReleasePendingCameraScope()
    self:ResetUICamera()
end

function PlayMechaAnimTB:OnInit()

end

function PlayMechaAnimTB:OnStart()
--     LogTable("播放机甲动画TB", self.args)
    local animName = self.conf.animName
    if not animName then
        self:BehaviorComplete()
        return
    end

    local entity = self:GetEntity()
    if not entity then
        self:BehaviorComplete()
        return
    end

    local cardUid = entity.ObjectDataComponent:GetCardUid()
    local isPreDead = self.world.StateSystem:GetCacheInfo("pre_dead_device_" .. cardUid)

    -- 配置了markPreDead时，标记设备为提前死亡状态并隐藏显示
    if self.conf.markPreDead and not isPreDead then
        self.world.StateSystem:SetCacheInfo("pre_dead_device_" .. cardUid, true)
        entity.EffectComponent:CleanEffect()
        entity.DeviceTopInfoComponent:SetActive(false)
        entity.DynamicEffectComponent:SetIsHide(true)
        -- entity.TposeComponent.tpose.gameObject:SetActive(false)
        -- self:BehaviorComplete()
        -- return
    end

    -- 已是预死亡状态，只允许播放死亡或退场相关动画
    if isPreDead then
        if animName and not (string.find(animName, "dead") or string.find(animName, "exeunt")) then
            self:BehaviorComplete()
            return
        end
    end

    -- 检查机体是否正在攻击，且当前不是攻击timeline
    local isAttacking = self.world.StateSystem:GetCacheInfo("carrier_attacking_" .. cardUid)
    local isFromAttackTimeline = self.args.kvData and self.args.kvData.isAttacking
    if isAttacking and not isFromAttackTimeline then
--         Log(string.format("PlayMechaAnimTB: 机体[%s]正在攻击中，非攻击timeline的动画[%s]被拦截", cardUid, animName))
        self:BehaviorComplete()
        return
    end

    self.pendingAnimName = animName
    self.pendingEntity = entity


    self:DOPlayAnim()

    -- -- 重击下的镜头逻辑
    -- if self.args.kvData and self.args.kvData.isHeavy then
    --     self:DOPlayAnim()
    --     return
    -- end

    -- 限制镜头逻辑，只在一倍速下播放动画时才启用，避免过度抢镜
    local currSpeed = self.world.StateSystem:GetPlaySpeed()
    if not self.world.CameraSystem:GetFreeCameraEnabled() and currSpeed == 1 then
        if self.args.kvData and self.args.kvData.isHeavy then
            self:DOPlayAnim()
        -- elseif self.args.kvData and self.args.kvData.dontUseCamera then
            -- self:DOPlayAnim()
        elseif self.args.kvData and self.args.kvData.isMerge then
            self:DOPlayAnim()
        elseif self.args.kvData and self.args.kvData.isAttacking then
            self:LoadCamera()
        else
            self:DOPlayAnim()
        end
    else
        self:DOPlayAnim()
    end
end

function PlayMechaAnimTB:GetEntity()
    local markTargetMap = self.args.info.markTargetMap
    local markTarget = self.conf.markTarget or BattleDefine.MarkTargetType.target
    -- 指定了有效targetIndex时取单个实体，否则取第一个
    -- return self.world.MixedSystem:GetMarkMapEntity(markTargetMap, markTarget, self.conf.targetIndex)
    return self.world.MixedSystem:GetTargetEntity(markTargetMap, self.conf)
end

function PlayMechaAnimTB:PlayAnim()
    local entity = self.pendingEntity
    local animName = self.pendingAnimName

    if entity.AnimComponent:IsAnimPlaying("dead") or entity.AnimComponent:IsAnimPlaying("exeunt") then
        -- LogError("PlayMechaAnimTB:PlayAnim 当前正在播放死亡相关动画，不允许播放："..animName)
        return 0
    end

    local realAnimName = animName
    if not entity.AnimComponent:HasAnim(animName) then
        realAnimName = BattleDefine.ToDefaultAnim[animName] or animName
    end

    entity.AnimComponent:PlayAnim(realAnimName)
    local clipTime = entity.AnimComponent:GetClipTime(realAnimName)
    return clipTime
end

function PlayMechaAnimTB:DoneTimer()
    self.doneTimer = nil
    -- 动画结束时恢复镜头与实体
    self:ResetCamera()
    self:BehaviorComplete()
end

function PlayMechaAnimTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
    if self.blendTimer then
        self.world.TimerSystem:RemoveTimer(self.blendTimer)
        self.blendTimer = nil
    end
end

function PlayMechaAnimTB:OnUpdate(deltaTime)
end

-- ====================== 镜头相关 ======================
function PlayMechaAnimTB:LoadCamera()
    -- 缓存本 TB 用到的实体（由外部设置 pendingEntity）
    local entity = self.pendingEntity
    local animName = self.pendingAnimName

    -- 合法性判断
    if not entity or not entity.TposeComponent:HasTpose() then
        self:DOPlayAnim()
        return
    end

    -- 敌人不播放镜头
    if entity.CampComponent:GetCamp() == BattleDefine.Camp.enemy then
        self:DOPlayAnim()
        return
    end

    -- 自由镜头开启时不播本 TB 的攻击镜头，减轻抢镜（主要影响因素可能还在别处：其他 VCam 优先级、SetShowTimeCameraLayer 等）
    if self.world.CameraSystem:GetFreeCameraEnabled() then
        self:DOPlayAnim()
        return
    end

    local modelId = entity.ObjectDataComponent.modelId
    local mode = entity.TposeComponent.mode
    local cardUid = entity.ObjectDataComponent:GetCardUid()
    local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
    mode = self.world.MixedSystem:GetTimelineMode(cardInfo and cardInfo.cardId, mode)
    local cameraName = string.format("%s_%s_%s_camera", modelId, mode, animName)
    local cameraFile = string.format("timeline/carrier/%s/camera/%s.prefab", modelId, cameraName)

    -- 设置主相机初始为无过渡
    local cinemachineBrain = self.world.AssetsSystem.nodeObjs["main_camera"].gameObject:GetComponent(CinemachineBrain)
    cinemachineBrain.m_DefaultBlend = CinemachineBlendDefinition(CinemachineBlendDefinition.Style.Cut, 0)

    -- 资源可能加载失败，直接播放动画
    if not AssetLoader.Instance:IsLocationValid(cameraFile) then
        -- LogError("PlayMechaAnimTB:LoadCamera 镜头资源不存在", cameraFile)
        self:DOPlayAnim()
        return
    end

    self.cameraFile = cameraFile
    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    local assetList = {}
    table.insert(assetList, { file = cameraFile, type = AssetType.Prefab })
    self.assetLoader:Load(assetList, self:ToFunc("OnCameraLoaded"))
end

function PlayMechaAnimTB:OnCameraLoaded(_,hasError)
    if hasError then
        self:RemoveCameraLoader()
        self:ReleasePendingCameraScope()
        self:DOPlayAnim()
        return
    end
    self.camera = self.assetLoader:Instantiate(self.cameraFile)
    self.camera:AddComponent(AssetScopeComponent):Adopt(self.assetScope)
    self.assetScope = nil
    self:RemoveCameraLoader()

    -- 读取播放时长与过渡
    local playableDirector = self.camera.gameObject:GetComponent(PlayableDirector)
    if playableDirector then
        playableDirector.time = 0
        playableDirector:Play()
    end

    -- 机体挂到镜头的entity节点
    local entity = self.pendingEntity

    -- 记录原始父节点与本地位姿，确保结束时还原
    self.fromParent = entity.TransformComponent.transform.parent
    self.fromPos = entity.TransformComponent.transform.localPosition
    self.fromRotate = entity.TransformComponent.transform.localEulerAngles

    -- 1) 创建瞬间：相机根位置/旋转与机体同步
    local entityTrans = entity.TransformComponent.transform
    self.camera.transform:SetParent(self.fromParent)
    self.camera.transform.position = entityTrans.position
    self.camera.transform.rotation = entityTrans.rotation
    self.camera.transform.localScale = entity.TposeComponent:GetScale()

    -- 2) 机体跟随镜头内 entity 节点(可能有动画k帧)
    local entityNode = self.camera.transform:Find("entity")
    if entityNode then
        -- self.entityFollowConstraint = self:AttachParentConstraint(entityTrans, entityNode)
        entityTrans:SetParent(entityNode)
        self.entityNode = entityNode
    end

    local isFollowEntity = true
    if self.camera.transform:Find("blend/df") then
        isFollowEntity = false
    end

    -- 3) 相机跟随机体(通过df 节点配置，动态判断)
    local cameraNode = self.camera.transform:Find("camera")
    if cameraNode and isFollowEntity then
        local entityTposeTrans = entity.TposeComponent:GetTpose().transform
        -- self.cameraFollowConstraint = self:AttachParentConstraint(cameraNode, entityTrans)
        cameraNode:SetParent(entityTposeTrans)
        cameraNode.localPosition = Vector3.zero
        cameraNode.localRotation = Quaternion.identity
        cameraNode.localScale = Vector3.one
        self.cameraNode = cameraNode
    end

    -- 监听镜头切换开始事件，在镜头真正切换时关闭 UI 相机
    self.cameraChangedEventUid = self.world.EventTriggerSystem:AddListener(
        BattleEvent.cinemachine_camera_changed,
        self:ToFunc("OnCinemachineCameraChanged")
    )

    -- 下一帧根据blend节点设置混合时长
    self.blendTimer = self.world.TimerSystem:AddTimerByNextFrame(1, 0, self:ToFunc("ChangeBlendTimer"))

    -- 将旋转目标透传给攻击流程：若存在，则攻击流程优先旋转该节点
    self.world.StateSystem:SetCacheInfo("attack_camera_transform_" .. tostring(entity.uid), entityNode)
    

    -- 镜头准备完成，开始动画
    self:DOPlayAnim()
end

-- 动态创建 ParentConstraint，保持当前相对偏移
-- function PlayMechaAnimTB:AttachParentConstraint(targetTrans, sourceTrans)
--     -- 关键参数校验：快速失败
--     assert(targetTrans and sourceTrans, "ParentConstraint 参数非法")

--     local constraint = targetTrans.gameObject:GetComponent(ParentConstraint)
--     if constraint then
--         GameObject.Destroy(constraint)
--     end

--     local constraint = targetTrans.gameObject:AddComponent(ParentConstraint)

--     local source = ConstraintSource()
--     source.sourceTransform = sourceTrans
--     source.weight = 1
--     local index = constraint:AddSource(source)

--     -- 保持当前相对位姿偏移（避免瞬移抖动）
--     local posOffset = sourceTrans:InverseTransformPoint(targetTrans.position)
--     local rotOffsetQuat = Quaternion.Inverse(sourceTrans.rotation) * targetTrans.rotation
--     constraint:SetTranslationOffset(index, posOffset)
--     constraint:SetRotationOffset(index, rotOffsetQuat.eulerAngles)

--     constraint.constraintActive = true
--     constraint.locked = true
--     return constraint
-- end

function PlayMechaAnimTB:ChangeBlendTimer()
    self.blendTimer = nil
    if not self.camera then return end

    local blendRoot = self.camera.transform:Find("blend")
    if not blendRoot or blendRoot.childCount <= 0 then return end

    local blendTime = tonumber(blendRoot:GetChild(0).gameObject.name) or 0
    local cinemachineBrain = self.world.AssetsSystem.nodeObjs["main_camera"].gameObject:GetComponent(CinemachineBrain)
    if blendTime <= 0 then
        cinemachineBrain.m_DefaultBlend = CinemachineBlendDefinition(CinemachineBlendDefinition.Style.Cut, 0)
    else
        cinemachineBrain.m_DefaultBlend = CinemachineBlendDefinition(CinemachineBlendDefinition.Style.Linear, blendTime)
    end
end

-- CinemachineBrain 活动镜头变化回调，关闭 UI 相机
function PlayMechaAnimTB:OnCinemachineCameraChanged(params)
    -- 镜头切换开始时关闭 UI 相机
    mod.MixedCtrl:SetUICameraEnabled(false, "机甲动画镜头切换")
    self.hideUICamera = true

    -- 移除事件监听，只处理一次
    self:RemoveCameraChangedListener()
end

function PlayMechaAnimTB:RemoveCameraChangedListener()
    if self.cameraChangedEventUid then
        self.world.EventTriggerSystem:RemoveListener(self.cameraChangedEventUid)
        self.cameraChangedEventUid = nil
    end
end

function PlayMechaAnimTB:ResetCamera()
    if not self.camera then return end

    local entity = self.pendingEntity
    if entity then
        -- 恢复机体到原有父节点与本地位姿
        if self.fromParent then
            entity.TransformComponent.transform:SetParent(self.fromParent)
        end
        if self.fromPos then
            entity.TransformComponent.transform.localPosition = self.fromPos
        end
        if self.fromRotate then
            entity.TransformComponent.transform.localEulerAngles = self.fromRotate
        end
    end

    -- -- 清理运行时约束，防止残留
    -- if self.entityFollowConstraint then
    --     GameObject.Destroy(self.entityFollowConstraint)
    --     self.entityFollowConstraint = nil
    -- end
    -- if self.cameraFollowConstraint then
    --     GameObject.Destroy(self.cameraFollowConstraint)
    --     self.cameraFollowConstraint = nil
    -- end

    -- 清除旋转目标缓存
    if entity then
        self.world.StateSystem:SetCacheInfo("attack_camera_transform_" .. tostring(entity.uid), nil)
    end

    if self.entityNode then
        GameObject.Destroy(self.entityNode.gameObject)
        self.entityNode = nil
    end
    
    if self.cameraNode then
        GameObject.Destroy(self.cameraNode.gameObject)
        self.cameraNode = nil
    end

    if self.camera then
        GameObject.Destroy(self.camera.gameObject)
        self.camera = nil
    end
    mod.MixedCtrl:SetUICameraEnabled(true, "机甲动画结束")
end

function PlayMechaAnimTB:ResetUICamera()
    if self.hideUICamera then
        mod.MixedCtrl:SetUICameraEnabled(true, "机甲动画结束")
    end
end

function PlayMechaAnimTB:RemoveCameraLoader()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function PlayMechaAnimTB:ReleasePendingCameraScope()
    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

-- 在镜头（若有）准备完成后启动动画与计时
function PlayMechaAnimTB:DOPlayAnim()
    if self.hasStartedAnim then return end
    self.hasStartedAnim = true

    if not self.pendingEntity or not self.pendingAnimName then
        self:BehaviorComplete()
        return
    end

    local animMaxTime = self:PlayAnim()

    local lastTime = nil
    if self.conf.isDynamicDuration or self.conf.duration < 0 then
        lastTime = animMaxTime * 1000
    else
        lastTime = self.conf.duration
    end

    if lastTime and lastTime > 0 then
        self.doneTimer = self.world.TimerSystem:AddTimer(1, lastTime * 0.001, self:ToFunc("DoneTimer"))
        self.doneTimer:SetScale(true)
    else
        self:BehaviorComplete()
    end
end
