PlaySwitchModeAnimTB = BaseClass("PlaySwitchModeAnimTB",TimelineBehaviorBase)

function PlaySwitchModeAnimTB:__Init()
    self.doneTimer = nil
end

function PlaySwitchModeAnimTB:__Delete()
    self:RemoveDoneTimer()
end

function PlaySwitchModeAnimTB:OnInit()

end

function PlaySwitchModeAnimTB:OnStart()
--     LogTable("播放变身动画TB",self.args)

    local carrierEntity = self.world.MixedSystem:GetGridDroneEntityByCardUid(self.args.info.cardUid)
    local mode = self.world.DataSystem:GetCarrierMode(self.args.info.cardUid)
    if DEBUG_MODE then
        mode = DEBUG_MODE
    end

    local animName = "trans_to" .. tostring(mode)

    carrierEntity.AnimComponent:PlayAnim(animName)

    local time = carrierEntity.AnimComponent:GetClipTime(animName)
    self.doneTimer = self.world.TimerSystem:AddTimer(1,time,self:ToFunc("OnDoneTimer"))
    self.doneTimer:SetScale(true)
end

function PlaySwitchModeAnimTB:OnDoneTimer()
    self.doneTimer = nil
    self:BehaviorComplete()
end

function PlaySwitchModeAnimTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function PlaySwitchModeAnimTB:OnUpdate(deltaTime)
end
