RemoveDeviceDroneShiledTB = BaseClass("RemoveDeviceDroneShiledTB", TimelineBehaviorBase)

function RemoveDeviceDroneShiledTB:__Init()
end

function RemoveDeviceDroneShiledTB:__Delete()
end

function RemoveDeviceDroneShiledTB:OnInit()

end

function RemoveDeviceDroneShiledTB:OnStart()
--     LogTable("移除无人机圣盾", self.args)
    
    local entity = self.world.MixedSystem:GetGridDroneEntityByCardUid(self.args.targetDevice)
    if not entity then
        self:BehaviorComplete()
        return
    end
    
    -- 预更新数据：从attrMap中移除圣盾属性
    local cardInfo = self.world.DataSystem:GetCardInfo(self.args.targetDevice)
    if cardInfo and cardInfo.attrMap then
        local newAttrMap = {}
        for _, attr in ipairs(cardInfo.attrMap) do
            if attr.attr ~= BattleDefine.CardAttrType.attkShield then
                table.insert(newAttrMap, attr)
            end
        end
        cardInfo.attrMap = newAttrMap
    end
    
    -- 触发特效刷新
    if entity.DynamicEffectComponent then
        entity.DynamicEffectComponent:RefreshEffect()
    end

    self:BehaviorComplete()
end

function RemoveDeviceDroneShiledTB:OnUpdate(deltaTime)
end
