ShakeScreenTB = BaseClass("ShakeScreenTB",TimelineBehaviorBase)

function ShakeScreenTB:__Init()
    self.cameraShakeAnim = nil
end

function ShakeScreenTB:__Delete()
    if self.cameraShakeAnim then
        self.cameraShakeAnim:Delete()
        self.cameraShakeAnim = nil
    end
end

function ShakeScreenTB:OnInit()
end

function ShakeScreenTB:OnStart()
--     LogTable("震屏TB",self.args)

    -- 自由镜头开启时震屏会与每帧写入的镜头控制冲突，导致画面抖动，直接跳过
    if self.world.CameraSystem:GetFreeCameraEnabled() then
        self:BehaviorComplete()
        return
    end

    local currCamera = self.world.CameraSystem:GetCurrCamera()

    local cameraTrans = currCamera.camera.transform
    local time = self.conf.duration * 0.001
    local strength = self.conf.strength
    local vibrato = self.conf.vibrato
    local randomness = self.conf.randomness
    local snapping = self.conf.snapping
    local fadeOut = self.conf.fadeOut

    -- 通过CameraSystem管理震屏基准位置，解决多个震屏同时运行时位置偏移问题
    self.world.CameraSystem:StartShake(cameraTrans)
    self.currCamera = cameraTrans

    self.cameraShakeAnim = ShakePositionAnim.New(cameraTrans,time,strength,vibrato,randomness,snapping,fadeOut)
    self.cameraShakeAnim:SetTimeScale(true)
    self.cameraShakeAnim:SetComplete(self:ToFunc("ShakeDone"))
    self.cameraShakeAnim:Play()
end

function ShakeScreenTB:OnUpdate(deltaTime)
end

function ShakeScreenTB:ShakeDone()
    self.cameraShakeAnim:Delete()
    self.cameraShakeAnim = nil

    -- 通过CameraSystem管理震屏结束，只有最后一个震屏结束时才恢复位置
    if self.currCamera then
        self.world.CameraSystem:EndShake(self.currCamera)
    end
    self:BehaviorComplete()
end
