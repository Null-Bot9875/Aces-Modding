ShuffleHandCardTB = BaseClass("ShuffleHandCardTB",TimelineBehaviorBase)

function ShuffleHandCardTB:__Init()
    self.shuffleEffect = nil
end

function ShuffleHandCardTB:__Delete()
    self:RemoveEffect()
end

function ShuffleHandCardTB:OnInit()
end

function ShuffleHandCardTB:OnStart()
--     LogTable("洗牌TB",self.args)

    local camp = self.world.DataSystem:GetCamp(self.args.targetPlayer)
    local library = self.world.AssetsSystem.uiObjs["campObjs"][camp].library


    local setting = {}
    setting.assetId = "ui_battle_card_library_shuffle"
    setting.parent = library.transform
    setting.onComplete = self:ToFunc("EffectDone")

    self.shuffleEffect = UIEffect.New()
    self.shuffleEffect:Init(setting)
    self.shuffleEffect:Play()
end

function ShuffleHandCardTB:EffectDone()
    self:RemoveEffect()
    self:BehaviorComplete()
end

function ShuffleHandCardTB:RemoveEffect()
    if self.shuffleEffect then
        self.shuffleEffect:Delete()
        self.shuffleEffect = nil
    end
end

function ShuffleHandCardTB:OnUpdate(deltaTime)
end
