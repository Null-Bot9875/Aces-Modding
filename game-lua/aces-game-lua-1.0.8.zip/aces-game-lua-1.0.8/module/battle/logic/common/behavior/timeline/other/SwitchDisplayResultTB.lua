SwitchDisplayResultTB = BaseClass("SwitchDisplayResultTB", TimelineBehaviorBase)

local EXEUNT_CONF_FALLBACK = "common_exeunt" -- 旧模型离场通用配置
local SWITCH_ENTRANCE_CONF_FALLBACK = "common_1_entrance" -- 新模型入场通用配置

function SwitchDisplayResultTB:__Init()
    self.exeuntTimeline = nil
    self.switchEntranceTimeline = nil

    self.currCardUid = nil
    self._newEntity = nil
end

function SwitchDisplayResultTB:__Delete()
    if self.exeuntTimeline then
        self.exeuntTimeline:Delete()
        self.exeuntTimeline = nil
    end
    if self.switchEntranceTimeline then
        self.switchEntranceTimeline:Delete()
        self.switchEntranceTimeline = nil
    end

    if self._newEntity and self._newEntity.TposeComponent then
        self._newEntity.TposeComponent:RemoveTposeListener()
    end
    self._newEntity = nil

    -- self.world.StateSystem:SetSpeedLock(false)
    self.world.StateSystem:SetCacheInfo("cantUseFreeCamera", false)
end

function SwitchDisplayResultTB:OnInit()
end

function SwitchDisplayResultTB:OnStart()
--     LogTable("播放切换表现TB", self.args)
    self.world.StateSystem:SetCacheInfo("cantUseFreeCamera", true)
    -- self.world.StateSystem:ChangeSpeed(false)
    -- self.world.StateSystem:SetSpeedLock(true)

    local cardUid = self:FindSwitchModeCardUid()
    if not cardUid then
--         Log("没有找到需要切换表现的卡牌")
        self:BehaviorComplete()
        return
    end
    self.currCardUid = cardUid
    self.world.StateSystem:SetCacheInfo("pre_dead_device_" .. self.currCardUid, false)

    -- 变身/切换完成后触发BGM阶段检测（沿用现有逻辑）
    if mod and mod.BgmCtrl then
        mod.BgmCtrl:CheckAce2Phase(self.world)
    end

    local oldEntity = self.world.MixedSystem:GetGridDroneEntityByCardUid(cardUid)
    if not oldEntity or not oldEntity.ObjectDataComponent then
        LogError("切换表现：未找到旧实体", tostring(cardUid))
        self:BehaviorComplete()
        return
    end

    local oldCardId = oldEntity.ObjectDataComponent:GetCardId()
    local newCardInfo = self.world.DataSystem:GetCardInfo(cardUid)
    assert(newCardInfo ~= nil, "切换表现：newCardInfo 不能为空")
    local newCardId = newCardInfo.cardId

    if oldCardId == nil then
        LogError("切换表现：旧实体未记录cardId", tostring(cardUid))
        -- 旧实体仍在场，确保模式与数据一致
        if oldEntity.TposeComponent then
            oldEntity.TposeComponent:SetMode(self.world.DataSystem:GetCarrierMode(cardUid))
        end
        self:BehaviorComplete()
        return
    end

    if oldCardId == newCardId then
        -- 同卡切换：模式可能已变，设置正确模式后退出（本表现仅处理换卡切换）
        LogError("切换表现：检测到前后cardId一致")
        if oldEntity.TposeComponent then
            oldEntity.TposeComponent:SetMode(self.world.DataSystem:GetCarrierMode(cardUid))
        end
        self:BehaviorComplete()
        return
    end

    -- 换卡切换：先播旧模型exeunt，再创建新实体并播switch_entrance
    self:PlayExeunt(oldEntity)
end

function SwitchDisplayResultTB:FindSwitchModeCardUid()
    local info = self.args and self.args.info
    local results = info and info.results
    if not results then
        return nil
    end

    for _, v in ipairs(results) do
        if v.event == BattleDefine.EffectEventType.switch_mode then
            return v.cardUid
        end
    end
    return nil
end

function SwitchDisplayResultTB:PlayExeunt(oldEntity)
    local modelId = oldEntity.ObjectDataComponent.modelId
    local mode = oldEntity.TposeComponent.mode
    self.world.StateSystem:SetCacheInfo("pre_dead_device_" .. self.currCardUid, false)


    -- local confName = string.format("%s_%s_exeunt", modelId, mode)
    -- if not Config.HasConf(confName) then
    --     confName = EXEUNT_CONF_FALLBACK
    -- end
    local confName = EXEUNT_CONF_FALLBACK

    local playDatas = Config.GetLua(confName)
    local playActions = {}
    for _, action in ipairs(playDatas) do
        table.insert(playActions, { args = nil, action = action })
    end

    local cardUid = self.currCardUid
    local execArgs = {}
    execArgs.info = {
        srcPlayer = self.args.info.srcPlayer,
        cardUid = cardUid,
        markTargetMap = {
            [BattleDefine.MarkTargetType.src] = { cardUid },
            [BattleDefine.MarkTargetType.target] = {},
        },
    }
    execArgs.targetRoleUids = {}
    execArgs.targetDeviceUids = {}
    execArgs.showDeviceUids = self.args.showDeviceUids

    self.exeuntTimeline = ActionTimeline.New()
    self.exeuntTimeline:SetWorld(self.world)
    self.exeuntTimeline:OnInit(oldEntity, playActions, execArgs)
    self.exeuntTimeline:SetComplete(self:ToFunc("OnExeuntDone"))
--     Log("播放切换表现TB离场", confName)
    self.exeuntTimeline:Start()
end

function SwitchDisplayResultTB:OnExeuntDone()
    local cardUid = self.currCardUid
    local oldEntity = self.world.MixedSystem:GetGridDroneEntityByCardUid(cardUid)

    -- 旧实体已经播完离场，移除实体（cardUid不变，按当前gridInfo构造参数即可）
    local gridInfo = self.world.DataSystem:GetGridInfoByDeviceUid(cardUid)
    if not gridInfo then
        LogError("切换表现：离场后未找到gridInfo", tostring(cardUid))
        -- 旧实体未能移除仍在场，确保模式与数据一致
        if oldEntity and oldEntity.TposeComponent then
            oldEntity.TposeComponent:SetMode(self.world.DataSystem:GetCarrierMode(cardUid))
        end
        self:BehaviorComplete()
        return
    end
    self.world.DroneDeviceSystem:RemoveSingleDevice({ gridInfo })

    -- 创建新实体（不走默认entrance，由本TB播switch_entrance）
    local camp = nil
    if oldEntity and oldEntity.CampComponent then
        camp = oldEntity.CampComponent:GetCamp()
    else
        camp = self.world.DataSystem:GetCamp(self.args.info.srcPlayer)
    end

    local deviceInfosMap = self.world.MixedSystem:GenerateDeviceInfos({ gridInfo })
    local newDeviceInfos = deviceInfosMap and deviceInfosMap[cardUid]
    if not newDeviceInfos then
        LogError("切换表现：生成deviceInfos失败", tostring(cardUid))
        self:BehaviorComplete()
        return
    end

    local newEntity = self.world.DroneDeviceSystem:CreateSingleDevice(camp, newDeviceInfos, true)
    if not newEntity then
        LogError("切换表现：创建新实体失败", tostring(cardUid))
        self:BehaviorComplete()
        return
    end
    self._newEntity = newEntity

    self:TryPlaySwitchEntrance(newEntity)
end

function SwitchDisplayResultTB:TryPlaySwitchEntrance(entity)
    if not entity or not entity.TposeComponent then
        self:BehaviorComplete()
        return
    end

    -- 等待tpose加载完成后再播放进场
    if not entity.TposeComponent:ExistTpose() then
        entity.TposeComponent:AddTposeListener(self:ToFunc("OnNewEntityTposeReady"))
        return
    end

    self:PlaySwitchEntrance(entity)
end

function SwitchDisplayResultTB:OnNewEntityTposeReady()
    if not self._newEntity or not self._newEntity.TposeComponent then
        self:BehaviorComplete()
        return
    end
    self._newEntity.TposeComponent:RemoveTposeListener()
    self:PlaySwitchEntrance(self._newEntity)
end

function SwitchDisplayResultTB:PlaySwitchEntrance(entity)
    local cardUid = self.currCardUid
    local newMode = self.world.DataSystem:GetCarrierMode(cardUid)
    self.world.StateSystem:SetCacheInfo("pre_dead_device_" .. self.currCardUid, false)

    -- 先设置为新模式，确保配置名与表现一致
    entity.TposeComponent:SetMode(newMode)

    local modelId = entity.ObjectDataComponent.modelId
    local mode = entity.TposeComponent.mode
    local cardUid = entity.ObjectDataComponent:GetCardUid()
    local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
    mode = self.world.MixedSystem:GetTimelineMode(cardInfo and cardInfo.cardId, mode)
    local confName = string.format("%s_%s_entrance", modelId, mode)
    if not Config.HasConf(confName) then
        confName = SWITCH_ENTRANCE_CONF_FALLBACK
    end

    local playDatas = Config.GetLua(confName)
    local playActions = {}
    for _, action in ipairs(playDatas) do
        table.insert(playActions, { args = nil, action = action })
    end

    local execArgs = {}
    execArgs.info = {
        srcPlayer = self.args.info.srcPlayer,
        cardUid = cardUid,
        markTargetMap = {
            [BattleDefine.MarkTargetType.src] = { cardUid },
            [BattleDefine.MarkTargetType.target] = {},
        },
    }
    execArgs.targetRoleUids = {}
    execArgs.targetDeviceUids = {}
    execArgs.showDeviceUids = self.args.showDeviceUids

    self.switchEntranceTimeline = ActionTimeline.New()
    self.switchEntranceTimeline:SetWorld(self.world)
    self.switchEntranceTimeline:OnInit(entity, playActions, execArgs)
    self.switchEntranceTimeline:SetComplete(self:ToFunc("OnSwitchEntranceDone"))
--     Log("播放切换表现TB进场", confName)
    self.switchEntranceTimeline:Start()
end

function SwitchDisplayResultTB:OnSwitchEntranceDone()
    self:BehaviorComplete()
end

function SwitchDisplayResultTB:OnCancel()
end

function SwitchDisplayResultTB:OnUpdate(deltaTime)
    if self.exeuntTimeline then
        self.exeuntTimeline:Update(deltaTime)
    end
    if self.switchEntranceTimeline then
        self.switchEntranceTimeline:Update(deltaTime)
    end
end

