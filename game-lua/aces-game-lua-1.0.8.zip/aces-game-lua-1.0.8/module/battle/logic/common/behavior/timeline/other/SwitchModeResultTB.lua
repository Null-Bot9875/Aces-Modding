SwitchModeResultTB = BaseClass("SwitchModeResultTB", TimelineBehaviorBase)

function SwitchModeResultTB:__Init()
    self._needModelSwap = false
    self._newEntity = nil
end

function SwitchModeResultTB:__Delete()
    if self.switchModeActionTimeline then
        self.switchModeActionTimeline:Delete()
        self.switchModeActionTimeline = nil
    end

    if self._newEntity and self._newEntity.TposeComponent then
        self._newEntity.TposeComponent:RemoveTposeListener()
    end
    self._newEntity = nil

    self.world.StateSystem:SetSpeedLock(false)
    self.world.StateSystem:SetCacheInfo("cantUseFreeCamera", false)
end

function SwitchModeResultTB:CheckAndSpawnAce2SwitchEvo(carrierEntity, curMode, newMode)
    local modelId = carrierEntity.ObjectDataComponent.modelId
    if modelId ~= "ace_2" then
        return
    end
    if not (curMode == 1 and (newMode == 2 or newMode == 3)) then
        return
    end
    if self.world.AssetsSystem.ace2SwitchEvoObj then
        return
    end

    local effectNode = self.world.AssetsSystem.nodeObjs["effect"]
    if not effectNode then
        LogError("effect node not found")
        return
    end

    local setting = {}
    setting.assetId = "mecha_ace_2_switch_evo"
    setting.parent = effectNode
    setting.isPool = false

    local sceneEffect = self.world.AssetsSystem:PlaySceneEffect(setting)
    if sceneEffect then
        self.world.AssetsSystem:SetAce2SwitchEvoObj(sceneEffect)
    end
end

function SwitchModeResultTB:OnInit()
end

function SwitchModeResultTB:OnStart()
--     LogTable("播放切换模式TB", self.args)
    self.world.StateSystem:SetCacheInfo("cantUseFreeCamera", true)
    
    self.world.StateSystem:ChangeSpeed(false)
    self.world.StateSystem:SetSpeedLock(true)

    local cardUid = nil
    for index, value in ipairs(self.args.info.results) do
        if value.event == BattleDefine.EffectEventType.switch_mode then
            cardUid = value.cardUid
            break
        end
    end
    if not cardUid then
--         Log("没有找到需要变身机甲的卡牌")
        self:BehaviorComplete()
        return
    end

    self.currCardUid = cardUid

    local cardInfo = self.world.DataSystem:GetCardInfo(cardUid)
    -- local gridInfo = self.world.DataSystem:GetGridInfoByDeviceUid(cardUid)
    -- local gridInfo = self.world.DataSystem:GetPlayerGridInfo(self.args.info.srcPlayer)

--     LogTable("需要变身机甲的卡牌信息",cardInfo)

    local newMode = self.world.DataSystem:GetCarrierMode(cardUid)

--     Log("准备切换模式",newMode)

    -- 变身完成后触发BGM阶段检测
    if mod and mod.BgmCtrl then
        mod.BgmCtrl:CheckAce2Phase(self.world)
    end

    local carrierEntity = self.world.MixedSystem:GetGridDroneEntityByCardUid(cardUid)
    local conf = Config.Get("card_def","config","cardId",cardInfo.cardId)
    carrierEntity.ObjectDataComponent:SetCardConf(conf)
    local newModelId = conf.extend.modelId
    self._needModelSwap = (newModelId ~= carrierEntity.ObjectDataComponent.modelId)
    if self._needModelSwap then
--         Log("变身需要切换模型", carrierEntity.ObjectDataComponent.modelId, "->", newModelId)
    end

    -- 同模型模式切换时才检查模式是否实际变化；换模型时直接走实体替换
    if not self._needModelSwap then
        local isSwitchMode = carrierEntity.TposeComponent:IsSwitchMode(newMode)
        if not isSwitchMode then
--             Log("无法切换模式")
            self:BehaviorComplete()
            return
        end
    end

    local curMode,lastMode = carrierEntity.TposeComponent:GetMode()
    local modelId = carrierEntity.ObjectDataComponent.modelId
    local switchModeConfName =  string.format("%s_%s_%s_switch_mode",modelId,curMode,newMode)

    self:CheckAndSpawnAce2SwitchEvo(carrierEntity, curMode, newMode)

    -- 特殊处理 ace_4 没有3状态下的动作，直接这样处理保证能用到2状态下的动作
    if modelId == "ace_4" and newMode == 3 then
        carrierEntity.TposeComponent:SetMode(newMode)
    end

--     Log("准备播放切换模式配置",switchModeConfName)

    if not Config.HasConf(switchModeConfName) then
        self:SwitchModeDone()
        return
    end

--     Log("播放切换模式配置",switchModeConfName)

    local playDatas = Config.GetLua(switchModeConfName)
--     LogTable("播放数据",playDatas)
    local playActions = {}
    for _,v in ipairs(playDatas) do
        table.insert(playActions,{args = nil,action = v})
    end

    --

    local execArgs = {}
    execArgs.info = {srcPlayer = self.args.info.srcPlayer,cardUid = cardUid}
    execArgs.targetRoleUids = {}
    execArgs.targetDeviceUids = {}
    execArgs.showDeviceUids = self.args.showDeviceUids
    execArgs.info.markTargetMap = {
        [BattleDefine.MarkTargetType.src] = {cardUid},
        [BattleDefine.MarkTargetType.target] = {},
    }


    self.switchModeActionTimeline = ActionTimeline.New()
    self.switchModeActionTimeline:SetWorld(self.world)
    self.switchModeActionTimeline:OnInit(carrierEntity,playActions,execArgs)
    self.switchModeActionTimeline:SetComplete(self:ToFunc("SwitchModeDone"))
    self.switchModeActionTimeline:Start()


    -- 删除
    -- local removeDeviceInfos = self.world.MixedSystem:GenerateDeviceInfos(infos.deleteGridInfos)
    -- for deviceUid, deviceInfo in pairs(removeDeviceInfos) do
    --     local args = {}
    --     args.deviceUid = deviceUid
    --     args.deviceInfo = deviceInfo
    --     self.world.ActionSystem:ParseAction(BattleDefine.ActionType.remove_drone, args, 1)
    -- end
end

function SwitchModeResultTB:SwitchModeDone()
--     Log("变身播放完成了")
    local newMode = self.world.DataSystem:GetCarrierMode(self.currCardUid)
    local cardUid = self.currCardUid

    if self._needModelSwap then
        -- 模型发生变化，参考翻转实现：移除旧实体，创建新实体
        local carrierEntity = self.world.MixedSystem:GetGridDroneEntityByCardUid(cardUid)
        local gridInfo = self.world.DataSystem:GetGridInfoByDeviceUid(cardUid)
        if not gridInfo then
            LogError("变身切换模型：未找到gridInfo", tostring(cardUid))
            self.world.StateSystem:SetSpeedLock(false)
            self:BehaviorComplete()
            return
        end

        local camp = nil
        if carrierEntity and carrierEntity.CampComponent then
            camp = carrierEntity.CampComponent:GetCamp()
        else
            camp = self.world.DataSystem:GetCamp(self.args.info.srcPlayer)
        end

        self.world.DroneDeviceSystem:RemoveSingleDevice({ gridInfo })

        local deviceInfosMap = self.world.MixedSystem:GenerateDeviceInfos({ gridInfo })
        local newDeviceInfos = deviceInfosMap and deviceInfosMap[cardUid]
        if not newDeviceInfos then
            LogError("变身切换模型：生成deviceInfos失败", tostring(cardUid))
            self.world.StateSystem:SetSpeedLock(false)
            self:BehaviorComplete()
            return
        end

        local newEntity = self.world.DroneDeviceSystem:CreateSingleDevice(camp, newDeviceInfos, true)
        if not newEntity then
            LogError("变身切换模型：创建新实体失败", tostring(cardUid))
            self.world.StateSystem:SetSpeedLock(false)
            self:BehaviorComplete()
            return
        end
        self._newEntity = newEntity

        -- 等待模型加载完成后再设置模式（参考翻转实现）
        if not newEntity.TposeComponent:ExistTpose() then
            newEntity.TposeComponent:AddTposeListener(self:ToFunc("OnNewEntityReady"))
            return
        end

        newEntity.TposeComponent:SetMode(newMode)
        self.world.StateSystem:SetSpeedLock(false)
        self:BehaviorComplete()
    else
        -- 同模型模式切换
        local carrierEntity = self.world.MixedSystem:GetGridDroneEntityByCardUid(cardUid)
        carrierEntity.TposeComponent:SetMode(newMode)
        self.world.StateSystem:SetSpeedLock(false)
        self:BehaviorComplete()
    end
end

function SwitchModeResultTB:OnNewEntityReady()
    if self._newEntity and self._newEntity.TposeComponent then
        self._newEntity.TposeComponent:RemoveTposeListener()
        local newMode = self.world.DataSystem:GetCarrierMode(self.currCardUid)
        self._newEntity.TposeComponent:SetMode(newMode)
    end
    self.world.StateSystem:SetSpeedLock(false)
    self:BehaviorComplete()
end

function SwitchModeResultTB:OnCancel()

end

function SwitchModeResultTB:OnUpdate(deltaTime)
    if self.switchModeActionTimeline then
        self.switchModeActionTimeline:Update(deltaTime)
    end
end
