EnergyResultTB = BaseClass("EnergyResultTB", TimelineBehaviorBase)

function EnergyResultTB:__Init()
    self.actionTimeline = nil
end

function EnergyResultTB:__Delete()
    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end
end

function EnergyResultTB:OnInit()
end

function EnergyResultTB:OnStart()
--     LogTable("能量结算TB", self.args)

    -- local isAdd = self.args.data.value > 0
    local playActions = {}

    -- -- 机体特效
    -- local effectId = isAdd and "1004" or "1004"
    -- table.insert(playActions, {
    --     args   = { targetPlayer = self.args.targetPlayer, effectId = effectId },
    --     action = { type = 61001, time = 0 }
    -- })

    -- -- 机体动画
    -- local animName = isAdd and "hit" or "hit"
    -- table.insert(playActions, {
    --     args   = { srcPlayer = self.args.targetPlayer, conf = { animName = animName } },
    --     action = { type = 10001, time = 0 }
    -- })

    -- -- 音效
    -- local audioId = isAdd and "hitted" or "hitted"
    -- table.insert(playActions, {
    --     args   = { conf = { audioId = audioId } },
    --     action = { type = 10006, time = 0 }
    -- })

    -- UI特效
    -- local startPos = {}
    -- local endPos = {}
    -- local camp = self.world.DataSystem:GetCamp(self.args.targetPlayer)

    -- if isAdd then
    --     -- 获得能量，从对应的实体飞出，到能量条UI
    --     startPos = self.world.MixedSystem:GetPosBySrcType(self.args.srcPlayer,self.args.effectSrcType,self.args.effectSrcValue)

    --     mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.GetEnergyFlyWorldPos, camp, endPos)
    --     endPos = endPos.pos
    -- else
    --     -- 花费能量，特效从能量条UI到堆叠
    --     mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.GetEnergyFlyWorldPos, camp, startPos)
    --     startPos = startPos.pos

    --     mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.GetStackWorldPos, endPos)
    --     endPos = endPos.pos
    -- end

    -- table.insert(playActions, {
    --     args   = {
    --         effectId = "ui_battle_particle_fly",
    --         parent = self.world.AssetsSystem.mainPanel.transform,
    --         scale = 120000,
    --         startPos = { x = startPos.x, y = startPos.y, z = 0 },
    --         endPos = { x = endPos.x, y = endPos.y, z = 0 },
    --         isWorld = true,
    --         time = 0.3,
    --     },
    --     action = { type = 60004, time = -1 }
    -- })

    -- 改变能量
    table.insert(playActions, {
        args   = { targetPlayer = self.args.targetPlayer, value = self.args.data.value },
        action = { type = 61005, time = 0 }
    })

    -- table.insert(playActions, {
    --     args   = {
    --         effectId = "ui_battle_particle_boom",
    --         scale = 120000,
    --         parent = self.world.AssetsSystem.mainPanel.transform,
    --         pos = { x = endPos.x, y = endPos.y, z = 0 },
    --         isWorld = true,
    --     },
    --     action = { type = 60002, time = -1 }
    -- })


    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(_, playActions, self.args)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()
end

function EnergyResultTB:TimelineDone()
--     Log("能量结算TB完成")
    self:BehaviorComplete()
end

function EnergyResultTB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end
