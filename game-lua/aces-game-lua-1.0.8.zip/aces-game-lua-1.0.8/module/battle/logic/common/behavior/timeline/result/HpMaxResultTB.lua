HpMaxResultTB = BaseClass("HpMaxResultTB", TimelineBehaviorBase)

function HpMaxResultTB:__Init()
end

function HpMaxResultTB:__Delete()

end

function HpMaxResultTB:OnInit()
end

function HpMaxResultTB:OnStart()
--     LogTable("血量上限结算TB", self.args)

    local isAdd = self.args.data.value > 0
    local playActions = {}

    -- 机体特效
    local effectId = isAdd and "1004" or "1004"
    table.insert(playActions, {
        args   = { targetPlayer = self.args.targetPlayer, effectId = effectId },
        action = { type = 61001, time = 0 }
    })

    -- 机体动画
    local animName = isAdd and "hit" or "hit"
    table.insert(playActions, {
        args   = { srcPlayer = self.args.targetPlayer, conf = { animName = animName } },
        action = { type = 10001, time = 0 }
    })

    -- 音效
    local audioId = isAdd and "hitted" or "hitted"
    table.insert(playActions, {
        args   = { conf = { audioId = audioId } },
        action = { type = 10006, time = 0 }
    })

    -- UI特效
    local startPos = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackTopTransform)
    local endPos = {}
    local camp = self.world.DataSystem:GetCamp(self.args.targetPlayer)
    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.GetEnergyFlyPos, self.args.targetPlayer, endPos)
    if not endPos.pos then
        self:BehaviorComplete()
        return
    end

    table.insert(playActions, {
        args   = {
            parent = self.world.AssetsSystem.mainPanel.transform,
            startPos = { x = startPos.pos.x, y = startPos.pos.y, z = 0 },
            endPos = { x = endPos.pos.x, y = endPos.pos.y, z = 0 },
        },
        action = { type = 60004, time = -1,effectId = "ui_battle_particle_fly",scale = 120000,flyTime = 0.6}
    })

    -- 改变血量上限
    table.insert(playActions, {
        args   = { targetPlayer = self.args.targetPlayer, value = self.args.data.value },
        action = { type = 61004, time = 0 }
    })

    table.insert(playActions, {
        args   = {
            parent = self.world.AssetsSystem.mainPanel.transform,
            pos = { x = endPos.pos.x, y = endPos.pos.y, z = 0 },
        },
        action = { type = 60002, time = -1,effectId = "ui_battle_particle_boom",scale = 120000}
    })

    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(_, playActions, self.args)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()
end

function HpMaxResultTB:TimelineDone()
--     Log("血量上限结算TB完成")
    self:BehaviorComplete()
end

function HpMaxResultTB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end
