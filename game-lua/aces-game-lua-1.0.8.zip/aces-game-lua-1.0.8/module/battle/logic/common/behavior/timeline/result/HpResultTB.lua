HpResultTB = BaseClass("HpResultTB", TimelineBehaviorBase)

function HpResultTB:__Init()
end

function HpResultTB:__Delete()
end

function HpResultTB:OnInit()
end

function HpResultTB:OnStart()
--     LogTable("伤害结算TB", self.args)

    local isAdd = self.args.data.value > 0
    local playActions = {}

    -- 机体特效
    local effectId = isAdd and "1004" or "1004"
    table.insert(playActions, {
        args   = { targetPlayer = self.args.targetPlayer, effectId = effectId },
        action = { type = 61001, time = 0 }
    })

    -- 机体动画
    local animName = isAdd and "hit" or "hit"
    table.insert(playActions, {
        args   = { srcPlayer = self.args.targetPlayer, conf = { animName = animName } },
        action = { type = 10001, time = 0 }
    })

    -- 音效
    local audioId = isAdd and "hitted" or "hitted"
    table.insert(playActions, {
        args   = { conf = { audioId = audioId } },
        action = { type = 10006, time = 0 }
    })

    -- UI特效
    local startPos = mod.BattleFacade:SendEvent(BattleStackCardView.Event.GetStackTopTransform)
    local endPos = {}
    local camp = self.world.DataSystem:GetCamp(self.args.targetPlayer)
    mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.GetEnergyFlyPos, self.args.targetPlayer, endPos)
    if not endPos.pos then
        self:BehaviorComplete()
        return
    end

    table.insert(playActions, {
        args   = {
            parent = self.world.AssetsSystem.mainPanel.transform,
            startPos = { x = startPos.pos.x, y = startPos.pos.y, z = 0 },
            endPos = { x = endPos.pos.x, y = endPos.pos.y, z = 0 },
        },
        action = { type = 60004, time = -1,effectId = "ui_battle_particle_fly",scale = 120000,flyTime = 0.6}
    })

    -- 改变血量
    table.insert(playActions, {
        args   = { targetPlayer = self.args.targetPlayer, value = self.args.data.value },
        action = { type = 61003, time = 0 }
    })

    table.insert(playActions, {
        args   = {
            parent = self.world.AssetsSystem.mainPanel.transform,
            pos = { x = endPos.pos.x, y = endPos.pos.y, z = 0 },
        },
        action = { type = 60002, time = -1,effectId = "ui_battle_particle_boom",scale = 120000}
    })


    self.actionTimeline = ActionTimeline.New()
    self.actionTimeline:SetWorld(self.world)
    self.actionTimeline:OnInit(_, playActions, self.args)
    self.actionTimeline:SetComplete(self:ToFunc("TimelineDone"))
    self.actionTimeline:Start()
end

function HpResultTB:TimelineDone()
--     Log("伤害结算TB完成")

    local enemyUids = self.world.DataSystem:GetRoleUids(BattleDefine.Camp.enemy)
    local enemyHpSum = 0
    local enemyHpMaxSum = 0
    for _, uid in ipairs(enemyUids) do
        enemyHpSum = enemyHpSum + self.world.DataSystem:GetRoleData(uid).stateInfo.hp
        enemyHpMaxSum = enemyHpMaxSum + self.world.DataSystem:GetRoleData(uid).stateInfo.hpMax
    end

    local playerUids = self.world.DataSystem:GetRoleUids(BattleDefine.Camp.player)
    local playerHpSum = 0
    local playerHpMaxSum = 0
    for _, uid in ipairs(playerUids) do
        playerHpSum = playerHpSum + self.world.DataSystem:GetRoleData(uid).stateInfo.hp
        playerHpMaxSum = playerHpMaxSum + self.world.DataSystem:GetRoleData(uid).stateInfo.hpMax
    end

    -- if playerHpSum / playerHpMaxSum <= 0.4 then
    --     AudioManager.Instance:PlayBgm("bad_situation")
    -- else
    --     if enemyHpSum / enemyHpMaxSum <= 0.4 then
    --         AudioManager.Instance:PlayBgm("nice_situation")
    --     end
    -- end

    self:BehaviorComplete()
end

function HpResultTB:OnUpdate(deltaTime)
    if self.actionTimeline then
        self.actionTimeline:Update(deltaTime)
    end
end
