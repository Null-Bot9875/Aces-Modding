ShieldResultTB = BaseClass("ShieldResultTB",TimelineBehaviorBase)

function ShieldResultTB:__Init()
end

function ShieldResultTB:__Delete()

end

function ShieldResultTB:OnInit()
end

function ShieldResultTB:OnStart()
--     LogTable("护盾结算TB",self.args)

    -- self.world.DataSystem:ChangeShield(self.args.targetPlayer,self.args.data.value)
    -- mod.BattleFacade:SendEvent(BattleCarrierInfoView.Event.RefreshShield,self.args.targetPlayer)

    self:BehaviorComplete()
end

function ShieldResultTB:OnUpdate(deltaTime)
end
