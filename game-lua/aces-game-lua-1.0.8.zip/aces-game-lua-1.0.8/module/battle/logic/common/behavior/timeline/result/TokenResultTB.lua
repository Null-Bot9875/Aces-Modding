TokenResultTB = BaseClass("TokenResultTB",TimelineBehaviorBase)

function TokenResultTB:__Init()
end

function TokenResultTB:__Delete()

end

function TokenResultTB:OnInit()
end

function TokenResultTB:OnStart()
--     LogTable("指示物结算TB",self.args)
    self:BehaviorComplete()
end

function TokenResultTB:OnUpdate(deltaTime)
end
