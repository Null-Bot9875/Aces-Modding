EnemySelectCarrierTB = BaseClass("EnemySelectCarrierTB", TimelineBehaviorBase)

function EnemySelectCarrierTB:__Init()
    self.selectList = {}
    self.selectIndex = 1
end

function EnemySelectCarrierTB:__Delete()
    if self.timer then
        self.world.TimerSystem:RemoveTimer(self.timer)
        self.timer = nil
    end
end

function EnemySelectCarrierTB:OnUpdate(deltaTime)
end

function EnemySelectCarrierTB:OnStart()
--     LogTable("敌人选择机体TB", self.args)

    self:BehaviorComplete()
end
