EnemySelectSlotTB = BaseClass("EnemySelectSlotTB", TimelineBehaviorBase)

function EnemySelectSlotTB:__Init()
    self.selectList = {}
    self.selectIndex = 1
end

function EnemySelectSlotTB:__Delete()
    if self.timer then
        self.world.TimerSystem:RemoveTimer(self.timer)
        self.timer = nil
    end

    ViewManager.Instance:CloseWindow(BattleSelectDeviceWindow)
end

function EnemySelectSlotTB:OnUpdate(deltaTime)
end

function EnemySelectSlotTB:OnStart()
--     LogTable("敌人选择槽位TB", self.args)

    local openArgs = {}
    openArgs.roleUid = self.args.roleUid
    openArgs.initTitle = TI18N("enemy_select_window_title_2")
    openArgs.canOperate = false
    openArgs.onShowFunc = self:ToFunc("InvokeSelectTimerFunc")
    openArgs.selectableSlotInfos = self:GetRoleSelectableSlotInfos(self.args.roleUid)
    openArgs.baseInfo = self.args.baseInfo
    ViewManager.Instance:OpenWindow(BattleSelectDeviceWindow, openArgs)
end

-- 可选槽位id
function EnemySelectSlotTB:GetRoleSelectableSlotInfos(roleUid)
    local camp = self.world.DataSystem:GetCamp(roleUid)

    local data = {}
    local infos = self.world.DataSystem:GetDeviceInfo(roleUid)
    for i, v in ipairs(infos) do
        if v.type ~= KvData.DeviceType.carrier1
            and v.type ~= KvData.DeviceType.carrier2
            and v.type ~= KvData.DeviceType.mode
            and v.type ~= KvData.DeviceType.ultimate then
            local args = {}
            args.target = camp
            args.camp = camp
            args.baseInfo = v

            table.insert(data, v)
        end
    end

    return data
end

function EnemySelectSlotTB:InvokeSelectTimerFunc()
    for i, slotInfo in ipairs(self.args.selectInfo) do
        local args = {}
        args.pos = slotInfo.position
        table.insert(self.selectList, args)
    end

    self:SelectTimerFunc(self.selectList[self.selectIndex])
end

function EnemySelectSlotTB:SelectTimerFunc(args)
    if self.timer then
        self.world.TimerSystem:RemoveTimer(self.timer)
        self.timer = nil
    end

    mod.BattleFacade:SendEvent(BattleSelectDeviceWindow.Event.PlaySlotSelectEffect, args.pos, 0.2, 3)

    self.timer = self.world.TimerSystem:AddTimer(1, 1, self:ToFunc("SelectTimerFuncComplete"))
    self.timer:SetScale(true)
end

function EnemySelectSlotTB:SelectTimerFuncComplete()
    self.timer = nil
    self.selectIndex = self.selectIndex + 1
    if self.selectIndex > #self.selectList then
        self:BehaviorComplete()
    else
        self:SelectTimerFunc(self.selectList[self.selectIndex])
    end
end
