EnemySelectStackTB = BaseClass("EnemySelectStackTB", TimelineBehaviorBase)

function EnemySelectStackTB:__Init()
    self.effect = nil

    self.selectList = {}
    self.selectIndex = 1

    self.timer = nil
end

function EnemySelectStackTB:__Delete()
    ViewManager.Instance:CloseWindow(BattleSelectCardWindow)

    if self.effect then
        self.effect:Delete()
        self.effect = nil
    end

    if self.timer then
        self.world.TimerSystem:RemoveTimer(self.timer)
        self.timer = nil
    end
end

function EnemySelectStackTB:OnUpdate(deltaTime)
end

function EnemySelectStackTB:OnInit()
end

function EnemySelectStackTB:OnStart()
--     LogTable("敌人选择堆叠TB", self.args)

    local openArgs = {}
    openArgs.titleKey = "enemy_select_window_title_1"
    openArgs.cards = self:GetStackCards()
    openArgs.canOperate = false
    openArgs.onShowFunc = self:ToFunc("InvokeSelectTimerFunc")

    ViewManager.Instance:OpenWindow(BattleSelectCardWindow, openArgs)
end

function EnemySelectStackTB:GetStackCards()
    local stackCards = {}

    local stackInfos = self.world.DataSystem:GetAllStackInfos()
    for _, v in ipairs(stackInfos) do
        table.insert(stackCards, { cardData = v.cardInfo, stackData = v, isNoCounteract = nil })
    end

    return stackCards
end

function EnemySelectStackTB:InvokeSelectTimerFunc()
    for i, v in ipairs(self.args.selectInfo) do
        local args = {}
        args.id = v.stackId
        table.insert(self.selectList, args)
    end

    self:SelectTimerFunc(self.selectList[self.selectIndex])
end

function EnemySelectStackTB:SelectTimerFunc(args)
    if self.effect then
        self.effect:Delete()
        self.effect = nil
    end

    local item = mod.BattleFacade:SendEvent(StackSelectWindow.Event.GetStackCardItem, args.id)

    local setting = {}
    setting.assetId = "ui_battle_card_activate"
    setting.parent = item.transform
    setting.pos = { x = 0, y = 0, z = 0 }
    setting.scale = 1000
    setting.lastTime = 2000

    local effect = UIEffect.New()
    effect:Init(setting)

    self.effect = effect
    self.effect:Play()

    -- delayTiemr:SetArgs(args)    

    mod.BattleFacade:SendEvent(StackSelectWindow.Event.PointerEnterStackCard, args.id)
    
    if self.timer then
        self.world.TimerSystem:RemoveTimer(self.timer)
        self.timer = nil
    end
    
    self.timer = self.world.TimerSystem:AddTimer(1, 1, self:ToFunc("SelectTimerFuncComplete"))
    self.timer:SetScale(true)
end

function EnemySelectStackTB:DelayPointerExit(args)
    mod.BattleFacade:SendEvent(StackSelectWindow.Event.PointerExitStackCard, args.id)

end

function EnemySelectStackTB:SelectTimerFuncComplete()
    self.timer = nil

    self.selectIndex = self.selectIndex + 1
    if self.selectIndex > #self.selectList then
        self:BehaviorComplete()
    else
        self:SelectTimerFunc(self.selectList[self.selectIndex])
    end
end
