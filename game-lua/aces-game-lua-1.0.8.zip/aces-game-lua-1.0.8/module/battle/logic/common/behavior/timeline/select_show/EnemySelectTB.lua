-- 每个waitTargetInfo执行一个timelineBehaviors
-- timelineBehaviors，根据roleUid来区分,由selectInfos生成
EnemySelectTB = BaseClass("EnemySelectTB", TimelineBehaviorBase)

function EnemySelectTB:__Init()
    self.timelineIdx = 1
    self.timelineBehaviors = {}
    self.timelineBehavior = nil

    self.idx = 1
    self.waitTargetInfos = nil

    --[[
        args.srcUid                  -- 操作者的uid
        args.targetInfos             -- 目标选择列表，结构
    --]]
    self.args = nil

    self.isShowSelect = false
end

function EnemySelectTB:__Delete()
    if self.timelineBehavior then
        self.timelineBehavior:Delete()
        self.timelineBehavior = nil
    end
end

function EnemySelectTB:OnUpdate(deltaTime)
    if self.timelineBehavior then
        self.timelineBehavior:Update(deltaTime)
    end
end

function EnemySelectTB:OnInit()
    self.waitTargetInfos = {}

    for _, v in ipairs(self.args.targetInfos) do
        local behaviorType = self:GetTargetInfoBehaviorType(v)
        if behaviorType then
            table.insert(self.waitTargetInfos, v)
        end
    end
end

function EnemySelectTB:OnStart()
--     LogTable("敌人选择TB", self.args)

    self:InvokeEnemeySelectTimeLine()
end

function EnemySelectTB:InvokeEnemeySelectTimeLine()
    local targetInfo = self.waitTargetInfos[self.idx]
    if self.timelineBehavior then
        self.timelineBehavior:Delete()
        self.timelineBehavior = nil
    end

    if not targetInfo then
        self:BehaviorComplete()
        return
    end

   local targetConf = Config.Get("battle_target_def", "config", "id",targetInfo.targetId)
    if targetConf.flag["showSelect"] and targetConf.flag["showSelect"] == 0 then
        self:BehaviorDone()
        return
    end

    local selectInfos = self:GetSelectInfos(targetInfo) or {}

    self.timelineBehaviors = {}
    for roleUid, selectInfo in pairs(selectInfos) do
        if #selectInfo > 0 then
            
            local timelineBehavior = self:CreateTB(roleUid, targetInfo, selectInfo)
            table.insert(self.timelineBehaviors, timelineBehavior)
        end
    end

    if #self.timelineBehaviors == 0 then
        self:BehaviorDone()
        return
    end

    self.isShowSelect = true

    self.timelineBehavior = self.timelineBehaviors[self.timelineIdx]
    self.timelineBehavior:Start()
end

function EnemySelectTB:CreateTB(roleUid, targetInfo, info)
    local class = nil

    local behaviorType = self:GetTargetInfoBehaviorType(targetInfo)

    if TimelineBehaviorIndex.Index[behaviorType] then
        class = _G[TimelineBehaviorIndex.Index[behaviorType].class]
    end

    if not class then
        LogErrorTable("对应的类型为空 targetInfo", targetInfo)
    else
        local args = {}
        args.roleUid = roleUid
        args.targetId = targetInfo.targetId
        args.selectInfo = info
        args.baseInfo = self.args.baseInfo

        local timelineBehavior = class.New()
        timelineBehavior:SetWorld(self.world)
        timelineBehavior:SetEntity(self.entity)
        timelineBehavior:SetUid(self.world:GetUid(SECBBehaviorComponent))
        timelineBehavior:SetArgs(args)
        timelineBehavior:SetComplete(self:ToFunc("TimelineBehaviorComplete"))

        return timelineBehavior
    end
end

function EnemySelectTB:GetSelectInfos(targetInfo)
    local behaviorType = self:GetTargetInfoBehaviorType(targetInfo)
    if behaviorType == 80003 then
        return self:GetSlotSelectInfos(targetInfo)
    elseif behaviorType == 80002 then
        return self:GetDeviceSelectInfos(targetInfo)
    elseif behaviorType == 80001 then
        return self:GetStackSelectInfos(targetInfo)
    elseif behaviorType == 80004 then
        return nil
    end
end

function EnemySelectTB:GetSlotSelectInfos(targetInfo)
    local roleUids = self:GetTargetinfoRoleUids(targetInfo)

    local selectInfos = {}
    for _, uid in ipairs(targetInfo.slotUids) do
        for i, roleUId in ipairs(roleUids) do
            if not selectInfos[roleUId] then
                selectInfos[roleUId] = {}
            end

            local infos = self.world.DataSystem:GetDeviceInfo(roleUId)
            for _, info in ipairs(infos) do
                if info.id == uid then
                    table.insert(selectInfos[roleUId], info)
                end
            end
        end
    end
    return selectInfos
end

function EnemySelectTB:GetDeviceSelectInfos(targetInfo)
    local roleUids = self:GetTargetinfoRoleUids(targetInfo)

    local selectInfos = {}
    for _, uid in ipairs(targetInfo.equipUids) do
        for i, roleUId in ipairs(roleUids) do
            if not selectInfos[roleUId] then
                selectInfos[roleUId] = {}
            end

            local infos = self.world.DataSystem:GetDeviceInfo(roleUId)
            for _, info in ipairs(infos) do
                if info.cardInfo.id == uid then
                    table.insert(selectInfos[roleUId], info)
                end
            end
        end
    end
    return selectInfos
end

function EnemySelectTB:GetStackSelectInfos(targetInfo)
    local roleUids = self:GetTargetinfoRoleUids(targetInfo)

    local selectInfos = {}
    for _, uid in ipairs(targetInfo.stackUids) do
        for i, roleUId in ipairs(roleUids) do
            if not selectInfos[roleUId] then
                selectInfos[roleUId] = {}
            end

            local infos = self.world.DataSystem:GetAllStackInfos()
            for _, info in ipairs(infos) do
                if info.id == uid then
                    table.insert(selectInfos[roleUId], info)
                end
            end
        end
    end
    return selectInfos
end

function EnemySelectTB:GetCarrierSelectInfos(targetInfo)
end

function EnemySelectTB:GetTargetinfoRoleUids(targetInfo)
    local targetId = targetInfo.targetId
    local conf = Config.Get("battle_target_def", "config", "id", targetId)
    local srcCamp = self.world.DataSystem:GetCamp(self.args.srcUid)
    local targetCamp = nil
    if conf.target == 1 then
        targetCamp = srcCamp
    elseif conf.target == 2 then
        targetCamp = srcCamp == BattleDefine.Camp.self and BattleDefine.Camp.enemy or BattleDefine.Camp.self
    else
        targetCamp = BattleDefine.Camp.both
    end
    local roleUids = self.world.DataSystem:GetRoleUids(targetCamp)
    return roleUids
end

function EnemySelectTB:GetTargetInfoBehaviorType(targetInfo)
    local behaviorType = nil
    if #targetInfo.slotUids > 0 then
        behaviorType = 80003
    elseif #targetInfo.equipUids > 0 then
        behaviorType = 80002
    elseif #targetInfo.cardUids > 0 then
        -- 不处理手牌
        behaviorType = nil
    elseif #targetInfo.stackUids > 0 then
        behaviorType = 80001
    elseif #targetInfo.playerUids > 0 then
        -- behaviorType = 80004
    end

    return behaviorType
end

function EnemySelectTB:TimelineBehaviorComplete()
    if self.timelineBehavior then
        self.timelineBehavior:Delete()
        self.timelineBehavior = nil
    end


    self.timelineIdx = self.timelineIdx + 1
    if self.timelineIdx > #self.timelineBehaviors then
        self.timelineIdx = 1
        self:BehaviorDone()
    else
        local timelineBehavior = self.timelineBehaviors[self.timelineIdx]
        self.timelineBehavior = timelineBehavior
        self.timelineBehavior:Start()
    end
end

function EnemySelectTB:BehaviorDone()
    self.idx = self.idx + 1
    if self.idx > #self.waitTargetInfos then
        self:BehaviorComplete()
    else
        self:InvokeEnemeySelectTimeLine()
    end
end
