ActiveBattleMainPanelTB = BaseClass("ActiveBattleMainPanelTB",TimelineBehaviorBase)

function ActiveBattleMainPanelTB:__Init()
    self.doneTimer = nil
end

function ActiveBattleMainPanelTB:__Delete()
    self:Reset()
	self:RemoveDoneTimer()	
end

function ActiveBattleMainPanelTB:OnInit()

end

function ActiveBattleMainPanelTB:OnStart()
--     LogTable("Active战斗主界面",self.args)
    mod.MixedCtrl:SetUICameraEnabled(self.conf.flag, "战斗主界面显隐")
    --self.world.AssetsSystem.mainPanel.gameObject:SetActive(self.conf.flag)

    self.doneTimer = self.world.TimerSystem:AddTimer(1,self.conf.duration * 0.001,self:ToFunc("DoneTimer"))
    self.doneTimer:SetScale(true)
end

function ActiveBattleMainPanelTB:DoneTimer()
    self.doneTimer = nil
    self:BehaviorComplete()
end

function ActiveBattleMainPanelTB:OnUpdate(deltaTime)
end

function ActiveBattleMainPanelTB:Reset()
    mod.MixedCtrl:SetUICameraEnabled(not self.conf.flag, "战斗主界面恢复")
end

function ActiveBattleMainPanelTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end
