ActiveLightTB = BaseClass("ActiveLightTB",TimelineBehaviorBase)

function ActiveLightTB:__Init()
    self.assetLoader = nil
    self.assetScope = nil
    self.doneTimer = nil
    self.light = nil
end

function ActiveLightTB:__Delete()
    self:RemoveAssetLoader()
    self:ReleasePendingScope()
    self:RemoveDoneTimer()
end

function ActiveLightTB:OnInit()

end

function ActiveLightTB:OnStart()
--     LogTable("激活灯光TB",self.args)

    local assetList = {}
    table.insert(assetList,{file = string.format("timeline/%s",self.conf.file) ,type = AssetType.Prefab})

    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    self.assetLoader:Load(assetList,self:ToFunc("OnLoadComplete"))

    self.doneTimer = self.world.TimerSystem:AddTimer(1,self.conf.duration * 0.001,self:ToFunc("DoneTimer"))
    self.doneTimer:SetScale(true)
end

function ActiveLightTB:OnLoadComplete(_,hasError)
    if hasError then
        self:RemoveAssetLoader()
        self:ReleasePendingScope()
        self:RemoveDoneTimer()
        self:BehaviorComplete()
        return
    end
    self.light = self.assetLoader:Instantiate(string.format("timeline/%s",self.conf.file))
    self.light:AddComponent(AssetScopeComponent):Adopt(self.assetScope)
    self.assetScope = nil
    self.light.transform:SetParent(self.world.AssetsSystem.nodeObjs["mixed"],false)
    self:RemoveAssetLoader()
end

function ActiveLightTB:ReleasePendingScope()
    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function ActiveLightTB:DoneTimer()
    self.doneTimer = nil
    GameObject.Destroy(self.light)
    self:RemoveAssetLoader()
    self:BehaviorComplete()
end

function ActiveLightTB:RemoveAssetLoader()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function ActiveLightTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function ActiveLightTB:OnUpdate(deltaTime)
end
