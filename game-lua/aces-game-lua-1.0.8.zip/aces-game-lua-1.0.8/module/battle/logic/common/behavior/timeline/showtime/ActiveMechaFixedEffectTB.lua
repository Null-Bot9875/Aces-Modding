ActiveMechaFixedEffectTB = BaseClass("ActiveMechaFixedEffectTB", TimelineBehaviorBase)

function ActiveMechaFixedEffectTB:__Init()
    self.doneTimer = nil
end

function ActiveMechaFixedEffectTB:__Delete()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function ActiveMechaFixedEffectTB:OnInit()

end

function ActiveMechaFixedEffectTB:OnStart()
--     LogTable("激活机甲固定特效", self.args)
    self:ActiveEffect(not self.conf.isHide)

    self.doneTimer = self.world.TimerSystem:AddTimer(1, self.conf.duration * 0.001, self:ToFunc("DoneTimer"))
end
 
function ActiveMechaFixedEffectTB:DoneTimer()
    self.doneTimer = nil
    self:ActiveEffect(true)

    self:BehaviorComplete()
end

function ActiveMechaFixedEffectTB:OnUpdate(deltaTime)
end

function ActiveMechaFixedEffectTB:ActiveEffect(flag)
    local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.info.srcPlayer)
    carrierEntity.EffectComponent:ActiveEffectByGroup("fixed", flag)
end
