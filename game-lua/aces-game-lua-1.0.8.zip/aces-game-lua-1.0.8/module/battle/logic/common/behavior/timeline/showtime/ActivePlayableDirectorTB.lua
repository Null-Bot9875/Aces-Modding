ActivePlayableDirectorTB = BaseClass("ActivePlayableDirectorTB",TimelineBehaviorBase)

function ActivePlayableDirectorTB:__Init()
    self.doneTimer = nil
end

function ActivePlayableDirectorTB:__Delete()
    self:RemoveDoneTimer()
    self.playableDirector = nil
end

function ActivePlayableDirectorTB:OnInit()

end

function ActivePlayableDirectorTB:OnRecover()
    local playableDirector = self.world.AssetsSystem.nodeObjs["sceneObj"].gameObject:GetComponent(PlayableDirector)
    if playableDirector then
        playableDirector.enabled = self.conf.isEnabled
        playableDirector.playOnAwake = true
        playableDirector.time = self.conf.duration * 0.001
    end
end

function ActivePlayableDirectorTB:OnStart()
--     LogTable("激活timeline TB",self.args)

    self.playableDirector = self.world.AssetsSystem.nodeObjs["sceneObj"].gameObject:GetComponent(PlayableDirector)
    self.playableDirector.enabled = self.conf.isEnabled
    self.playableDirector.playOnAwake = true

    self.doneTimer = self.world.TimerSystem:AddTimer(1,self.conf.duration * 0.001,self:ToFunc("DoneTimer"))
    self.doneTimer:SetScale(true)
end

function ActivePlayableDirectorTB:DoneTimer()
    self.doneTimer = nil
    -- self.playableDirector.time = 0
    -- self.playableDirector:Evaluate()
    if not self.conf.isKeepState then
        self.playableDirector.enabled = not self.conf.isEnabled
    end
    self:BehaviorComplete()
end

function ActivePlayableDirectorTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function ActivePlayableDirectorTB:OnUpdate(deltaTime)

end
