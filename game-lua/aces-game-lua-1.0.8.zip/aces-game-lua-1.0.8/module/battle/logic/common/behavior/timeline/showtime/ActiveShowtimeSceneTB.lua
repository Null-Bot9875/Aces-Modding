ActiveShowtimeSceneTB = BaseClass("ActiveShowtimeSceneTB",TimelineBehaviorBase)

function ActiveShowtimeSceneTB:__Init()
    self.doneTimer = nil
end

function ActiveShowtimeSceneTB:__Delete()
    self:RemoveDoneTimer()
end

function ActiveShowtimeSceneTB:OnInit()

end

function ActiveShowtimeSceneTB:OnStart()
--     LogTable("Active表演场景TB",self.args)


    local cullingMask = 0
    cullingMask = cullingMask + BitUtils.LShift(1,KvData.Layer.layer7)
    KvData.mainCamera.cullingMask = cullingMask
    
    self.world.AssetsSystem:SetRenderLayer(KvData.Layer.layer7)

    local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.srcPlayer)
    local targetEntity = self.world.EntitySystem:GetCarrierEntity(self.args.targetPlayer)

    BaseUtils.ChangeLayers(carrierEntity.TposeComponent.tpose.gameObject,KvData.Layer.layer7)
    BaseUtils.ChangeLayers(targetEntity.TposeComponent.tpose.gameObject,KvData.Layer.layer7)


    self.doneTimer = self.world.TimerSystem:AddTimer(1,self.conf.duration * 0.001,self:ToFunc("DoneTimer"))
    self.doneTimer:SetScale(true)
end

function ActiveShowtimeSceneTB:DoneTimer()
    self.doneTimer = nil

    mod.MixedCtrl:SetUICameraEnabled(true, "表演场景结束")

    local cullingMask = 1
    cullingMask = cullingMask + BitUtils.LShift(1,KvData.Layer.layer6)
    KvData.mainCamera.cullingMask = cullingMask

    local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.srcPlayer)
    local targetEntity = self.world.EntitySystem:GetCarrierEntity(self.args.targetPlayer)

    BaseUtils.ChangeLayers(carrierEntity.TposeComponent.tpose.gameObject,KvData.Layer.layer6)
    BaseUtils.ChangeLayers(targetEntity.TposeComponent.tpose.gameObject,KvData.Layer.layer6)

    self.world.AssetsSystem:SetRenderLayer(KvData.Layer.layer6)

    self:BehaviorComplete()
end

function ActiveShowtimeSceneTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function ActiveShowtimeSceneTB:OnUpdate(deltaTime)
end
