ActiveTargetMechaTB = BaseClass("ActiveTargetMechaTB",TimelineBehaviorBase)

function ActiveTargetMechaTB:__Init()
    self.doneTimer = nil
end

function ActiveTargetMechaTB:__Delete()
    self:RemoveDoneTimer()
end

function ActiveTargetMechaTB:OnInit()

end

function ActiveTargetMechaTB:OnStart()
--     LogTable("Active目标机体TB",self.args)

    local targetEntity = self.world.EntitySystem:GetCarrierEntity(self.args.targetPlayer)

    if self.conf.flag then
        BaseUtils.ChangeLayers(targetEntity.TposeComponent.tpose.gameObject, self.world.AssetsSystem:GetRenderLayer())
    else
        BaseUtils.ChangeLayers(targetEntity.TposeComponent.tpose.gameObject,KvData.Layer.layer10)
    end

    self.doneTimer = self.world.TimerSystem:AddTimer(1,self.conf.duration * 0.001,self:ToFunc("DoneTimer"))
    self.doneTimer:SetScale(true)
end

function ActiveTargetMechaTB:DoneTimer()
    self.doneTimer = nil
    self:BehaviorComplete()
end

function ActiveTargetMechaTB:OnUpdate(deltaTime)
end

function ActiveTargetMechaTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end
