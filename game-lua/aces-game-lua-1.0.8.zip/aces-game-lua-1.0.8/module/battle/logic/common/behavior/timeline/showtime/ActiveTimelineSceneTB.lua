ActiveTimelineSceneTB = BaseClass("ActiveTimelineSceneTB",TimelineBehaviorBase)

function ActiveTimelineSceneTB:__Init()
    self.assetLoader = nil
    self.assetScope = nil
    self.doneTimer = nil
    self.timelineNode = nil

    self.selfSrcPos = nil
    self.selfSrcRotate = nil

    self.targetSrcPos = nil
    self.targetSrcRotate = nil

    self.isInit = false
end

function ActiveTimelineSceneTB:__Delete()
    self:RemoveAssetLoader()
    self:ReleasePendingScope()
    self:RemoveDoneTimer()
    self:RecoverCarrier()
end

function ActiveTimelineSceneTB:OnInit()

end

function ActiveTimelineSceneTB:OnStart()
--     LogTable("激活Timeline场景TB",self.args)

    local assetList = {}
    table.insert(assetList,{file = string.format("timeline/%s",self.conf.file) ,type = AssetType.Prefab})

    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    self.assetLoader:Load(assetList,self:ToFunc("OnLoadComplete"))
end

function ActiveTimelineSceneTB:OnLoadComplete(_,hasError)
    if hasError then
        self:RemoveAssetLoader()
        self:ReleasePendingScope()
        self:BehaviorComplete()
        return
    end
    self.isInit = true

    self.timelineNode = self.assetLoader:Instantiate(string.format("timeline/%s",self.conf.file))
    self.timelineNode:AddComponent(AssetScopeComponent):Adopt(self.assetScope)
    self.assetScope = nil
    self:RemoveAssetLoader()
    self.timelineNode.transform.position = Vector3(self.conf.pos.x * 0.001,self.conf.pos.y * 0.001,self.conf.pos.z * 0.001)

    local selfCarrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.info.srcPlayer)
    local targetCarrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.info.targetPlayer)

    selfCarrierEntity.EffectComponent:ActiveEffectByGroup("state",false)
    targetCarrierEntity.EffectComponent:ActiveEffectByGroup("state",false)

    self.selfSrcPos = selfCarrierEntity.TransformComponent.transform.localPosition
    self.selfSrcRotate = selfCarrierEntity.TransformComponent.transform.localEulerAngles

    self.targetSrcPos = targetCarrierEntity.TransformComponent.transform.localPosition
    self.targetSrcRotate = targetCarrierEntity.TransformComponent.transform.localEulerAngles

    local selfParent = self.timelineNode.transform:Find("attack")
    selfCarrierEntity.TransformComponent.transform:SetParent(selfParent)
    selfCarrierEntity.TransformComponent.transform.localPosition = Vector3.zero
    selfCarrierEntity.TransformComponent.transform.localEulerAngles = Vector3.zero

    local targetParent = self.timelineNode.transform:Find("hit")
    targetCarrierEntity.TransformComponent.transform:SetParent(targetParent)
    targetCarrierEntity.TransformComponent.transform.localPosition = Vector3.zero
    targetCarrierEntity.TransformComponent.transform.localEulerAngles = Vector3.zero


    KvData.mainCamera.enabled = false
    mod.MixedCtrl:SetUICameraEnabled(false, "时间轴场景")



    self.doneTimer = self.world.TimerSystem:AddTimer(1,self.conf.duration * 0.001,self:ToFunc("DoneTimer"))
    self.doneTimer:SetScale(true)
end

function ActiveTimelineSceneTB:ReleasePendingScope()
    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function ActiveTimelineSceneTB:DoneTimer()
    self.doneTimer = nil

    self:RecoverCarrier()

    self.isInit = false
    
    self:RemoveAssetLoader()
    self:BehaviorComplete()
end

function ActiveTimelineSceneTB:RecoverCarrier()
    if not self.isInit then
        return
    end

    local selfCarrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.info.srcPlayer)
    local targetCarrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.info.targetPlayer)

    selfCarrierEntity.EffectComponent:ActiveEffectByGroup("state",true)
    targetCarrierEntity.EffectComponent:ActiveEffectByGroup("state",true)

    selfCarrierEntity.TransformComponent.transform:SetParent(self.world.AssetsSystem.nodeObjs["entity"])
    selfCarrierEntity.TransformComponent.transform.localPosition = self.selfSrcPos
    selfCarrierEntity.TransformComponent.transform.localEulerAngles = self.selfSrcRotate

    targetCarrierEntity.TransformComponent.transform:SetParent(self.world.AssetsSystem.nodeObjs["entity"])
    targetCarrierEntity.TransformComponent.transform.localPosition = self.targetSrcPos
    targetCarrierEntity.TransformComponent.transform.localEulerAngles = self.targetSrcRotate

    KvData.mainCamera.enabled = true
    mod.MixedCtrl:SetUICameraEnabled(true, "时间轴场景结束")

    GameObject.Destroy(self.timelineNode)
end

function ActiveTimelineSceneTB:RemoveAssetLoader()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function ActiveTimelineSceneTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function ActiveTimelineSceneTB:OnUpdate(deltaTime)
end
