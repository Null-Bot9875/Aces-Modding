ActiveVirtualCameraTB = BaseClass("ActiveVirtualCameraTB",TimelineBehaviorBase)

function ActiveVirtualCameraTB:__Init()
    self.assetLoader = nil
    self.assetScope = nil
    self.doneTimer = nil
    self.virtualCamera = nil
end

function ActiveVirtualCameraTB:__Delete()
    self:RemoveAssetLoader()
    self:ReleasePendingScope()
    self:RemoveDoneTimer()
end

function ActiveVirtualCameraTB:OnInit()

end

function ActiveVirtualCameraTB:OnStart()
--     LogTable("加载虚拟相机TB",self.args)

    if self.args.kvData and self.args.kvData.dontUseCamera then
        self:BehaviorComplete()
        return
    end

    local assetList = {}
    table.insert(assetList,{file = string.format("timeline/%s",self.conf.file) ,type = AssetType.Prefab})

    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    self.assetLoader:Load(assetList,self:ToFunc("OnLoadComplete"))

    self.doneTimer = self.world.TimerSystem:AddTimer(1,self.conf.duration * 0.001,self:ToFunc("DoneTimer"))
    self.doneTimer:SetScale(true)
end

function ActiveVirtualCameraTB:OnLoadComplete(_,hasError)
    if hasError then
        self:RemoveAssetLoader()
        self:ReleasePendingScope()
        self:RemoveDoneTimer()
        self:BehaviorComplete()
        return
    end
    local carrierEntity = self.world.EntitySystem:GetCarrierEntity(self.args.srcPlayer)
    self.virtualCamera = self.assetLoader:Instantiate(string.format("timeline/%s",self.conf.file))
    self.virtualCamera:AddComponent(AssetScopeComponent):Adopt(self.assetScope)
    self.assetScope = nil
    self.virtualCamera.transform:SetParent(carrierEntity.TransformComponent.transform,false)
    self:RemoveAssetLoader()
end

function ActiveVirtualCameraTB:ReleasePendingScope()
    if self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
end

function ActiveVirtualCameraTB:DoneTimer()
    self.doneTimer = nil
    GameObject.Destroy(self.virtualCamera)
    self:RemoveAssetLoader()
    self:BehaviorComplete()
end

function ActiveVirtualCameraTB:RemoveAssetLoader()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end
end

function ActiveVirtualCameraTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end

function ActiveVirtualCameraTB:OnUpdate(deltaTime)
end
