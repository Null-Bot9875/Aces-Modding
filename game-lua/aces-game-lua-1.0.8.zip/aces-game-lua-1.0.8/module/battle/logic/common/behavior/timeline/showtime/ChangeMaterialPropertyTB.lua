ChangeMaterialPropertyTB = BaseClass("ChangeMaterialPropertyTB",TimelineBehaviorBase)

function ChangeMaterialPropertyTB:__Init()
    self.materialList = {}
    self.lastTime = 0
    self.isInitialized = false
end

function ChangeMaterialPropertyTB:__Delete()
    self:ClearMaterialList()
    self.lastTime = 0
end

function ChangeMaterialPropertyTB:ClearMaterialList()
    self.materialList = {}
    self.isInitialized = false
end

function ChangeMaterialPropertyTB:OnInit()

end

function ChangeMaterialPropertyTB:OnStart()
--     LogTable("修改材质球属性", self.args)
    if not self.conf.assetId or self.conf.assetId == "" then
        self:BehaviorComplete()
        return
    end

    self:ClearMaterialList()

    local srcEntity = self.world.MixedSystem:GetTargetEntity(self.args.info.markTargetMap, self.conf)
    if not srcEntity then
        self:BehaviorComplete()
        return
    end

    if self.conf.curveId and self.conf.curveId ~= "" then
        self.curve = self.world.AssetsSystem:GetCurveById(self.conf.curveId)
    end
    self.skinMeshRenderArray = srcEntity.TransformComponent.gameObject:GetComponentsInChildren(SkinnedMeshRenderer)

    for i = 0, self.skinMeshRenderArray.Length - 1 do
        local skinMeshRender = self.skinMeshRenderArray[i]
        for k = 0, skinMeshRender.sharedMaterials.Length - 1 do
            local mat = skinMeshRender.sharedMaterials[k]
            if mat and UnityUtils.GetMatBaseName(mat) == self.conf.assetId then
                table.insert(self.materialList, mat)
            end
        end
    end

    self.lastTime = 0
    self.isInitialized = true
end

function ChangeMaterialPropertyTB:OnUpdate(deltaTime)
    if not self.isInitialized then
        return
    end

    if self.lastTime >= self.conf.duration then
        self:ClearMaterialList()
        self:BehaviorComplete()
        return
    end

    self.lastTime = self.lastTime + deltaTime
    local progress = self.lastTime / self.conf.duration

    if self.curve and self.curve.length > 0 then
        progress = self.curve:Evaluate(progress)
    end
    progress = Mathf.Clamp(progress, 0, 1)

    for i, material in pairs(self.materialList) do
        if self.conf.propertyType == 1 then
            if material then
                local curValue = Mathf.Lerp(self.conf.startValueF, self.conf.targetValueF, progress)
                material:SetFloat(self.conf.propertyName, curValue)
            end
        elseif self.conf.propertyType == 2 then
            if material then
                local curValue = Color.Lerp(self.conf.startValueC, self.conf.targetValueC, progress)
                material:SetColor(self.conf.propertyName, curValue)
            end

        elseif self.conf.propertyType == 3 then
            if material then
                local curValue = Vector4.Lerp(self.conf.startValueV, self.conf.targetValueV, progress)
                material:SetVector(self.conf.propertyName, curValue)
            end
        end
    end
end
