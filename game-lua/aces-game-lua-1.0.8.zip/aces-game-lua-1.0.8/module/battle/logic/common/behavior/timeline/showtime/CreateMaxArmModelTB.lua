CreateMaxArmModelTB = BaseClass("CreateMaxArmModelTB", TimelineBehaviorBase)

function CreateMaxArmModelTB:__Init()

end

function CreateMaxArmModelTB:__Delete()

end

function CreateMaxArmModelTB:OnInit()

end

function CreateMaxArmModelTB:OnStart()
--     LogTable("播放满状态武装TB", self.args)

    --self.world.CarrierSystem:CreateMaxArmModel(self.args.info.srcPlayer)

    self:BehaviorComplete()
end
