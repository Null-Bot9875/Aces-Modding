IncreaseMaterialTB = BaseClass("IncreaseMaterialTB",TimelineBehaviorBase)

function IncreaseMaterialTB:__Init()
    self.oldMatDic = {}
    self.addedMatDic = {} -- 添加的材质字典，key -> material（使用材质对象本身作为标识）
end

function IncreaseMaterialTB:__Delete()
    -- 先恢复材质，避免 RemoveDoneTimer 因 world 已销毁抛异常导致 ResetMaterial 未执行
    self:ResetMaterial()
    self:RemoveDoneTimer()
    self:RemoveAssetLoader()
end



function IncreaseMaterialTB:RemoveAssetLoader()
    if self.assetLoader then
        self.assetLoader:Destroy()
        self.assetLoader = nil
    end

    -- if self.materialPrefab then
    --     GameObject.Destroy(self.materialPrefab)
    -- end
    -- if self.materialInstance then
    --     GameObject.Destroy(self.materialInstance)
    -- end
end

function IncreaseMaterialTB:OnInit()

end


function IncreaseMaterialTB:OnStart()
--     LogTable("新增材质球", self.args)
    if not self.conf.assetId or self.conf.assetId == "" then
        self:BehaviorComplete()
        return
    end
    
    -- local assetList = {}
    -- self.materialPath = "effect/prefab/timelinePreloadMats.prefab" --self.conf.assetId
    -- table.insert(assetList, {file = self.materialPath,type = AssetType.Prefab})
    -- self.assetLoader:Load(assetList,self:ToFunc("OnLoaded"))
    self.materialPrefab = PreloadManager.Instance:GetAsset(AssetPath.timelinePreloadMats)
    
    if not self.materialPrefab then
        self:BehaviorComplete()
        return
    end
    self.materialPrefab.gameObject:SetActive(false)
    local meshRender = self.materialPrefab.gameObject:GetComponent(MeshRenderer)

    for i = 0, meshRender.sharedMaterials.Length - 1 do
        if meshRender.sharedMaterials[i].name == self.conf.assetId then
            self.materialInstance = meshRender.sharedMaterials[i]
            self.materialInstance.name = self.conf.assetId
        end
    end


    -- self.materialInstance = material
    if not self.materialInstance then
        LogError(string.format("%s材质球不存在timeline_preload_mats 资源内", self.conf.assetId))
        self:BehaviorComplete()
       return 
    end

    -- local srcEntity = self.world.MixedSystem:GetMarkMapEntity(self.args.info.markTargetMap, self.conf.markTarget, self.conf.targetIndex)
    local srcEntity = self.world.MixedSystem:GetTargetEntity(self.args.info.markTargetMap, self.conf)

    if not srcEntity then
        self:BehaviorComplete()
        return
    end

    -- 可选：仅对指定子节点下的 SkinnedMeshRenderer 添加材质
    local rootGo = srcEntity.TransformComponent.gameObject
    -- local rootTrans = srcEntity.TransformComponent.transform
    if self.conf.childNodeName and self.conf.childNodeName ~= "" then
        -- local childTrans = rootTrans:Find(self.conf.childNodeName)
        local childTrans = srcEntity.TposeComponent:GetBone(self.conf.childNodeName)
        if not childTrans then
            LogError(string.format("IncreaseMaterial 未找到子节点: %s，机体: %s", self.conf.childNodeName, rootGo.name))
            self:BehaviorComplete()
            return
        end
        rootGo = childTrans.gameObject
    end
    self.skinMeshRenderArray = rootGo:GetComponentsInChildren(SkinnedMeshRenderer)
    for i = 0, self.skinMeshRenderArray.Length - 1 do
        local skinMeshRender = self.skinMeshRenderArray[i]
        local key = skinMeshRender:GetHashCode()

        local oldMats = skinMeshRender.sharedMaterials
        local hasSameMaterial = false
        for j = 0, oldMats.Length - 1 do
            if oldMats[j] and UnityUtils.GetMatBaseName(oldMats[j]) == self.conf.assetId then
                hasSameMaterial = true
                break
            end
        end

        if hasSameMaterial then
        elseif not self.oldMatDic[key] then
            self.oldMatDic[key] = {}
            self.oldMatDic[key] = oldMats

            local newMats = {}
            for j = 0, oldMats.Length - 1 do
                newMats[j + 1] = oldMats[j]
            end
            table.insert(newMats, self.materialInstance)
            self.addedMatDic[key] = self.materialInstance
            skinMeshRender.sharedMaterials = newMats
        end
    end


    self.doneTimer = self.world.TimerSystem:AddTimer(1,self.conf.duration * 0.001,self:ToFunc("DoneTimer"))
    self.doneTimer:SetScale(true)

end

function IncreaseMaterialTB:OnLoaded()
end

function IncreaseMaterialTB:OnUpdate(deltaTime)
end

function IncreaseMaterialTB:RemoveDoneTimer()
    if self.doneTimer then
        self.world.TimerSystem:RemoveTimer(self.doneTimer)
        self.doneTimer = nil
    end
end


function IncreaseMaterialTB:ResetMaterial()
    if not self.skinMeshRenderArray then
        return
    end
    
    -- 如果 restoreAfterEnd 为 false 或 nil，则不恢复材质
    if self.conf.restoreAfterEnd ~= true then
        return
    end

    -- 只移除自己添加的材质，使用材质对象匹配（通过哈希值或对象引用）
    for i = 0, self.skinMeshRenderArray.Length - 1 do
        local skinMeshRender = self.skinMeshRenderArray[i]
        if skinMeshRender then
            local key = skinMeshRender:GetHashCode()
            local addedMaterial = self.addedMatDic[key]
            
            if addedMaterial then
                -- 从当前数组中按名称移除，而非回滚旧快照
                -- 避免多个节点并行时互相覆盖（与 C# IncreaseMaterialBehaviour.OnClear 逻辑对齐）
                local currentMats = skinMeshRender.sharedMaterials
                local newMats = {}
                for j = 0, currentMats.Length - 1 do
                    local mat = currentMats[j]
                    -- 剥离 (Instance)/(Clone) 后缀再比较，防止材质被意外实例化后名字不匹配
                    if mat and UnityUtils.GetMatBaseName(mat) ~= self.conf.assetId then
                        table.insert(newMats, mat)
                    end
                end
                skinMeshRender.sharedMaterials = newMats
            end
        end
    end
end


function IncreaseMaterialTB:DoneTimer()
    self.doneTimer = nil
    self:ResetMaterial()
    self:RemoveAssetLoader()
    self:BehaviorComplete()

end


