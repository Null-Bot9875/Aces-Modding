# Aces Lua Reference 1.0.9

Game version: 1.0.9. Updated on 2026-10-23.

The files retain the game directory structure for MOD authors to look up existing logic. Internal APIs may change between versions. This package cannot be installed as a MOD. See the repository LICENSE.md for usage terms.
