IconLoader = BaseClass("IconLoader")
IconLoader.poolKey = "icon_loader"
-- 仅本次 Lua 运行共享，重启后重新尝试缺失的图片。
local missingIconFiles = {}

function IconLoader:__Init()
    self.isLoaded = false
    self.file = nil
    self.image = nil
    self.isLanguageTexture = false
    self.assetScope = nil
    self.requestVersion = 0
    self.loadFile = nil
end

function IconLoader:LoadIcon(image,file,nativeSize,callBack)
    if BaseUtils.IsNull(image) then 
        LogError("Icon加载异常,空的Image组件") 
        return 
    end

    if not file or file == "" then 
        LogError("Icon加载异常,路径为空") 
        return 
    end

    -- if image:GetType():ToString() ~= "UnityEngine.UI.Image" then
    --     LogError("Icon加载异常,错误的组件类型:"..tostring(image:GetType():ToString()))
    --     return
    -- end

    if self.isLoaded and self.file == file and self.image == image
        and not BaseUtils.IsNull(image.sprite) then
        self.callBack = callBack
        self.nativeSize = nativeSize or false
        self:Completed()
        return
    end

    --self.debug = debug.traceback()

    self:RemoveLoader()
    self:Releaser()
    self.requestVersion = self.requestVersion + 1
    
    self.isLoaded = false
    self.image = image
    self.file = file
    self.callBack = callBack
    self.nativeSize = nativeSize or false

    self.image.enabled = false
    
    self.isLanguageTexture = false

    if missingIconFiles[self.file] then
        self.image.sprite = nil
        self:Completed()
        return
    end

    if type(self.file) == "string" and string.sub(self.file, 1, 6) == "mod://" then
        local requestVersion = self.requestVersion
        if ModSpriteManager == nil then
            LogErrorf("MOD 图片加载桥未初始化[%s]",self.file)
            self:LoadAsset(AssetPath.GetCardIcon(10001),requestVersion)
            return
        end
        ModSpriteManager.GetSpriteByAsync(self.file,self:SafeCallback(function(sprite)
            self:ModSpriteLoaded(requestVersion,sprite)
        end))
        return
    end

    if Language.Instance:HasTexture(self.file) then
        self.isLanguageTexture = true
        local requestVersion = self.requestVersion
        Language.Instance:GetSprite(self.file,self:SafeCallback(function(sprite)
            self:LanguageAssetLoaded(requestVersion,sprite)
        end))
    else
        self:LoadAsset(self.file)
    end
end

function IconLoader:LoadAsset(file,requestVersion)
    self.loadFile = file
    if missingIconFiles[file] then
        self.isLoaded = false
        self.image.sprite = nil
        self.image.enabled = false
        self:Completed()
        return
    end
    self.assetScope = AssetScope()
    self.assetLoader = AssetBatchLoader.New(self.assetScope)
    local loadVersion = requestVersion or self.requestVersion
    self.assetLoader:Load({{file = file,type = AssetType.Sprite}},self:SafeCallback(function()
        self:AssetLoaded(loadVersion)
    end))
end

function IconLoader:ModSpriteLoaded(requestVersion,sprite)
    if requestVersion ~= self.requestVersion or BaseUtils.IsNull(self.image) then return end
    if sprite == nil then
        self:LoadAsset(AssetPath.GetCardIcon(10001),requestVersion)
        return
    end
    self.image.enabled = true
    self.isLoaded = true
    self.image.sprite = sprite
    if self.nativeSize then self.image:SetNativeSize() end
    self:Completed()
end

function IconLoader:__Delete()
    self:OnReset()
end

function IconLoader:AssetLoaded(requestVersion)
    if requestVersion ~= self.requestVersion then return end
    if BaseUtils.IsNull(self.image) then
        self:RemoveLoader()
        LogErrorf( "icon加载完成,单位图片对象已经被删除了[%s]\n[%s]",self.file,self.debug)
        self:Releaser()
        return
    end

    self.image.sprite = self.assetLoader:GetAsset(self.loadFile or self.file)
    self.isLoaded = not BaseUtils.IsNull(self.image.sprite)
    if not self.isLoaded then
        missingIconFiles[self.loadFile or self.file] = true
    end
    self.image.enabled = self.isLoaded

    if self.isLoaded and self.nativeSize then
        self.image:SetNativeSize() 
    end

    self:RemoveLoader()
    self:Completed()
end

function IconLoader:LanguageAssetLoaded(requestVersion,sprite)
    if requestVersion ~= self.requestVersion then return end
    if BaseUtils.IsNull(self.image) then 
        LogErrorf( "icon加载完成,单位图片对象已经被删除了[%s]\n[%s]",self.file,self.debug)
        return
    end

    self.image.sprite = sprite
    self.isLoaded = not BaseUtils.IsNull(sprite)
    if not self.isLoaded then
        missingIconFiles[self.file] = true
    end
    self.image.enabled = self.isLoaded

    if self.isLoaded and self.nativeSize then
        self.image:SetNativeSize()
    end

    self:Completed()
end

function IconLoader:Completed()
    if self.callBack then 
        self.callBack(self.image) 
    end
end

function IconLoader:RemoveLoader()
    if self.assetLoader then 
        self.assetLoader:Destroy()
        self.assetLoader = nil 
    end
end

function IconLoader:OnReset()
    self.requestVersion = self.requestVersion + 1
    self.image = nil
    self.name = nil
    self.callBack = nil
    self:RemoveLoader()
    self:Releaser()
end

function IconLoader:Releaser()
    if self.isLanguageTexture then
        if not self.isLoaded and self.file then
            local requestVersion = self.requestVersion
            Language.Instance:RemoveSpriteAsync(self.file,self:SafeCallback(function(sprite)
                self:LanguageAssetLoaded(requestVersion,sprite)
            end))
        end
    elseif self.assetScope then
        self.assetScope:Dispose()
        self.assetScope = nil
    end
    
    self.isLoaded = false
    self.file = nil
    self.loadFile = nil
end

function IconLoader.Create()
    return PoolManager.Instance:Pop(PoolType.class,IconLoader.poolKey) or IconLoader.New() 
end
