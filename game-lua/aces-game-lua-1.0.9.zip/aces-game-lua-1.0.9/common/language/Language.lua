Language = SingleClass("Language")

function Language:__Init()
    self.language = nil

    self.confHashToTexts = {}
    self.prefabHashToTexts = {}

    self.languageHashToText = {}
    self.textureMappings = {}
    
    -- 文本->哈希Key缓存，避免重复计算
    self.textToHashCache = {}

    -- 关键字占位替换钩子（由上层注册，避免底层依赖业务模块）
    self.keywordResolver = nil

    LanguageManager.Instance:SetPrefabTextFun("PTI18N")
    LanguageManager.Instance:SetAssetPathPrefix("res/")

    self:InitLanguage()
end

function Language:InitLanguage()
    local language = self:GetLocalLanguage()
    if language ~= "" then
        self:SetupLanguage(language)
    end
end

function Language:Check(language)
    LanguageManager.Instance:Check(language)
end

function Language:SetNoticeCheckComplete(func)
    LanguageManager.Instance:SetNoticeCheckComplete(func)
end

function Language:SetNoticeDownloadProgress(func)
    LanguageManager.Instance:SetNoticeDownloadProgress(func)
end

function Language:SetNoticeDownloadComplete(func)
    LanguageManager.Instance:SetNoticeDownloadComplete(func)
end

function Language:SetNoticeUpdateComplete(func)
    LanguageManager.Instance:SetNoticeUpdateComplete(func)
end


function Language:UpdateAsset(language)
    LanguageManager.Instance:UpdateAsset(language)
end

function Language:CancelUpdate()
    LanguageManager.Instance:CancelUpdate()
end


function Language:SetupLanguage(language)
    if not self:IsSelectableLanguage(language) then
        LogError("不支持的语言: " .. tostring(language))
        return false
    end
    Log("开始进行语言安装",language)
    
    Log("SetupLanguage 之前重新设置 prefabTextFun")
    LanguageManager.Instance:SetPrefabTextFun("PTI18N")

    self.language = language
    PlayerPrefsEx.SetString("language", language)

    Config.Unload()

    self.confHashToTexts = {}
    self.prefabHashToTexts = {}
    self.textureMappings = {}

    LanguageManager.Instance:SetLanguage(language)

    self:ReadLanguageText()
    ModRuntime.ReinstallConfigsForCurrentLanguage()
    --self:ReadConfigText()
    --self:ReadPrefabText()
    self:ReadTextureMapping()

    LanguageManager.Instance:SetupLanguage()

    BaseView.ChangeLanguage()
end

function Language:ReadLanguageText()
    self.languageHashToText = {}
    local dataStr = LanguageManager.Instance:GetConfig("language.json")
    if type(dataStr) ~= "string" or dataStr == "" then
        return
    end

    -- Log(dataStr)

    local data
    local success, err = pcall(function()
        data = CJson.decode(dataStr)
    end)
    
    if not success then
        LogError("JSON解码错误: " .. tostring(err))
        -- 保存JSON文件到本地用于调试
        local debugPath = Application.persistentDataPath .. "/language_debug.json"
        IOUtils.WriteAllText(debugPath, dataStr)
        LogError("JSON文件已保存到: " .. debugPath)
        return
    end
    
    if type(data) ~= "table" then
        LogError("language.json 必须是文本映射")
        return
    end
    for k, v in pairs(data) do
        if type(k) == "string" and type(v) == "string" and string.find(v, "%S") then
            self.languageHashToText[k] = v
        end
    end
end

-- function Language:ReadConfigText()
--     self.confHashToTexts[confFile] = {}
--     local dataStr = LanguageManager.Instance:GetConfig("config/" .. confFile .. ".json")
--     if dataStr == "" then
--         return
--     end
--     local data = CJson.decode(dataStr)
--     for _, v in ipairs(data) do
--         self.confHashToTexts[confFile][v["key"]] = v["text"]
--     end
-- end

function Language:GetConfigKey(srcText)
    -- 官方导表以字面量反斜杠 n 参与 key 计算；Lua 加载后需恢复该表示。
    -- MOD 的独立语言对象不实现此方法，继续使用其原文 key 合同。
    local keyText = string.gsub(srcText, "\n", "\\n")
    return IOUtils.GetMD5ByStringLen(keyText)
end

function Language:GetConfigText(confFile,hash,srcText)
    return self.languageHashToText[hash] or srcText

    -- if not self.confHashToTexts[confFile] then
    --     self:ReadConfigText(confFile)
    -- end
    -- return self.confHashToTexts[confFile][hash] or srcText
end


-- function Language:ReadPrefabText()
--     local dataStr = LanguageManager.Instance:GetConfig("config/prefab.json")
--     if dataStr == "" then
--         return
--     end
--     local data = CJson.decode(dataStr)
--     for _, v in ipairs(data) do
--         self.prefabHashToTexts[v["key"]] = v["text"]
--     end
-- end

function Language:GetPrefabeText(hash,srcText)
    local text = self.languageHashToText[hash] or srcText
    return self:ApplyKeywordResolvers(text)
end

function Language:ReadTextureMapping()
    self.textureMappings = {}
    local dataStr = LanguageManager.Instance:GetConfig("texture_mapping.json")
    if type(dataStr) ~= "string" or dataStr == "" then
        return
    end
    local ok, data = pcall(CJson.decode, dataStr)
    if not ok or type(data) ~= "table" then
        LogError("texture_mapping.json 不是有效映射")
        return
    end
    for _, group in ipairs({"ui", "icon"}) do
        if type(data[group]) == "table" then
            for _, v in ipairs(data[group]) do
                if type(v) == "string" and v ~= "" then
                    self.textureMappings[v] = true
                end
            end
        end
    end
end

function Language:HasTexture(file)
    return self.textureMappings[file] == true
end

function Language:GetSprite(file,onComplete)
    if onComplete then
        LanguageManager.Instance:GetSpriteByAsync(file,onComplete)
    else
        return LanguageManager.Instance:GetSprite(file)
    end
end

function Language:RemoveSpriteAsync(file,onComplete)
    LanguageManager.Instance:RemoveSpriteAsync(file,onComplete)
end

function Language:GetLocalLanguage()
    local language = LanguageManager.Instance.Language
    if not self:IsSelectableLanguage(language) then
        language = LanguageDefine.language.en_us
    end
    return language
end

function Language:IsSelectableLanguage(language)
    for _, info in ipairs(LanguageDefine.languages) do
        if info.type == language then return true end
    end
    return false
end

function Language:HasLanguage(language)
    return LanguageManager.Instance:HasLanguage(language)
end

function Language:IsLanguage(language)
    return self.language == language    
end

function Language:GetCurrentLanguage()
    return self.language    
end

function Language:GetArea()
    local language = self:GetCurrentLanguage()
    local languageInfo = nil
    for _, v in ipairs(LanguageDefine.languages) do
        if v.type == language then
            languageInfo = v
            break
        end
    end
    return languageInfo and languageInfo.area or "en"
end

--动态文本
function TI18N(key,...)
    local conf = Config.Get("text","tips","key",key) or Config.Get("text_server","svr_error","key",key)

    if not conf then
        LogErrorf("文本提示不存在对应Key值[%s]",key)
        return key
    end
    local result = nil
    if conf.isFormat then
        result = Language.Instance:FormatText(conf.text,...)
    else
        result = conf.text
    end
    
    return Language.Instance:ApplyKeywordResolvers(result)
end

--预设文本
function PTI18N(hash,srcText)
    return Language.Instance:GetPrefabeText(hash,srcText)
end

-- 稳定哈希Key生成（中文原文 -> 稳定Key）
-- 说明：统一走 IOUtils.GetMD5ByStringLen，保证与工具链/编辑器侧完全一致
function Language:GenerateStableHashKey(str)
    assert(type(str) == "string" and str ~= "", "GenerateStableHashKey: 文本不能为空")

    local cached = self.textToHashCache[str]
    if cached then return cached end

    local hex = IOUtils.GetMD5ByStringLen(str)
    assert(type(hex) == "string" and hex ~= "", "GetMD5ByStringLen: 返回空")

    self.textToHashCache[str] = hex
    return hex
end

function Language:ResolveHashKeyForText(str)
    assert(type(str) == "string" and str ~= "", "ResolveHashKeyForText: 文本不能为空")
    local baseKey = self:GenerateStableHashKey(str)
    return baseKey

end

-- 动态文本（中文原文 -> 稳定Key -> 翻译），与TI18N同风格
-- 参数1：srcText 原始中文文本（用于生成稳定Key）
-- 其余参数：用于格式化占位（当译文包含%s等占位时）
function TTI18N(srcText,...)
    if srcText == "" then
        return ""
    end

    local key = Language.Instance:ResolveHashKeyForText(srcText)
    local text = Language.Instance.languageHashToText[key] or srcText

    if select('#', ...) > 0 then
        local formatted
        text, formatted = Language.Instance:FormatText(text, ...)
        if not formatted and text ~= srcText then
            text = Language.Instance:FormatText(srcText, ...)
        end
    end

    return Language.Instance:ApplyKeywordResolvers(text)
end

function Language:FormatText(text, ...)
    local ok, result = pcall(string.format, text, ...)
    if ok then return result, true end
    LogError("多语言格式化失败: " .. tostring(result))
    return text, false
end

-- 语言表的读取，在编辑器下直接读了原文没有走json
--配置文本
function CTI18N(confFile,hash,srcText)
    -- Log(string.format("CTI18N: 尝试多语言翻译 - confFile=%s, hash=%s, srcText=%s", confFile, hash, srcText))
    return Language.Instance:GetConfigText(confFile,hash,srcText)
end

-- 供上层注册自定义占位解析器（例如 @roleName 等）
function Language:SetKeywordResolver(func)
    self.keywordResolver = func
end

-- 对任意字符串应用关键字解析器
function Language:ApplyKeywordResolvers(str)
    if not str or str == "" then return str end
    if not self.keywordResolver then return str end
    local ok, res = pcall(self.keywordResolver, str)
    if ok and type(res) == "string" then
        return res
    end
    return str
end
