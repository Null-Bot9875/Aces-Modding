local ModConfigAuthoring = {}

local AUTHORING_ADAPTERS

local CARD_REQUIRED_FIELDS = {
    "cardId",
    "name",
    "rare",
    "type",
    "tagMap",
    "targetIds",
    "costEffect",
    "skillList",
}

local CARD_DEFAULTS = {
    tag = {},
    descLua = {},
    extraCost = {},
    staticList = {},
    attkSkill = 0,
    dir = 0,
    dirSkillList = {},
    areaSkillList = {},
    hp = 0,
    useConditions = { 0 },
    stackcard = {},
    stackcardSkill = {},
    extend = {},
    limitBaseIds = {},
    upgrade = 0,
    slotType = { 0 },
    initCard = 0,
    pvpReplace = 0,
    assetId = 10001,
    mainType = 1,
    mainTag = {},
    subTag = {},
    iconId = 0,
    deviceStackIcon = {},
    keywordList = {},
}

local EFFECT_DEFAULTS = {
    desc = "",
    extend = {},
    playResultType = 0,
    customResultType = "",
    dontUseCardTimeline = false,
    markTarget = "",
}

local SKILL_DEFAULTS = {
    tag = "",
    desc = "",
    tagMap = {},
    targetIds = { 0 },
    useConditions = { 0 },
    costEffect = 0,
    extraCost = {},
    icon = "",
    triggerEx = {},
    stack = 1,
    srcCardId = 0,
    extend = {},
    visibility = 0,
    keywordList = {},
    playResultType = 0,
}

local STATIC_SKILL_DEFAULTS = {
    desc = "",
    flag = {},
    conditionList = {},
    conditionListSelf = {},
    visibility = 0,
    keywordList = {},
    disable = 1,
    showEffects = {},
}

local CARD_SCHEMA_OVERRIDE = {
    assetId = { type = "asset_ref" },
}

local CARD_FIELDS = {
    cardId = true,
    name = true,
    tag = true,
    descLua = true,
    targetIds = true,
    costEffect = true,
    extraCost = true,
    skillList = true,
    staticList = true,
    attkSkill = true,
    dir = true,
    dirSkillList = true,
    areaSkillList = true,
    hp = true,
    useConditions = true,
    stackcard = true,
    stackcardSkill = true,
    extend = true,
    tagMap = true,
    limitBaseIds = true,
    upgrade = true,
    slotType = true,
    initCard = true,
    pvpReplace = true,
    assetId = true,
    mainType = true,
    type = true,
    mainTag = true,
    subTag = true,
    iconId = true,
    rare = true,
    deviceStackIcon = true,
    keywordList = true,
}

local function IsModId(value)
    if type(value) ~= "string" or value == "" then return false end
    if string.sub(value, 1, 1) == "." or string.sub(value, -1) == "." then return false end
    if string.find(value, "..", 1, true) then return false end
    for segment in string.gmatch(value, "[^.]+") do
        if not string.match(segment, "^[a-z0-9]+$") then return false end
    end
    return string.find(value, ".", 1, true) ~= nil
end

local function CopyDefault(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for key, item in pairs(value) do result[key] = CopyDefault(item) end
    return result
end

local function GetLocation(context, fieldPath)
    return string.format(
        "[modId:%s][path:%s][configName:card_def][sheetName:config][field:%s]",
        tostring(context.modId),
        tostring(context.path),
        tostring(fieldPath)
    )
end

local function LogUnknownField(context, fieldPath)
    local message = string.format("MOD Card 包含未知字段%s；字段将保留但不获得 Schema、索引或 i18n 语义", GetLocation(context, fieldPath))
    if context.logError ~= nil then
        context.logError(message)
    elseif LogError ~= nil then
        LogError(message)
    end
end

local function NormalizeModAssetPath(value, context)
    if not IsModId(context.modId) then
        return nil, string.format("MOD Card 图片缺少合法 modId%s", GetLocation(context, "assetId"))
    end
    if value == ""
        or string.sub(value, 1, 1) == "/"
        or string.sub(value, 1, 1) == "\\"
        or string.match(value, "^%a:[/\\]")
        or string.sub(value, 1, 6) == "mod://" then
        return nil, string.format("MOD Card assetId 必须是本 MOD assets 下的相对 PNG 路径%s", GetLocation(context, "assetId"))
    end
    local normalized = string.gsub(value, "\\", "/")
    if string.find(normalized, "//", 1, true)
        or string.find(normalized, "[%z\1-\31]")
        or string.find(normalized, "[<>:\"|%?%*]")
        or string.lower(string.sub(normalized, -4)) ~= ".png" then
        return nil, string.format("MOD Card assetId 需要合法 .png 相对路径%s", GetLocation(context, "assetId"))
    end
    for segment in string.gmatch(normalized, "[^/]+") do
        if segment == "." or segment == ".." then
            return nil, string.format("MOD Card assetId 不能越过 assets 目录%s", GetLocation(context, "assetId"))
        end
    end
    return "mod://" .. context.modId .. "/" .. normalized
end

local function ValidateCardAuthorTypes(row, context, assetProvided)
    if type(row.name) ~= "string" then
        return false, string.format("MOD Card name 必须是 string%s", GetLocation(context, "name"))
    end
    if type(row.rare) ~= "number" or row.rare % 1 ~= 0 then
        return false, string.format("MOD Card rare 必须是 int%s", GetLocation(context, "rare"))
    end
    if type(row.type) ~= "table" then
        return false, string.format("MOD Card type 必须是 list%s", GetLocation(context, "type"))
    end
    if type(row.tagMap) ~= "table" then
        return false, string.format("MOD Card tagMap 必须是 dict%s", GetLocation(context, "tagMap"))
    end
    if type(row.targetIds) ~= "table" then
        return false, string.format("MOD Card targetIds 必须是 list%s", GetLocation(context, "targetIds"))
    end
    if type(row.costEffect) ~= "number" or row.costEffect % 1 ~= 0 then
        return false, string.format("MOD Card costEffect 必须是 int%s", GetLocation(context, "costEffect"))
    end
    if type(row.skillList) ~= "table" then
        return false, string.format("MOD Card skillList 必须是 list%s", GetLocation(context, "skillList"))
    end
    if assetProvided then
        local assetType = type(row.assetId)
        if assetType ~= "string" and (assetType ~= "number" or row.assetId % 1 ~= 0) then
            return false, string.format("MOD Card assetId 必须是 int 或相对 PNG 路径%s", GetLocation(context, "assetId"))
        end
    end
    return true
end

local function NormalizeCardRow(source, context)
    if type(source) ~= "table" then
        return nil, string.format("MOD Card row 需要 table%s", GetLocation(context, "row"))
    end
    for _, fieldName in ipairs(CARD_REQUIRED_FIELDS) do
        if source[fieldName] == nil then
            return nil, string.format("MOD Card 缺少必填字段%s", GetLocation(context, fieldName))
        end
    end
    if type(source.cardId) ~= "number" or source.cardId % 1 ~= 0 or source.cardId <= 0 then
        return nil, string.format("MOD Card cardId 必须是正整数%s[value:%s]", GetLocation(context, "cardId"), tostring(source.cardId))
    end
    local assetProvided = source.assetId ~= nil
    local result = source
    for fieldName, defaultValue in pairs(CARD_DEFAULTS) do
        if result[fieldName] == nil then result[fieldName] = CopyDefault(defaultValue) end
    end
    for fieldName in pairs(result) do
        if not CARD_FIELDS[fieldName] then LogUnknownField(context, fieldName) end
    end
    local valid, err = ValidateCardAuthorTypes(result, context, assetProvided)
    if not valid then return nil, err end
    if assetProvided and type(result.assetId) == "string" then
        result.assetId, err = NormalizeModAssetPath(result.assetId, context)
        if result.assetId == nil then return nil, err end
    end
    return result
end

local function NormalizeCardBatch(batch, context)
    if type(batch) ~= "table" or type(batch.rows) ~= "table" then
        return nil, "MOD Card 批次需要包含 rows table"
    end
    context = context or {}
    local result = {}
    for key, value in pairs(batch) do result[key] = value end
    result.rows = {}
    for rowIndex, source in ipairs(batch.rows) do
        local rowContext = {
            modId = context.modId,
            path = context.path,
            logError = context.logError,
        }
        local row, err = NormalizeCardRow(source, rowContext)
        if row == nil then return nil, string.format("第%s行: %s", rowIndex, tostring(err)) end
        result.rows[rowIndex] = row
    end
    return result, nil, CARD_SCHEMA_OVERRIDE
end

AUTHORING_ADAPTERS = {
    card_def = {
        config = {
            normalizeBatch = NormalizeCardBatch,
        },
    },
    battle_effect_def = {
        config = {
            label = "MOD Effect",
            requiredFields = { "effectId", "targetId", "event", "value" },
            defaults = EFFECT_DEFAULTS,
        },
    },
    battle_skill_def = {
        config = {
            label = "MOD Skill",
            requiredFields = { "skillId", "name", "effect", "trigger" },
            defaults = SKILL_DEFAULTS,
        },
    },
    static_skill_def = {
        config = {
            label = "MOD Static Skill",
            requiredFields = { "id", "name", "srcArea", "targetArea", "effect" },
            defaults = STATIC_SKILL_DEFAULTS,
        },
    },
    act_card_pool_def = {
        base_pool = {
            label = "MOD Card Pool",
            requiredFields = { "cardId", "baseId", "poolId" },
            batchDefaults = {
                operation = "append",
            },
            defaults = {
                minBaseLevel = 1,
                maxBaseLevel = 10,
                limitActIds = { -1 },
            },
        },
    },
    act_ep_map_def = {
        config = {
            label = "MOD EP Map",
            requiredFields = { "id", "epId", "refreshGroup", "layer" },
            defaults = {
                nextNode = {},
            },
        },
    },
    act_node_def = {
        config = {
            label = "MOD Node",
            requiredFields = { "id", "mainType", "showType", "name" },
            defaults = {
                subheading = "",
                desc = "",
                summary = "",
                replaceNode = {},
                finishReplaceNode = {},
                failReplaceNode = {},
                finish = 0,
                finishReward = { 0 },
                battleReward = {},
                winCondition = {},
                conditionRewards = {},
                robot = 0,
                robotChips = {},
                gridPoolList = { 200 },
                robotGridPoolList = {},
                robotInitGrid = {},
                playerInitGrid = {},
                battleExtend = {},
                heroList = {},
                shopId = 0,
                optionType = 1,
                optionStatic = { 0 },
                optionRandom1 = {},
                optionRandom2 = {},
                optionRandom3 = {},
                heroIds = {},
                enemyHeroIds = {},
                dialogueId = 0,
                conditionGroup = 99,
                skybox = "",
                dontShowEnemyEntrance = 0,
                useRetreat = 0,
                endTimeline = "",
                showLink = 0,
            },
        },
    },
    act_node_refresh_def = {
        config = {
            label = "MOD Node Refresh",
            requiredFields = { "groupId", "nodeId" },
            defaults = {
                weight = 1,
                limitBaseId = {},
                nodeLimit = 1,
            },
        },
    },
    act_option_def = {
        config = {
            label = "MOD Option",
            requiredFields = { "id", "title", "icon", "desc", "type" },
            defaults = {
                costList = {},
                replaceNode = {},
                rewardList = {},
                heroId = 0,
                cardId = 0,
                chipId = 0,
            },
            compatibilityDefaults = {
                conditionGroup = 0,
                conditionFailDesc = "",
                assetId = 0,
                itemId = 0,
            },
            schemaOverride = {
                cost = false,
                rewards = false,
            },
        },
    },
    robot_def = {
        config = {
            label = "MOD Robot",
            requiredFields = { "id", "name", "baseId" },
            defaults = {
                groupId = 0,
                chainId = 0,
                newCards = 0,
                noSuffle = 0,
                roundAction = -1,
                noCardCheck = 2,
                roomRobot = 0,
                robotType = 1,
            },
        },
    },
    robot_chain_def = {
        config = {
            label = "MOD Robot Chain",
            requiredFields = { "id", "poolId", "cardId", "assetId" },
            defaults = {
                type = 1,
                weight = 1,
                useConditions = {},
                extend = {},
            },
        },
        sequence = {
            label = "MOD Robot Chain Sequence",
            requiredFields = { "chainId", "round", "circle", "poolId" },
            defaults = {
                seqType = 2,
            },
        },
    },
}

local function GetAdapter(configName, sheetName)
    local configAdapters = AUTHORING_ADAPTERS[configName]
    if configAdapters == nil then return nil end
    return configAdapters[sheetName]
end

local function GetAdapterLocation(configName, sheetName, context, fieldPath)
    return string.format(
        "[modId:%s][path:%s][configName:%s][sheetName:%s][field:%s]",
        tostring(context.modId),
        tostring(context.path),
        tostring(configName),
        tostring(sheetName),
        tostring(fieldPath)
    )
end

local function IsDeclaredField(adapter, fieldName)
    if adapter.defaults[fieldName] ~= nil then return true end
    for _, requiredField in ipairs(adapter.requiredFields) do
        if requiredField == fieldName then return true end
    end
    return false
end

local function LogAdapterUnknownField(configName, sheetName, context, adapter, fieldName)
    local message = string.format(
        "%s 包含未知字段%s；字段将保留但不获得 Schema、索引或 i18n 语义",
        adapter.label,
        GetAdapterLocation(configName, sheetName, context, fieldName)
    )
    if context.logError ~= nil then
        context.logError(message)
    elseif LogError ~= nil then
        LogError(message)
    end
end

local function NormalizeDefaultBatch(configName, sheetName, batch, context, adapter)
    if type(batch) ~= "table" or type(batch.rows) ~= "table" then
        return nil, adapter.label .. " 批次需要包含 rows table"
    end
    context = context or {}
    local result = {}
    for key, value in pairs(batch) do result[key] = value end
    for fieldName, defaultValue in pairs(adapter.batchDefaults or {}) do
        if result[fieldName] == nil then result[fieldName] = CopyDefault(defaultValue) end
    end
    result.rows = {}
    for rowIndex, source in ipairs(batch.rows) do
        if type(source) ~= "table" then
            return nil, string.format("第%s行: %s row 需要 table", rowIndex, adapter.label)
        end
        for _, fieldName in ipairs(adapter.requiredFields) do
            if source[fieldName] == nil then
                return nil, string.format(
                    "第%s行: %s 缺少必填字段%s",
                    rowIndex,
                    adapter.label,
                    GetAdapterLocation(configName, sheetName, context, fieldName)
                )
            end
        end
        for fieldName, defaultValue in pairs(adapter.defaults) do
            if source[fieldName] == nil then source[fieldName] = CopyDefault(defaultValue) end
        end
        for fieldName in pairs(source) do
            if not IsDeclaredField(adapter, fieldName) then
                LogAdapterUnknownField(configName, sheetName, context, adapter, fieldName)
            end
        end
        for fieldName, defaultValue in pairs(adapter.compatibilityDefaults or {}) do
            if source[fieldName] == nil then source[fieldName] = CopyDefault(defaultValue) end
        end
        result.rows[rowIndex] = source
    end
    return result, nil, adapter.schemaOverride
end

function ModConfigAuthoring.HasAdapter(configName, sheetName)
    return GetAdapter(configName, sheetName) ~= nil
end

function ModConfigAuthoring.Normalize(configName, sheetName, batch, context)
    local adapter = GetAdapter(configName, sheetName)
    if adapter == nil then return batch end
    if adapter.normalizeBatch ~= nil then return adapter.normalizeBatch(batch, context) end
    return NormalizeDefaultBatch(configName, sheetName, batch, context, adapter)
end

return ModConfigAuthoring
