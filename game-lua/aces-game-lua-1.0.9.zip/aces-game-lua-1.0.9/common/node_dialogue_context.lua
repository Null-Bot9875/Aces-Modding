-- 编辑器由 NodeDialoguePreviewSession 加载，正式客户端由 PveRogueDialogueCtrl 集中加载。
-- 不依赖游戏启动；步骤推进与表现分发由两种 host 共用。
local Context = {}

local function ParseList(text, label)
    if type(text) == "table" then return text end
    if not text or text == "" then
        return {}
    end
    local chunk, reason = load("return {" .. text .. "}", label, "t", {})
    if not chunk then
        error(label .. ": " .. reason)
    end
    local result = chunk()
    for index, item in ipairs(result) do
        if type(item) ~= "table" then
            error(label .. " 第 " .. index .. " 项必须是结构化配置")
        end
    end
    return result
end

function Context.New(data, host)
    local self = { steps = {}, actors = {}, host = host }
    for _, row in ipairs(data.steps) do
        local original = row
        row = {}
        for key, value in pairs(original) do row[key] = value end
        if self.steps[row.id] then
            error("重复步骤编号: " .. row.id)
        end
        row.actions = ParseList(row.actions, "步骤 " .. row.id .. " actions")
        row.answers = ParseList(row.answers, "步骤 " .. row.id .. " answers")
        self.steps[row.id] = row
    end
    for _, actor in ipairs(data.actors) do
        if self.actors[actor.id] then
            error("重复人物编号: " .. actor.id)
        end
        self.actors[actor.id] = actor
        if host.DefineActor then
            host:DefineActor(actor.id, actor.image, actor.height, actor.offsetX or 0, actor.offsetY or 0)
        end
    end
    return setmetatable(self, { __index = Context })
end

-- 按配置顺序寻找可达路径。汇合前画面一致是内容前提，不提供站位路径选择。
function Context:FindPath(entryId, targetId)
    if not self.steps[entryId] or not self.steps[targetId] then
        error("入口或目标步骤不存在")
    end
    local queue, parent, visited = { entryId }, {}, { [entryId] = true }
    local index = 1
    while index <= #queue do
        local id = queue[index]
        if id == targetId then
            local result = {}
            while id do
                table.insert(result, 1, id)
                id = parent[id]
            end
            return result
        end
        local row = self.steps[id]
        local nextIds = {}
        if #row.answers > 0 then
            for _, answer in ipairs(row.answers) do
                if answer.nextId and answer.nextId ~= 0 then
                    nextIds[#nextIds + 1] = answer.nextId
                end
            end
        elseif row.nextId and row.nextId ~= 0 then
            nextIds[1] = row.nextId
        end
        for _, nextId in ipairs(nextIds) do
            if self.steps[nextId] and not visited[nextId] then
                visited[nextId] = true
                parent[nextId] = id
                queue[#queue + 1] = nextId
            end
        end
        index = index + 1
    end
    error("从入口 " .. entryId .. " 无法到达步骤 " .. targetId)
end

function Context:ApplyAction(stepId, action)
    local kind = action.type
    local id = action.speakerId or ""
    local x, y = action.offsetX or 0, action.offsetY or 0
    if kind == "show" then
        local actor = self.actors[id]
        if not actor then
            error("步骤 " .. stepId .. " 的人物不存在: " .. id)
        end
        self.host:ShowActor(stepId, id, actor.image, actor.height,
            actor.offsetX + x, actor.offsetY + y, action.position or "")
    elseif kind == "hide" then
        self.host:HideActor(stepId, id)
    elseif kind == "move" then
        local actor = self.actors[id]
        if not actor then error("人物不存在: " .. id) end
        self.host:MoveActor(stepId, id, action.position or "",
            actor.offsetX + x, actor.offsetY + y)
    elseif kind == "portrait" then
        self.host:SetPortrait(stepId, id, action.image or "")
    elseif kind == "scale" then
        self.host:ScaleActor(stepId, id, action.scale or 1)
    elseif kind == "background" then
        self.host:SetBackground(action.image or "")
    elseif kind == "bgm" or kind == "stopBgm" or kind == "sfx" or kind == "loopSfx" or kind == "stopLoopSfx" then
        -- 编辑器只重建画面；正式客户端由唯一运行 host 执行音频。
        if self.host.ApplyAudio then self.host:ApplyAudio(action) end
    else
        error("步骤 " .. stepId .. " 包含当前上下文入口尚不支持的动作: " .. tostring(kind))
    end
end

-- 只用于重建前置画面：按触发 delay 落实基础状态，再求前置 Timeline 的结束状态。
function Context:CompleteStep(stepId)
    local row = self.steps[stepId]
    if not row then error("步骤不存在: " .. stepId) end
    local actions = {}
    for index, action in ipairs(row.actions) do
        actions[#actions + 1] = { value = action, index = index }
    end
    table.sort(actions, function(a, b)
        local at, bt = a.value.delay or 0, b.value.delay or 0
        if at == bt then return a.index < b.index end
        return at < bt
    end)
    local first = 1
    while first <= #actions and (actions[first].value.delay or 0) <= 0 do
        self:ApplyAction(stepId, actions[first].value)
        first = first + 1
    end
    local duration = self.host:BeginTimeline(row.timeline or "")
    for index = first, #actions do
        local action = actions[index].value
        local time = action.delay or 0
        -- 晚于动画结束的配置变化应覆盖结束画面，而不是被末帧再次覆盖。
        if time > duration then self.host:SampleTimeline(duration) end
        self:ApplyAction(stepId, action)
        self.host:SampleTimeline(time)
    end
    self.host:FinishTimeline()
end

function Context:Prepare(entryId, targetId)
    local path = self:FindPath(entryId, targetId)
    for index = 1, #path - 1 do
        self:CompleteStep(path[index])
    end
    return table.concat(path, " → ")
end

return Context
