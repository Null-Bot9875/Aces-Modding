-- 编辑器与正式客户端共用的阅读状态机。玩法提交、历史和可用性由 host 提供。
local Player = {}

function Player.New(context, host, reading)
    return setmetatable({ context = context, host = host, finished = false,
        reading = reading, paused = {}, fast = false, pending = false }, { __index = Player })
end

function Player:SetPaused(reason, value)
    self.paused[reason] = value and true or nil
end

function Player:IsPaused()
    return next(self.paused) ~= nil or self.pending
end

function Player:RecordLine()
    if self.recorded or not self.reading or self.characterCount == 0 then return end
    self.recorded = true
    self.host:RecordHistory(self.speakerName, self.row.content or "", false)
end

function Player:Enter(stepId)
    local row = self.context.steps[stepId]
    if not row then error("预览步骤不存在: " .. tostring(stepId)) end
    self.row, self.elapsed, self.visible, self.duration = row, 0, 0, 0
    self.answersShown = false
    self.recorded, self.readTime, self.answerStates = false, 0, {}
    self.completedTextAt = nil
    self.actions, self.actionIndex, self.lastActionTime = {}, 1, 0
    for index, action in ipairs(row.actions) do
        local delay = action.delay or 0
        if type(delay) ~= "number" or delay < 0 or delay ~= delay or delay == math.huge then
            error("步骤 " .. stepId .. " 的动作 delay 必须为非负有限数值")
        end
        self.actions[#self.actions + 1] = { value = action, index = index, delay = delay }
        self.lastActionTime = math.max(self.lastActionTime, delay)
    end
    table.sort(self.actions, function(a, b)
        if a.delay == b.delay then return a.index < b.index end
        return a.delay < b.delay
    end)
    local speakerId = row.speakerId or ""
    local actor = self.context.actors[speakerId]
    local name = row.speakerNameOverride or ""
    if name == "" and actor then name = actor.name end
    if speakerId == "" then name = "" end
    self.speakerName = name
    self.host:ShowLine(stepId, speakerId, name, row.content or "")
    self.characterCount = self.host.TextCharacterCount
    self:ApplyActions(0)
    self.duration = self.host:BeginTimeline(row.timeline or "")
end

function Player:Start(entryId)
    self.finished = false
    self:Enter(entryId)
    self:Tick(0)
end

function Player:ApplyActions(time)
    while self.actionIndex <= #self.actions and self.actions[self.actionIndex].delay <= time do
        if self.actions[self.actionIndex].delay > self.duration then self.host:SampleTimeline(self.duration) end
        self.context:ApplyAction(self.row.id, self.actions[self.actionIndex].value)
        self.actionIndex = self.actionIndex + 1
    end
end

function Player:EffectsFinished()
    return self.elapsed >= math.max(self.duration, self.lastActionTime)
end

function Player:ShowAnswersIfReady()
    if self.answersShown or self.visible < self.characterCount or not self:EffectsFinished() then return end
    self.answersShown = true
    for index, answer in ipairs(self.row.answers) do
        local nextId, optionId = answer.nextId or 0, answer.optionId or 0
        if type(nextId) ~= "number" or type(optionId) ~= "number" or nextId < 0 or optionId < 0
            or nextId % 1 ~= 0 or optionId % 1 ~= 0 or (nextId > 0) == (optionId > 0) then
            error("步骤 " .. self.row.id .. " 回答 " .. index .. " 需要 nextId、optionId 二选一的正整数")
        end
        local state = self.reading and self.host:GetAnswerState(answer) or { visible = true, enabled = true }
        self.answerStates[index] = state
        if state.visible then
            if self.reading then self.host:AddRuntimeAnswer(index, answer.text or "", state)
            else self.host:AddAnswer(index, answer.text or "") end
        end
    end
end

function Player:FinishEffects()
    self:ApplyActions(math.huge)
    self.host:FinishTimeline()
    self.elapsed = math.max(self.elapsed, self.duration, self.lastActionTime)
end

function Player:Next()
    self:RecordLine()
    local nextId = self.row.nextId or 0
    if nextId == 0 then
        self.finished = true
        self.host:EndPreview(0)
    else
        self:Enter(nextId)
    end
end

function Player:Tick(delta)
    if self.finished or self:IsPaused() then return end
    delta = math.max(0, delta)
    local speed = self.fast and 8 or 1
    self.elapsed = self.elapsed + delta * speed
    -- 纯配置步骤可以连续完成，但不允许没有阅读/动画停顿的循环锁死编辑器。
    for _ = 1, 64 do
        self:ApplyActions(self.elapsed)
        self.host:SampleTimeline(self.elapsed)
        local delay = self.row.contentDelay or 0
        local textSpeed = self.reading and self.reading.textSpeed or 30
        self.visible = math.min(self.characterCount, math.max(self.visible, math.floor(math.max(0, self.elapsed - delay) * textSpeed)))
        self.host:RevealText(self.visible)
        if self.visible >= self.characterCount then
            self:RecordLine()
            self.completedTextAt = self.completedTextAt or (delay + self.characterCount / textSpeed)
            self.readTime = self.readTime + math.max(0, self.elapsed - math.max(self.elapsed - delta * speed, self.completedTextAt))
        end
        self:ShowAnswersIfReady()
        if #self.row.answers > 0 or not self:EffectsFinished() then return end
        if self.characterCount > 0 then
            if self.visible < self.characterCount then return end
            if not self.fast and (not self.reading or not self.reading.auto or self.readTime < self.reading.autoDelay) then return end
        end
        self:FinishEffects()
        self:Next()
        delta = 0
        if self.finished then return end
    end
    error("连续自动步骤超过 64，请检查纯演出步骤是否形成无等待循环")
end

function Player:Advance()
    if self.finished or self:IsPaused() then return end
    if self.visible < self.characterCount then
        self.visible = self.characterCount
        self.completedTextAt = self.elapsed
        self.host:RevealText(self.visible)
        self:RecordLine()
        self:ShowAnswersIfReady()
        return
    end
    self:FinishEffects()
    if #self.row.answers > 0 then
        self:ShowAnswersIfReady()
        return
    end
    self:Next()
    self:Tick(0)
end

function Player:Choose(index)
    if self.finished or self:IsPaused() or not self.answersShown then return end
    local answer = self.row.answers[index]
    if not answer then error("回答序号不存在: " .. tostring(index)) end
    if self.reading then
        local state = self.host:GetAnswerState(answer)
        if not state.visible or not state.enabled then return end
        self:RecordLine()
    end
    self:FinishEffects()
    if answer.optionId and answer.optionId > 0 then
        if self.reading then
            self.pending, self.pendingAnswer = true, index
            self.host:SubmitOption(answer.optionId)
        else
            self.finished = true
            self.host:EndPreview(answer.optionId)
        end
    else
        if self.reading then
            self.host:RecordHistory("", answer.text or "", true)
            self.host:MarkAnswerRead(self.row.id, index)
        end
        self:Enter(answer.nextId)
        self:Tick(0)
    end
end

function Player:SubmitFinished(success)
    if not self.pending then return end
    local answer = self.row.answers[self.pendingAnswer]
    self.pending, self.pendingAnswer = false, nil
    if success then
        self.host:RecordHistory("", answer.text or "", true)
        self.finished = true
    else
        self.answersShown = false
        self.host:ClearAnswers()
        self:ShowAnswersIfReady()
    end
end

return Player
