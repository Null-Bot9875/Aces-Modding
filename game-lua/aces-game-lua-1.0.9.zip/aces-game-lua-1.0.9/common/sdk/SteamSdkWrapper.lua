SteamSdkWrapper = BaseClass("SteamSdkWrapper",SdkWrapperBase)

local ACHIEVEMENT_RETRY_SECONDS = 30
local ACHIEVEMENT_CALLBACK_TIMEOUT = 60

function SteamSdkWrapper:__Init( )
    self.ticketCallback = self:ToFunc("OnTicketCallback")
    self.statsReadyCallback = self:ToFunc("OnStatsReadyCallback")
    self.statsStoredCallback = self:ToFunc("OnStatsStoredCallback")
    self.ticket = nil
    self.ticketBase64  = nil
    self.ticketErrorNum = 0
    self.onTicketResult = nil
    self.localRoleReady = false
    self.statsRequested = false
    self.storeRetryRequired = false
    self.localAchievements = {}
    self.achievementIds = {}
    self.lastStoreAchievements = {}
    self.storeInFlight = false
    self.achievementAccount = nil
    self.achievementRetryTimer = nil
    self.statsRequestTime = 0
    self.storeRequestTime = 0
    self.achievementDeleted = false
end

function SteamSdkWrapper:__Delete()
    self.achievementDeleted = true
    if self.achievementRetryTimer then
        TimerManager.Instance:RemoveTimer(self.achievementRetryTimer)
        self.achievementRetryTimer = nil
    end
end

function SteamSdkWrapper:OnInitSdk()
    SteamSdkProxy.InitSdk()
    SteamSdkProxy.Instance:SetTicketCallback(self,"ticketCallback")
    SteamSdkProxy.Instance:SetAchievementCallbacks(self, "statsReadyCallback", "statsStoredCallback")

    if SteamSdkProxy.Instance:IsInitialized() then
        self.ticketErrorNum = 1
        self:ResetLocalAchievements()
        self:InitDone(true,self.ticketErrorNum)
        self:EnsureStatsRequest()
        if self:IsLocalAchievementEligible() and not self.achievementRetryTimer then
            self.achievementRetryTimer = TimerManager.Instance:AddTimer(0,
                ACHIEVEMENT_RETRY_SECONDS, self:ToFunc("RetryAchievements"))
        end
    else
        self:InitDone(false,self.ticketErrorNum)
    end
end

function SteamSdkWrapper:IsLocalAchievementEligible()
    local channel = BaseSetting.channel
    local appId = SteamSdkProxy.Instance:GetAppID()
    -- 渠道和实际 Steam App 同时匹配，防止测试配置误写正式版账号状态。
    return not self.achievementDeleted and (
        (channel == LoginDefine.ChannelName.steamrelease and appId == "3127770")
        or (channel == LoginDefine.ChannelName.steam and appId == "3145470"))
end

function SteamSdkWrapper:ResetLocalAchievements()
    local account = SteamSdkProxy.Instance:IsInitialized()
        and SteamSdkProxy.Instance:GetSteamID() or nil
    local sameAccount = account ~= nil and account == self.achievementAccount
    self.localRoleReady = false
    self.localAchievements = {}
    self.achievementIds = {}
    -- 同账号重连时 Steam 缓存可能已置位但尚未持久化，必须保留待提交状态。
    if not sameAccount then
        self.lastStoreAchievements = {}
        self.storeRetryRequired = false
        self.storeInFlight = false
        self.statsRequested = false
    end
    self.achievementAccount = account
end

function SteamSdkWrapper:IsAchievementAccountCurrent()
    if not SteamSdkProxy.Instance:IsInitialized() then return false end
    if self.achievementAccount ~= SteamSdkProxy.Instance:GetSteamID() then
        -- 必须等待新角色初始化重新绑定，不能把旧角色队列提交给新 Steam 账号。
        self.localRoleReady = false
        self.localAchievements = {}
        self.achievementIds = {}
        self.lastStoreAchievements = {}
        self.storeRetryRequired = false
        self.storeInFlight = false
        return false
    end
    return true
end

function SteamSdkWrapper:RetryAchievements()
    if not self:IsLocalAchievementEligible() or not self:IsAchievementAccountCurrent() then return end
    local now = Time.realtimeSinceStartup
    if self.statsRequested and not SteamSdkProxy.Instance:IsStatsReady()
        and now - self.statsRequestTime >= ACHIEVEMENT_CALLBACK_TIMEOUT then
        self.statsRequested = false
    end
    if self.storeInFlight and now - self.storeRequestTime >= ACHIEVEMENT_CALLBACK_TIMEOUT then
        self.storeInFlight = false
        self.storeRetryRequired = true
        self:LogStoreErrors("提交回调超时")
    end
    self:EnsureStatsRequest()
    self:TrySyncLocalAchievements()
end

function SteamSdkWrapper:EnsureStatsRequest()
    if self.statsRequested or not self:IsLocalAchievementEligible()
        or not self:IsAchievementAccountCurrent() then
        return
    end

    self.statsRequested = SteamSdkProxy.Instance:RequestCurrentStats()
    self.statsRequestTime = Time.realtimeSinceStartup
    if not self.statsRequested then
        LogErrorf("Steam成就 stats 请求失败[appId:%s]", SteamSdkProxy.Instance:GetAppID())
    end
end

function SteamSdkWrapper:SyncLocalAchievements(completedIds)
    if not self:IsLocalAchievementEligible() or not self:IsAchievementAccountCurrent() then
        return
    end

    self.localRoleReady = true
    for _, achievementId in ipairs(completedIds or {}) do
        local conf = Config.Get("steam_achievements_def", "config", "id", achievementId)
        local key = conf and conf.key or ""
        if key == "" then
            LogErrorf("Steam成就 key 无效[id:%s][key:%s][appId:%s]",
                tostring(achievementId), tostring(key), SteamSdkProxy.Instance:GetAppID())
        elseif not self.achievementIds[achievementId] then
            self.achievementIds[achievementId] = true
            self.localAchievements[#self.localAchievements + 1] = {
                id = achievementId,
                key = key,
            }
        end
    end

    self:EnsureStatsRequest()
    self:TrySyncLocalAchievements()
end

function SteamSdkWrapper:OnStatsReadyCallback(success, result)
    if not self:IsLocalAchievementEligible() or not self:IsAchievementAccountCurrent() then return end
    if not success then
        self.statsRequested = false
        LogErrorf("Steam成就 stats 获取失败[result:%s][appId:%s]",
            tostring(result), SteamSdkProxy.Instance:GetAppID())
        return
    end
    self:TrySyncLocalAchievements()
end

function SteamSdkWrapper:TrySyncLocalAchievements()
    if not self:IsLocalAchievementEligible() or not self:IsAchievementAccountCurrent()
        or not self.localRoleReady or self.storeInFlight or not SteamSdkProxy.Instance:IsStatsReady() then
        return
    end

    local missingAchievements = {}
    for _, achievement in ipairs(self.localAchievements) do
        local state = SteamSdkProxy.Instance:GetAchievementState(achievement.key)
        if state < 0 then
            self:LogAchievementError("查询失败", achievement)
        elseif state == 0 then
            if SteamSdkProxy.Instance:SetAchievement(achievement.key) then
                missingAchievements[#missingAchievements + 1] = achievement
            else
                self:LogAchievementError("设置失败", achievement)
            end
        end
    end

    if #missingAchievements == 0 and not self.storeRetryRequired then
        return
    end

    self.lastStoreAchievements = #missingAchievements > 0 and missingAchievements or self.localAchievements
    self.storeInFlight = true
    self.storeRequestTime = Time.realtimeSinceStartup
    if not SteamSdkProxy.Instance:StoreStats() then
        self.storeInFlight = false
        self.storeRetryRequired = true
        self:LogStoreErrors("提交调用失败")
        self.lastStoreAchievements = {}
    end
end

function SteamSdkWrapper:OnStatsStoredCallback(success, result)
    if not self:IsLocalAchievementEligible() or not self:IsAchievementAccountCurrent()
        or not self.storeInFlight then return end
    self.storeInFlight = false
    if not success then
        self.storeRetryRequired = true
        self:LogStoreErrors("提交回调失败 result=" .. tostring(result))
        -- Steam 可能在失败后回滚缓存，下次先重新获取 stats 再补发。
        self.statsRequested = false
    else
        self.storeRetryRequired = false
    end
    self.lastStoreAchievements = {}
    if success then self:TrySyncLocalAchievements() end
end

function SteamSdkWrapper:LogAchievementError(reason, achievement)
    LogErrorf("Steam成就%s[id:%s][key:%s][appId:%s]", reason,
        tostring(achievement.id), tostring(achievement.key), SteamSdkProxy.Instance:GetAppID())
end

function SteamSdkWrapper:LogStoreErrors(reason)
    for _, achievement in ipairs(self.lastStoreAchievements) do
        self:LogAchievementError(reason, achievement)
    end
end

function SteamSdkWrapper:RequestTicket()
    assert(SteamSdkProxy.Instance:IsInitialized(), "Steam SDK 未初始化完成")
    SteamSdkProxy.Instance:GetTicket()
end

function SteamSdkWrapper:SetTicketResult(onTicketResult)
    self.onTicketResult = onTicketResult
end

function SteamSdkWrapper:TicketDone(flag,num)
    if self.onTicketResult then
        self.onTicketResult(flag,num)
    end
end

function SteamSdkWrapper:OnTicketCallback(result,ticket,ticketBase64,error)
    Log("获取Ticket信息",result,ticket,error)
    if result == 1 and error == "" then
        self.ticket = ticket
        self.ticketBase64 = ticketBase64
        self:TicketDone(true,self.ticketErrorNum)
    else
        self:TicketDone(false,self.ticketErrorNum)
        self.ticketErrorNum = self.ticketErrorNum + 1
        SteamSdkProxy.Instance:GetTicket()
        LogInfof("Steam票据获取失败[result:%s][error:%s]",result,error)
    end
end

function SteamSdkWrapper:GetToken()
    return self.ticketBase64
end

function SteamSdkWrapper:GetUid()
    return SteamSdkProxy.Instance:GetSteamID()
end
