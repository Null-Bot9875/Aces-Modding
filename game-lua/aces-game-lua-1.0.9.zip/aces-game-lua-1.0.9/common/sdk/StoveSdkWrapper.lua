StoveSdkWrapper = BaseClass("StoveSdkWrapper",SdkWrapperBase)

local ACHIEVEMENT_RETRY_SECONDS = 60
local ACHIEVEMENT_REQUEST_INTERVAL = 2
local ACHIEVEMENT_CALLBACK_TIMEOUT = 60
local ACHIEVEMENT_GAME_IDS = {
    stoverelease = "GM-2710-6948B56A_IND",
    stovedemo = "GM-2710-6948E3D3_IND",
}

function StoveSdkWrapper:__Init()
    self.ticketCallback = self:ToFunc("OnTicketCallback")
    self.initCallback = self:ToFunc("OnInitCallback")
    
    self.stoveUserId = nil
    self.sessionTicket = nil
    self.ticketErrorNum = 0
    self.achievementCallback = self:ToFunc("OnAchievementCallback")
    self.achievementDeleted = false
    self.achievementRequestId = 0
    self.achievementQueue = {}
    self.achievementKeys = {}
    self.achievementConfirmed = {}
    self.achievementLastAttempts = {}
    self.achievementNextRequestTime = 0
end

function StoveSdkWrapper:__Delete()
    self.achievementDeleted = true
    if self.achievementRetryTimer then
        TimerManager.Instance:RemoveTimer(self.achievementRetryTimer)
        self.achievementRetryTimer = nil
    end
    StoveSdkProxy.Instance:ClearAchievementCallback()
end

function StoveSdkWrapper:OnInitSdk()
    LogInfof("[StoveAchievement] stage=boot diagnostics=1 channel=%s", tostring(BaseSetting.channel))
    -- 设置回调
    StoveSdkProxy.Instance:SetInitCallback(self,"initCallback")
    StoveSdkProxy.Instance:SetTicketCallback(self,"ticketCallback")
    StoveSdkProxy.Instance:SetAchievementCallback(self,"achievementCallback")
    
    -- 启动异步初始化
    StoveSdkProxy.InitSdk()
end

function StoveSdkWrapper:OnInitCallback(success)
    Log("Stove SDK初始化回调", tostring(success))
    if success then
        self.ticketErrorNum = 1
        StoveSdkProxy.Instance:GetTicket()
    else
        self:InitDone(false, self.ticketErrorNum)
    end
end

function StoveSdkWrapper:OnTicketCallback(result, stoveUserId, sessionTicket)
    LogInfof("[StoveAchievement] stage=ticket result=%s accountPresent=%s",
        tostring(result), tostring(stoveUserId ~= nil and stoveUserId ~= ""))
    if result == 0 then
        self.stoveUserId = stoveUserId
        self.sessionTicket = sessionTicket
        self:ResetLocalAchievements()
        if self:IsAchievementEligible() and not self.achievementRetryTimer then
            self.achievementRetryTimer = TimerManager.Instance:AddTimer(0,
                ACHIEVEMENT_REQUEST_INTERVAL, self:ToFunc("RetryAchievements"))
        end
        LogInfof("[StoveAchievement] stage=timer active=%s", tostring(self.achievementRetryTimer ~= nil))
        self:InitDone(true,self.ticketErrorNum)
    else
        self:InitDone(false,self.ticketErrorNum)
        self.ticketErrorNum = self.ticketErrorNum + 1
        StoveSdkProxy.Instance:GetTicket()
        Log("Stove票据获取失败[result:%s]", result)
    end
end

function StoveSdkWrapper:IsAchievementEligible()
    local gameId = ACHIEVEMENT_GAME_IDS[BaseSetting.channel]
    if self.achievementDeleted then return false end
    if not gameId then self:TraceAchievementGate("unsupported_channel"); return false end
    if not StoveSdkProxy.Instance:IsInitialized() then self:TraceAchievementGate("sdk_not_ready"); return false end
    if StoveSdkProxy.Instance:GetGameId() ~= gameId then self:TraceAchievementGate("game_id_mismatch"); return false end
    return true
end

-- 周期检查只在阻塞原因变化时记录，避免每两秒重复刷屏。
function StoveSdkWrapper:TraceAchievementGate(reason)
    if self.achievementGateReason == reason then return end
    self.achievementGateReason = reason
    LogInfof("[StoveAchievement] stage=gate reason=%s channel=%s gameId=%s expectedGameId=%s",
        reason, tostring(BaseSetting.channel), tostring(StoveSdkProxy.Instance:GetGameId()),
        tostring(ACHIEVEMENT_GAME_IDS[BaseSetting.channel]))
end

function StoveSdkWrapper:ResetLocalAchievements()
    local account = StoveSdkProxy.Instance:IsInitialized()
        and StoveSdkProxy.Instance:GetStoveUserId() or nil
    local gameId = StoveSdkProxy.Instance:GetGameId()
    if account ~= self.achievementAccount or gameId ~= self.achievementGameId then
        self.achievementConfirmed = {}
        self.achievementLastAttempts = {}
        self.achievementNextRequestTime = 0
    end
    self.achievementAccount = account
    self.achievementGameId = gameId
    self.achievementRoleReady = false
    self.achievementQueue = {}
    self.achievementKeys = {}
    self.achievementInFlight = nil
    StoveSdkProxy.Instance:CancelAchievementRequest()
    LogInfof("[StoveAchievement] stage=role_reset accountPresent=%s gameId=%s",
        tostring(account ~= nil and account ~= ""), tostring(gameId))
end

function StoveSdkWrapper:IsAchievementAccountCurrent()
    if not StoveSdkProxy.Instance:IsInitialized() then self:TraceAchievementGate("sdk_not_ready"); return false end
    local account = StoveSdkProxy.Instance:GetStoveUserId()
    -- 暂时取不到账号时保留队列，恢复后继续；不能当成切换到另一个账号。
    if not account or account == "" then self:TraceAchievementGate("account_unavailable"); return false end
    if not self.achievementAccount or self.achievementAccount == ""
        or account ~= self.achievementAccount
        or StoveSdkProxy.Instance:GetGameId() ~= self.achievementGameId then
        -- 新账号必须等角色重新初始化绑定，不能接走上个角色的队列。
        self.achievementRoleReady = false
        self.achievementQueue = {}
        self.achievementKeys = {}
        self.achievementInFlight = nil
        StoveSdkProxy.Instance:CancelAchievementRequest()
        self:TraceAchievementGate("account_binding_mismatch")
        return false
    end
    return true
end

function StoveSdkWrapper:SyncLocalAchievements(completedIds)
    LogInfof("[StoveAchievement] stage=receive completedCount=%s", tostring(#(completedIds or {})))
    if not self:IsAchievementEligible() or not self:IsAchievementAccountCurrent() then return end
    self.achievementRoleReady = true
    for _, achievementId in ipairs(completedIds or {}) do
        -- 保留游戏内稳定 key；C# 桥接层转换为 STOVE 大写统计 ID 和带 _1 的成就 ID。
        local conf = Config.Get("steam_achievements_def", "config", "id", achievementId)
        local key = conf and conf.key or ""
        if key == "" then
            LogErrorf("STOVE成就 key 无效[id:%s]", tostring(achievementId))
        elseif not self.achievementKeys[key] and not self.achievementConfirmed[key] then
            self.achievementKeys[key] = true
            self.achievementQueue[#self.achievementQueue + 1] = {id = achievementId, key = key}
        end
    end
    self:RetryAchievements()
end

function StoveSdkWrapper:RetryAchievements()
    if not self:IsAchievementEligible() or not self:IsAchievementAccountCurrent() then return end
    if not self.achievementRoleReady then self:TraceAchievementGate("role_not_ready"); return end
    self:TraceAchievementGate(#self.achievementQueue == 0 and "empty_queue" or "ready")
    local now = Time.realtimeSinceStartup
    if self.achievementInFlight then
        if now - self.achievementInFlight.startedAt < ACHIEVEMENT_CALLBACK_TIMEOUT then return end
        self:LogAchievementError(self.achievementInFlight.achievement, "回调超时，稍后补发")
        StoveSdkProxy.Instance:CancelAchievementRequest()
        self.achievementInFlight = nil
    end
    if now < self.achievementNextRequestTime then return end
    for _, achievement in ipairs(self.achievementQueue) do
        local lastAttempt = self.achievementLastAttempts[achievement.key]
        if not self.achievementConfirmed[achievement.key]
            and (not lastAttempt or now - lastAttempt >= ACHIEVEMENT_RETRY_SECONDS) then
            self.achievementRequestId = self.achievementRequestId + 1
            self.achievementLastAttempts[achievement.key] = now
            self.achievementNextRequestTime = now + ACHIEVEMENT_REQUEST_INTERVAL
            self.achievementInFlight = {
                requestId = self.achievementRequestId,
                achievement = achievement,
                startedAt = now,
            }
            LogInfof("[StoveAchievement] stage=request request=%s key=%s queueCount=%s",
                tostring(self.achievementRequestId), achievement.key, tostring(#self.achievementQueue))
            if not StoveSdkProxy.Instance:SyncAchievement(achievement.key,
                self.achievementRequestId, self.achievementAccount) then
                self.achievementInFlight = nil
                self.achievementNextRequestTime = now + ACHIEVEMENT_RETRY_SECONDS
                self:LogAchievementError(achievement, "SDK调用失败，稍后补发")
            end
            return
        end
    end
end

function StoveSdkWrapper:OnAchievementCallback(requestId, account, key, success, errorMessage)
    if not self:IsAchievementEligible() or not self:IsAchievementAccountCurrent() then return end
    local request = self.achievementInFlight
    if not request or request.requestId ~= requestId or account ~= self.achievementAccount
        or key ~= request.achievement.key then return end
    self.achievementInFlight = nil
    if success then
        self.achievementConfirmed[key] = true
        LogInfof("[StoveAchievement] stage=confirmed request=%s key=%s", tostring(requestId), key)
    else
        self:LogAchievementError(request.achievement, tostring(errorMessage))
    end
end

function StoveSdkWrapper:LogAchievementError(achievement, reason)
    LogErrorf("STOVE成就同步失败[id:%s][key:%s][gameId:%s]: %s",
        tostring(achievement.id), achievement.key, tostring(self.achievementGameId), reason)
end

function StoveSdkWrapper:GetToken()
    return self.sessionTicket
end

function StoveSdkWrapper:GetUid()
    return self.stoveUserId
end
