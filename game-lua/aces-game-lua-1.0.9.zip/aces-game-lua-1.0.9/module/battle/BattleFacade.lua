BattleFacade = BaseClass("BattleFacade",Facade)

BattleFacade.Event = EventEnum.New(
	"EnterComplete", -- 进场完成
	"EnterAllComplete", -- 进场所有完成
	"RoundStart", -- 回合开始
	"FreeCameraEnableChanged", -- 自由镜头开关改变
	"FreeCameraFocusChanged" -- 自由镜头焦点/目标改变（如双击格子切换中心）
)

function BattleFacade:__Init()

end

function BattleFacade:__InitFacade()
    self:BindCtrl(BattleCtrl)
    self:BindCtrl(BattleTickCtrl)

    self:BindProxy(BattleProxy)
end

function BattleFacade:CanSendMsg(msgId)
    if msgId == 4004 or msgId == 4100 or msgId == 4200 or msgId == 4300 then
        return not BattleReplayInputGate.IsPlayerInputBlocked()
    end
    return true
end
