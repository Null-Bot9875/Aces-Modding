ActionBehaviorBase = BaseClass("ActionBehaviorBase",SECBBehavior)

function ActionBehaviorBase:__Init()
    self.onComplete = nil
    self.onPreComplete = nil
    self.isRunComplete = false
    self.isPreComplete = false
    self.args = nil
end

function ActionBehaviorBase:__Delete()
end

function ActionBehaviorBase:SetComplete(onComplete)
    self.onComplete = onComplete
end

function ActionBehaviorBase:SetPreComplete(onPreComplete)
    self.onPreComplete = onPreComplete
end

function ActionBehaviorBase:SetArgs(args)
    self.args = args
end

function ActionBehaviorBase:Start()
    self:OnStart()
end

function ActionBehaviorBase:ActionPreComplete()
    if self.isPreComplete or self.isRunComplete then
        return
    end

    self.isPreComplete = true
    if self.onPreComplete then
        self.onPreComplete(self)
    end
end

function ActionBehaviorBase:ActionComplete()
    if self.isRunComplete then
        return
    end

    self.isRunComplete = true
    self:OnComplete()
    if self.onComplete then
        self.onComplete(self)
    end
end

function ActionBehaviorBase:IsPreComplete()
    return self.isPreComplete
end

function ActionBehaviorBase:IsComplete()
    return self.isRunComplete
end

function ActionBehaviorBase:GetStackId()
    local args = self.args
    if args then
        if args.stackId then
            return args.stackId
        end
        if args.info and args.info.stackId then
            return args.info.stackId
        end
        if args.info and args.info.stackContext then
            return args.info.stackContext.stackId
        end
        if args.info and args.info.effectSrcType == BattleDefine.EffectSrcType.stack_effect then
            return args.info.effectSrcValue
        end
    end

    return self.stackContext and self.stackContext.stackId or nil
end

function ActionBehaviorBase:IsStackSkipRequested()
    local stackId = self:GetStackId()
    return self.world and self.world.StateSystem
        and self.world.StateSystem:IsStackSkipRequested(stackId)
        or false
end

function ActionBehaviorBase:OnStackSkipRequested(stackId)
    if stackId ~= self:GetStackId() then
        return
    end

    if self.actionTimeline then
        self.actionTimeline:NotifyStackSkip(stackId)
    end
end

--
function ActionBehaviorBase:OnStart() end
function ActionBehaviorBase:OnComplete() end
