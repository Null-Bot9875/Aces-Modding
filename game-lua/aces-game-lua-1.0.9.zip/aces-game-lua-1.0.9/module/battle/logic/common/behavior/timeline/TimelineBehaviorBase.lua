TimelineBehaviorBase = BaseClass("TimelineBehaviorBase",SECBBehavior)

local STACK_SKIP_PRESENTATION_TYPES = {
    ["HitResultTB"] = true,
    ["PlayAudioTB"] = true,
    ["PlayMechaAnimTB"] = true,
    ["PlayMechaEffectTB"] = true,
    ["PlayStretchEffectTB"] = true,
    ["PlayDisperseEffectTB"] = true,
    ["PlayHitReactionTB"] = true,
    ["ShakeScreenTB"] = true,
    [10001] = true,
    [10002] = true,
    [10003] = true,
    [10006] = true,
    [70006] = true,
    [70009] = true,
}

function TimelineBehaviorBase:__Init()
    self.conf = nil
    self.args = nil
    self.onComplete = nil
    self.executeActionTimeline = nil
    self.onHookComplete = nil
    self.isStart = false
    self.isComplete = false
    self.durationTimer = nil
end

function TimelineBehaviorBase:__Delete()
    self:RemoveDurationTimer()
    if self.actionTimeline then
        self.actionTimeline:Delete()
        self.actionTimeline = nil
    end
end

function TimelineBehaviorBase:SetExecuteActionTimeline(timeline)
    self.executeActionTimeline = timeline
end

function TimelineBehaviorBase:SetComplete(onComplete)
    self.onComplete = onComplete
end

function TimelineBehaviorBase:SetHookComplete(onComplete)
    self.onHookComplete = onComplete
end

function TimelineBehaviorBase:SetConf(conf)
    self.conf = conf
end

function TimelineBehaviorBase:SetArgs(args)
    self.args = args
end

function TimelineBehaviorBase:Start()
    if not self:CheckCondValid() then
        -- LogTable("条件不满足，行为不执行",self.args)
        self:BehaviorComplete()
        return
    end

    self.isStart = true
    self:OnStart()
    self:TryStartDurationTimer()
end

function TimelineBehaviorBase:CheckCondValid()
    if self.conf and self.conf.checkCond then
        local checkCond = self.conf.checkCond
        local checkArgs = {}
        checkArgs.args = self.args
        checkArgs.conf = self.conf
        local flag = self.world.PluginSystem.CheckTimelineCond:CheckCond(checkCond, checkArgs)
        if not flag then
            return false
        end
    end
    
    return true
end


function TimelineBehaviorBase:BehaviorComplete(...)
    if self.isComplete then
        return
    end
    self.isComplete = true
    self:RemoveDurationTimer()

    if self.onHookComplete then
        self.onHookComplete(self,...)
    end
    if self.onComplete then
        self.onComplete(self,...)
    end
end


--
function TimelineBehaviorBase:OnStart()
end

function TimelineBehaviorBase:TryStartDurationTimer()
    if self.isComplete or not self.conf then
        return
    end

    -- 显式配置 dontUseDuration 时跳过基础超时规则
    if self.conf.dontUseDuration then
        return
    end

    local duration = self.conf.duration
    if not duration or duration <= 0 then
        return
    end

    self:RemoveDurationTimer()
    self.durationTimer = self.world.TimerSystem:AddTimer(1, duration * 0.001, self:ToFunc("OnDurationTimeout"))
    self.durationTimer:SetScale(true)
end

function TimelineBehaviorBase:OnDurationTimeout()
    self.durationTimer = nil
    self:BehaviorComplete()
end

function TimelineBehaviorBase:RemoveDurationTimer()
    if self.durationTimer then
        self.world.TimerSystem:RemoveTimer(self.durationTimer)
        self.durationTimer = nil
    end
end

function TimelineBehaviorBase:GetStackId()
    local args = self.args
    if args then
        if args.stackId then
            return args.stackId
        end
        if args.info and args.info.stackId then
            return args.info.stackId
        end
        if args.info and args.info.stackContext then
            return args.info.stackContext.stackId
        end
        if args.info and args.info.effectSrcType == BattleDefine.EffectSrcType.stack_effect then
            return args.info.effectSrcValue
        end
        if args.kvData and args.kvData.stackContext then
            return args.kvData.stackContext.stackId
        end
    end

    return self.stackContext and self.stackContext.stackId or nil
end

function TimelineBehaviorBase:IsStackSkipRequested()
    local stackId = self:GetStackId()
    return self.world and self.world.StateSystem
        and self.world.StateSystem:IsStackSkipRequested(stackId)
        or false
end

function TimelineBehaviorBase:OnStackSkipRequested(stackId)
    if stackId ~= self:GetStackId() then
        return
    end

    if self.actionTimeline then
        self.actionTimeline:NotifyStackSkip(stackId)
    end
end

function TimelineBehaviorBase:CanReplaceTimelineWithHitResult(playDatas, allowMissingHitResult)
    if not playDatas then
        return false
    end

    local hitResultCount = 0
    for _, action in ipairs(playDatas) do
        if not STACK_SKIP_PRESENTATION_TYPES[action.type] then
            return false
        end
        if action.type == "HitResultTB" or action.type == 10003 then
            hitResultCount = hitResultCount + 1
            if hitResultCount > 1 then
                return false
            end
        end
    end

    return hitResultCount == 1 or (hitResultCount == 0 and allowMissingHitResult == true)
end
